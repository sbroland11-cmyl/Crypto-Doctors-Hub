# CDH Manual Payment Flow

## How it works
1. Admin opens Admin Dashboard -> Payments -> Payment Settings.
2. Admin configures the platform receiving methods: USDT TRC20, USDT BEP20, USDT ERC20 and Easypaisa, including the actual receiving details.
3. These central payment settings are stored in Firestore at `paymentSettings/config`.
4. Signed-in users read the same central configuration, so changing a wallet/account in the Admin dashboard updates the payment page for users automatically.
5. A user chooses a plan and payment method, then can click `NOTIFY ADMIN — I WANT TO PAY`. This creates a live payment alert in the Admin Dashboard showing who intends to pay, what plan they selected, the amount and payment method.
6. The user pays manually, imports a screenshot from the phone/desktop gallery, optionally enters a transaction/reference ID, and sends the proof. The same payment alert changes to a pending proof request.
7. The screenshot is uploaded to Firebase Storage under `payment_proofs/{uid}/...` and the request is stored in Firestore under `paymentRequests/{requestId}`.
8. Admin Dashboard -> Payments shows the request with username, UID, product/plan, amount, method, reference, submission time and the screenshot.
9. Admin clicks APPROVE or REJECT.
10. APPROVE automatically updates the user's entitlement in Firebase. Premium approval sets `isPremium=true`; Mentorship approval activates Student access and creates the relevant badge entitlement/Mail item. Installment Mentorship approvals advance the paid installment stage. Verified Creator approval records the verified-creator payment approval state and sends an in-app Mail notice.
11. Because the user's app reads the Firebase user state, the approved entitlement becomes available without manually editing every user's device.

## Important distinction
- Admin payment settings = where users send money to CDH.
- User Payment Details = where CDH pays earnings to a user. These remain separate.
- Users do not see other users' payment screenshots. Only the submitting user and Admin can read the payment request/proof.

## Firebase rules
Deploy both `firestore.rules` and `storage.rules` to the same Firebase project used by the Flutter app.

The Storage rule protects payment screenshots so the owner and Admin can read them, while only the owner can upload to their own proof folder.

## Admin Graduated Badge Vault

The Admin Dashboard → Admin Controls now initializes exactly 25 Firebase-backed Graduated badge slots (`graduated_01` through `graduated_25`).

Admin can:
- Select any registered non-admin user.
- Send any available Graduated badge to that user.
- The assigned badge creates a private badge entitlement and a CDH Mail notification for that user.
- The user collects the badge from Mail.
- Collection records `graduated: true`, `graduatedBadgeId`, and `graduatedAt` on that user's Firebase profile.
- The user's confirmed mentorship badge is set to `mentorship_installment_4`, which uses the existing black graduation-cap / GRADUATED profile presentation across public profile/feed surfaces.
- Each of the 25 inventory slots is assigned only once.

## Payment model

CDH is using manual payment verification. There is no automatic payment gateway/webhook flow in this project. Users notify Admin, make the payment using the Admin-configured payment details, upload the proof screenshot, and Admin manually approves or rejects the request.

The Firestore rules protect payment requests so users cannot self-approve Premium or Mentorship. Admin approval is the entitlement-changing action.


## Payment method persistence
Admin payment settings are stored as one shared `paymentSettings/config` document. Saving one method preserves the other configured methods and restores the four standard methods (Easypaisa, USDT TRC20, USDT BEP20, USDT ERC20) if they are missing. Users see all enabled methods and can select whichever is easiest for them.

## Student caps vs Graduated badge
The Mentorship installment badges are separate progress badges:
- Student 1 = first verified installment — white cap
- Student 2 = second verified installment — white cap
- Student 3 = third verified installment — white cap
- Student 4 = fourth verified installment — white cap

The **Graduated** badge is a separate Admin-awarded badge. Admin has 25 official Graduated badge slots. A user must receive and collect the Admin-awarded badge before Firebase records `graduated: true`. The Graduated badge uses the black graduation cap and remains separate from Student 4.

## Referral qualification + incentive automation

Referral attribution is captured at account creation from the user's personal referral code/link. After an Admin approves a Premium or Mentorship payment request, the Firebase Functions backend checks the referred user's `referredByUid` / `referredByCode` and validates the referrer account.

The backend then permanently records:
- `referralRelationships/{referredUid}` — who referred the user.
- `referralQualifications/{referrerUid_referredUid}` — first qualified conversion.
- `referralRewards/{rewardId}` — each approved earning, including product, plan, referred UID/name, referrer UID/name, payment amount, incentive amount and status (`earned` / `paid`).
- `referralStats/{referrerUid}` — qualified referral count and Premium/Mentorship earnings, total earned, paid and outstanding.
- `referralAdminNotifications/{rewardId}` — Admin dashboard notification for each qualified Premium/Mentorship purchase.

Default product incentives implemented in the backend:
- Premium Monthly: $4 per confirmed monthly Premium purchase.
- Premium Lifetime: $12 one-time.
- Mentorship One-Time: $20 one-time.
- Mentorship Installment: $5 per confirmed installment.

The Admin Dashboard → Payments now includes a Referral Incentive section showing the referred user, referrer, both UIDs, product/plan, incentive amount, total earned/paid/outstanding and a `MARK PAID` action. The Admin notification can also be marked read.

### Deploy the referral backend

From the Firebase project root, deploy the Functions after installing the existing `functions/package.json` dependencies:

`cd functions`

`npm install`

`cd ..`

`firebase deploy --only functions`

The referral automation depends on the Functions deployment. The Flutter client alone must not be treated as the authority for referral earnings.

### What the user should share

The user's Profile → Referral page now labels the code as **YOUR PERSONAL REFERRAL CODE** and explains that the **PERSONAL REFERRAL LINK** is what they should send to a new user before that user creates their CDH account. The link carries `?ref=USERCODE` automatically. A user does not need to create a new referral code for every person.
