import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ReferralService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  static DocumentReference<Map<String, dynamic>> get _settings =>
      _db.collection('referralSettings').doc('config');

  static Stream<Map<String, dynamic>> watchSettings() =>
      _settings.snapshots().map((snap) => snap.data() ?? <String, dynamic>{});

  static Future<Map<String, dynamic>> loadSettings() async {
    final snap = await _settings.get();
    return snap.data() ?? <String, dynamic>{};
  }

  static Future<String> buildReferralLink(String code) async {
    final clean = code.trim().toUpperCase();
    final settings = await loadSettings();
    var base = (settings['publicReferralUrl'] ?? '').toString().trim();
    if (base.isEmpty) base = 'https://crypto-doctors-hub.web.app/';
    final uri = Uri.tryParse(base);
    if (uri == null || !uri.hasScheme || uri.host.isEmpty) {
      throw StateError('The referral link URL is not configured correctly.');
    }
    final query = Map<String, String>.from(uri.queryParameters);
    query['ref'] = clean;
    return uri.replace(queryParameters: query).toString();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> watchMyRewards(String uid) =>
      _db.collection('referralRewards')
          .where('referrerUid', isEqualTo: uid)
          .orderBy('createdAt', descending: true)
          .limit(100)
          .snapshots();

  static Stream<QuerySnapshot<Map<String, dynamic>>> watchAdminRewards() =>
      _db.collection('referralRewards')
          .orderBy('createdAt', descending: true)
          .limit(250)
          .snapshots();

  static Stream<QuerySnapshot<Map<String, dynamic>>> watchAdminNotifications() =>
      _db.collection('referralAdminNotifications')
          .orderBy('createdAt', descending: true)
          .limit(100)
          .snapshots();

  static Stream<QuerySnapshot<Map<String, dynamic>>> watchAdminStats() =>
      _db.collection('referralStats')
          .orderBy('totalEarnedUsd', descending: true)
          .limit(100)
          .snapshots();

  static Future<void> adminMarkRewardPaid(String rewardId) async {
    final admin = FirebaseAuth.instance.currentUser;
    if (admin == null) throw StateError('Admin session required.');
    final token = await admin.getIdTokenResult(true);
    if (token.claims?['admin'] != true) throw StateError('Admin access required.');
    await _db.collection('referralRewards').doc(rewardId).update({
      'status': 'paid',
      'paidAt': FieldValue.serverTimestamp(),
      'paidByUid': admin.uid,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> savePendingReferralForSignedInUser({
    required String uid,
    required String referralCode,
    required String referrerUid,
  }) async {
    if (uid == referrerUid) throw StateError('Self-referrals are not allowed.');
    await _db.collection('referralRelationships').doc(uid).set({
      'referredUid': uid,
      'referrerUid': referrerUid,
      'referralCode': referralCode.trim().toUpperCase(),
      'status': 'pending_qualification',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }
}
