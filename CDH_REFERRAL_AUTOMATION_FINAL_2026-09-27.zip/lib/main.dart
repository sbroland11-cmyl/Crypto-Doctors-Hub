import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:universal_html/html.dart' as html;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';
import 'services/profile_service.dart';
import 'services/auth_service.dart';
import 'services/notification_service.dart';
import 'models/feed_post_model.dart';
import 'services/feed_service.dart';
import 'services/alpha_den_service.dart';
import 'services/trading_journal_service.dart';
import 'services/mentorship_service.dart';
import 'services/payment_service.dart';
import 'services/referral_service.dart';
import 'services/badge_service.dart';
import 'services/payout_service.dart';
import 'services/customer_support_service.dart';

String _supportTicketFormatAdminDateTime(DateTime value) {
  final hh = value.hour.toString().padLeft(2, '0');
  final mm = value.minute.toString().padLeft(2, '0');
  final dd = value.day.toString().padLeft(2, '0');
  final mo = value.month.toString().padLeft(2, '0');
  return '${value.year}-$mo-$dd $hh:$mm';
}

String? _pendingReferralCode;

void _captureIncomingReferralCode() {
  try {
    final candidates = <String>[
      Uri.base.toString(),
      WidgetsBinding.instance.platformDispatcher.defaultRouteName,
    ];
    for (final raw in candidates) {
      final value = raw.trim();
      if (value.isEmpty || value == '/') continue;
      final uri = Uri.tryParse(value);
      final code = (uri?.queryParameters['ref'] ?? uri?.queryParameters['referral'] ?? '').trim();
      if (code.isNotEmpty) {
        _pendingReferralCode = code.toUpperCase();
        return;
      }
      final match = RegExp(r'(?:^|[/#?&])ref(?:erral)?[=/]([A-Za-z0-9_-]{4,64})', caseSensitive: false).firstMatch(value);
      if (match != null) {
        _pendingReferralCode = match.group(1)?.toUpperCase();
        return;
      }
    }
  } catch (_) {}
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  _captureIncomingReferralCode();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const CryptoDoctorsHub());
}

final ValueNotifier<String> appThemePreference = ValueNotifier<String>('current');


Future<bool> _hasFirebaseAdminClaim(User user) async {
  try {
    final token = await user.getIdTokenResult(true);
    return token.claims?['admin'] == true;
  } catch (_) {
    return false;
  }
}


class CryptoDoctorsHub extends StatefulWidget {
  const CryptoDoctorsHub({super.key});

  @override
  State<CryptoDoctorsHub> createState() => _CryptoDoctorsHubState();
}

class _CryptoDoctorsHubState extends State<CryptoDoctorsHub> {
  @override
  void initState() {
    super.initState();
    _loadSavedTheme();
  }

  Future<void> _loadSavedTheme() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final data = await ProfileService.loadUserProfile(user.uid);
      final saved = (data?['themePreference'] ?? 'current').toString();
      if (saved == 'light' || saved == 'dark' || saved == 'current') {
        appThemePreference.value = saved;
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: appThemePreference,
      builder: (context, choice, _) {
        final selectedTheme = switch (choice) {
          'light' => AppTheme.light(),
          'dark' => AppTheme.matteBlack(),
          _ => AppTheme.dark(),
        };
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'CRYPTO-DOCTORS-HUB',
          theme: selectedTheme,
          builder: (context, child) {
            final light = choice == 'light';
            return DefaultTextStyle.merge(
              style: TextStyle(color: light ? const Color(0xFF1A1A18) : Colors.white),
              child: IconTheme.merge(
                data: IconThemeData(color: light ? const Color(0xFF4A463E) : Colors.white70),
                child: child ?? const SizedBox.shrink(),
              ),
            );
          },
          home: const SplashScreen(),
        );
      },
    );
  }
}

// ============================================================
// APP THEME
// ============================================================

class AppTheme {
  static const Color neonGreen = Color(0xFF59D7FF);
  static const Color luxuryGold = Color(0xFFFFD54A);
  static const Color deepBlack = Color(0xFF030405);
  static const Color panelBlack = Color(0xFF0B0F11);

  // Shared adaptive palette for bespoke widgets. Current and Dark retain the
  // exact existing colors; Light switches to the cream/ink palette.
  static bool get isLight => appThemePreference.value == 'light';
  static Color get textPrimary => isLight ? const Color(0xFF1A1A18) : Colors.white;
  static Color get textSecondary => isLight ? const Color(0xFF5D5A52) : Colors.white70;
  static Color get textSoft => isLight ? const Color(0xFF6B675F) : Colors.white60;
  static Color get textMuted => isLight ? const Color(0xFF6B675F) : Colors.white54;
  static Color get textFaint => isLight ? const Color(0xFF8A857B) : Colors.white38;
  static Color get textVeryFaint => isLight ? const Color(0xFF9A9489) : Colors.white30;
  static Color get borderSoft => isLight ? const Color(0x558A6A18) : Colors.white24;
  static Color get borderFaint => isLight ? const Color(0x448A6A18) : Colors.white12;
  static Color get fillFaint => isLight ? const Color(0x1A8A6A18) : Colors.white10;
  static Color adaptiveWhite({double alpha = 1.0}) => (isLight ? const Color(0xFF1A1A18) : Colors.white).withValues(alpha: alpha);
  static Color adaptiveSurface(Color darkColor) => isLight ? const Color(0xFFFFFCF6) : darkColor;

  static ThemeData light() {
    const cream = Color(0xFFF4F0E8);
    const creamPanel = Color(0xFFFFFCF6);
    const ink = Color(0xFF1A1A18);
    return ThemeData(
      brightness: Brightness.light,
      useMaterial3: true,
      primaryColor: const Color(0xFF8A6A18),
      canvasColor: cream,
      scaffoldBackgroundColor: cream,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF8A6A18),
        brightness: Brightness.light,
        surface: creamPanel,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFFF4F0E8),
        elevation: 0,
        titleTextStyle: TextStyle(color: ink, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 1.5),
        iconTheme: IconThemeData(color: ink),
      ),
      navigationBarTheme: const NavigationBarThemeData(
        backgroundColor: creamPanel,
        indicatorColor: Color(0x228A6A18),
        height: 72,
        labelTextStyle: WidgetStatePropertyAll(TextStyle(color: ink, fontSize: 10, fontWeight: FontWeight.w700)),
        iconTheme: WidgetStatePropertyAll(IconThemeData(color: Color(0xFF5D5A52), size: 23)),
      ),
      iconTheme: const IconThemeData(color: Color(0xFF4A463E)),
      listTileTheme: const ListTileThemeData(
        iconColor: Color(0xFF5D5A52),
        textColor: ink,
        subtitleTextStyle: TextStyle(color: Color(0xFF625E55)),
      ),
      popupMenuTheme: const PopupMenuThemeData(
        color: creamPanel,
        textStyle: TextStyle(color: ink, fontWeight: FontWeight.w700),
      ),
      menuTheme: const MenuThemeData(
        style: MenuStyle(
          backgroundColor: WidgetStatePropertyAll(creamPanel),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: creamPanel,
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 17),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0x338A6A18))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0x338A6A18))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFF8A6A18), width: 1.5)),
        labelStyle: const TextStyle(color: Color(0xFF5D5A52)),
      ),
      cardTheme: CardThemeData(
        color: creamPanel,
        elevation: 5,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0x338A6A18))),
      ),
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: ink),
        bodyMedium: TextStyle(color: Color(0xFF44413A)),
        bodySmall: TextStyle(color: Color(0xFF625E55)),
        titleLarge: TextStyle(color: ink, fontWeight: FontWeight.w900),
        titleMedium: TextStyle(color: ink, fontWeight: FontWeight.w800),
        titleSmall: TextStyle(color: Color(0xFF44413A), fontWeight: FontWeight.w700),
        labelLarge: TextStyle(color: ink, fontWeight: FontWeight.w800),
      ),
      dividerTheme: const DividerThemeData(color: Color(0x338A6A18), thickness: 1),
      dialogTheme: const DialogThemeData(
        backgroundColor: creamPanel,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: TextStyle(color: ink, fontSize: 16, fontWeight: FontWeight.w900),
        contentTextStyle: TextStyle(color: Color(0xFF44413A)),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: creamPanel,
        surfaceTintColor: Colors.transparent,
        modalBackgroundColor: creamPanel,
      ),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: Color(0xFF3A3429),
        contentTextStyle: TextStyle(color: Colors.white),
        behavior: SnackBarBehavior.floating,
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: Color(0xFF8A6A18),
        linearTrackColor: Color(0x228A6A18),
      ),
      sliderTheme: const SliderThemeData(
        activeTrackColor: Color(0xFF8A6A18),
        inactiveTrackColor: Color(0x338A6A18),
        thumbColor: Color(0xFF8A6A18),
        overlayColor: Color(0x228A6A18),
      ),
      tabBarTheme: const TabBarThemeData(
        labelColor: Color(0xFF6F5414),
        unselectedLabelColor: Color(0xFF625E55),
        indicatorColor: Color(0xFF8A6A18),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF8A6A18),
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 50),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFF6F5414),
          side: const BorderSide(color: Color(0x668A6A18)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      checkboxTheme: CheckboxThemeData(fillColor: WidgetStatePropertyAll(const Color(0xFF8A6A18))),
      radioTheme: RadioThemeData(fillColor: WidgetStatePropertyAll(const Color(0xFF8A6A18))),
      switchTheme: SwitchThemeData(thumbColor: const WidgetStatePropertyAll(Color(0xFF8A6A18)), trackColor: const WidgetStatePropertyAll(Color(0x338A6A18))),
      chipTheme: ChipThemeData(
        backgroundColor: creamPanel,
        selectedColor: const Color(0x228A6A18),
        side: const BorderSide(color: Color(0x338A6A18)),
        labelStyle: const TextStyle(color: ink, fontWeight: FontWeight.w700),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: Color(0xFF8A6A18),
        foregroundColor: Colors.white,
      ),
      iconButtonTheme: const IconButtonThemeData(
        style: ButtonStyle(foregroundColor: WidgetStatePropertyAll(ink)),
      ),
    );
  }

  static ThemeData matteBlack() {
    return dark().copyWith(
      scaffoldBackgroundColor: Colors.black,
    );
  }

  static ThemeData dark() {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: deepBlack,
      useMaterial3: true,

      colorScheme: ColorScheme.fromSeed(
        seedColor: neonGreen,
        brightness: Brightness.dark,
      ),

      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        titleTextStyle: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.5,
        ),
      ),

      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: Color(0xF0090C0E),
        indicatorColor: Color(0x3359D7FF),
        height: 72,
        labelTextStyle: WidgetStatePropertyAll(
          TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
        iconTheme: WidgetStateProperty.resolveWith(
          (states) {
            if (states.contains(WidgetState.selected)) {
              return const IconThemeData(
                color: neonGreen,
                size: 25,
              );
            }

            return const IconThemeData(
              color: Colors.white54,
              size: 22,
            );
          },
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: panelBlack,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 17,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: Color(0x2259D7FF),
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: Color(0x2259D7FF),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(
            color: neonGreen,
            width: 1.5,
          ),
        ),
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: neonGreen,
          foregroundColor: Colors.black,
          minimumSize: const Size(double.infinity, 52),
          elevation: 10,
          shadowColor: neonGreen,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          textStyle: const TextStyle(
            fontWeight: FontWeight.w900,
          ),
        ),
      ),

      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: neonGreen,
          minimumSize: const Size(double.infinity, 52),
          side: const BorderSide(
            color: Color(0xAA59D7FF),
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
      ),

      cardTheme: CardThemeData(
        color: const Color(0xE6090C0E),
        elevation: 12,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(
            color: Color(0x2259D7FF),
          ),
        ),
      ),
      dialogTheme: const DialogThemeData(
        backgroundColor: Color(0xFF0B0F11),
        surfaceTintColor: Colors.transparent,
        titleTextStyle: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
        contentTextStyle: TextStyle(color: Colors.white70),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Color(0xFF0B0F11),
        surfaceTintColor: Colors.transparent,
        modalBackgroundColor: Color(0xFF0B0F11),
      ),
      chipTheme: const ChipThemeData(
        backgroundColor: Color(0xFF11161A),
        selectedColor: Color(0x3359D7FF),
        side: BorderSide(color: Color(0x2259D7FF)),
        labelStyle: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
      ),
    );
  }
}

// ============================================================
// SPLASH SCREEN
// ============================================================

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;

  @override
  void initState() {
    super.initState();

    // One cinematic build pass: the mark assembles first, then settles into a
    // slow orbital motion while the seven-second splash remains on screen.
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 7),
    )..forward();

    Timer(const Duration(seconds: 7), () {
      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => const AuthGate(),
        ),
      );
    });
  }


  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const GalaxyBackground(
            animatePlanets: false,
            animateCryptoCoins: false,
            cinematicEntrance: true,
            animationDuration: Duration(seconds: 72),
          ),

          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _CryptoDoctorsSplashLogo(animation: controller),

                const SizedBox(height: 30),

                const Text(
                  'CRYPTO DOCTORS HUB',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFB9C3CF),
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2.6,
                  ),
                ),

                const SizedBox(height: 24),

                SizedBox(
                  width: 180,
                  child: LinearProgressIndicator(
                    minHeight: 3,
                    backgroundColor: Color(0x3359D7FF),
                    valueColor: AlwaysStoppedAnimation(
                      AppTheme.neonGreen,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// AUTH SESSION GATE
// ============================================================

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  @override
  void initState() {
    super.initState();
    _continueFromSession();
  }

  Future<void> _continueFromSession() async {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;

      final user = AuthService.currentUser;
      if (user == null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
        );
        return;
      }

      final email = user.email ?? '';
      final isAdmin = await _hasFirebaseAdminClaim(user);
      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => HubHome(
            accountEmail: email,
            isAdmin: isAdmin,
          ),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}

class _CryptoDoctorsSplashLogo extends StatelessWidget {
  final Animation<double> animation;

  const _CryptoDoctorsSplashLogo({required this.animation});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, _) {
        final p = animation.value;
        // Cinematic sequence:
        // 0.00-0.46: fragments fly in from outside the screen.
        // 0.38-0.64: the mark forms/evolves in the centre.
        // 0.62-1.00: the completed atom begins its slow orbital life.
        final assembly = Curves.easeOutCubic.transform(
          (p / 0.46).clamp(0.0, 1.0).toDouble(),
        );
        final formation = Curves.easeInOutCubic.transform(
          ((p - 0.30) / 0.34).clamp(0.0, 1.0).toDouble(),
        );
        final orbitProgress = Curves.easeInOut.transform(
          ((p - 0.62) / 0.38).clamp(0.0, 1.0).toDouble(),
        );
        final logoOpacity = Curves.easeOut.transform(
          ((p - 0.30) / 0.34).clamp(0.0, 1.0).toDouble(),
        );
        final logoScale = 0.42 + 0.46 * formation;
        final orbitScale = 0.985 + 0.015 * math.sin(orbitProgress * math.pi * 2);

        return SizedBox(
          width: 380,
          height: 250,
          child: Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _SplashAssemblyPainter(
                      progress: p,
                      assembly: assembly,
                      formation: formation,
                    ),
                  ),
                ),
              ),

              // Back orbital layer starts faintly during formation and becomes
              // fully alive only after the logo has assembled.
              Positioned.fill(
                child: CustomPaint(
                  painter: _SplashAtomOrbitPainter(
                    progress: orbitProgress,
                    front: false,
                    reveal: Curves.easeOut.transform(formation),
                  ),
                ),
              ),

              IgnorePointer(
                child: Opacity(
                  opacity: logoOpacity,
                  child: Transform.scale(
                    scale: logoScale * orbitScale,
                    child: Container(
                      width: 92,
                      height: 92,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const RadialGradient(
                          colors: [
                            Color(0xDFFFFFFF),
                            Color(0x7759D7FF),
                            Color(0x00131C32),
                          ],
                          stops: [0.0, 0.25, 1.0],
                        ),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x7759D7FF),
                            blurRadius: 28,
                            spreadRadius: 4,
                          ),
                          BoxShadow(
                            color: Color(0x55FFD54A),
                            blurRadius: 34,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              Opacity(
                opacity: logoOpacity,
                child: Transform.scale(
                  scale: logoScale * orbitScale,
                  child: _SplashTypewriterTitle(progress: formation),
                ),
              ),

              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _SplashAtomOrbitPainter(
                      progress: orbitProgress,
                      front: true,
                      reveal: Curves.easeOut.transform(formation),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SplashTypewriterTitle extends StatelessWidget {
  final double progress;

  const _SplashTypewriterTitle({required this.progress});

  @override
  Widget build(BuildContext context) {
    // Medium-fast typewriter reveal: the lettering appears character by
    // character while the cinematic mark is forming, then holds cleanly.
    final typed = Curves.easeOut.transform(
      ((progress - 0.08) / 0.92).clamp(0.0, 1.0).toDouble(),
    );
    final showCursor = typed < 0.995;

    return SizedBox(
      width: 270,
      height: 48,
      child: Stack(
        alignment: Alignment.center,
        children: [
          ClipRect(
            child: Align(
              alignment: Alignment.centerLeft,
              widthFactor: typed.clamp(0.0, 1.0),
              child: ShaderMask(
                blendMode: BlendMode.srcIn,
                shaderCallback: (bounds) => const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFFFFFFFF),
                    Color(0xFFE7EBF0),
                    Color(0xFF9EA7B2),
                    Color(0xFFF8FAFC),
                  ],
                  stops: [0.0, 0.34, 0.68, 1.0],
                ).createShader(bounds),
                child: Text(
                  'CRYPTO DOCTORS',
                  maxLines: 1,
                  softWrap: false,
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.8,
                    height: 1.0,
                    shadows: [
                      Shadow(
                        color: Color(0x88FFFFFF),
                        blurRadius: 10,
                      ),
                      Shadow(
                        color: Color(0x665D6875),
                        blurRadius: 18,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          if (showCursor)
            Positioned(
              left: 135 * typed,
              child: Container(
                width: 2,
                height: 27,
                decoration: const BoxDecoration(
                  color: Color(0xFFF5F7FA),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x99FFFFFF),
                      blurRadius: 8,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _SplashAssemblyPainter extends CustomPainter {
  final double progress;
  final double assembly;
  final double formation;

  const _SplashAssemblyPainter({
    required this.progress,
    required this.assembly,
    required this.formation,
  });

  static const List<Offset> _targets = [
    Offset(-150, -72), Offset(-132, -38), Offset(-112, -12), Offset(-92, 18),
    Offset(-72, 48), Offset(-48, -54), Offset(-26, -28), Offset(-8, 54),
    Offset(16, -58), Offset(38, 28), Offset(62, -46), Offset(84, 12),
    Offset(108, 42), Offset(132, -18), Offset(150, 64), Offset(-146, 56),
    Offset(-120, 2), Offset(-88, -62), Offset(-56, 70), Offset(-18, 4),
    Offset(20, 6), Offset(58, 62), Offset(92, -68), Offset(126, -4),
    Offset(-174, 30), Offset(174, -36), Offset(-30, 88), Offset(44, -86),
    Offset(-188, -78), Offset(188, 76), Offset(12, 92), Offset(-8, -92),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final easedAssembly = Curves.easeOutBack.transform(assembly.clamp(0.0, 1.0));

    // The pieces start beyond the visible logo area on multiple axes, then
    // converge into the centre as if the mark is being constructed in space.
    for (int i = 0; i < _targets.length; i++) {
      final target = center + _targets[i];
      final side = i % 4;
      final outside = switch (side) {
        0 => Offset(-size.width * 0.72 - i * 4.0, -70 + i * 9.0),
        1 => Offset(size.width * 0.72 + i * 3.5, 55 - i * 7.0),
        2 => Offset(35 + i * 8.0, -size.height * 0.78 - i * 4.0),
        _ => Offset(-45 - i * 7.0, size.height * 0.78 + i * 5.0),
      };

      final stagger = (i % 5) * 0.035;
      final local = ((easedAssembly - stagger) / (1.0 - stagger))
          .clamp(0.0, 1.0)
          .toDouble();
      final localEase = Curves.easeOutCubic.transform(local);
      final wobble = Offset(
        math.sin(progress * math.pi * 7 + i * 1.7) * (1.0 - localEase) * 12,
        math.cos(progress * math.pi * 6 + i * 1.3) * (1.0 - localEase) * 9,
      );
      final point = Offset.lerp(outside, target, localEase)! + wobble;

      final alpha = (0.12 + 0.88 * localEase) * (1.0 - formation * 0.72);
      final color = i.isEven ? const Color(0xFF8FE8FF) : const Color(0xFFFFD86A);

      final glow = Paint()
        ..color = color.withValues(alpha: alpha * 0.24)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
      canvas.drawCircle(point, 5.0 - 1.7 * localEase, glow);

      final core = Paint()..color = color.withValues(alpha: alpha);
      canvas.drawCircle(point, 1.15 + 1.0 * localEase, core);
    }

    // A compact burst of construction energy appears immediately before the
    // completed logo settles into its orbital motion.
    final burst = Curves.easeOut.transform(
      ((formation - 0.55) / 0.45).clamp(0.0, 1.0).toDouble(),
    );
    if (burst > 0) {
      final burstPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.9
        ..color = const Color(0xFFBFEFFF).withValues(alpha: 0.45 * (1 - burst));
      canvas.drawCircle(center, 30 + burst * 54, burstPaint);
      canvas.drawCircle(center, 18 + burst * 30, burstPaint..color = const Color(0xFFFFD86A).withValues(alpha: 0.20 * (1 - burst)));
    }
  }

  @override
  bool shouldRepaint(covariant _SplashAssemblyPainter oldDelegate) =>
      oldDelegate.progress != progress ||
      oldDelegate.assembly != assembly ||
      oldDelegate.formation != formation;
}


class _TopCryptoDoctorsAtom extends StatefulWidget {
  const _TopCryptoDoctorsAtom();

  @override
  State<_TopCryptoDoctorsAtom> createState() => _TopCryptoDoctorsAtomState();
}

class _TopCryptoDoctorsAtomState extends State<_TopCryptoDoctorsAtom>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 8),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 112,
      height: 56,
      child: Transform.scale(
        scale: 0.30,
        child: _CryptoDoctorsSplashLogo(animation: _controller),
      ),
    );
  }
}

class _SplashAtomOrbitPainter extends CustomPainter {
  final double progress;
  final bool front;
  final double reveal;

  const _SplashAtomOrbitPainter({
    required this.progress,
    required this.front,
    this.reveal = 1.0,
  });

  static List<_SplashOrbit> _orbits = [
    _SplashOrbit(224, 39, -0.12, 0.00, 0.14, AppTheme.neonGreen),
    _SplashOrbit(212, 52,  0.30, 0.31, 0.12, AppTheme.luxuryGold),
    _SplashOrbit(200, 66, -0.52, 0.61, 0.13, Color(0xFF6D78FF)),
    _SplashOrbit(188, 79,  0.82, 0.18, 0.11, AppTheme.neonGreen),
    _SplashOrbit(180, 94, -0.96, 0.49, 0.12, AppTheme.luxuryGold),
    _SplashOrbit(170, 106,  0.15, 0.79, 0.13, Color(0xFF7F91FF)),
    _SplashOrbit(160, 61, -1.18, 0.37, 0.11, AppTheme.neonGreen),
    _SplashOrbit(150, 87,  0.56, 0.67, 0.12, AppTheme.luxuryGold),
    _SplashOrbit(140, 112, -0.35, 0.08, 0.13, Color(0xFF65B8FF)),
    _SplashOrbit(128, 73,  1.05, 0.55, 0.11, AppTheme.luxuryGold),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);

    canvas.save();
    canvas.translate(center.dx, center.dy);

    // The same smooth orbital language as the Alpha Den portal:
    // continuous elliptical motion with no abrupt direction changes.
    for (int i = 0; i < _orbits.length; i++) {
      final orbit = _orbits[i];

      // Five paths sit behind the logo and five cross the foreground.
      final isFront = i >= 5;
      if (isFront != front) continue;

      // All orbital paths now travel clockwise (rightward on screen),
      // with a deliberately slow cinematic pace.
      const direction = 1.0;
      final rotation =
          orbit.baseRotation +
          direction * progress * math.pi * 2 * orbit.speed;

      canvas.save();
      canvas.rotate(rotation);

      final rect = Rect.fromCenter(
        center: Offset.zero,
        width: orbit.width,
        height: orbit.height,
      );

      final opacity = front ? 0.58 : 0.25;

      final ringPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.72
        ..isAntiAlias = true
        ..color = orbit.color.withValues(alpha: opacity);

      canvas.drawArc(rect, -math.pi / 2, math.pi * 2 * reveal, false, ringPaint);

      // A small atmospheric glow follows each thin orbital path.
      final glowPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.8
        ..isAntiAlias = true
        ..color = orbit.color.withValues(
          alpha: front ? 0.055 : 0.025,
        );

      canvas.drawArc(rect, -math.pi / 2, math.pi * 2 * reveal, false, glowPaint);

      // Orbiting particle / electron.
      final theta =
          orbit.phase * math.pi * 2 +
          direction * progress * math.pi * 2 * orbit.speed;

      final electron = Offset(
        math.cos(theta) * orbit.width / 2,
        math.sin(theta) * orbit.height / 2,
      );

      final glow = Paint()
        ..color = orbit.color.withValues(
          alpha: (front ? 0.22 : 0.10) * reveal,
        )
        ..maskFilter = const MaskFilter.blur(
          BlurStyle.normal,
          5,
        );

      canvas.drawCircle(electron, front ? 5.0 : 4.0, glow);

      final core = Paint()
        ..color = orbit.color.withValues(
          alpha: (front ? 0.95 : 0.62) * reveal,
        );

      canvas.drawCircle(
        electron,
        front ? 1.9 : 1.45,
        core,
      );

      canvas.restore();
    }

    // Tiny central particles give the logo the same living,
    // atomic energy as the reference image without overpowering the text.
    for (int i = 0; i < 8; i++) {
      final angle =
          progress * math.pi * 2 * 0.20 +
          i * math.pi / 4;
      final radius = 31.0 + (i % 3) * 4.0;

      final p = Offset(
        math.cos(angle) * radius,
        math.sin(angle) * radius * 0.54,
      );

      final color =
          i.isEven ? AppTheme.neonGreen : AppTheme.luxuryGold;

      final particleGlow = Paint()
        ..color = color.withValues(
          alpha: (front ? 0.18 : 0.08) * reveal,
        )
        ..maskFilter = const MaskFilter.blur(
          BlurStyle.normal,
          4,
        );

      canvas.drawCircle(p, 3.5, particleGlow);

      final particle = Paint()
        ..color = color.withValues(
          alpha: (front ? 0.82 : 0.38) * reveal,
        );

      canvas.drawCircle(p, 1.15, particle);
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _SplashAtomOrbitPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.front != front ||
        oldDelegate.reveal != reveal;
  }
}

class _SplashOrbit {
  final double width;
  final double height;
  final double baseRotation;
  final double phase;
  final double speed;
  final Color color;

  const _SplashOrbit(
    this.width,
    this.height,
    this.baseRotation,
    this.phase,
    this.speed,
    this.color,
  );
}

// ============================================================
// LOGIN
// ============================================================

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  bool _isSigningIn = false;

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> enterApp() async {
    if (_isSigningIn) return;

    final email = emailController.text.trim();
    final password = passwordController.text;

    if (email.isEmpty || password.isEmpty) {
      _showAuthMessage(
        'Sign-in required',
        'Please enter your email and password to continue.',
      );
      return;
    }

    setState(() => _isSigningIn = true);

    try {
      final credential =
          await AuthService.signIn(
        email: email,
        password: password,
      );

      final user = credential.user;
      if (user == null) {
        throw FirebaseAuthException(
          code: 'user-null',
          message: 'Authentication could not be completed.',
        );
      }

      final authenticatedEmail = user.email ?? email;
      final isAdmin = await _hasFirebaseAdminClaim(user);

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => HubHome(
            accountEmail: authenticatedEmail,
            isAdmin: isAdmin,
          ),
        ),
      );
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;

      String title;
      String message;
      switch (e.code) {
        case 'invalid-credential':
        case 'wrong-password':
        case 'user-not-found':
          title = 'Sign-in failed';
          message =
              'We couldn’t verify those credentials. Check your email and password, then try again.';
          break;
        case 'invalid-email':
          title = 'Invalid email address';
          message = 'Please check your email address and try again.';
          break;
        case 'user-disabled':
          title = 'Account unavailable';
          message =
              'This account is currently unavailable. Please contact support if you need assistance.';
          break;
        case 'invalid-referral':
          title = 'Referral code not found';
          message = 'Please check the referral code and try again, or leave it blank.';
          break;
        case 'too-many-requests':
          title = 'Please try again later';
          message =
              'Too many sign-in attempts were made. Please wait a moment and try again.';
          break;
        case 'network-request-failed':
          title = 'Connection problem';
          message =
              'We couldn’t reach the secure sign-in service. Check your connection and try again.';
          break;
        default:
          title = 'Sign-in unavailable';
          message =
              'We couldn’t complete your secure sign-in. Please try again in a moment.';
      }

      _showAuthMessage(title, message);
    } catch (_) {
      if (!mounted) return;
      _showAuthMessage(
        'Sign-in unavailable',
        'We couldn’t complete your secure sign-in. Please try again in a moment.',
      );
    } finally {
      if (mounted) setState(() => _isSigningIn = false);
    }
  }

  void _showAuthMessage(String title, String message) {
    if (!mounted) return;

    final messenger = ScaffoldMessenger.of(context);
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 18),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          duration: const Duration(seconds: 4),
          backgroundColor: AppTheme.adaptiveSurface(Color(0xFF151A1F)),
          elevation: 8,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(
              color: Color(0xFF26343C),
              width: 1,
            ),
          ),
          content: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.adaptiveSurface(Color(0xFF0E242B)),
                  border: Border.all(
                    color: const Color(0xFF5CD6FF),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.lock_outline_rounded,
                  color: Color(0xFF5CD6FF),
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      message,
                      style: const TextStyle(
                        color: Color(0xFFB7C0C6),
                        fontSize: 13,
                        height: 1.25,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          const GalaxyBackground(
            animatePlanets: true,
            animateCryptoCoins: true,
            cinematicEntrance: true,
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(22, 28, 22, 28),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 460),
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: const Color(0xE6090C10),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: const Color(0x4459D7FF)),
                      boxShadow: const [
                        BoxShadow(color: Color(0x553F5AA8), blurRadius: 40, spreadRadius: 2),
                        BoxShadow(color: Color(0x33000000), blurRadius: 24, offset: Offset(0, 14)),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(24, 28, 24, 22),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 58,
                                height: 58,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: const LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [Color(0xFF16222B), Color(0xFF080B10)],
                                  ),
                                  border: Border.all(color: const Color(0x8859D7FF)),
                                  boxShadow: const [
                                    BoxShadow(color: Color(0x4459D7FF), blurRadius: 20),
                                  ],
                                ),
                                child: const Icon(Icons.hub_rounded, color: Color(0xFFB9C8FF), size: 29),
                              ),
                              const SizedBox(width: 15),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'CRYPTO DOCTORS',
                                      style: TextStyle(
                                        color: AppTheme.textPrimary,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 2.0,
                                      ),
                                    ),
                                    SizedBox(height: 4),
                                    Text(
                                      'SECURE MARKET ACCESS',
                                      style: TextStyle(
                                        color: Color(0xFF7F91A0),
                                        fontSize: 9,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 1.8,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 28),
                          Text(
                            'WELCOME BACK',
                            style: TextStyle(
                              color: AppTheme.luxuryGold,
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2.4,
                            ),
                          ),
                          const SizedBox(height: 7),
                          const Text(
                            'Enter your secure hub credentials',
                            style: TextStyle(color: Color(0xFFAEB8C2), fontSize: 14),
                          ),
                          const SizedBox(height: 22),
                          TextField(
                            controller: emailController,
                            keyboardType: TextInputType.emailAddress,
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                              labelText: 'Email address',
                              hintText: 'you@example.com',
                              prefixIcon: const Icon(Icons.alternate_email_rounded),
                              filled: true,
                              fillColor: const Color(0x66131A20),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                            ),
                          ),
                          const SizedBox(height: 13),
                          TextField(
                            controller: passwordController,
                            obscureText: true,
                            textInputAction: TextInputAction.done,
                            onSubmitted: (_) => enterApp(),
                            decoration: InputDecoration(
                              labelText: 'Password / PIN',
                              prefixIcon: const Icon(Icons.lock_outline_rounded),
                              filled: true,
                              fillColor: const Color(0x66131A20),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                            ),
                          ),
                          const SizedBox(height: 20),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                            decoration: BoxDecoration(
                              color: const Color(0x1459D7FF),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: const Color(0x2859D7FF)),
                            ),
                            child: const Row(
                              children: [
                                Icon(Icons.verified_user_outlined, color: Color(0xFF6DDCFF), size: 17),
                                SizedBox(width: 9),
                                Expanded(
                                  child: Text(
                                    'Protected sign-in • secure market connection',
                                    style: TextStyle(color: Color(0xFF8E9BA6), fontSize: 11),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 18),
                          SizedBox(
                            height: 54,
                            child: ElevatedButton(
                              onPressed: _isSigningIn ? null : enterApp,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppTheme.neonGreen,
                                foregroundColor: Colors.black,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                elevation: 10,
                              ),
                              child: _isSigningIn
                                  ? const SizedBox(width: 21, height: 21, child: CircularProgressIndicator(strokeWidth: 2))
                                  : const Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.login_rounded, size: 19),
                                        SizedBox(width: 9),
                                        Text('ENTER HUB', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                                      ],
                                    ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          TextButton(
                            onPressed: _isSigningIn
                                ? null
                                : () => Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (_) => const SignUpScreen()),
                                    ),
                            child: const Text(
                              'CREATE A NEW ACCOUNT',
                              style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.0),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'CRYPTO DOCTORS HUB • PRIVATE COMMUNITY',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: AppTheme.textVeryFaint, fontSize: 9, letterSpacing: 1.4),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// SIGN UP
// ============================================================

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  final referralController = TextEditingController();

  bool _isCreatingAccount = false;
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;

  @override
  void initState() {
    super.initState();
    try {
      final params = Uri.base.queryParameters;
      final incoming = (params['ref'] ?? params['referral'] ?? '').trim();
      if (incoming.isNotEmpty) {
        referralController.text = incoming.toUpperCase();
      } else if ((_pendingReferralCode ?? '').isNotEmpty) {
        referralController.text = _pendingReferralCode!;
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    referralController.dispose();
    super.dispose();
  }

  Future<void> _createAccount() async {
    if (_isCreatingAccount) return;

    final email = emailController.text.trim();
    final password = passwordController.text;
    final confirmPassword = confirmPasswordController.text;

    if (email.isEmpty || password.isEmpty || confirmPassword.isEmpty) {
      _showMessage(
        'Account details required',
        'Please complete all fields to create your account.',
      );
      return;
    }

    if (password.length < 6) {
      _showMessage(
        'Password too short',
        'Choose a password with at least 6 characters.',
      );
      return;
    }

    if (password != confirmPassword) {
      _showMessage(
        'Passwords do not match',
        'Please make sure both password fields match.',
      );
      return;
    }

    setState(() => _isCreatingAccount = true);

    try {
      final credential = await AuthService.createAccount(email: email, password: password);

      final user = credential.user;
      if (user == null) {
        throw FirebaseAuthException(code: 'user-null', message: 'Account creation could not be completed.');
      }

      final enteredReferral = referralController.text.trim().toUpperCase();
      String? referredByUid;
      if (enteredReferral.isNotEmpty) {
        final referralQuery = await FirebaseFirestore.instance
            .collection('users')
            .where('referralCode', isEqualTo: enteredReferral)
            .limit(1)
            .get();
        if (referralQuery.docs.isNotEmpty && referralQuery.docs.first.id != user.uid) {
          referredByUid = referralQuery.docs.first.id;
        } else {
          await user.delete();
          throw FirebaseAuthException(code: 'invalid-referral', message: 'That referral code could not be verified.');
        }
      }

      final ownReferralCode = ProfileService.referralCodeForUid(user.uid);
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'uid': user.uid,
        'email': user.email ?? email,
        'createdAt': FieldValue.serverTimestamp(),
        'role': 'user',
        'displayName': '',
        'referralCode': ownReferralCode,
        'referredByUid': referredByUid,
        'referredByCode': referredByUid == null ? '' : enteredReferral,
      });

      _pendingReferralCode = null;
      final isAdmin = await _hasFirebaseAdminClaim(user);

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => HubHome(
            accountEmail: user.email ?? email,
            isAdmin: isAdmin,
          ),
        ),
      );
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;

      String title;
      String message;

      switch (e.code) {
        case 'email-already-in-use':
          title = 'Account already exists';
          message =
              'An account is already registered with this email. Try signing in instead.';
          break;
        case 'invalid-email':
          title = 'Invalid email address';
          message = 'Please enter a valid email address and try again.';
          break;
        case 'weak-password':
          title = 'Choose a stronger password';
          message =
              'Please choose a stronger password with at least 6 characters.';
          break;
        case 'network-request-failed':
          title = 'Connection problem';
          message =
              'We couldn’t reach the secure account service. Check your connection and try again.';
          break;
        case 'too-many-requests':
          title = 'Please try again later';
          message =
              'Too many account requests were made. Please wait a moment and try again.';
          break;
        default:
          title = 'Account creation unavailable';
          message =
              'We couldn’t create your account right now. Please try again in a moment.';
      }

      _showMessage(title, message);
    } catch (_) {
      if (!mounted) return;
      _showMessage(
        'Account creation unavailable',
        'We couldn’t create your account right now. Please try again in a moment.',
      );
    } finally {
      if (mounted) setState(() => _isCreatingAccount = false);
    }
  }

  void _showMessage(
    String title,
    String message, {
    bool isSuccess = false,
  }) {
    if (!mounted) return;

    final messenger = ScaffoldMessenger.of(context);
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 18),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          duration: const Duration(seconds: 4),
          backgroundColor: AppTheme.adaptiveSurface(Color(0xFF151A1F)),
          elevation: 8,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(
              color: isSuccess
                  ? const Color(0x6659D7FF)
                  : const Color(0xFF26343C),
              width: 1,
            ),
          ),
          content: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isSuccess
                      ? const Color(0x1A59D7FF)
                      : AppTheme.adaptiveSurface(Color(0xFF0E242B)),
                  border: Border.all(
                    color: isSuccess
                        ? AppTheme.neonGreen
                        : const Color(0xFF5CD6FF),
                    width: 1,
                  ),
                ),
                child: Icon(
                  isSuccess
                      ? Icons.check_rounded
                      : Icons.person_add_alt_1_outlined,
                  color: isSuccess
                      ? AppTheme.neonGreen
                      : const Color(0xFF5CD6FF),
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      message,
                      style: const TextStyle(
                        color: Color(0xFFB7C0C6),
                        fontSize: 13,
                        height: 1.25,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const GalaxyBackground(),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 480),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(26),
                      child: Column(
                        children: [
                          Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0xFF101812),
                              border: Border.all(
                                color: AppTheme.neonGreen,
                              ),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x6659D7FF),
                                  blurRadius: 22,
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.person_add_alt_1_rounded,
                              size: 36,
                              color: AppTheme.luxuryGold,
                            ),
                          ),
                          const SizedBox(height: 18),
                          Text(
                            'CREATE ACCOUNT',
                            style: TextStyle(
                              color: AppTheme.luxuryGold,
                              fontSize: 24,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Create your secure CRYPTO-DOCTORS-HUB account',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: AppTheme.textMuted),
                          ),
                          const SizedBox(height: 24),
                          TextField(
                            controller: emailController,
                            keyboardType: TextInputType.emailAddress,
                            textInputAction: TextInputAction.next,
                            decoration: const InputDecoration(
                              labelText: 'Email',
                              prefixIcon: Icon(Icons.email_outlined),
                            ),
                          ),
                          const SizedBox(height: 14),
                          TextField(
                            controller: passwordController,
                            obscureText: _obscurePassword,
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                              labelText: 'Password',
                              prefixIcon:
                                  const Icon(Icons.lock_outline_rounded),
                              suffixIcon: IconButton(
                                tooltip: 'Show or hide password',
                                onPressed: () {
                                  setState(() {
                                    _obscurePassword = !_obscurePassword;
                                  });
                                },
                                icon: Icon(
                                  _obscurePassword
                                      ? Icons.visibility_outlined
                                      : Icons.visibility_off_outlined,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          TextField(
                            controller: confirmPasswordController,
                            obscureText: _obscureConfirmPassword,
                            textInputAction: TextInputAction.done,
                            onSubmitted: (_) => _createAccount(),
                            decoration: InputDecoration(
                              labelText: 'Confirm password',
                              prefixIcon:
                                  const Icon(Icons.lock_reset_outlined),
                              suffixIcon: IconButton(
                                tooltip: 'Show or hide password',
                                onPressed: () {
                                  setState(() {
                                    _obscureConfirmPassword =
                                        !_obscureConfirmPassword;
                                  });
                                },
                                icon: Icon(
                                  _obscureConfirmPassword
                                      ? Icons.visibility_outlined
                                      : Icons.visibility_off_outlined,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          TextField(
                            controller: referralController,
                            textCapitalization: TextCapitalization.characters,
                            textInputAction: TextInputAction.done,
                            decoration: const InputDecoration(
                              labelText: 'Referral code (optional)',
                              hintText: 'Example: CD-A1B2C3D4',
                              prefixIcon: Icon(Icons.card_giftcard_outlined),
                            ),
                          ),
                          const SizedBox(height: 22),
                          ElevatedButton(
                            onPressed:
                                _isCreatingAccount ? null : _createAccount,
                            child: _isCreatingAccount
                                ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Text('CREATE ACCOUNT'),
                          ),
                          const SizedBox(height: 10),
                          TextButton.icon(
                            onPressed: _isCreatingAccount
                                ? null
                                : () => Navigator.pop(context),
                            icon: const Icon(Icons.arrow_back_rounded, size: 18),
                            label: const Text('BACK TO SIGN IN'),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Secure authentication enabled.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: AppTheme.textFaint,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// MAIN HUB
// ============================================================


class HubHome extends StatefulWidget {
  final String accountEmail;
  final bool isAdmin;
  final bool isPremium;

  const HubHome({
    super.key,
    required this.accountEmail,
    this.isAdmin = false,
    this.isPremium = false,
  });

  @override
  State<HubHome> createState() => _HubHomeState();
}

class _HubHomeState extends State<HubHome> {
  int selectedIndex = 0;
  int _tabDirection = 1;
  Offset? _pointerDownPosition;
  Offset _pointerDelta = Offset.zero;
  bool _pointerSwipeTriggered = false;

  // Keep page instances stable. The Feed subtree must not be recreated when
  // the user switches tabs.
  final GlobalKey<_FeedPageState> _feedKey = GlobalKey<_FeedPageState>();
  final GlobalKey<_AnalysisPageState> _analysisKey = GlobalKey<_AnalysisPageState>();
  final GlobalKey<_LiveCallsPageState> _liveCallsKey = GlobalKey<_LiveCallsPageState>();
  final GlobalKey<_JournalPageState> _journalKey = GlobalKey<_JournalPageState>();

  late final List<Widget> pages = [
    FeedPage(key: _feedKey, isAdmin: widget.isAdmin),
    AnalysisPage(key: _analysisKey, isAdmin: widget.isAdmin, accountEmail: widget.accountEmail),
    LiveCallsPage(key: _liveCallsKey, isAdmin: widget.isAdmin, isPremium: widget.isPremium, onCreate: _createLiveCall),
    JournalPage(key: _journalKey),
    MentorshipPage(isAdmin: widget.isAdmin),
  ];

  final List<int> _unreadCounts = [3, 0, 2, 1, 0];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _showEntryPromotions();
    });
  }

  Future<void> _showEntryPromotions() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierColor: const Color(0xD9000000),
      builder: (_) => _EntryPromotionsDialog(
        onReferral: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const _ReferralCenterPage()));
        },
        onAlphaDen: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const _AlphaDenRulesPage()));
        },
        onLiveCalls: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const _PromoLiveCallsEntryPage()));
        },
        onMentorship: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => MentorshipPage(isAdmin: widget.isAdmin)));
        },
        onJournal: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const _PersonalTradingJournalPage()));
        },
      ),
    );
  }

  void _changeTab(int index) {
    if (index < 0 || index >= pages.length || index == selectedIndex) return;
    setState(() {
      _tabDirection = index > selectedIndex ? 1 : -1;
      selectedIndex = index;
      _unreadCounts[index] = 0;
    });
  }

  void _handlePointerDown(PointerDownEvent event) {
    _pointerDownPosition = event.position;
    _pointerDelta = Offset.zero;
    _pointerSwipeTriggered = false;
  }

  void _handlePointerMove(PointerMoveEvent event) {
    if (_pointerDownPosition == null || _pointerSwipeTriggered) return;
    _pointerDelta += event.delta;

    final dx = _pointerDelta.dx;
    final dy = _pointerDelta.dy;
    if (dx.abs() < 56 || dx.abs() <= dy.abs() * 1.15) return;

    _pointerSwipeTriggered = true;
    if (dx < 0) {
      _changeTab(selectedIndex + 1);
    } else {
      _changeTab(selectedIndex - 1);
    }
  }

  void _handlePointerUp(PointerUpEvent event) {
    _pointerDownPosition = null;
    _pointerDelta = Offset.zero;
    _pointerSwipeTriggered = false;
  }

  void _handlePointerCancel(PointerCancelEvent event) {
    _pointerDownPosition = null;
    _pointerDelta = Offset.zero;
    _pointerSwipeTriggered = false;
  }

  void _openCustomerSupport() {
    showCustomerSupportSheet(context);
  }

  Future<void> _openAlphaDen() async {
    await Navigator.push(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 700),
        pageBuilder: (_, _, _) => AlphaDenLoadingPage(isAdmin: widget.isAdmin),
        transitionsBuilder: (_, animation, _, child) {
          return FadeTransition(
            opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.08, end: 1.0).animate(
                CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
              ),
              child: child,
            ),
          );
        },
      ),
    );

    if (!mounted) return;
    await _feedKey.currentState?._refresh();
  }

  void _showSectionRules(BuildContext context, int sectionIndex) {
    final String title;
    final String intro;
    final List<_GuidePageData> pages;
    switch (sectionIndex) {
      case 1:
        title = 'ANALYSIS — RULES & INFORMATION';
        intro = 'Analysis is provided to help users understand and assess market conditions. It is not a guarantee or a substitute for independent decision-making.';
        pages = const [
          _GuidePageData('INFORMATIONAL PURPOSE', 'All Analysis is for informational and educational purposes only.'),
          _GuidePageData('MARKET INTERPRETATION', 'Analysis represents Crypto Doctors Hub’s view or interpretation of market conditions and may be incorrect.'),
          _GuidePageData('NO GUARANTEE', 'No Analysis post guarantees that the market will move according to the stated view.'),
          _GuidePageData('ANALYSIS VS LIVE SIGNAL', 'Do not trade solely because of an Analysis post. Analysis is different from an official Live Signal.'),
          _GuidePageData('OFFICIAL SIGNALS', 'Only a Live Signal published through the official Live Calls / Live Signals system should be treated as an actual signal from that system.'),
          _GuidePageData('USER RESPONSIBILITY', 'Conduct your own research and use appropriate risk management before making any financial decision.'),
          _GuidePageData('VOLATILITY', 'Crypto markets can be highly volatile. Prices, liquidity and market conditions can change rapidly.'),
          _GuidePageData('PAST RESULTS', 'Past analysis, outcomes or results do not guarantee future outcomes.'),
          _GuidePageData('TRADING FROM ANALYSIS', 'If you open a trade based only on Analysis, Crypto Doctors Hub is not responsible for any resulting profit or loss.'),
        ];
        break;
      case 2:
        title = 'LIVE CALLS — COMPLETE GUIDE';
        intro = 'Official Live Signal rules: access, sequence, operation, outcomes, Premium locking, trade closure and participation.';
        pages = const [
          _GuidePageData('DAILY SEQUENCE', 'Live Calls are detected automatically in chronological sequence for each calendar day. The first published signal is sequence 1, the second is sequence 2, and every signal after that continues the same sequence. Nothing needs to be written inside the signal.'),
          _GuidePageData('FIRST 2 ARE FREE', 'Sequence 1 and sequence 2 are free for all signed-in users. The count resets at 12:00 AM each calendar day.'),
          _GuidePageData('SEQUENCE 3 ONWARD', 'Sequence 3, 4, 5, 6 and every later unclosed Live Call are Premium-only for Free users. Free users see the established golden 3D lock.'),
          _GuidePageData('BLUR / UNBLUR', 'A locked Premium signal remains visible as a card, but its trade content is blurred and not readable to Free users. Approved Premium users see the full signal without the blur.'),
          _GuidePageData('PUBLIC RESULTS', 'If a locked signal reaches TP or Stop Loss, its result information can be shown publicly while the underlying trade content remains blurred for users without access.'),
          _GuidePageData('PREMIUM ACCESS', 'Approved Premium users can open sequence 3 onward. Payment submission does not grant Premium automatically; an Admin must approve the Premium status.'),
          _GuidePageData('SIGNAL FIELDS', 'Each signal uses ENTRY, LONG/SHORT, LEVERAGE, TP1, TP2, TP3 and STOPLOSS. Signal prices are locked after publication.'),
          _GuidePageData('WIN / LOSS', 'Live Calls count 1 WIN when at least one TP is hit. LOSS requires the trade to end at Stop Loss without a TP hit. Break Even is separate.'),
          _GuidePageData('PROFIT PERCENTAGE', 'Admin can record the actual percentage for each TP or Stop Loss hit. When multiple TPs are hit, the signal box shows their average profit percentage. A manually entered final Green closure percentage becomes the official final result.'),
          _GuidePageData('ADMIN MANAGEMENT', 'Only Admin can record TP/SL results and choose Trade Closed — Green or Trade Closed — Red. Users cannot edit signal prices or management controls.'),
          _GuidePageData('CD FEED', 'Only the first 2 Live Calls of each calendar day are automatically shared to CD Feed. Later unclosed Premium calls stay inside Live Calls.'),
          _GuidePageData('RISK NOTICE', 'Live Calls do not guarantee profit. Volatility, leverage, slippage, fees, funding and execution can change actual results. Use appropriate risk management.'),
        ];
        break;
      default:
        title = 'TRADING JOURNAL — RULES & INFORMATION';
        intro = 'Trading Journal is intended to help users record, review and learn from their trading activity and habits.';
        pages = const [
          _GuidePageData('WHAT IS THE TRADING JOURNAL?', 'The Trading Journal is the historical record for officially closed Live Calls and for your own private trading-task and profit records. Community performance comes from Live Calls. Personal performance is tied to your own participation and private entries.'),
          _GuidePageData('WHERE THE COMMUNITY NUMBERS COME FROM', 'Community statistics are calculated from Live Calls stored in Firebase. A signal is eligible only after Admin selects Trade Closed — Green or Trade Closed — Red. TP1, TP2, TP3 and Stop Loss events can update Live Calls, but a TP hit alone does not enter the Journal.'),
          _GuidePageData('OFFICIAL CLOSURE', 'Trade Closed — Green/Red makes the final result official. The final percentage, result and closure time become historical data. Officially closed Live Calls are treated as immutable records and are not eligible for normal editing or deletion.'),
          _GuidePageData('DAILY / MONTHLY / YEARLY', 'Daily uses official closed results for the current calendar day and resets at 12:00 AM. Monthly uses official closed results within the current calendar month. Yearly uses official closed results within the current calendar year. These are calculated from the stored final trade percentages.'),
          _GuidePageData('TP RESULTS', 'TP1/TP2/TP3 hits affect the Live Call result and its displayed win information. They do not by themselves close the trade. The Journal waits for the explicit Trade Closed — Green or Trade Closed — Red action.'),
          _GuidePageData('PERSONAL PRIVACY', 'Every user has a separate private personal Journal. Your Live Call participation, personal profit entries, portfolio, task settings, risk settings and task history are stored under your Firebase user account. Other users cannot read them through the normal Journal interface.'),
          _GuidePageData('PERSONAL LIVE CALL RECORDS', 'Once a participated trade is officially closed, its final result can be associated with that user’s private Journal. A user’s personal result does not become another user’s personal result.'),
          _GuidePageData('PERSONAL TRADING TASK', 'Personal Trading Task is a private planning tool. It uses your portfolio, monthly target, trading days, trades per day, risk per trade, stop-loss, risk/reward and daily-risk settings to calculate planning figures. These are educational calculations, not guarantees of profit.'),
          _GuidePageData('RISK MANAGEMENT', 'Position size should be determined from account equity, predefined risk and a logical stop. Predetermining maximum trade and daily loss helps control exposure. Leverage amplifies both gains and losses. Do not increase leverage or risk simply to reach a daily target, and do not trade money needed for essential expenses.'),
          _GuidePageData('WHEN NOT TO TRADE', 'The plan should permit no-trade decisions. If the predefined loss limit is reached, if a logical stop cannot be placed, or if the trader is attempting to recover losses through larger or more frequent trades, stopping for the day can be a risk-control decision.'),
          _GuidePageData('DATA & HISTORY', 'Official Live Call history remains in Firebase. Personal daily task records are stored by calendar date so completed and incomplete days remain available instead of being overwritten. Community history is public; personal history is private.'),
          _GuidePageData('EDUCATIONAL NOTICE', 'Journal information and risk-management guidance are educational and should not be treated as a promise of returns or individualized financial advice.'),
        ];
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _SectionGuidePage(title: title, intro: intro, pages: pages),
      ),
    );
  }

  Future<void> _createLiveCall() async {
    if (!widget.isAdmin || selectedIndex != 2) return;
    final post = await Navigator.push<_LiveCallPost>(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, animation, _) => const _LiveCallComposerPage(),
        transitionsBuilder: (_, animation, _, child) {
          return FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.08, 0),
                end: Offset.zero,
              ).animate(
                CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
              ),
              child: child,
            ),
          );
        },
      ),
    );
    if (post != null && mounted) {
      try {
        await _publishLiveCall(post);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Live Call published successfully.')));
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Live Call was not published: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        // Keep CD Feed at its existing header height; compact the other tabs
        // so their top chrome occupies less vertical space.
        toolbarHeight: selectedIndex == 0 ? kToolbarHeight : 48,
        centerTitle: true,
        leading: selectedIndex == 0
            ? IconButton(
                tooltip: 'Profile',
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const ProfilePage()),
                  );
                },
                icon: StreamBuilder<User?>(
                  stream: FirebaseAuth.instance.authStateChanges(),
                  builder: (context, authSnapshot) {
                    final user = authSnapshot.data;
                    if (user == null) return CircleAvatar(radius: 16, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF2A2F35)), child: Icon(Icons.person, color: AppTheme.textSecondary, size: 20));
                    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                      stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
                      builder: (context, profileSnapshot) {
                        final data = profileSnapshot.data?.data();
                        final legacy = (data?['appAvatarBase64'] ?? '').toString();
                        return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                          stream: ProfileService.watchAppAvatar(uid: user.uid),
                          builder: (context, avatarSnapshot) {
                            final encoded = (avatarSnapshot.data?.data()?['imageBase64'] ?? legacy).toString();
                            if (encoded.isNotEmpty) {
                              try { return CircleAvatar(radius: 16, backgroundImage: MemoryImage(base64Decode(encoded))); } catch (_) {}
                            }
                            final photoUrl = user.photoURL?.trim() ?? '';
                            if (photoUrl.isNotEmpty) return CircleAvatar(radius: 16, backgroundImage: NetworkImage(photoUrl));
                            return CircleAvatar(radius: 16, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF2A2F35)), child: Icon(Icons.person, color: AppTheme.textSecondary, size: 20));
                          },
                        );
                      },
                    );
                  },
                ),
              )
            : null,
        title: selectedIndex == 0
            ? _FeedTopSearchBar(onTap: () => _openFeedSearch(context))
            : Text(pageTitles[selectedIndex]),
        actions: [
          if (selectedIndex == 0)
            IconButton(
              tooltip: 'Notifications',
              onPressed: () => _showFeedNotificationSettings(context),
              icon: Icon(Icons.notifications_none_rounded, color: AppTheme.textSecondary),
            ),
          if (selectedIndex == 0)
            IconButton(
              tooltip: 'Customer Support',
              onPressed: _openCustomerSupport,
              icon: Icon(Icons.support_agent_rounded, color: AppTheme.textSecondary),
            ),
          if (widget.isAdmin)
            IconButton(
              tooltip: 'Admin Dashboard',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AdminDashboardPage(
                      adminEmail: widget.accountEmail,
                    ),
                  ),
                );
              },
              icon: Icon(Icons.admin_panel_settings, color: AppTheme.luxuryGold),
            ),
          if (selectedIndex == 1 || selectedIndex == 2 || selectedIndex == 3)
            IconButton(
              tooltip: 'Rules & Information',
              onPressed: () => _showSectionRules(context, selectedIndex),
              icon: Icon(Icons.help_outline_rounded, color: AppTheme.textSecondary),
            ),
        ],
      ),
      body: Listener(
        behavior: HitTestBehavior.translucent,
        onPointerDown: _handlePointerDown,
        onPointerMove: _handlePointerMove,
        onPointerUp: _handlePointerUp,
        onPointerCancel: _handlePointerCancel,
        child: Stack(
          children: [
            const GalaxyBackground(
              animatePlanets: true,
              animateCryptoCoins: true,
              cinematicEntrance: true,
            ),
            SafeArea(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 320),
                reverseDuration: const Duration(milliseconds: 240),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                transitionBuilder: (child, animation) {
                  final begin = Offset(0.055 * _tabDirection, 0);
                  final slide = Tween<Offset>(
                    begin: begin,
                    end: Offset.zero,
                  ).animate(
                    CurvedAnimation(
                      parent: animation,
                      curve: Curves.easeOutCubic,
                    ),
                  );
                  return FadeTransition(
                    opacity: animation,
                    child: SlideTransition(position: slide, child: child),
                  );
                },
                child: KeyedSubtree(
                  key: ValueKey<int>(selectedIndex),
                  child: pages[selectedIndex],
                ),
              ),
            ),
            if (selectedIndex == 0)
              Positioned(
                right: 0,
                top: MediaQuery.sizeOf(context).height * 0.70 - 30,
                child: _AlphaDenDashboardTile(onTap: _openAlphaDen),
              ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Builder(builder: (context) {
          final light = Theme.of(context).brightness == Brightness.light;
          return Container(
          margin: const EdgeInsets.fromLTRB(10, 4, 10, 6),
          height: 62,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: light
                  ? const [Color(0xE8FFFFFF), Color(0xDDF1EEE7), Color(0xE6E3DED4)]
                  : const [Color(0xCC4A4F55), Color(0xAA30343A), Color(0xB52A2E33)],
            ),
            borderRadius: BorderRadius.circular(34),
            border: Border.all(color: light ? const Color(0x338A6A18) : AppTheme.adaptiveWhite(alpha: 0.13)),
            boxShadow: [
              BoxShadow(color: Colors.black.withValues(alpha: light ? 0.10 : 0.24), blurRadius: 18, offset: const Offset(0, 6)),
              BoxShadow(color: AppTheme.adaptiveWhite(alpha: light ? 0.35 : 0.025), blurRadius: 8, offset: const Offset(0, -1)),
            ],
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildGlassBottomItem(Icons.dynamic_feed_outlined, Icons.dynamic_feed, 'Feed', 0),
                _buildGlassBottomItem(Icons.analytics_outlined, Icons.analytics, 'Analysis', 1),
                _buildGlassBottomItem(Icons.sensors_outlined, Icons.sensors, 'Calls', 2),
                _buildGlassBottomItem(Icons.menu_book_outlined, Icons.menu_book, 'Journal', 3),
                _buildGlassBottomItem(Icons.school_outlined, Icons.school, 'Mentorship', 4),
                const SizedBox(width: 2),
                _buildGlassBottomAbout(),
              ],
            ),
          ),
          );
        }),
      ),
    );
  }

  Widget _buildGlassBottomItem(IconData icon, IconData selectedIcon, String label, int index) {
    final selected = selectedIndex == index;
    final hasUnread = _unreadCounts[index] > 0;
    final light = Theme.of(context).brightness == Brightness.light;
    return GestureDetector(
      onTap: () => _changeTab(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
        width: 78,
        height: 48,
        margin: const EdgeInsets.symmetric(horizontal: 2.5),
        decoration: BoxDecoration(
          gradient: selected
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppTheme.adaptiveWhite(alpha: 0.13),
                    AppTheme.adaptiveWhite(alpha: 0.045),
                  ],
                )
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppTheme.adaptiveWhite(alpha: 0.055),
                    AppTheme.adaptiveWhite(alpha: 0.018),
                  ],
                ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.adaptiveWhite(alpha: selected ? 0.11 : 0.055)),
          boxShadow: [
            BoxShadow(color: Colors.black.withValues(alpha: selected ? 0.10 : 0.045), blurRadius: 8, offset: const Offset(0, 2)),
          ],
        ),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.center,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(selected ? selectedIcon : icon, size: 20, color: selected ? (light ? const Color(0xFF6F5414) : AppTheme.textPrimary) : (light ? const Color(0xFF5D5A52) : AppTheme.textSecondary)),
                const SizedBox(height: 2),
                Text(label, style: TextStyle(color: selected ? (light ? const Color(0xFF6F5414) : AppTheme.textPrimary) : (light ? const Color(0xFF5D5A52) : AppTheme.textSecondary), fontSize: 9, fontWeight: selected ? FontWeight.w800 : FontWeight.w600)),
              ],
            ),
            if (hasUnread)
              Positioned(
                right: 19,
                top: 6,
                child: Container(width: 8, height: 8, decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlassBottomAbout() {
    final light = Theme.of(context).brightness == Brightness.light;
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _AboutPage())),
      child: Container(
        width: 78,
        height: 48,
        margin: const EdgeInsets.symmetric(horizontal: 2.5),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: light ? const [Color(0x22FFFFFF), Color(0x11000000)] : [AppTheme.adaptiveWhite(alpha: 0.055), AppTheme.adaptiveWhite(alpha: 0.018)],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: light ? const Color(0x338A6A18) : AppTheme.adaptiveWhite(alpha: 0.055)),
          boxShadow: [
            BoxShadow(color: Colors.black.withValues(alpha: 0.045), blurRadius: 8, offset: const Offset(0, 2)),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.info_outline_rounded, size: 20, color: light ? const Color(0xFF5D5A52) : AppTheme.textSecondary),
            const SizedBox(height: 2),
            Text('About', style: TextStyle(color: light ? const Color(0xFF5D5A52) : AppTheme.textSecondary, fontSize: 9, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

}


class _EntryPromotionsDialog extends StatefulWidget {
  final VoidCallback onReferral;
  final VoidCallback onAlphaDen;
  final VoidCallback onLiveCalls;
  final VoidCallback onMentorship;
  final VoidCallback onJournal;

  const _EntryPromotionsDialog({
    required this.onReferral,
    required this.onAlphaDen,
    required this.onLiveCalls,
    required this.onMentorship,
    required this.onJournal,
  });

  @override
  State<_EntryPromotionsDialog> createState() => _EntryPromotionsDialogState();
}

class _EntryPromotionsDialogState extends State<_EntryPromotionsDialog>
    with TickerProviderStateMixin {
  late final AnimationController _motion = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
  )..repeat(reverse: true);

  late final AnimationController _swipe = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 420),
  );

  int _page = 0;
  double _dragX = 0;
  double _promote = 0;
  double _swipeStart = 0;
  double _swipeTarget = 0;
  bool _animating = false;

  static const int _pageCount = 5;

  @override
  void dispose() {
    _motion.dispose();
    _swipe.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _swipe.addListener(() {
      if (!mounted) return;
      final eased = Curves.easeOutCubic.transform(_swipe.value);
      if (_promote > 0) {
        setState(() => _promote = 1 - eased);
        return;
      }
      setState(() {
        _dragX = ui.lerpDouble(_swipeStart, _swipeTarget, eased) ?? _swipeTarget;
      });
    });
  }

  void _finishSwipe(double target) {
    if (_animating) return;
    _animating = true;
    _swipeStart = _dragX;
    _swipeTarget = target;
    _swipe.duration = const Duration(milliseconds: 420);
    _swipe.forward(from: 0).whenComplete(() async {
      if (!mounted) return;
      if (target < -120) {
        setState(() {
          _page = (_page + 1) % _pageCount;
          _dragX = 0;
          _promote = 1;
        });
        _swipe
          ..duration = const Duration(milliseconds: 480)
          ..value = 0;
        await _swipe.forward(from: 0);
        if (!mounted) return;
        setState(() => _promote = 0);
      } else {
        setState(() => _dragX = 0);
      }
      _swipe.duration = const Duration(milliseconds: 420);
      _animating = false;
    });
  }

  void _onDragEnd(DragEndDetails details) {
    if (_dragX < -65 || details.primaryVelocity != null && details.primaryVelocity! < -350) {
      _finishSwipe(-430);
    } else {
      _finishSwipe(0);
    }
  }

  void _openCurrent() {
    switch (_page) {
      case 0:
        widget.onReferral();
        break;
      case 1:
        widget.onAlphaDen();
        break;
      case 2:
        widget.onLiveCalls();
        break;
      case 3:
        widget.onMentorship();
        break;
      case 4:
        widget.onJournal();
        break;
    }
  }

  Widget _pageCard(int index, {required bool top}) {
    final isReferral = index == 0;
    final isAlpha = index == 1;
    final isCalls = index == 2;
    final isMentorship = index == 3;
    final title = isReferral
        ? 'START EARNING'
        : isAlpha
            ? 'ALPHA DEN'
            : isCalls
                ? 'LIVE CALLS'
                : isMentorship
                    ? 'MENTORSHIP'
                    : 'TRADING JOURNAL';
    final headline = isReferral
        ? 'Turn your network into real rewards.'
        : isAlpha
            ? 'Prove your knowledge. Build your name.'
            : isCalls
                ? 'Trade with the official signal system.'
                : isMentorship
                    ? 'Learn. Practice. Graduate.'
                    : 'Be responsible. Trade more profitably.';
    final body = isReferral
        ? 'Start from \$0. Earn qualified referral rewards, plus an applicable recurring monthly incentive while eligible.'
        : isAlpha
            ? 'Publish your ideas, grow your visibility, earn recognition and build your name in the community.'
            : isCalls
                ? 'First 2 daily calls are free. Premium and Lifetime unlock the full signal experience and eligible badge benefits.'
                : isMentorship
                    ? 'Daily lessons, practical work, backtesting and live classes built around a structured learning path.'
                    : 'Follow your rules, track your progress, manage risk and build disciplined trading habits with your Personal Task.';
    final accent = isReferral
        ? const Color(0xFF63D7FF)
        : isAlpha
            ? const Color(0xFF9BB7D7)
            : isCalls
                ? const Color(0xFF9C8BFF)
                : isMentorship
                    ? const Color(0xFF8FAFFF)
                    : const Color(0xFF5BBEFF);

    final nextOffset = top ? _dragX : 34.0 * (1 - _promote);
    final baseScale = top ? 1.0 : (.97 + .03 * _promote);
    final baseY = top ? 0.0 : 14.0 * (1 - _promote);
    final nextRotation = top ? (_dragX / 5200).clamp(-.10, .10) : .025 * (1 - _promote);
    final nextX = top ? nextOffset : 34.0 * (1 - _promote);
    final topDrop = top ? math.min(44.0, (-_dragX) * .10) : baseY;
    return Positioned.fill(
      child: Transform.translate(
        offset: Offset(nextX, topDrop),
        child: Transform.rotate(
          angle: nextRotation,
          alignment: Alignment.bottomLeft,
          child: Transform.scale(
            scale: baseScale,
            alignment: Alignment.topCenter,
            child: Opacity(
              opacity: top ? 1 : (.88 + .12 * _promote),
              child: IgnorePointer(
                ignoring: !top || _animating,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _openCurrent,
                  onHorizontalDragUpdate: (details) {
                    if (!top || _animating) return;
                    setState(() => _dragX = math.min(0, _dragX + details.delta.dx));
                  },
                  onHorizontalDragEnd: top ? _onDragEnd : null,
                  child: _PromoCard(
                    index: index,
                    title: title,
                    headline: headline,
                    body: body,
                    accent: accent,
                    animation: _motion,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final next = (_page + 1) % _pageCount;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 405, maxHeight: 365),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 304,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(26),
                child: Stack(
                  clipBehavior: Clip.hardEdge,
                  children: [
                    _pageCard(next, top: false),
                    _pageCard(_page, top: true),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                _pageCount,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: _page == i ? 19 : 5,
                  height: 4,
                  decoration: BoxDecoration(
                    color: _page == i ? AppTheme.luxuryGold : AppTheme.textVeryFaint,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 5),
            Text(
              'SWIPE LEFT FOR MORE',
              style: TextStyle(
                color: AppTheme.textFaint,
                fontSize: 7,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.1,
              ),
            ),
            const SizedBox(height: 2),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Padding(
                padding: EdgeInsets.all(4),
                child: Icon(Icons.close_rounded, color: AppTheme.textPrimary, size: 23),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PromoCard extends StatelessWidget {
  final int index;
  final String title;
  final String headline;
  final String body;
  final Color accent;
  final Animation<double> animation;

  const _PromoCard({
    required this.index,
    required this.title,
    required this.headline,
    required this.body,
    required this.accent,
    required this.animation,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xE6171C22),
            const Color(0xCC171C22),
            accent.withValues(alpha: .055),
          ],
        ),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: accent.withValues(alpha: .28)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: .58),
            blurRadius: 30,
            offset: const Offset(0, 14),
          ),
          BoxShadow(
            color: accent.withValues(alpha: .08),
            blurRadius: 24,
            spreadRadius: 2,
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned(
            right: -45,
            top: -65,
            child: AnimatedBuilder(
              animation: animation,
              child: Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: accent.withValues(alpha: .12), width: 1.5),
                ),
              ),
              builder: (_, child) {
                final p = math.sin(animation.value * math.pi);
                return Transform.rotate(
                  angle: p * .18,
                  child: child,
                );
              },
            ),
          ),
          Positioned(
            left: -60,
            bottom: -85,
            child: Container(
              width: 180,
              height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [accent.withValues(alpha: .12), Colors.transparent],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 15, 20, 11),
            child: Column(
              children: [
                RepaintBoundary(child: _PromoArtwork(index: index, accent: accent, animation: animation)),
                const SizedBox(height: 4),
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: accent,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.8,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  headline,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    height: 1.08,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  body,
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 9.4,
                    fontWeight: FontWeight.w600,
                    height: 1.35,
                  ),
                ),
                if (index == 0)
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: FutureBuilder<Map<String, dynamic>>(
                      future: ReferralService.loadSettings(),
                      builder: (_, snapshot) {
                        final amount = double.tryParse(
                          (snapshot.data?['monthlyRecurringRewardUsd'] ?? '').toString(),
                        );
                        final ten = amount == null ? null : amount * 10;
                        return Text(
                          ten == null || ten <= 0
                              ? 'QUALIFIED REWARDS • RECURRING MONTHLY INCENTIVE'
                              : '10 active Premium referrals → up to \$${ten.toStringAsFixed(0)}/month recurring',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: accent.withValues(alpha: .86),
                            fontSize: 7.7,
                            fontWeight: FontWeight.w900,
                            letterSpacing: .35,
                          ),
                        );
                      },
                    ),
                  ),
                if (index == 2)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _PromoBadgeMini(
                          icon: Icons.workspace_premium_rounded,
                          color: AppTheme.luxuryGold,
                          label: 'PREMIUM',
                        ),
                        SizedBox(width: 5),
                        _PromoBadgeMini(
                          icon: Icons.workspace_premium_rounded,
                          color: Color(0xFFB56CFF),
                          label: 'LIFETIME',
                        ),
                        SizedBox(width: 5),
                        _PromoBadgeMini(
                          icon: Icons.school_rounded,
                          color: AppTheme.textPrimary,
                          label: 'STUDENT 1',
                        ),
                      ],
                    ),
                  ),                if (index == 4)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        _PromoBadgeMini(icon: Icons.track_changes_rounded, color: Color(0xFF5BBEFF), label: 'PERSONAL TASK'),
                        SizedBox(width: 5),
                        _PromoBadgeMini(icon: Icons.shield_rounded, color: Color(0xFF9BB7D7), label: 'RISK'),
                        SizedBox(width: 5),
                        _PromoBadgeMini(icon: Icons.insights_rounded, color: Color(0xFF8FAFFF), label: 'PROGRESS'),
                      ],
                    ),
                  ),
                const Spacer(),
                Text(
                  index == 0
                      ? 'TAP TO OPEN REFERRAL RULES'
                      : index == 1
                          ? 'TAP TO OPEN ALPHA DEN RULES'
                          : index == 2
                              ? 'TAP TO OPEN LIVE CALLS'
                              : index == 3
                                  ? 'TAP TO OPEN MENTORSHIP'
                                  : 'TAP TO START YOUR PERSONAL TASK',
                  style: TextStyle(
                    color: accent.withValues(alpha: .9),
                    fontSize: 7.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .85,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PromoArtwork extends StatelessWidget {
  final int index;
  final Color accent;
  final Animation<double> animation;

  const _PromoArtwork({
    required this.index,
    required this.accent,
    required this.animation,
  });

  @override
  Widget build(BuildContext context) {
    final p = math.sin(animation.value * math.pi);
    final icons = <IconData>[
      Icons.card_giftcard_rounded,
      Icons.auto_awesome_rounded,
      Icons.bolt_rounded,
      Icons.school_rounded,
      Icons.menu_book_rounded,
    ];
    final secondary = <IconData>[
      Icons.monetization_on_rounded,
      Icons.emoji_events_rounded,
      Icons.workspace_premium_rounded,
      Icons.menu_book_rounded,
      Icons.track_changes_rounded,
    ];
    return SizedBox(
      height: 82,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Transform.rotate(
            angle: p * .05,
            child: Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [accent.withValues(alpha: .18), Colors.transparent],
                ),
                border: Border.all(color: accent.withValues(alpha: .28), width: 1.2),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(0, -p * 3),
            child: Icon(icons[index], color: accent, size: 48),
          ),
          Positioned(
            right: 84,
            top: 15 + p * 4,
            child: Transform.rotate(
              angle: -.18,
              child: Icon(secondary[index], color: AppTheme.adaptiveWhite(alpha: .78), size: 20),
            ),
          ),
          Positioned(
            left: 84,
            bottom: 12 + p * 3,
            child: Transform.rotate(
              angle: .2,
              child: Icon(
                index == 2 ? Icons.bolt_rounded : index == 4 ? Icons.insights_rounded : Icons.auto_awesome_rounded,
                color: accent.withValues(alpha: .75),
                size: 16,
              ),
            ),
          ),
          Positioned(
            right: 70,
            bottom: 2,
            child: Transform.scale(
              scale: 1 + p * .10,
              child: Icon(Icons.circle, color: accent.withValues(alpha: .22), size: 7),
            ),
          ),
        ],
      ),
    );
  }
}

class _PromoBadgeMini extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;

  const _PromoBadgeMini({
    required this.icon,
    required this.color,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .07),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: .20)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 11),
          const SizedBox(width: 2),
          Text(
            label,
            style: TextStyle(color: color, fontSize: 5.8, fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }
}

class _PromoLiveCallsEntryPage extends StatefulWidget {
  const _PromoLiveCallsEntryPage();

  @override
  State<_PromoLiveCallsEntryPage> createState() => _PromoLiveCallsEntryPageState();
}

class _PromoLiveCallsEntryPageState extends State<_PromoLiveCallsEntryPage> {
  bool _loading = true;
  bool _isAdmin = false;
  bool _isPremium = false;

  @override
  void initState() {
    super.initState();
    _loadAccess();
  }

  Future<void> _loadAccess() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      _isAdmin = await _hasFirebaseAdminClaim(user);
      final data = await ProfileService.loadUserProfile(user.uid);
      _isPremium = data?['isPremium'] == true;
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return LiveCallsPage(isAdmin: _isAdmin, isPremium: _isPremium);
  }
}

class _AlphaDenDashboardOrb extends StatefulWidget {
  const _AlphaDenDashboardOrb();

  @override
  State<_AlphaDenDashboardOrb> createState() => _AlphaDenDashboardOrbState();
}

class _AlphaDenDashboardOrbState extends State<_AlphaDenDashboardOrb>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 7),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Stack(
          alignment: Alignment.center,
          clipBehavior: Clip.none,
          children: [
            CustomPaint(
              size: const Size(112, 76),
              painter: _AlphaDenDashboard3DOrbitPainter(
                progress: _controller.value,
              ),
            ),
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.adaptiveSurface(Color(0xFF080B0F)),
                border: Border.all(
                  color: AppTheme.luxuryGold.withValues(alpha: 0.55),
                  width: 1.6,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.luxuryGold.withValues(alpha: 0.20),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                  BoxShadow(
                    color: AppTheme.neonGreen.withValues(alpha: 0.15),
                    blurRadius: 32,
                    spreadRadius: 2,
                  ),
                ],
              ),
            ),
            Icon(
              Icons.blur_circular,
              size: 24,
              color: AppTheme.luxuryGold.withValues(alpha: 0.72),
            ),
            Container(
              width: 5,
              height: 5,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.textPrimary,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.luxuryGold,
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

class _AlphaDenDashboard3DOrbitPainter extends CustomPainter {
  final double progress;

  const _AlphaDenDashboard3DOrbitPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final t = progress * math.pi * 2;

    // Same existing Alpha Den colours — only the orbital geometry is changed.
    final gold = AppTheme.luxuryGold;
    final green = AppTheme.neonGreen;

    final orbits = <_DashboardOrbit3D>[
      _DashboardOrbit3D(104, 26, -0.25, 0.62, gold, 0.80),
      _DashboardOrbit3D(96, 34, 0.68, -0.54, green, 0.72),
      _DashboardOrbit3D(86, 44, -1.00, 0.46, gold, 0.62),
      _DashboardOrbit3D(74, 54, 0.32, -0.38, green, 0.54),
      _DashboardOrbit3D(62, 62, 1.12, 0.30, gold, 0.46),
    ];

    // Back planes first, then the nucleus, then foreground planes. This gives
    // the icon the same layered 3D/atom feeling as the splash reference.
    for (var i = 0; i < orbits.length; i++) {
      if (i.isOdd) continue;
      _drawOrbit(canvas, center, orbits[i], t, i, front: false);
    }

    final nucleusPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = AppTheme.adaptiveSurface(Color(0xFF080B0F));
    canvas.drawCircle(center, 20, nucleusPaint);

    final nucleusBorder = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.7
      ..color = gold.withValues(alpha: 0.55);
    canvas.drawCircle(center, 20, nucleusBorder);

    final glow = Paint()
      ..color = gold.withValues(alpha: 0.09)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
    canvas.drawCircle(center, 18, glow);

    for (var i = 0; i < orbits.length; i++) {
      if (i.isEven) continue;
      _drawOrbit(canvas, center, orbits[i], t, i, front: true);
    }

  }

  void _drawOrbit(
    Canvas canvas,
    Offset center,
    _DashboardOrbit3D orbit,
    double t,
    int index, {
    required bool front,
  }) {
    final direction = index.isEven ? 1.0 : -1.0;
    final rotation = orbit.baseRotation + t * orbit.speed * direction;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(rotation);

    final rect = Rect.fromCenter(
      center: Offset.zero,
      width: orbit.width,
      height: orbit.height,
    );

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9
      ..isAntiAlias = true
      ..color = orbit.color.withValues(
        alpha: front ? orbit.alpha : orbit.alpha * 0.48,
      );
    canvas.drawOval(rect, paint);

    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.6
      ..isAntiAlias = true
      ..color = orbit.color.withValues(
        alpha: front ? orbit.alpha * 0.10 : orbit.alpha * 0.055,
      )
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.8);
    canvas.drawOval(rect, glow);

    final a = t * orbit.speed * direction + orbit.phase;
    final dot = Offset(
      math.cos(a) * orbit.width * 0.5,
      math.sin(a) * orbit.height * 0.5,
    );
    final dotPaint = Paint()
      ..color = orbit.color
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.0);
    canvas.drawCircle(dot, front ? 2.8 : 2.3, dotPaint);

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _AlphaDenDashboard3DOrbitPainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}

class _DashboardOrbit3D {
  final double width;
  final double height;
  final double baseRotation;
  final double speed;
  final Color color;
  final double alpha;
  final double phase;

  const _DashboardOrbit3D(
    this.width,
    this.height,
    this.baseRotation,
    this.speed,
    this.color,
    this.alpha, {
    this.phase = 0,
  });
}

class _AlphaDenDashboardTile extends StatelessWidget {
  final VoidCallback onTap;
  const _AlphaDenDashboardTile({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          width: 182,
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 6),
          decoration: const BoxDecoration(color: Colors.transparent),
          child: Row(
            children: [
              SizedBox(
                width: 84,
                height: 60,
                child: Transform.scale(
                  scale: 0.76,
                  child: const _AlphaDenDashboardOrb(),
                ),
              ),
              const SizedBox(width: 1),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('ALPHA DEN', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 12.5, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                    SizedBox(height: 2),
                    Text('Your way to Web 3.0 🌐', style: TextStyle(color: AppTheme.textSoft, fontSize: 9, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              Icon(Icons.chevron_right, color: AppTheme.luxuryGold.withValues(alpha: 0.8), size: 18),
            ],
          ),
        ),
      ),
    );
  }
}

const List<String> pageTitles = [
  "CD's FEED",
  "CD's ANALYSIS",
  'LIVE CALLS',
  'JOURNAL',
  'MENTORSHIP',
  'PERSONAL',
];



// ============================================================
// ADMIN DASHBOARD
// ============================================================

class AdminDashboardPage extends StatefulWidget {
  final String adminEmail;

  const AdminDashboardPage({
    super.key,
    required this.adminEmail,
  });

  @override
  State<AdminDashboardPage> createState() => _AdminDashboardPageState();
}

class _AdminDashboardPageState extends State<AdminDashboardPage> {
  int _section = 0;

  // Unread admin notifications by section: Overview, Users, Payments, Activity, Verification, Reports, Controls.
  final List<int> _adminUnreadCounts = [0, 0, 0, 0, 0, 0, 0];

  // All admin data shown in the dashboard is loaded from Firebase.
  final List<_AdminUser> _users = [];
  final List<_AdminVerification> _verifications = [];
  String? _selectedGraduatedTargetUid;
  bool _graduatedInventoryReady = false;

  @override
  void initState() {
    super.initState();
    _prepareGraduatedBadgeInventory();
  }

  Future<void> _prepareGraduatedBadgeInventory() async {
    try {
      await BadgeService.ensureGraduatedBadgeInventory();
      if (mounted) setState(() => _graduatedInventoryReady = true);
    } catch (_) {
      if (mounted) setState(() => _graduatedInventoryReady = false);
    }
  }

  String get _sectionTitle => const [
        'Overview',
        'Users & Sign-ups',
        'Pending Payments',
        'Posts & Activity',
        'Verification Requests',
        'Reports & Moderation',
        'Admin Controls',
      ][_section];

  void _approvePayment(_AdminPayment payment) {
    setState(() {
      payment.status = 'Approved';
      final user = _users.cast<_AdminUser?>().firstWhere(
        (u) => u!.email == payment.email,
        orElse: () => null,
      );
      user?.status = 'Active';
      final verification = _verifications.cast<_AdminVerification?>().firstWhere(
        (v) => v!.txHash == payment.txHash,
        orElse: () => null,
      );
      verification?.status = 'Approved';
    });
  }

  void _cancelPayment(_AdminPayment payment) {
    setState(() {
      payment.status = 'Cancelled';
      final user = _users.cast<_AdminUser?>().firstWhere(
        (u) => u!.email == payment.email,
        orElse: () => null,
      );
      user?.status = 'Payment cancelled';
      final verification = _verifications.cast<_AdminVerification?>().firstWhere(
        (v) => v!.txHash == payment.txHash,
        orElse: () => null,
      );
      verification?.status = 'Cancelled';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.deepBlack,
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.admin_panel_settings, color: AppTheme.luxuryGold),
            const SizedBox(width: 10),
            Flexible(
              child: Text(
                'ADMIN • $_sectionTitle',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          const GalaxyBackground(animatePlanets: true),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final wide = constraints.maxWidth >= 850;
                final content = Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: SingleChildScrollView(
                        key: ValueKey<int>(_section),
                        physics: const BouncingScrollPhysics(),
                        child: _buildSection(),
                      ),
                    ),
                  ),
                );

                if (wide) {
                  return Row(
                    children: [
                      _buildRail(),
                      content,
                    ],
                  );
                }

                return Column(
                  children: [
                    content,
                    _buildMobileNav(),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRail() {
    const labels = [
      'Overview',
      'Users',
      'Payments',
      'Activity',
      'Verification',
      'Reports',
      'Controls',
    ];
    const icons = [
      Icons.dashboard_outlined,
      Icons.people_outline,
      Icons.payments_outlined,
      Icons.dynamic_feed_outlined,
      Icons.verified_user_outlined,
      Icons.flag_outlined,
      Icons.tune,
    ];

    return Container(
      width: 190,
      margin: const EdgeInsets.fromLTRB(14, 12, 0, 18),
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.adaptiveSurface(Color(0xE90A1012)),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: 0.16)),
      ),
      child: NavigationRail(
        backgroundColor: Colors.transparent,
        selectedIndex: _section,
        onDestinationSelected: (value) => setState(() { _section = value; _adminUnreadCounts[value] = 0; }),
        labelType: NavigationRailLabelType.all,
        leading: Padding(
          padding: EdgeInsets.only(bottom: 16),
          child: Icon(Icons.shield, color: AppTheme.luxuryGold, size: 30),
        ),
        destinations: List.generate(
          labels.length,
          (i) => NavigationRailDestination(
            icon: _adminNavIcon(icons[i], i),
            selectedIcon: _adminNavIcon(icons[i], i, selected: true),
            label: Text(labels[i]),
          ),
        ),
      ),
    );
  }

  Widget _buildMobileNav() {
    const labels = ['Home', 'Users', 'Pay', 'Activity', 'Verify', 'Reports', 'More'];
    const icons = [
      Icons.dashboard_outlined,
      Icons.people_outline,
      Icons.payments_outlined,
      Icons.dynamic_feed_outlined,
      Icons.verified_user_outlined,
      Icons.flag_outlined,
      Icons.tune,
    ];

    return NavigationBar(
      selectedIndex: _section,
      onDestinationSelected: (value) => setState(() {
        _section = value;
        _adminUnreadCounts[value] = 0;
      }),
      destinations: List.generate(
        labels.length,
        (i) => NavigationDestination(
          icon: _adminNavIcon(icons[i], i),
          selectedIcon: _adminNavIcon(icons[i], i, selected: true),
          label: labels[i],
        ),
      ),
    );
  }

  Widget _adminNavIcon(IconData icon, int index, {bool selected = false}) {
    final unread = _adminUnreadCounts[index];
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Icon(icon, color: selected ? AppTheme.luxuryGold : null),
        if (unread > 0)
          Positioned(
            right: -10,
            top: -8,
            child: Container(
              constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
              padding: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(20),
              ),
              alignment: Alignment.center,
              child: Text(
                unread > 99 ? '99+' : '$unread',
                style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 8,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildSection() {
    switch (_section) {
      case 1:
        return _buildUsers();
      case 2:
        return _buildPayments();
      case 3:
        return _buildActivity();
      case 4:
        return _buildVerifications();
      case 5:
        return _buildReports();
      case 6:
        return _buildControls();
      default:
        return _buildOverview();
    }
  }

  Widget _panel({required String title, required Widget child, IconData? icon}) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.adaptiveSurface(Color(0xE90A1012)),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.adaptiveWhite(alpha: 0.08)),
        boxShadow: const [BoxShadow(color: Color(0x44000000), blurRadius: 18)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(icon, color: AppTheme.luxuryGold, size: 21),
                const SizedBox(width: 9),
              ],
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  Widget _buildOverview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('CRYPTO DOCTORS ADMIN', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        const SizedBox(height: 6),
        Text('Central control for community, payments, verification and moderation.', style: TextStyle(color: AppTheme.textMuted)),
        const SizedBox(height: 18),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            _realUsersStatCard(),
            _realCountStatCard('Open reports', Icons.flag_outlined, 'content_reports', () => setState(() => _section = 5)),
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: PaymentService.watchAdminRequests(),
              builder: (context, snap) {
                final count = snap.data?.docs.where((d) {
                  final status = (d.data()['status'] ?? '').toString();
                  return status == 'intent' || status == 'pending';
                }).length ?? 0;
                return _statCard('Payment alerts', '$count', Icons.payments_outlined, () => setState(() => _section = 2));
              },
            ),
            _statCard('Verification queue', '0', Icons.verified_user_outlined, () => setState(() => _section = 4)),
          ],
        ),
        const SizedBox(height: 16),
        _buildRecentActivityPanel(),
      ],
    );
  }

  Widget _realCountStatCard(String title, IconData icon, String collection, VoidCallback onTap) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection(collection).snapshots(),
      builder: (context, snapshot) {
        final count = snapshot.data?.docs.length ?? 0;
        return _statCard(title, snapshot.connectionState == ConnectionState.waiting ? '…' : '$count', icon, onTap);
      },
    );
  }

  Widget _buildRecentActivityPanel() {
    return _panel(
      title: 'Recent community activity',
      icon: Icons.timeline,
      child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('feed_posts')
            .where('isPublished', isEqualTo: true)
            .orderBy('createdAt', descending: true)
            .limit(8)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(18), child: CircularProgressIndicator()));
          if (snapshot.hasError) return Text('Unable to load live activity: ${snapshot.error}', style: TextStyle(color: AppTheme.textMuted));
          final docs = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
          if (docs.isEmpty) return Text('No community activity yet.', style: TextStyle(color: AppTheme.textMuted));
          return Column(children: docs.map(_realActivityTile).toList());
        },
      ),
    );
  }

  Widget _realActivityTile(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data();
    final author = (data['authorDisplayName'] ?? '').toString().trim();
    final uid = (data['authorUid'] ?? '').toString();
    final sourceType = (data['sourceType'] ?? 'community').toString();
    final text = (data['text'] ?? '').toString().trim();
    final ts = data['createdAt'];
    final time = ts is Timestamp ? _formatAdminDateTime(ts.toDate()) : 'Time unavailable';
    final shortUid = uid.isEmpty ? 'Unknown account' : 'UID ${uid.substring(0, math.min(8, uid.length))}';
    final name = author.isEmpty ? shortUid : author;
    final action = sourceType == 'alpha_den' ? 'Alpha Den post' : sourceType == 'analysis' ? 'Analysis post' : sourceType == 'live_call' ? 'Live Call' : 'Community post';
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(vertical: 3),
      leading: Icon(sourceType == 'analysis' ? Icons.analytics_outlined : sourceType == 'live_call' ? Icons.campaign_outlined : Icons.article_outlined, color: AppTheme.neonGreen),
      title: Text('$name • $action', style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text('${text.isEmpty ? 'No text content' : text}\n$time', maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppTheme.textMuted, height: 1.35)),
      isThreeLine: true,
    );
  }

  String _formatAdminDateTime(DateTime value) {
    final hh = value.hour.toString().padLeft(2, '0');
    final mm = value.minute.toString().padLeft(2, '0');
    return '${_formatAdminDate(value)} $hh:$mm';
  }

  Widget _realUsersStatCard() {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').snapshots(),
      builder: (context, snapshot) {
        final count = snapshot.data?.docs.length ?? 0;
        return _statCard(
          'Users',
          snapshot.connectionState == ConnectionState.waiting ? '…' : '$count',
          Icons.people_outline,
          () => setState(() => _section = 1),
        );
      },
    );
  }

  Widget _statCard(String title, String value, IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        width: 190,
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(
          color: AppTheme.adaptiveSurface(Color(0xE90A1012)),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: 0.13)),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppTheme.luxuryGold),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                Text(title, style: TextStyle(color: AppTheme.textMuted, fontSize: 11)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUsers() {
    return _panel(
      title: 'User / Sign-up Management',
      icon: Icons.people_outline,
      child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .orderBy('createdAt', descending: true)
            .limit(200)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Padding(
              padding: EdgeInsets.symmetric(vertical: 28),
              child: Center(child: CircularProgressIndicator()),
            );
          }

          if (snapshot.hasError) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 18),
              child: Text(
                'Unable to load real sign-ups: ${snapshot.error}',
                style: TextStyle(color: AppTheme.textMuted),
              ),
            );
          }

          final docs = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
          if (docs.isEmpty) {
            return Padding(
              padding: EdgeInsets.symmetric(vertical: 28),
              child: Center(
                child: Text(
                  'No registered users found yet.',
                  style: TextStyle(color: AppTheme.textMuted),
                ),
              ),
            );
          }

          return ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: docs.length,
            separatorBuilder: (_, _) => Divider(color: AppTheme.fillFaint),
            itemBuilder: (_, index) {
              final doc = docs[index];
              final data = doc.data();
              final name = (data['displayName'] ?? '').toString().trim();
              final email = (data['email'] ?? '').toString().trim();
              final uid = (data['uid'] ?? doc.id).toString();
              final role = (data['role'] ?? 'user').toString();
              final createdAt = data['createdAt'];
              final joined = createdAt is Timestamp
                  ? _formatAdminDate(createdAt.toDate())
                  : 'Date unavailable';
              final displayName = name.isEmpty ? 'Unnamed user' : name;
              final badge = role == 'admin' ? 'ADMIN' : 'USER';

              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: CircleAvatar(
                  backgroundColor: AppTheme.neonGreen.withValues(alpha: 0.12),
                  child: Text(
                    displayName.substring(0, 1).toUpperCase(),
                    style: TextStyle(color: AppTheme.neonGreen),
                  ),
                ),
                title: Text(displayName, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(
                  '${email.isEmpty ? 'Email unavailable' : email}\nJoined $joined',
                  style: TextStyle(color: AppTheme.textMuted, height: 1.4),
                ),
                isThreeLine: true,
                trailing: Chip(label: Text(badge)),
                onTap: () => _showFirestoreUserDetails(
                  context,
                  uid: uid,
                  name: displayName,
                  email: email,
                  role: role,
                  joined: joined,
                  data: data,
                ),
              );
            },
          );
        },
      ),
    );
  }

  String _formatAdminDate(DateTime value) {
    const months = <String>[
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    return '${months[value.month - 1]} ${value.day}, ${value.year}';
  }

  void _showFirestoreUserDetails(
    BuildContext context, {
    required String uid,
    required String name,
    required String email,
    required String role,
    required String joined,
    required Map<String, dynamic> data,
  }) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0A1012)),
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 22, 22, 30),
        child: Wrap(
          runSpacing: 10,
          children: [
            Text(name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            Text(email.isEmpty ? 'Email unavailable' : email, style: TextStyle(color: AppTheme.textMuted)),
            Text('UID: $uid', style: TextStyle(color: AppTheme.textMuted, fontSize: 11)),
            Text('Role: $role'),
            Text('Premium: ${data['isPremium'] == true ? 'APPROVED' : 'NOT APPROVED'}', style: TextStyle(color: data['isPremium'] == true ? AppTheme.neonGreen : AppTheme.textMuted, fontWeight: FontWeight.w800)),
            ElevatedButton.icon(onPressed: () async { final approved=data['isPremium']==true; try { await FirebaseFirestore.instance.collection('users').doc(uid).update({'isPremium':!approved,'premiumApprovedAt':!approved?FieldValue.serverTimestamp():FieldValue.delete()}); if(context.mounted)Navigator.pop(context); } catch (_) {} }, icon: Icon(data['isPremium']==true?Icons.lock_outline:Icons.workspace_premium_outlined), label: Text(data['isPremium']==true?'REMOVE PREMIUM':'APPROVE PREMIUM')),
            Builder(builder: (_) {
              final mentorshipApproved = data['mentorshipApproved']==true || data['isMentorship']==true || data['mentorship']==true;
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Mentorship: ${mentorshipApproved ? 'APPROVED' : 'NOT APPROVED'}', style: TextStyle(color: mentorshipApproved ? AppTheme.neonGreen : AppTheme.textMuted, fontWeight: FontWeight.w800)),
                ElevatedButton.icon(onPressed: () async { try { await MentorshipService.adminSetStudent(uid: uid, approved: !mentorshipApproved, name: (data['displayName'] ?? 'Unnamed user').toString().trim()); if(context.mounted)Navigator.pop(context); } catch (_) {} }, icon: const Icon(Icons.school_rounded), label: Text(mentorshipApproved ? 'REMOVE MENTORSHIP' : 'APPROVE MENTORSHIP')),
              ]);
            }),
            Text('Joined: $joined'),
            Text('Referral code: ${(data['referralCode'] ?? 'Not set').toString()}'),
            if ((data['referredByCode'] ?? '').toString().isNotEmpty)
              Text('Referred by code: ${data['referredByCode']}'),
          ],
        ),
      ),
    );
  }

  void _syncPaymentUnreadCount(int count) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final target = _section == 2 ? 0 : count;
      if (_adminUnreadCounts[2] != target) {
        setState(() => _adminUnreadCounts[2] = target);
      }
    });
  }

  Widget _buildPayments() {
    final user = FirebaseAuth.instance.currentUser;
    return _panel(
      title: 'Pending Payments',
      icon: Icons.payments_outlined,
      child: user == null
          ? Text('Admin session required.', style: TextStyle(color: AppTheme.textMuted))
          : FutureBuilder<bool>(
              future: _hasFirebaseAdminClaim(user),
              builder: (context, claimSnapshot) {
                if (claimSnapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()));
                if (claimSnapshot.data != true) return Text('Admin access required.', style: TextStyle(color: AppTheme.textMuted));
                return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  stream: PaymentService.watchAdminRequests(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()));
                    if (snapshot.hasError) return Text('Payment requests could not be loaded. Check Firestore rules.', style: TextStyle(color: AppTheme.textMuted));
                    final docs = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
                    final intents = docs.where((d) => (d.data()['status'] ?? '').toString() == 'intent').toList();
                    final pending = docs.where((d) => (d.data()['status'] ?? '').toString() == 'pending').toList();
                    _syncPaymentUnreadCount(intents.length + pending.length);
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Manual payments are stored in Firebase. When you approve a verified proof, the user entitlement is updated automatically.', style: TextStyle(color: AppTheme.textMuted, fontSize: 11, height: 1.4)),
                        if (intents.isNotEmpty) ...[
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(color: const Color(0x22FFD166), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: .28))),
                            child: Row(children: [
                              Icon(Icons.notifications_active_rounded, color: AppTheme.luxuryGold, size: 20),
                              const SizedBox(width: 9),
                              Expanded(child: Text('${intents.length} user${intents.length == 1 ? '' : 's'} notified Admin that they want to make a payment.', style: TextStyle(color: AppTheme.textPrimary, fontSize: 11, fontWeight: FontWeight.w800))),
                            ]),
                          ),
                          const SizedBox(height: 10),
                          for (final doc in intents) _adminPaymentRequestTile(doc),
                        ],
                        const SizedBox(height: 12),
                        if (pending.isEmpty) Text('No payment proofs waiting for review.', style: TextStyle(color: AppTheme.textMuted, fontSize: 12)),
                        for (final doc in pending) _adminPaymentRequestTile(doc),
                        const SizedBox(height: 14),
                        FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _AdminPaymentSettingsPage())), icon: const Icon(Icons.settings_outlined), label: const Text('PAYMENT SETTINGS')),
                        const SizedBox(height: 8),
                        OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _AdminReferralSettingsPage())), icon: const Icon(Icons.card_giftcard_rounded), label: const Text('REFERRAL SETTINGS')),
                        const SizedBox(height: 14),
                        _buildUserPayoutDetails(),
                        const SizedBox(height: 14),
                        _buildReferralPayoutDetails(),
                        const SizedBox(height: 14),
                        _buildReferralIncentives(),
                      ],
                    );
                  },
                );
              },
            ),
    );
  }

  Widget _adminPaymentRequestTile(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data();
    final uid = (d['uid'] ?? '').toString();
    final username = (d['username'] ?? 'User').toString();
    final product = (d['product'] ?? '').toString();
    final plan = (d['planName'] ?? d['planId'] ?? '').toString();
    final amount = (d['amount'] ?? '').toString();
    final currency = (d['currency'] ?? 'USD').toString();
    final method = (d['paymentMethodName'] ?? d['paymentMethodType'] ?? '').toString();
    final tx = (d['transactionReference'] ?? '').toString();
    final proof = (d['proofUrl'] ?? '').toString();
    final installment = (d['installmentNumber'] ?? 0).toString();
    final status = (d['status'] ?? 'pending').toString();
    final isIntent = status == 'intent';
    final ts = d['submittedAt'];
    final submitted = ts is Timestamp ? _formatAdminDateTime(ts.toDate()) : 'Just submitted';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(color: AppTheme.adaptiveSurface(const Color(0xAA11191B)), borderRadius: BorderRadius.circular(15), border: Border.all(color: isIntent ? AppTheme.luxuryGold.withValues(alpha: .30) : AppTheme.luxuryGold.withValues(alpha: .18))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(username, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14))), Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: isIntent ? const Color(0x33FFD166) : const Color(0x22FFFFFF), borderRadius: BorderRadius.circular(20)), child: Text(isIntent ? 'WANTS TO PAY' : 'PENDING PROOF', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 9, fontWeight: FontWeight.w900)))]),
        const SizedBox(height: 6),
        Text('UID: $uid', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)),
        Text('Product: ${product.toUpperCase()} • $plan', style: TextStyle(color: AppTheme.textSecondary, fontSize: 11, fontWeight: FontWeight.w700)),
        Text('Amount: $amount $currency • Method: $method', style: TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
        if (product == 'mentorship' && installment != '0') Text('Installment: #$installment', style: TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
        if (tx.isNotEmpty) Text('Reference: $tx', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)),
        Text('Submitted: $submitted', style: TextStyle(color: AppTheme.textFaint, fontSize: 9)),
        const SizedBox(height: 10),
        if (proof.isNotEmpty)
          GestureDetector(
            onTap: () => _showPaymentProof(proof, username),
            child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(proof, height: 180, width: double.infinity, fit: BoxFit.contain, errorBuilder: (_, __, ___) => Container(height: 80, alignment: Alignment.center, color: Colors.black26, child: const Text('Proof image unavailable')))),
          )
        else
          Text(isIntent ? 'No screenshot yet — waiting for the user to submit payment proof.' : 'No screenshot attached.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)),
        if (!isIntent) ...[
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: FilledButton.icon(onPressed: () => _approveManualPayment(doc.id), icon: const Icon(Icons.check_rounded), label: const Text('APPROVE'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(onPressed: () => _rejectManualPayment(doc.id), icon: const Icon(Icons.close_rounded), label: const Text('REJECT'))),
          ]),
        ],
      ]),
    );
  }

  Future<void> _approveManualPayment(String requestId) async {
    try {
      await PaymentService.adminApproveRequest(requestId);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Payment approved. User entitlement updated automatically.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Approval failed: $e')));
    }
  }

  Future<void> _rejectManualPayment(String requestId) async {
    final reason = TextEditingController();
    final result = await showDialog<bool>(context: context, builder: (dc) => AlertDialog(
      title: const Text('REJECT PAYMENT'),
      content: TextField(controller: reason, maxLines: 3, decoration: const InputDecoration(hintText: 'Optional reason')),
      actions: [TextButton(onPressed: () => Navigator.pop(dc, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(dc, true), child: const Text('REJECT'))],
    ));
    if (result != true) return;
    try {
      await PaymentService.adminRejectRequest(requestId, reason: reason.text);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Payment rejected.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Rejection failed: $e')));
    } finally {
      reason.dispose();
    }
  }

  Future<void> _showPaymentProof(String url, String username) async {
    await showDialog<void>(
      context: context,
      builder: (dc) => Dialog(
        backgroundColor: Colors.black,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(padding: const EdgeInsets.all(10), child: Row(children: [Expanded(child: Text('PAYMENT PROOF • $username', style: const TextStyle(fontWeight: FontWeight.w900))), IconButton(onPressed: () => Navigator.pop(dc), icon: const Icon(Icons.close))])),
          InteractiveViewer(child: Image.network(url, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Padding(padding: EdgeInsets.all(30), child: Text('Proof image unavailable')))),
          Padding(padding: const EdgeInsets.all(10), child: SelectableText(url, style: TextStyle(color: AppTheme.textMuted, fontSize: 9))),
        ]),
      ),
    );
  }

  Widget _buildUserPayoutDetails() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const SizedBox.shrink();
    return FutureBuilder<bool>(
      future: _hasFirebaseAdminClaim(user),
      builder: (context, claimSnapshot) {
        if (claimSnapshot.data != true) return const SizedBox.shrink();
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: PayoutService.watchAll(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Text(
                'User payout details could not be loaded. Check Firestore rules.',
                style: TextStyle(color: AppTheme.textMuted, fontSize: 11),
              );
            }
            final docs = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
            return Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.adaptiveSurface(const Color(0xAA11191B)),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: .20)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.account_balance_wallet_outlined, color: AppTheme.luxuryGold, size: 20),
                      const SizedBox(width: 8),
                      Expanded(child: Text('USER PAYOUT DETAILS', style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: .6))),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'Users save their own payout destination here. These details are separate from CDH platform payment receiving methods.',
                    style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.4),
                  ),
                  const SizedBox(height: 12),
                  if (docs.isEmpty)
                    Text('No user payout details submitted yet.', style: TextStyle(color: AppTheme.textMuted, fontSize: 11))
                  else
                    for (final doc in docs) _adminUserPayoutTile(doc),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _adminUserPayoutTile(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data();
    final uid = (data['uid'] ?? doc.id).toString();
    final name = (data['userName'] ?? 'Unnamed user').toString().trim();
    final method = (data['paymentMethod'] ?? '').toString().trim();
    final detail = (data['paymentDetail'] ?? '').toString().trim();
    return Card(
      color: AppTheme.adaptiveSurface(const Color(0xFF12171A)),
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        leading: Icon(
          method == 'Easypaisa' ? Icons.phone_android_rounded : Icons.currency_exchange_rounded,
          color: AppTheme.luxuryGold,
        ),
        title: Text(name.isEmpty ? 'Unnamed user' : name, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(
          '${uid}\n${method.isEmpty ? 'Method unavailable' : method} • ${detail.isEmpty ? 'Details unavailable' : detail}',
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.35),
        ),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: () => _showUserPayoutDetailsDialog(context, uid: uid, name: name, method: method, detail: detail),
      ),
    );
  }

  Future<void> _showUserPayoutDetailsDialog(
    BuildContext context, {
    required String uid,
    required String name,
    required String method,
    required String detail,
  }) async {
    final text = 'Name: ${name.isEmpty ? 'Unnamed user' : name}\nUID: $uid\nPayout method: ${method.isEmpty ? 'Unavailable' : method}\nPayout details: ${detail.isEmpty ? 'Unavailable' : detail}';
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('USER PAYOUT DETAILS', style: TextStyle(fontWeight: FontWeight.w900)),
        content: SelectableText(text, style: const TextStyle(height: 1.5)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CLOSE')),
          FilledButton.icon(
            onPressed: detail.isEmpty ? null : () async {
              await Clipboard.setData(ClipboardData(text: text));
              if (dialogContext.mounted) {
                Navigator.pop(dialogContext);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('User payout details copied.')));
              }
            },
            icon: const Icon(Icons.copy_rounded),
            label: const Text('COPY DETAILS'),
          ),
        ],
      ),
    );
  }

  Widget _buildReferralIncentives() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const SizedBox.shrink();
    return FutureBuilder<bool>(
      future: _hasFirebaseAdminClaim(user),
      builder: (context, claimSnapshot) {
        if (claimSnapshot.data != true) return const SizedBox.shrink();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: ReferralService.watchAdminNotifications(),
              builder: (context, notificationSnapshot) {
                if (notificationSnapshot.hasError) {
                  return Text('Referral notifications could not be loaded: ${notificationSnapshot.error}', style: TextStyle(color: AppTheme.textMuted, fontSize: 10));
                }
                final docs = notificationSnapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
                final unread = docs.where((d) => (d.data()['status'] ?? 'unread').toString() != 'read').toList();
                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: unread.isEmpty ? AppTheme.adaptiveSurface(Color(0xAA11191B)) : const Color(0x22FFD166),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: .24)),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Icon(unread.isEmpty ? Icons.link_rounded : Icons.notifications_active_rounded, color: AppTheme.luxuryGold, size: 21),
                      const SizedBox(width: 8),
                      Expanded(child: Text('REFERRAL INCENTIVE NOTIFICATIONS', style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: .55))),
                      if (unread.isNotEmpty) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: AppTheme.luxuryGold, borderRadius: BorderRadius.circular(20)), child: Text('${unread.length} NEW', style: const TextStyle(color: Colors.black, fontSize: 8, fontWeight: FontWeight.w900))),
                    ]),
                    const SizedBox(height: 5),
                    Text('Every confirmed Premium or Mentorship purchase under a referral appears here with the referrer, referred user, UID and incentive earned.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.4)),
                    const SizedBox(height: 10),
                    if (docs.isEmpty) Text('No referral purchase notifications yet.', style: TextStyle(color: AppTheme.textMuted, fontSize: 11))
                    else for (final doc in docs.take(25)) _adminReferralNotificationTile(doc),
                  ]),
                );
              },
            ),
            const SizedBox(height: 14),
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: ReferralService.watchAdminRewards(),
              builder: (context, snapshot) {
                if (snapshot.hasError) return Text('Referral earnings could not be loaded: ${snapshot.error}', style: TextStyle(color: AppTheme.textMuted, fontSize: 10));
                final docs = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
                double totalEarned = 0;
                double totalPaid = 0;
                for (final doc in docs) {
                  final d = doc.data();
                  final amount = (d['incentiveAmountUsd'] as num?)?.toDouble() ?? double.tryParse('${d['incentiveAmountUsd']}') ?? 0;
                  totalEarned += amount;
                  if ((d['status'] ?? '').toString() == 'paid') totalPaid += amount;
                }
                final outstanding = totalEarned - totalPaid;
                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xAA11191B)), borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: .20))),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [Icon(Icons.account_balance_wallet_rounded, color: AppTheme.luxuryGold, size: 20), const SizedBox(width: 8), Expanded(child: Text('REFERRAL EARNINGS • PAYOUT QUEUE', style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: .6)))]),
                    const SizedBox(height: 7),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      _referralAdminMetric('Earned', '\$${totalEarned.toStringAsFixed(2)}'),
                      _referralAdminMetric('Paid', '\$${totalPaid.toStringAsFixed(2)}'),
                      _referralAdminMetric('Outstanding', '\$${outstanding.toStringAsFixed(2)}'),
                      _referralAdminMetric('Records', '${docs.length}'),
                    ]),
                    const SizedBox(height: 12),
                    if (docs.isEmpty) Text('No qualified referral earnings recorded yet.', style: TextStyle(color: AppTheme.textMuted, fontSize: 11))
                    else for (final doc in docs.take(100)) _adminReferralRewardTile(doc),
                  ]),
                );
              },
            ),
            const SizedBox(height: 14),
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: ReferralService.watchAdminStats(),
              builder: (context, snapshot) {
                if (snapshot.hasError) return const SizedBox.shrink();
                final docs = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xAA11191B)), borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.fillFaint)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('REFERRER PERFORMANCE', style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: .6)),
                    const SizedBox(height: 8),
                    if (docs.isEmpty) Text('No qualified referrers yet.', style: TextStyle(color: AppTheme.textMuted, fontSize: 11))
                    else for (final doc in docs.take(50)) _adminReferralStatTile(doc),
                  ]),
                );
              },
            ),
          ],
        );
      },
    );
  }

  Widget _referralAdminMetric(String label, String value) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: .035), borderRadius: BorderRadius.circular(11), border: Border.all(color: AppTheme.fillFaint)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)), const SizedBox(height: 2), Text(label, style: TextStyle(color: AppTheme.textMuted, fontSize: 8))]),
      );

  Widget _adminReferralNotificationTile(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data();
    final status = (d['status'] ?? 'unread').toString();
    final referrer = (d['referrerUsername'] ?? 'Unknown referrer').toString();
    final referrerUid = (d['referrerUid'] ?? '').toString();
    final referred = (d['referredUsername'] ?? 'Unknown user').toString();
    final referredUid = (d['referredUid'] ?? '').toString();
    final incentive = ((d['incentiveAmountUsd'] as num?)?.toDouble() ?? double.tryParse('${d['incentiveAmountUsd']}') ?? 0).toStringAsFixed(2);
    return Card(
      color: status == 'read' ? AppTheme.adaptiveSurface(Color(0xFF101619)) : const Color(0x221F8A5B),
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        dense: true,
        leading: Icon(status == 'read' ? Icons.link_rounded : Icons.notifications_active_rounded, color: AppTheme.luxuryGold),
        title: Text('$referred → $referrer • +\$$incentive', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 11)),
        subtitle: Text('Referred UID: $referredUid\nReferrer UID: $referrerUid\n${d['planName'] ?? d['product'] ?? 'Purchase'}', style: TextStyle(color: AppTheme.textMuted, fontSize: 9, height: 1.35)),
        trailing: status == 'read' ? const Icon(Icons.check_rounded, size: 17) : TextButton(onPressed: () async { try { await FirebaseFirestore.instance.collection('referralAdminNotifications').doc(doc.id).update({'status': 'read', 'readAt': FieldValue.serverTimestamp()}); } catch (_) {} }, child: const Text('READ')),
      ),
    );
  }

  Widget _adminReferralRewardTile(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data();
    final status = (d['status'] ?? 'earned').toString();
    final amount = ((d['incentiveAmountUsd'] as num?)?.toDouble() ?? double.tryParse('${d['incentiveAmountUsd']}') ?? 0).toStringAsFixed(2);
    final referred = (d['referredUsername'] ?? d['referredUid'] ?? 'User').toString();
    final referrer = (d['referrerUsername'] ?? d['referrerUid'] ?? 'Referrer').toString();
    return Card(
      color: AppTheme.adaptiveSurface(Color(0xFF101619)),
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        dense: true,
        title: Text('$referrer • $referred • +\$$amount', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 11)),
        subtitle: Text('Referrer UID: ${d['referrerUid'] ?? ''}\nReferred UID: ${d['referredUid'] ?? ''}\n${d['planName'] ?? d['planId'] ?? ''} • ${d['incentiveType'] ?? ''}\nStatus: ${status.toUpperCase()}', style: TextStyle(color: AppTheme.textMuted, fontSize: 9, height: 1.35)),
        trailing: status == 'paid' ? const Icon(Icons.check_circle_rounded, color: AppTheme.neonGreen) : FilledButton(onPressed: () async { try { await ReferralService.adminMarkRewardPaid(doc.id); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Referral incentive marked as paid.'))); } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not mark incentive paid: $e'))); } }, child: const Text('MARK PAID')),
      ),
    );
  }

  Widget _adminReferralStatTile(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data();
    final name = (d['referrerUsername'] ?? doc.id).toString();
    final count = (d['qualifiedReferrals'] ?? d['totalReferrals'] ?? 0).toString();
    final earned = ((d['totalEarnedUsd'] as num?)?.toDouble() ?? double.tryParse('${d['totalEarnedUsd']}') ?? 0).toStringAsFixed(2);
    final paid = ((d['totalPaidUsd'] as num?)?.toDouble() ?? double.tryParse('${d['totalPaidUsd']}') ?? 0).toStringAsFixed(2);
    final outstanding = ((d['outstandingUsd'] as num?)?.toDouble() ?? double.tryParse('${d['outstandingUsd']}') ?? 0).toStringAsFixed(2);
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: const Icon(Icons.people_alt_outlined, color: AppTheme.luxuryGold),
      title: Text('$name • $count qualified referrals', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 11)),
      subtitle: Text('UID: ${doc.id}\nMentorship: \$${((d['mentorshipEarningsUsd'] as num?)?.toDouble() ?? 0).toStringAsFixed(2)} • Premium Monthly: \$${((d['premiumMonthlyEarningsUsd'] as num?)?.toDouble() ?? 0).toStringAsFixed(2)} • Lifetime: \$${((d['premiumLifetimeEarningsUsd'] as num?)?.toDouble() ?? 0).toStringAsFixed(2)}', style: TextStyle(color: AppTheme.textMuted, fontSize: 9, height: 1.35)),
      trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [Text('Earned \$$earned', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 9)), Text('Paid \$$paid', style: TextStyle(color: AppTheme.neonGreen, fontSize: 8)), Text('Due \$$outstanding', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 8))]),
    );
  }

  Widget _buildReferralPayoutDetails() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const SizedBox.shrink();
    return FutureBuilder<bool>(
      future: _hasFirebaseAdminClaim(user),
      builder: (context, claimSnapshot) {
        if (claimSnapshot.data != true) return const SizedBox.shrink();
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('referral_payment_details').limit(200).snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) return Text('Referral payout details could not be loaded. Check Firestore rules.', style: TextStyle(color: AppTheme.textMuted, fontSize: 11));
        final docs = snapshot.data?.docs ?? const [];
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xAA11191B)), borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: .2))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(Icons.card_giftcard_rounded, color: AppTheme.luxuryGold, size: 20), SizedBox(width: 8), Expanded(child: Text('REFERRAL PAYOUT DETAILS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .6)))]),
            const SizedBox(height: 5),
            Text('Creator-submitted USDT destinations and Pakistan PKR payment details for qualified referral incentives.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)),
            const SizedBox(height: 12),
            if (docs.isEmpty) Text('No payout details submitted yet.', style: TextStyle(color: AppTheme.textMuted, fontSize: 11)),
            for (final doc in docs) _adminReferralPayoutTile(doc),
          ]),
        );
      },
    );
      },
    );
  }

  Widget _adminReferralPayoutTile(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data();
    String value(String key) => (d[key] ?? '').toString().trim();
    Widget row(String label, String val) => val.isEmpty ? const SizedBox.shrink() : Padding(padding: const EdgeInsets.only(top: 4), child: Text('$label: $val', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10, height: 1.35)));
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: .025), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.fillFaint)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value('recipientName').isEmpty ? doc.id : value('recipientName'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 11)),
        row('UID', value('uid')),
        row('Country', value('country')),
        row('Preferred', value('preferredMethod')),
        row('Payment note', value('country') == 'Pakistan' ? 'Easypaisa = direct PKR payments' : 'USDT crypto payouts only'),
        row('USDT TRC-20', value('usdtTrc20Address')),
        row('USDT BEP-20', value('usdtBep20Address')),
        row('USDT ERC-20', value('usdtErc20Address')),
        row('Easypaisa', value('easypaisaNumber')),
        row('Status', value('status')),
        const SizedBox(height: 4),
        Text('Review the submitted destination before sending the applicable referral reward.', style: TextStyle(color: AppTheme.luxuryGold.withValues(alpha: .75), fontSize: 9)),
      ]),
    );
  }

  Widget _buildActivity() {
    return _panel(
      title: 'Posts & Community Activity',
      icon: Icons.dynamic_feed_outlined,
      child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('feed_posts')
            .where('isPublished', isEqualTo: true)
            .orderBy('createdAt', descending: true)
            .limit(50)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()));
          if (snapshot.hasError) return Text('Unable to load live activity: ${snapshot.error}', style: TextStyle(color: AppTheme.textMuted));
          final docs = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
          if (docs.isEmpty) return Padding(padding: EdgeInsets.symmetric(vertical: 18), child: Text('No real community activity found yet.', style: TextStyle(color: AppTheme.textMuted)));
          return Column(children: docs.map(_realActivityTile).toList());
        },
      ),
    );
  }

  Widget _buildVerifications() {
    return _panel(
      title: 'Verification Requests',
      icon: Icons.verified_user_outlined,
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 18),
        child: Text('No live verification requests are connected yet.', style: TextStyle(color: AppTheme.textMuted)),
      ),
    );
  }

  Widget _buildReports() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _panel(
          title: 'Support Tickets',
          icon: Icons.support_agent_rounded,
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: CustomerSupportService.allTickets(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(18), child: Center(child: CircularProgressIndicator()));
              if (snapshot.hasError) return Text('Unable to load support tickets: ${snapshot.error}', style: TextStyle(color: AppTheme.textMuted));
              final docs = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
              if (docs.isEmpty) return Text('No support tickets have been submitted.', style: TextStyle(color: AppTheme.textMuted));
              return Column(children: docs.map((doc) => _SupportTicketTile(doc: doc, isAdmin: true)).toList());
            },
          ),
        ),
        const SizedBox(height: 14),
        _panel(
          title: 'Reports & Moderation',
      icon: Icons.flag_outlined,
      child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('content_reports')
            .orderBy('createdAt', descending: true)
            .limit(100)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()));
          if (snapshot.hasError) return Text('Unable to load real reports: ${snapshot.error}', style: TextStyle(color: AppTheme.textMuted));
          final docs = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
          if (docs.isEmpty) return Padding(padding: EdgeInsets.symmetric(vertical: 22), child: Center(child: Text('No reports have been submitted.', style: TextStyle(color: AppTheme.textMuted))));
          return Column(children: docs.map(_realReportTile).toList());
        },
      ),
        ),
      ],
    );
  }

  Widget _realReportTile(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data();
    final type = (data['type'] ?? 'content').toString();
    final reason = (data['reason'] ?? 'No reason supplied').toString();
    final details = (data['details'] ?? '').toString().trim();
    final reporterUid = (data['reporterUid'] ?? 'Unknown').toString();
    final postId = (data['postId'] ?? '').toString();
    final commentId = (data['commentId'] ?? '').toString();
    final status = (data['status'] ?? 'open').toString();
    final ts = data['createdAt'];
    final created = ts is Timestamp ? _formatAdminDateTime(ts.toDate()) : 'Time unavailable';
    final high = reason.toLowerCase().contains('fraud') || reason.toLowerCase().contains('scam');
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xAA11191B)), borderRadius: BorderRadius.circular(15), border: Border.all(color: high ? const Color(0x66FF5252) : AppTheme.fillFaint)),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(high ? Icons.warning_amber : Icons.flag_outlined, color: high ? Colors.redAccent : AppTheme.luxuryGold),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(reason, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text('Type: $type • Status: $status', style: TextStyle(color: AppTheme.textMuted, fontSize: 12)),
                Text('Reporter UID: $reporterUid', style: TextStyle(color: AppTheme.textMuted, fontSize: 11)),
                if (postId.isNotEmpty) Text('Post: $postId', style: TextStyle(color: AppTheme.textFaint, fontSize: 10)),
                if (commentId.isNotEmpty) Text('Comment: $commentId', style: TextStyle(color: AppTheme.textFaint, fontSize: 10)),
                if (details.isNotEmpty) Text(details, style: TextStyle(color: AppTheme.textSecondary)),
                const SizedBox(height: 4),
                Text(created, style: TextStyle(color: AppTheme.textFaint, fontSize: 10)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControls() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _panel(
          title: 'Graduated Badge Vault • 25 Admin Badges',
          icon: Icons.school_rounded,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Twenty-five official Graduated badges are reserved here. Select any registered user, then send an available badge. The user receives it in CDH Mail, collects it, and the public profile shows the black graduation cap.',
                style: TextStyle(color: AppTheme.textMuted, fontSize: 10.5, height: 1.4),
              ),
              const SizedBox(height: 12),
              if (!_graduatedInventoryReady)
                const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: LinearProgressIndicator())
              else
                StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  stream: FirebaseFirestore.instance.collection('users').orderBy('createdAt', descending: true).limit(300).snapshots(),
                  builder: (context, usersSnap) {
                    if (usersSnap.hasError) return Text('Users could not be loaded: ${usersSnap.error}', style: TextStyle(color: AppTheme.textMuted, fontSize: 10));
                    final users = usersSnap.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
                    final validUsers = users.where((doc) => (doc.data()['role'] ?? 'user').toString() != 'admin').toList();
                    if (_selectedGraduatedTargetUid != null && !validUsers.any((d) => d.id == _selectedGraduatedTargetUid || (d.data()['uid'] ?? '').toString() == _selectedGraduatedTargetUid)) {
                      _selectedGraduatedTargetUid = null;
                    }
                    return DropdownButtonFormField<String>(
                      value: _selectedGraduatedTargetUid,
                      isExpanded: true,
                      decoration: const InputDecoration(labelText: 'SELECT USER TO RECEIVE THE BADGE'),
                      items: validUsers.map((doc) {
                        final data = doc.data();
                        final uid = (data['uid'] ?? doc.id).toString();
                        final name = (data['displayName'] ?? data['username'] ?? data['nickname'] ?? 'Unnamed User').toString();
                        final graduated = data['graduated'] == true;
                        return DropdownMenuItem<String>(value: uid, child: Text('$name • ${uid.substring(0, math.min(10, uid.length))}${graduated ? ' • ALREADY GRADUATED' : ''}', overflow: TextOverflow.ellipsis));
                      }).toList(),
                      onChanged: (value) => setState(() => _selectedGraduatedTargetUid = value),
                    );
                  },
                ),
              const SizedBox(height: 14),
              StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: BadgeService.watchGraduatedBadgeInventory(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) return Text('Graduated badge inventory could not be loaded: ${snapshot.error}', style: TextStyle(color: AppTheme.textMuted, fontSize: 10));
                  if (!snapshot.hasData) return const Center(child: Padding(padding: EdgeInsets.all(18), child: CircularProgressIndicator()));
                  final docs = snapshot.data!.docs;
                  final assigned = docs.where((d) => (d.data()['status'] ?? '') == 'assigned').length;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${docs.length}/25 badges loaded • $assigned assigned • ${docs.length - assigned} available', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 11, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: docs.map((doc) {
                          final data = doc.data();
                          final number = (data['badgeNumber'] as num?)?.toInt() ?? 0;
                          final isAssigned = (data['status'] ?? '') == 'assigned';
                          final assignedUid = (data['assignedToUid'] ?? '').toString();
                          return Container(
                            width: 180,
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: isAssigned ? const Color(0x1800FF8A) : AppTheme.adaptiveSurface(const Color(0xAA11191B)),
                              borderRadius: BorderRadius.circular(13),
                              border: Border.all(color: isAssigned ? AppTheme.neonGreen.withValues(alpha: .28) : AppTheme.luxuryGold.withValues(alpha: .18)),
                            ),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Row(children: [
                                const Icon(Icons.school_rounded, size: 18, color: AppTheme.luxuryGold),
                                const SizedBox(width: 6),
                                Expanded(child: Text('GRADUATED #${number.toString().padLeft(2, '0')}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 10))),
                              ]),
                              const SizedBox(height: 6),
                              Text(isAssigned ? 'ASSIGNED\n$assignedUid' : 'AVAILABLE', style: TextStyle(color: isAssigned ? AppTheme.neonGreen : AppTheme.textMuted, fontSize: 9, height: 1.35, fontWeight: FontWeight.w800)),
                              if (!isAssigned) ...[
                                const SizedBox(height: 7),
                                SizedBox(width: double.infinity, child: FilledButton.icon(
                                  onPressed: _selectedGraduatedTargetUid == null ? null : () => _sendGraduatedBadge(number),
                                  icon: const Icon(Icons.send_rounded, size: 15),
                                  label: const Text('SEND TO USER', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900)),
                                )),
                              ],
                            ]),
                          );
                        }).toList(),
                      ),
                    ],
                  );
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        _panel(
          title: 'Admin Navigation & Controls',
          icon: Icons.tune,
          child: Column(
            children: [
              _controlRow(Icons.people_alt_outlined, 'User management', 'View individual accounts and account status.'),
              _controlRow(Icons.payments_outlined, 'Payment control', 'Manual proof review and Admin approval only.'),
              _controlRow(Icons.verified_outlined, 'Creator verification', 'Review transaction proofs before verification.'),
              _controlRow(Icons.shield_outlined, 'Moderation', 'Review reports, scam warnings and abusive content.'),
              _controlRow(Icons.analytics_outlined, 'Activity audit', 'Review posts, comments, likes and reposts.'),
              _controlRow(Icons.lock_outline, 'Role enforcement', 'Admin access is enforced with the Firebase custom admin claim.'),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _sendGraduatedBadge(int badgeNumber) async {
    final uid = _selectedGraduatedTargetUid;
    if (uid == null || uid.isEmpty) return;
    try {
      await BadgeService.grantGraduatedBadge(badgeNumber: badgeNumber, targetUid: uid);
      if (!mounted) return;
      setState(() => _selectedGraduatedTargetUid = null);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Graduated Badge #${badgeNumber.toString().padLeft(2, '0')} sent. The user will receive it in CDH Mail.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not send Graduated badge: $e')));
    }
  }

  Widget _controlRow(IconData icon, String title, String subtitle) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: AppTheme.luxuryGold),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text(subtitle, style: TextStyle(color: AppTheme.textMuted)),
    );
  }
}

class _AdminUser {
  String name;
  final String email;
  String status;
  final String badge;
  final String joined;

  _AdminUser(this.name, this.email, this.status, this.badge, this.joined);
}

class _AdminPayment {
  final String name;
  final String email;
  final String plan;
  final String amount;
  final String txHash;
  String status;

  _AdminPayment(this.name, this.email, this.plan, this.amount, this.txHash, this.status);
}

class _AdminActivity {
  final String username;
  final String type;
  final String detail;
  final String time;

  _AdminActivity(this.username, this.type, this.detail, this.time);
}

class _AdminVerification {
  final String name;
  final String email;
  final String plan;
  final String amount;
  final String txHash;
  String status;

  _AdminVerification(this.name, this.email, this.plan, this.amount, this.txHash, this.status);
}

class _AdminReport {
  final String title;
  final String reporter;
  final String detail;
  final String severity;
  bool resolved;

  _AdminReport(this.title, this.reporter, this.detail, this.severity, this.resolved);
}


// ============================================================
// SHARED COMMUNITY FEED
// ============================================================

class _CommunityComment {
  final String id;
  final String authorUid;
  final String author;
  final String text;
  final bool creatorReply;
  final String? parentId;
  int likes;
  bool likedByMe = false;

  _CommunityComment({
    this.id = '',
    this.authorUid = '',
    required this.author,
    required this.text,
    this.creatorReply = false,
    this.parentId,
    this.likes = 0,
  });
}

class _CommunityPost {
  final String id;
  final String authorUid;
  final String username;
  final String nickname;
  final String profilePicUrl;
  final Uint8List? profilePicBytes;
  final String badge;
  final int referrals;
  final bool verified;
  final bool isPremium;
  final bool hasMentorship;
  final String premiumBadgeType;
  final String mentorshipBadgeType;
  String text;
  final Uint8List? imageBytes;
  final Uint8List? thumbnailBytes;
  final bool bullish;
  final List<String> hashtags;
  final List<String> coins;
  final String? signalAsset;
  final String? signalEntry;
  final bool? signalLongDirection;
  final int? signalLeverage;
  final String? signalTp1;
  final String? signalTp2;
  final String? signalTp3;
  final String? signalStopLoss;
  final String sourceType;
  final String? sourceId;
  final DateTime createdAt;
  bool tp1Hit, tp2Hit, tp3Hit, stopLossHit, breakEven, winTradeCounted;
  String tp1Profit, tp2Profit, tp3Profit, stopLossProfit, breakEvenProfit;
  bool tradeClosed = false;
  bool closedGreen = false;
  double finalProfitPercentage = 0;
  String resultPercentage = '';
  Uint8List? winResultImageBytes;
  int winTrades;
  final List<_CommunityComment> commentItems;
  int likes = 0;
  int comments = 0;
  int reposts = 0;
  int followers = 0;
  int views = 0;

  _CommunityPost({
    required this.id,
    this.authorUid = '',
    required this.username,
    this.nickname = '',
    required this.profilePicUrl,
    this.profilePicBytes,
    required this.badge,
    required this.referrals,
    required this.verified,
    this.isPremium = false,
    this.hasMentorship = false,
    this.premiumBadgeType = '',
    this.mentorshipBadgeType = '',
    required this.text,
    required this.imageBytes,
    required this.thumbnailBytes,
    required this.bullish,
    required this.hashtags,
    required this.coins,
    this.signalAsset,
    this.signalEntry,
    this.signalLongDirection,
    this.signalLeverage,
    this.signalTp1,
    this.signalTp2,
    this.signalTp3,
    this.signalStopLoss,
    this.sourceType = 'community',
    this.sourceId,
    this.tp1Hit = false, this.tp2Hit = false, this.tp3Hit = false, this.stopLossHit = false, this.breakEven = false, this.winTradeCounted = false,
    this.tp1Profit = '', this.tp2Profit = '', this.tp3Profit = '', this.stopLossProfit = '', this.breakEvenProfit = '',
    this.winResultImageBytes,
    this.winTrades = 0,
    DateTime? createdAt,
    List<_CommunityComment>? commentItems,
  })  : createdAt = createdAt ?? DateTime.now(),
        commentItems = commentItems ?? <_CommunityComment>[];
}

final ValueNotifier<List<_CommunityPost>> _communityFeed =
    ValueNotifier<List<_CommunityPost>>(<_CommunityPost>[]);

String _referralBadgeLabel(int referrals) {
  if (referrals >= 100) return 'PLATINUM';
  if (referrals >= 25) return 'GOLD';
  if (referrals >= 5) return 'SILVER';
  return 'BRONZE';
}

Future<Uint8List?> _pickImageBytes() async {
  try {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 68,
      maxWidth: 1280,
      maxHeight: 1280,
    );
    if (picked == null) return null;
    final bytes = await picked.readAsBytes();
    if (bytes.isEmpty) return null;
    if (bytes.length > 600000) return null;
    return bytes;
  } catch (_) {
    return null;
  }
}

Uint8List? _tryDecodeBase64(String value) {
  try { return base64Decode(value); } catch (_) { return null; }
}

String? _safeImageBase64(Uint8List? bytes) {
  if (bytes == null || bytes.isEmpty) return null;
  // Firestore documents are limited in size. Keep embedded images conservative
  // so a post can be persisted reliably without exceeding the document limit.
  if (bytes.length > 600000) return null;
  return base64Encode(bytes);
}

Future<String> _publishToCommunityFeed(_CommunityPost post, {String sourceType = 'alpha_den', String? sourceId}) async {
  final user = FirebaseAuth.instance.currentUser;
  var localPost = post;
  var persistedId = post.id;

  // Persist first. The Firestore document id is the single identity used by
  // the local feed as well, so returning from Alpha Den can never create a
  // duplicate card for the same backend post.
  if (user != null) {
    persistedId = await FeedService.createPost(FeedPostModel(
      id: '', authorUid: user.uid, authorDisplayName: post.username,
      authorPhotoUrl: post.profilePicUrl, authorPhotoBase64: _safeImageBase64(post.profilePicBytes), badge: post.badge, referralsCount: post.referrals, verified: post.verified,
      text: post.text, bullish: post.bullish, hashtags: post.hashtags, coins: post.coins,
      signalAsset: post.signalAsset, signalEntry: post.signalEntry, signalLongDirection: post.signalLongDirection,
      signalLeverage: post.signalLeverage, signalTp1: post.signalTp1, signalTp2: post.signalTp2, signalTp3: post.signalTp3,
      signalStopLoss: post.signalStopLoss, imageBase64: _safeImageBase64(post.imageBytes),
      articleTitle: sourceType == 'article' ? (post.text.split('\n\n').isNotEmpty ? post.text.split('\n\n').first : null) : null,
      articleBody: sourceType == 'article' ? (post.text.split('\n\n').length > 1 ? post.text.split('\n\n').sublist(1).join('\n\n') : post.text) : null,
      articleThumbnailBase64: null,
      createdAt: post.createdAt, likesCount: post.likes, commentsCount: post.comments,
      tp1Hit: post.tp1Hit, tp2Hit: post.tp2Hit, tp3Hit: post.tp3Hit, stopLossHit: post.stopLossHit, breakEven: post.breakEven, winTradeCounted: post.winTradeCounted,
      tp1Profit: post.tp1Profit, tp2Profit: post.tp2Profit, tp3Profit: post.tp3Profit, stopLossProfit: post.stopLossProfit, breakEvenProfit: post.breakEvenProfit,
      winResultImageBase64: _safeImageBase64(post.winResultImageBytes),
      winTrades: post.winTrades,
      repostsCount: post.reposts, followersCount: post.followers, viewsCount: post.views,
      sourceType: sourceType,
      sourceId: sourceId ?? post.id, isPublished: true,
    ));
    localPost = _CommunityPost(
      id: persistedId,
      authorUid: post.authorUid, username: post.username, nickname: post.nickname, profilePicUrl: post.profilePicUrl,
      profilePicBytes: post.profilePicBytes, badge: post.badge, referrals: post.referrals, verified: post.verified, isPremium: post.isPremium,
      text: post.text, imageBytes: post.imageBytes, thumbnailBytes: post.thumbnailBytes,
      bullish: post.bullish, hashtags: post.hashtags, coins: post.coins,
      signalAsset: post.signalAsset, signalEntry: post.signalEntry,
      signalLongDirection: post.signalLongDirection, signalLeverage: post.signalLeverage,
      signalTp1: post.signalTp1, signalTp2: post.signalTp2, signalTp3: post.signalTp3,
      signalStopLoss: post.signalStopLoss, sourceType: sourceType, sourceId: sourceId ?? post.sourceId, createdAt: post.createdAt,
      tp1Hit: post.tp1Hit, tp2Hit: post.tp2Hit, tp3Hit: post.tp3Hit, stopLossHit: post.stopLossHit, breakEven: post.breakEven, winTradeCounted: post.winTradeCounted,
      tp1Profit: post.tp1Profit, tp2Profit: post.tp2Profit, tp3Profit: post.tp3Profit, stopLossProfit: post.stopLossProfit, breakEvenProfit: post.breakEvenProfit,
      winResultImageBytes: post.winResultImageBytes,
      winTrades: post.winTrades,
      commentItems: post.commentItems,
    )
      ..likes = post.likes
      ..comments = post.comments
      ..reposts = post.reposts
      ..followers = post.followers
      ..views = post.views;
  }

  final next = <_CommunityPost>[localPost, ..._communityFeed.value];
  next.sort((a, b) => b.createdAt.compareTo(a.createdAt));
  _communityFeed.value = next;
  return persistedId;
}


// ============================================================
// FEED
// ============================================================

class FeedPage extends StatefulWidget {
  final bool isAdmin;

  const FeedPage({super.key, this.isAdmin = false});

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  List<FeedPostModel> _backendPosts = const <FeedPostModel>[];
  final Map<String, Map<String, dynamic>> _publicAlphaProfiles = <String, Map<String, dynamic>>{};
  final Map<String, bool> _publicPremiumByUid = <String, bool>{};
  final Map<String, bool> _publicMentorshipByUid = <String, bool>{};
  final Map<String, String> _publicPremiumBadgeByUid = <String, String>{};
  final Map<String, String> _publicMentorshipBadgeByUid = <String, String>{};
  List<_CommunityPost> _localPosts = const <_CommunityPost>[];
  bool _loading = true;
  String? _loadError;

  @override
  void initState() {
    super.initState();
    _localPosts = List<_CommunityPost>.of(_communityFeed.value);
    _communityFeed.addListener(_onLocalFeedChanged);
    _loadFeed();
  }

  void _onLocalFeedChanged() {
    if (!mounted) return;
    final next = List<_CommunityPost>.of(_communityFeed.value);
    setState(() => _localPosts = next);
  }

  @override
  void dispose() {
    _communityFeed.removeListener(_onLocalFeedChanged);
    super.dispose();
  }

  Future<void> _loadFeed() async {
    try {
      final general = await FeedService.loadFeed(limit: 500);
      var merged = <String, FeedPostModel>{
        for (final post in general) post.id: post,
      };

      // Keep the existing Alpha Den fallback, but never let it control the
      // lifetime of the Feed widget itself.
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        try {
          final alpha = await AlphaDenService.loadPosts(user.uid);
          for (final data in alpha) {
            final id = (data['id'] ?? '').toString();
            if (id.isEmpty) continue;
            merged[id] = FeedPostModel.fromData(id, data);
          }
        } catch (_) {
          // General feed data is still valid if the Alpha Den fallback fails.
        }
      }

      final result = merged.values.toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

      // Alpha Den identity is public. Load the current public profile for
      // Alpha Den authors so Feed shows the nickname beside the crown/tick
      // and the @username underneath, rather than freezing an old snapshot.
      final authorUids = result
          .where((p) => p.authorUid.trim().isNotEmpty)
          .map((p) => p.authorUid)
          .toSet()
          .toList();
      final publicProfiles = <String, Map<String, dynamic>>{};
      final publicPremium = <String, bool>{};
      final publicMentorship = <String, bool>{};
      final publicPremiumBadges = <String, String>{};
      final publicMentorshipBadges = <String, String>{};
      for (var i = 0; i < authorUids.length; i += 30) {
        final chunk = authorUids.skip(i).take(30).toList();
        if (chunk.isEmpty) continue;
        try {
          final snap = await FirebaseFirestore.instance
              .collection('users')
              .where(FieldPath.documentId, whereIn: chunk)
              .get();
          for (final doc in snap.docs) {
            final data = doc.data();
            final raw = data['alphaDenProfile'];
            if (raw is Map) publicProfiles[doc.id] = Map<String, dynamic>.from(raw);
            publicPremium[doc.id] = data['isPremium'] == true;
            publicMentorship[doc.id] = data['mentorshipApproved'] == true || data['isMentorship'] == true || data['mentorship'] == true || data['studentApproved'] == true || data['isStudent'] == true;
            final premiumBadge = (data['confirmedPremiumBadgeType'] ?? '').toString();
            final mentorshipBadge = (data['confirmedMentorshipBadgeType'] ?? '').toString();
            if (premiumBadge.isNotEmpty) publicPremiumBadges[doc.id] = premiumBadge;
            if (mentorshipBadge.isNotEmpty) publicMentorshipBadges[doc.id] = mentorshipBadge;
          }
        } catch (_) {}
      }

      if (!mounted) return;
      setState(() {
        _backendPosts = result;
        _publicAlphaProfiles
          ..clear()
          ..addAll(publicProfiles);
        _publicPremiumByUid
          ..clear()
          ..addAll(publicPremium);
        _publicMentorshipByUid
          ..clear()
          ..addAll(publicMentorship);
        _publicPremiumBadgeByUid
          ..clear()
          ..addAll(publicPremiumBadges);
        _publicMentorshipBadgeByUid
          ..clear()
          ..addAll(publicMentorshipBadges);
        _loading = false;
        _loadError = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _loadError = error.toString();
      });
    }
  }

  Future<void> _refresh() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _loadError = null;
    });
    await _loadFeed();
  }

  _CommunityPost _toCommunity(FeedPostModel p) {
    final publicProfile = _publicAlphaProfiles[p.authorUid];
    final publicUsername = (publicProfile?['username'] ?? p.authorDisplayName).toString();
    final publicNickname = (publicProfile?['nickname'] ?? publicProfile?['handle'] ?? '').toString();
    final publicReferrals = (publicProfile?['referrals'] as num?)?.toInt() ?? p.referralsCount;
    final publicWinTrades = (publicProfile?['winTrades'] as num?)?.toInt() ?? p.winTrades;
    final publicVerified = publicProfile?['verifiedCreatorApproved'] == true || p.verified;
    final publicPhoto = (publicProfile?['profilePicUrl'] ?? p.authorPhotoUrl).toString();
    return _CommunityPost(
    id: p.id, authorUid: p.authorUid, username: publicUsername, nickname: publicNickname, profilePicUrl: publicPhoto,
    badge: p.badge, referrals: publicReferrals, verified: publicVerified, isPremium: _publicPremiumByUid[p.authorUid] == true, hasMentorship: _publicMentorshipByUid[p.authorUid] == true, premiumBadgeType: _publicPremiumBadgeByUid[p.authorUid] ?? '', mentorshipBadgeType: _publicMentorshipBadgeByUid[p.authorUid] ?? '', text: p.text,
    imageBytes: p.imageBase64 == null ? null : base64Decode(p.imageBase64!), thumbnailBytes: null,
    profilePicBytes: p.authorPhotoBase64 == null || p.authorPhotoBase64!.isEmpty ? null : _tryDecodeBase64(p.authorPhotoBase64!),
    bullish: p.bullish, hashtags: p.hashtags, coins: p.coins, createdAt: p.createdAt,
    signalAsset: p.signalAsset, signalEntry: p.signalEntry, signalLongDirection: p.signalLongDirection,
    signalLeverage: p.signalLeverage, signalTp1: p.signalTp1, signalTp2: p.signalTp2, signalTp3: p.signalTp3, signalStopLoss: p.signalStopLoss,
    tp1Hit: p.tp1Hit, tp2Hit: p.tp2Hit, tp3Hit: p.tp3Hit, stopLossHit: p.stopLossHit, breakEven: p.breakEven, winTradeCounted: p.winTradeCounted,
    tp1Profit: p.tp1Profit ?? '', tp2Profit: p.tp2Profit ?? '', tp3Profit: p.tp3Profit ?? '', stopLossProfit: p.stopLossProfit ?? '', breakEvenProfit: p.breakEvenProfit ?? '',
    winResultImageBytes: p.winResultImageBase64 == null || p.winResultImageBase64!.isEmpty ? null : _tryDecodeBase64(p.winResultImageBase64!),
    winTrades: publicWinTrades,
  )..likes = p.likesCount
   ..comments = p.commentsCount
   ..reposts = p.repostsCount
   ..followers = p.followersCount
   ..views = p.viewsCount;
  }

  List<_CommunityPost> _mergedPosts() {
    final merged = <String, _CommunityPost>{};
    for (final post in _localPosts) {
      if (post.id.isNotEmpty) merged[post.id] = post;
    }
    for (final post in _backendPosts) {
      final community = _toCommunity(post);
      final key = post.id.isNotEmpty
          ? post.id
          : ((post.sourceId?.isNotEmpty ?? false) ? post.sourceId! : community.id);

      // Preserve the in-memory comment state when a fresh feed snapshot
      // arrives. The backend post payload does not contain the comment
      // subcollection, so rebuilding this object must never wipe comments
      // that were just posted successfully.
      final existing = merged[key];
      if (existing != null) {
        for (final comment in existing.commentItems) {
          if (!community.commentItems.any((c) => c.id == comment.id)) {
            community.commentItems.add(comment);
          }
        }
        community.comments = community.comments < existing.comments ? existing.comments : community.comments;
      }
      merged[key] = community;
    }
    final posts = merged.values.toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return posts;
  }

  @override
  Widget build(BuildContext context) {
    final posts = _mergedPosts();

    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
        children: [
          const Align(
            alignment: Alignment.centerLeft,
            child: _GalacticFeedHeading(),
          ),
          const SizedBox(height: 8),
          const LiveMarketPreview(),
          const SizedBox(height: 6),
          _FeedQuickActions(isAdmin: widget.isAdmin),
          const SizedBox(height: 18),
          if (_loading && posts.isEmpty)
            const Padding(
              padding: EdgeInsets.all(18),
              child: Center(child: CircularProgressIndicator()),
            ),
          if (_loadError != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Text(
                'Community posts could not be refreshed. Your Feed is still available.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppTheme.textMuted, fontSize: 11),
              ),
            ),
          for (final post in posts)
            _CommunityPostCard(post: post),
        ],
      ),
    );
  }
}

class _FeedQuickActions extends StatelessWidget {
  final bool isAdmin;

  const _FeedQuickActions({this.isAdmin = false});

  @override
  Widget build(BuildContext context) {
    Widget tile(IconData icon, String label, VoidCallback onTap) => Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        child: Material(
          color: AppTheme.adaptiveSurface(Color(0xFF303238)),
          borderRadius: BorderRadius.circular(10),
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: onTap,
            child: SizedBox(
              height: 58,
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(icon, size: 19, color: AppTheme.textSoft),
                const SizedBox(height: 4),
                Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppTheme.textSecondary, fontSize: 8.5, fontWeight: FontWeight.w800)),
              ]),
            ),
          ),
        ),
      ),
    );
    return Row(children: [
      tile(Icons.school_outlined, 'MENTORSHIP', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _MentorshipInfoPage()))),
      tile(Icons.link_rounded, 'REFERRAL', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _ReferralCenterPage()))),
      _RewardsQuickAction(),
      tile(Icons.campaign_outlined, 'UPDATES', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _UpdatesPage()))),
    ]);
  }
}


class _RewardsQuickAction extends StatelessWidget {
  const _RewardsQuickAction();

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        child: Material(
          color: AppTheme.adaptiveSurface(Color(0xFF303238)),
          borderRadius: BorderRadius.circular(10),
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _RewardsPage())),
            child: SizedBox(
              height: 58,
              child: Stack(
                children: [
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.card_giftcard_rounded, size: 19, color: AppTheme.textSoft),
                        SizedBox(height: 4),
                        Text('REWARDS', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppTheme.textSecondary, fontSize: 8.5, fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                  if (uid != null)
                    Positioned(
                      top: 7,
                      right: 8,
                      child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                        stream: BadgeService.watchBadgeEntitlements(uid),
                        builder: (context, snapshot) {
                          final pending = snapshot.hasData && snapshot.data!.docs.any((doc) {
                            final status = (doc.data()['status'] ?? '').toString();
                            return status == 'available' || status == 'collected';
                          });
                          if (!pending) return const SizedBox.shrink();
                          return Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: const Color(0xFFE05252),
                              shape: BoxShape.circle,
                              border: Border.all(color: AppTheme.adaptiveSurface(Color(0xFF303238)), width: 1.2),
                            ),
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _RewardsPage extends StatelessWidget {
  const _RewardsPage();

  String _title(Map<String, dynamic> data) {
    switch ((data['badgeType'] ?? '').toString()) {
      case 'premium_lifetime': return 'Lifetime Premium';
      case 'premium_monthly': return 'Monthly Premium';
      case 'mentorship_installment': return 'Mentorship Installment';
      case 'mentorship_one_time': return 'Mentorship One-Time';
      case 'referral_crown_blue': return 'Blue Crown';
      case 'referral_crown_purple': return 'Purple Crown';
      case 'referral_crown_gold': return 'Golden Crown';
      case 'referral_crown_black_gold': return 'Black + Gold Crown';
      default: return (data['title'] ?? data['name'] ?? 'Crypto Doctors Hub Reward').toString();
    }
  }

  String _description(Map<String, dynamic> data) {
    switch ((data['badgeType'] ?? '').toString()) {
      case 'premium_lifetime': return 'Purple Lifetime Star badge.';
      case 'premium_monthly': return 'Normal Premium Star badge.';
      case 'mentorship_installment': return 'White Student 1 installment badge.';
      case 'mentorship_one_time': return 'Blue Student badge.';
      case 'referral_crown_blue': return 'Blue Crown • 1 qualified referral.';
      case 'referral_crown_purple': return 'Purple Crown • 3 qualified referrals.';
      case 'referral_crown_gold': return 'Golden Crown • 5 qualified referrals.';
      case 'referral_crown_black_gold': return 'Black + Gold Crown • 10 qualified referrals.';
      default: return (data['description'] ?? 'A reward prepared for your account.').toString();
    }
  }

  IconData _icon(Map<String, dynamic> data) {
    return (data['badgeType'] ?? '').toString().startsWith('mentorship_')
        ? Icons.school_rounded
        : Icons.workspace_premium_rounded;
  }

  Color _color(Map<String, dynamic> data) {
    switch ((data['badgeType'] ?? '').toString()) {
      case 'premium_lifetime': return const Color(0xFFB56CFF);
      case 'graduated_admin': return Colors.black;
      case 'mentorship_installment_1':
      case 'mentorship_installment_2':
      case 'mentorship_installment_3':
      case 'mentorship_installment_4':
      case 'mentorship_installment': return Colors.white;
      case 'mentorship_one_time': return const Color(0xFF8DB0FF);
      case 'referral_crown_blue': return const Color(0xFF4FA8FF);
      case 'referral_crown_purple': return const Color(0xFFB86CFF);
      case 'referral_crown_gold': return const Color(0xFFFFD34D);
      case 'referral_crown_black_gold': return const Color(0xFFE7C76B);
      default: return AppTheme.luxuryGold;
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Scaffold(body: Center(child: Text('Please sign in again.')));
    return Scaffold(
      appBar: AppBar(title: const Text('REWARDS')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: BadgeService.watchBadgeEntitlements(user.uid),
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Rewards are temporarily unavailable.\\n\\n${snapshot.error}', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textMuted))));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = [...snapshot.data!.docs]..sort((a, b) => ((b.data()['createdAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0).compareTo((a.data()['createdAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0));
          final pending = docs.where((doc) {
            final status = (doc.data()['status'] ?? '').toString();
            return status == 'available' || status == 'collected';
          }).toList();
          final confirmed = docs.where((doc) => (doc.data()['status'] ?? '').toString() == 'confirmed').toList();
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
            children: [
              if (pending.isNotEmpty) ...[
                const Text('COLLECT YOUR BADGES', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: .5)),
                const SizedBox(height: 6),
                Text('Your eligible rewards are waiting here. Collect them, preview your Alpha Den profile, then confirm the final badge placement.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.45)),
                const SizedBox(height: 14),
                for (final doc in pending) ...[
                  _RewardCard(
                    title: _title(doc.data()),
                    description: _description(doc.data()),
                    icon: _icon(doc.data()),
                    color: _color(doc.data()),
                    status: (doc.data()['status'] ?? '').toString(),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _BadgeCollectionPage(messageId: doc.id, badgeIds: [doc.id]))),
                  ),
                  const SizedBox(height: 10),
                ],
              ],
              if (pending.isEmpty && confirmed.isEmpty)
                GlassCard(child: Padding(padding: EdgeInsets.all(20), child: Column(children: [Icon(Icons.card_giftcard_rounded, color: AppTheme.luxuryGold, size: 38), SizedBox(height: 10), Text('NO REWARDS YET', style: TextStyle(fontWeight: FontWeight.w900)), SizedBox(height: 6), Text('Eligible rewards will appear here after secure backend verification.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.4))]))),
              if (confirmed.isNotEmpty) ...[
                const SizedBox(height: 8),
                const Text('COLLECTED & CONFIRMED', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: .5)),
                const SizedBox(height: 9),
                for (final doc in confirmed) ...[
                  _RewardCard(title: _title(doc.data()), description: _description(doc.data()), icon: _icon(doc.data()), color: _color(doc.data()), status: 'confirmed'),
                  const SizedBox(height: 10),
                ],
              ],
            ],
          );
        },
      ),
    );
  }
}

class _RewardCard extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;
  final Color color;
  final String status;
  final VoidCallback? onTap;

  const _RewardCard({required this.title, required this.description, required this.icon, required this.color, required this.status, this.onTap});

  @override
  Widget build(BuildContext context) {
    final ready = status == 'available' || status == 'collected';
    return GlassCard(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        leading: Container(width: 42, height: 42, decoration: BoxDecoration(shape: BoxShape.circle, color: color.withValues(alpha: .10), border: Border.all(color: color.withValues(alpha: .34))), child: Icon(icon, color: color, size: 23)),
        title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
        subtitle: Padding(padding: const EdgeInsets.only(top: 4), child: Text(description, style: TextStyle(color: AppTheme.textMuted, fontSize: 9.5, height: 1.35))),
        trailing: ready ? FilledButton(onPressed: onTap, style: FilledButton.styleFrom(backgroundColor: AppTheme.textPrimary, foregroundColor: Colors.black), child: Text(status == 'collected' ? 'CONTINUE' : 'COLLECT')) : Icon(Icons.check_circle_rounded, color: AppTheme.neonGreen),
      ),
    );
  }
}



class _UpdatesPage extends StatelessWidget {
  const _UpdatesPage();

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('UPDATES')),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
      children: [
        GlassCard(
          child: ListTile(
            leading: Icon(Icons.mail_outline_rounded, color: AppTheme.luxuryGold),
            title: const Text('MAIL', style: TextStyle(fontWeight: FontWeight.w900)),
            subtitle: Text('Badge notifications, payment confirmations, reports and official account messages.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _MailPage())),
          ),
        ),
        const SizedBox(height: 10),
        GlassCard(
          child: ListTile(
            leading: Icon(Icons.campaign_outlined, color: AppTheme.luxuryGold),
            title: Text('PRODUCT UPDATES', style: TextStyle(fontWeight: FontWeight.w900)),
            subtitle: Text('Product updates, new features and community announcements will appear here.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)),
          ),
        ),
      ],
    ),
  );
}

class _MailPage extends StatelessWidget {
  const _MailPage();

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Scaffold(body: Center(child: Text('Please sign in again.')));
    return Scaffold(
      appBar: AppBar(title: const Text('MAIL')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: BadgeService.watchMail(user.uid),
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Mail is temporarily unavailable.\n\n${snapshot.error}', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textMuted))));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          if (docs.isEmpty) return Center(child: Text('No mail yet.', style: TextStyle(color: AppTheme.textMuted)));
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final data = doc.data();
              final badgeIds = ((data['badgeIds'] as List?) ?? const []).map((e) => e.toString()).toList();
              final isBadgeMail = (data['type'] ?? '').toString() == 'badge';
              final unread = data['readAt'] == null;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: GlassCard(
                  child: ListTile(
                    onTap: () async {
                      if (unread) {
                        try { await BadgeService.markMailRead(user.uid, doc.id); } catch (_) {}
                      }
                      if (isBadgeMail && badgeIds.isNotEmpty && context.mounted) {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => _BadgeCollectionPage(messageId: doc.id, badgeIds: badgeIds)));
                      }
                    },
                    leading: Icon(isBadgeMail ? Icons.workspace_premium_rounded : Icons.mail_outline_rounded, color: unread ? AppTheme.luxuryGold : AppTheme.textMuted),
                    title: Text((data['title'] ?? 'Crypto Doctors Hub').toString(), style: TextStyle(fontWeight: unread ? FontWeight.w900 : FontWeight.w700)),
                    subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text((data['body'] ?? '').toString(), style: TextStyle(color: AppTheme.textSoft, fontSize: 10, height: 1.4))),
                    trailing: isBadgeMail ? Icon(Icons.card_giftcard_rounded, color: AppTheme.luxuryGold) : null,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _BadgeCollectionPage extends StatelessWidget {
  final String messageId;
  final List<String> badgeIds;
  const _BadgeCollectionPage({required this.messageId, required this.badgeIds});

  String _badgeTitle(Map<String, dynamic> data) {
    switch ((data['badgeType'] ?? '').toString()) {
      case 'premium_lifetime': return 'Lifetime';
      case 'mentorship_installment_1': return 'Student 1';
      case 'mentorship_installment_2': return 'Student 2';
      case 'mentorship_installment_3': return 'Student 3';
      case 'mentorship_installment_4': return 'Student 4';
      case 'mentorship_installment': return 'Student 1';
      case 'mentorship_one_time': return 'Student';
      case 'referral_crown_blue': return 'Blue Crown';
      case 'referral_crown_purple': return 'Purple Crown';
      case 'referral_crown_gold': return 'Golden Crown';
      case 'referral_crown_black_gold': return 'Black + Gold Crown';
      default: return 'Premium';
    }
  }

  IconData _badgeIcon(Map<String, dynamic> data) => (data['badgeType'] ?? '').toString().startsWith('mentorship_') ? Icons.school_rounded : Icons.workspace_premium_rounded;

  Color _badgeColor(Map<String, dynamic> data) {
    switch ((data['badgeType'] ?? '').toString()) {
      case 'premium_lifetime': return const Color(0xFFB56CFF);
      case 'graduated_admin': return Colors.black;
      case 'mentorship_installment_1':
      case 'mentorship_installment_2':
      case 'mentorship_installment_3':
      case 'mentorship_installment_4':
      case 'mentorship_installment': return Colors.white;
      case 'mentorship_one_time': return const Color(0xFF8DB0FF);
      default: return AppTheme.luxuryGold;
    }
  }

  Future<void> _collect(BuildContext context, String badgeId, Map<String, dynamic> data) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final status = (data['status'] ?? '').toString();
      Map<String, dynamic> collected = data;
      if (status == 'available') {
        collected = await BadgeService.collectBadge(uid: user.uid, badgeId: badgeId);
      } else if (status != 'collected') {
        return;
      }
      if (!context.mounted) return;
      if (status == 'available') {
        await showDialog<void>(
          context: context,
          barrierDismissible: false,
          builder: (_) => _BadgeRewardAnimation(data: {...data, ...collected}),
        );
      }
      if (!context.mounted) return;
      final confirmed = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _BadgeProfilePreview(data: data),
      );
      if (confirmed == true && context.mounted) {
        try {
          await BadgeService.confirmBadge(uid: user.uid, badgeId: badgeId, badgeType: (data['badgeType'] ?? '').toString());
          if (context.mounted) Navigator.pop(context);
        } catch (error) {
          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('The badge could not be confirmed yet: $error')));
        }
      }
    } catch (error) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('This badge is not ready to collect: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Scaffold(body: Center(child: Text('Please sign in again.')));
    return Scaffold(
      appBar: AppBar(title: const Text('EARNED BADGES')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: BadgeService.watchBadgeEntitlements(user.uid),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs.where((d) => badgeIds.contains(d.id)).toList();
          if (docs.isEmpty) return Center(child: Text('No collectible badges are ready.', style: TextStyle(color: AppTheme.textMuted)));
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
            children: [
              const Text('Congratulations! You have earned these badges.', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              Text('Collect each prepared badge, preview your Alpha Den profile, then confirm it.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.4)),
              const SizedBox(height: 16),
              for (final doc in docs) ...[
                Builder(builder: (context) {
                  final data = doc.data();
                  final status = (data['status'] ?? '').toString();
                  final color = _badgeColor(data);
                  return GlassCard(child: ListTile(
                    leading: Icon(_badgeIcon(data), color: color, size: 27),
                    title: Text(_badgeTitle(data), style: TextStyle(color: color, fontWeight: FontWeight.w900)),
                    subtitle: Text(status == 'confirmed' ? 'Confirmed and applied to your profile.' : status == 'collected' ? 'Collected — ready for profile confirmation.' : 'Ready to collect.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)),
                    trailing: status == 'available'
                        ? FilledButton(onPressed: () => _collect(context, doc.id, data), child: const Text('COLLECT'))
                        : status == 'collected'
                            ? FilledButton(onPressed: () => _collect(context, doc.id, data), child: const Text('CONTINUE'))
                            : Icon(Icons.check_circle_rounded, color: AppTheme.neonGreen),
                  ));
                }),
                const SizedBox(height: 10),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _BadgeRewardAnimation extends StatefulWidget {
  final Map<String, dynamic> data;
  const _BadgeRewardAnimation({required this.data});
  @override State<_BadgeRewardAnimation> createState() => _BadgeRewardAnimationState();
}

class _BadgeRewardAnimationState extends State<_BadgeRewardAnimation> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
  @override void dispose() { _controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final type = (widget.data['badgeType'] ?? '').toString();
    final graduated = type == 'graduated_admin';
    final color = type == 'premium_lifetime' ? const Color(0xFFB56CFF) : graduated ? Colors.black : type == 'referral_crown_blue' ? const Color(0xFF4FA8FF) : type == 'referral_crown_purple' ? const Color(0xFFB86CFF) : type == 'referral_crown_gold' ? const Color(0xFFFFD34D) : type == 'referral_crown_black_gold' ? const Color(0xFFE7C76B) : type.startsWith('mentorship_installment') ? const Color(0xFF8DB0FF) : type.startsWith('mentorship_') ? const Color(0xFF8DB0FF) : AppTheme.luxuryGold;
    final icon = type.startsWith('mentorship_') ? Icons.school_rounded : Icons.workspace_premium_rounded;
    final label = type == 'graduated_admin' ? 'GRADUATED' : type == 'premium_lifetime' ? 'LIFETIME' : type == 'referral_crown_blue' ? 'BLUE CROWN' : type == 'referral_crown_purple' ? 'PURPLE CROWN' : type == 'referral_crown_gold' ? 'GOLDEN CROWN' : type == 'referral_crown_black_gold' ? 'BLACK + GOLD CROWN' : type.startsWith('mentorship_installment') ? _studentBadgeLabel(type) : type == 'mentorship_one_time' ? 'STUDENT' : 'PREMIUM';
    return AlertDialog(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0B0F11)),
      content: AnimatedBuilder(animation: _controller, builder: (_, _) => Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('CONGRATULATIONS', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        const SizedBox(height: 18),
        Transform.scale(scale: 0.78 + _controller.value * 0.22, child: Icon(icon, color: color, size: 70)),
        const SizedBox(height: 10),
        Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1)),
        const SizedBox(height: 9),
        Text('Your badge has been collected. Next, preview how your Alpha Den profile will look.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSoft, fontSize: 10, height: 1.4)),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CONTINUE'))],
    );
  }
}

class _BadgeProfilePreview extends StatefulWidget {
  final Map<String, dynamic> data;
  const _BadgeProfilePreview({required this.data});

  @override
  State<_BadgeProfilePreview> createState() => _BadgeProfilePreviewState();
}

class _BadgeProfilePreviewState extends State<_BadgeProfilePreview> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..forward();
  bool _showConfirm = false;

  @override
  void initState() {
    super.initState();
    Future<void>.delayed(const Duration(milliseconds: 3900), () {
      if (mounted) setState(() => _showConfirm = true);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final type = (widget.data['badgeType'] ?? '').toString();
    final lifetime = type == 'premium_lifetime';
    final installment = type.startsWith('mentorship_installment');
    final graduated = type == 'graduated_admin';
    final referralCrown = type.startsWith('referral_crown_');
    final crownReferrals = type == 'referral_crown_blue' ? 1 : type == 'referral_crown_purple' ? 3 : type == 'referral_crown_gold' ? 5 : 10;
    final color = lifetime ? const Color(0xFFB56CFF) : graduated ? Colors.black : type == 'referral_crown_blue' ? const Color(0xFF4FA8FF) : type == 'referral_crown_purple' ? const Color(0xFFB86CFF) : type == 'referral_crown_gold' ? const Color(0xFFFFD34D) : type == 'referral_crown_black_gold' ? const Color(0xFFE7C76B) : installment ? const Color(0xFF8DB0FF) : type.startsWith('mentorship_') ? const Color(0xFF8DB0FF) : AppTheme.luxuryGold;
    final icon = type.startsWith('mentorship_') ? Icons.school_rounded : Icons.workspace_premium_rounded;
    final label = type == 'graduated_admin' ? 'GRADUATED' : type == 'referral_crown_blue' ? 'BLUE CROWN' : type == 'referral_crown_purple' ? 'PURPLE CROWN' : type == 'referral_crown_gold' ? 'GOLDEN CROWN' : type == 'referral_crown_black_gold' ? 'BLACK + GOLD CROWN' : lifetime ? 'LIFETIME' : installment ? _studentBadgeLabel(type) : type == 'mentorship_one_time' ? 'STUDENT' : 'PREMIUM';
    return AlertDialog(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0B0F11)),
      title: const Text('YOUR ALPHA DEN PROFILE WILL NOW LOOK LIKE THIS.'),
      content: AnimatedBuilder(
        animation: _controller,
        builder: (_, _) {
          final progress = Curves.easeOutCubic.transform(_controller.value);
          return GlassCard(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              CircleAvatar(radius: 28, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF111A24)), child: Icon(Icons.person, color: AppTheme.luxuryGold, size: 28)),
              const SizedBox(height: 12),
              const Text('@YOUR_USERNAME', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              Transform.scale(
                scale: .78 + (progress * .22),
                child: Opacity(
                  opacity: progress.clamp(0.0, 1.0),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: .10 * progress),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: color.withValues(alpha: .42 * progress)),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      if (referralCrown)
                        Transform.scale(scale: .82, child: _ReferralCrownBadge(referrals: crownReferrals, flamingAura: type == 'referral_crown_black_gold'))
                      else
                        Icon(icon, color: color, size: 22),
                      const SizedBox(width: 5),
                      Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 10)),
                    ]),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text('Congratulations! Your profile will now look like this. The badge animation shows where the new badge will appear after confirmation.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.4)),
            ]),
          );
        },
      ),
      actions: [
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: _showConfirm
              ? SizedBox(
                  key: const ValueKey('confirm'),
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () => Navigator.pop(context, true),
                    style: FilledButton.styleFrom(backgroundColor: AppTheme.textPrimary, foregroundColor: Colors.black),
                    child: const Text('CONFIRM', style: TextStyle(fontWeight: FontWeight.w900)),
                  ),
                )
              : const SizedBox(key: ValueKey('waiting'), height: 48),
        ),
      ],
    );
  }
}

Future<void> _openContentReportSupportPage(
  BuildContext context, {
  String? postId,
  String? commentId,
  String? authorUid,
}) async {
  final openCustomerSupport = await Navigator.of(context).push<bool>(MaterialPageRoute(
    builder: (_) => _ContentReportSupportPage(
      postId: postId,
      commentId: commentId,
      authorUid: authorUid,
    ),
  ));

  if (openCustomerSupport == true && context.mounted) {
    await showCustomerSupportSheet(context);
  }
}

String _articleAuthorUid(_AlphaDenArticle article) {
  return FirebaseAuth.instance.currentUser?.uid ?? '';
}

class _ContentReportSupportPage extends StatefulWidget {
  final String? postId;
  final String? commentId;
  final String? authorUid;
  const _ContentReportSupportPage({this.postId, this.commentId, this.authorUid});
  @override
  State<_ContentReportSupportPage> createState() => _ContentReportSupportPageState();
}

class _ContentReportSupportPageState extends State<_ContentReportSupportPage> {
  static const reasons = <String>[
    'Abusive language',
    'Explicit content',
    'Misinformation',
    'Misguiding',
    'Fraud',
  ];
  String? selectedReason;
  final details = TextEditingController();
  bool submitted = false;
  bool sending = false;

  @override
  void dispose() { details.dispose(); super.dispose(); }

  Future<void> _submit() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || selectedReason == null || sending) return;
    setState(() => sending = true);
    try {
      String? reportId;
      if ((widget.commentId ?? '').isNotEmpty && (widget.postId ?? '').isNotEmpty) {
        reportId = await FeedService.reportComment(postId: widget.postId!, commentId: widget.commentId!, reporterUid: user.uid, reason: selectedReason!, details: details.text.trim());
      } else if ((widget.postId ?? '').isNotEmpty) {
        reportId = await FeedService.reportPost(postId: widget.postId!, reporterUid: user.uid, reason: selectedReason!, details: details.text.trim());
      }
      if (reportId != null) {
        await CustomerSupportService.queueReportEmail(reportId: reportId, email: user.email ?? '', uid: user.uid);
      }
      if (!mounted) return;
      setState(() { sending = false; submitted = true; });
    } catch (_) {
      if (!mounted) return;
      setState(() => sending = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not submit the report. Please try again.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF070B10)),
      appBar: AppBar(title: const Text('CONTENT REPORT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1))),
      body: RadioGroup<String>(
        groupValue: selectedReason,
        onChanged: (value) {
          if (!submitted) setState(() => selectedReason = value);
        },
        child: ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 32), children: [
        const Text('REPORT CONTENT / USER', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        Text('Choose the reason that best describes the issue. Your report will be sent to moderation.', style: TextStyle(color: AppTheme.textSoft, fontSize: 12, height: 1.45)),
        const SizedBox(height: 16),
        for (final reason in reasons) Card(
          color: selectedReason == reason ? const Color(0x1A59D7FF) : AppTheme.adaptiveSurface(Color(0xFF15181E)),
          child: RadioListTile<String>(
            value: reason,
            enabled: !submitted,
            title: Text(reason, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            activeColor: AppTheme.luxuryGold,
          ),
        ),
        const SizedBox(height: 10),
        TextField(controller: details, maxLines: 4, enabled: !submitted, decoration: const InputDecoration(labelText: 'Additional details (optional)', hintText: 'Tell Customer Support what happened…')),
        const SizedBox(height: 16),
        if (!submitted)
          ElevatedButton.icon(onPressed: selectedReason == null || sending ? null : _submit, icon: const Icon(Icons.flag_outlined), label: Text(sending ? 'SUBMITTING…' : 'SUBMIT REPORT'))
        else ...[
          Icon(Icons.check_circle_outline, color: AppTheme.neonGreen, size: 42),
          const SizedBox(height: 8),
          const Center(child: Text('REPORT SUBMITTED', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.0))),
          const SizedBox(height: 6),
          Text('You can now continue with Customer Support if you need to provide more context.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSoft, fontSize: 11, height: 1.4)),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: () => Navigator.of(context).pop(true),
            icon: const Icon(Icons.support_agent_rounded),
            label: const Text('CONTACT CUSTOMER SUPPORT'),
          ),
        ],
      ]),
      ),
    );
  }
}

Future<void> showCustomerSupportSheet(BuildContext context) async {
  final options = <String>[
    'Account & Login', 'Premium & Payments', 'Alpha Den', 'CD Feed & Posts',
    'Technical Issue', 'Report Content / User', 'Feature Request', 'Submit a Ticket', 'My Tickets',
  ];
  await showModalBottomSheet<void>(
    context: context, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF070C12)),
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (sheetContext) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(sheetContext).size.height * 0.78),
          child: Column(children: [
            Container(width: 42, height: 4, decoration: BoxDecoration(color: AppTheme.borderSoft, borderRadius: BorderRadius.circular(8))),
            const SizedBox(height: 12),
            const Row(children: [Icon(Icons.support_agent_rounded, color: Color(0xFF59D7FF)), SizedBox(width: 9), Text('CUSTOMER SUPPORT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.0))]),
            const SizedBox(height: 8),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  ...options.map((label) => ListTile(
                    dense: true, contentPadding: EdgeInsets.zero, leading: Icon(Icons.chevron_right_rounded, color: AppTheme.textMuted), title: Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                    onTap: () {
                      Navigator.pop(sheetContext);
                      if (label == 'Report Content / User') {
                        _openContentReportSupportPage(context);
                      } else if (label == 'Submit a Ticket') {
                        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SubmitSupportTicketPage()));
                      } else if (label == 'My Tickets') {
                        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MySupportTicketsPage()));
                      } else {
                        showSupportRequestDialog(context, label);
                      }
                    },
                  )),
                ],
              ),
            ),
          ]),
        ),
      ),
    ),
  );
}

Future<void> showSupportRequestDialog(BuildContext context, String category) async {
  final controller = TextEditingController();
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Please sign in before contacting Customer Support.')),
    );
    controller.dispose();
    return;
  }


  final result = await showDialog<Map<String, String>?>(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) => AlertDialog(
      backgroundColor: AppTheme.adaptiveSurface(const Color(0xFF080D13)),
      title: Text(category.toUpperCase()),
      content: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(dialogContext).size.height * 0.32),
        child: SingleChildScrollView(
          child: TextField(
            controller: controller,
            autofocus: true,
            minLines: 4,
            maxLines: 7,
            decoration: const InputDecoration(
              labelText: 'ENTER DETAILS',
              hintText: 'Describe what you need help with…',
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            FocusScope.of(dialogContext).unfocus();
            Navigator.of(dialogContext).pop(<String, String>{'action': 'cancel'});
          },
          child: const Text('CANCEL'),
        ),
        TextButton(
          onPressed: () {
            Navigator.of(dialogContext).pop(<String, String>{'action': 'save'});
          },
          child: const Text('SAVE'),
        ),
        TextButton(
          onPressed: () {
            Navigator.of(dialogContext).pop(<String, String>{'action': 'send'});
          },
          child: const Text('SEND'),
        ),
        FilledButton(
          onPressed: () {
            Navigator.of(dialogContext).pop(<String, String>{'action': 'submit'});
          },
          child: const Text('SUBMIT'),
        ),
      ],
    ),
  );

  final action = result?['action'];
  final details = controller.text.trim();
  controller.dispose();

  if (action == null || action == 'cancel') return;
  if (details.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Please enter your support details first.')),
    );
    return;
  }

  final status = action == 'save' ? 'draft' : 'submitted';
  final actionLabel = action == 'save' ? 'saved' : 'sent successfully';

  try {
    await CustomerSupportService.createRequest(
      uid: user.uid,
      email: user.email ?? '',
      category: category,
      details: details,
      status: status,
      action: action,
    );

    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          action == 'save'
              ? 'Customer Support details saved successfully.'
              : 'Customer Support request $actionLabel.',
        ),
      ),
    );
  } catch (_) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Customer Support could not process the request. Please try again.'),
      ),
    );
  }
}


class SubmitSupportTicketPage extends StatefulWidget {
  const SubmitSupportTicketPage({super.key});
  @override
  State<SubmitSupportTicketPage> createState() => _SubmitSupportTicketPageState();
}

class _SubmitSupportTicketPageState extends State<SubmitSupportTicketPage> {
  final controller = TextEditingController();
  bool sending = false;

  @override
  void dispose() { controller.dispose(); super.dispose(); }

  Future<void> _submit() async {
    final user = FirebaseAuth.instance.currentUser;
    final details = controller.text.trim();
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please sign in first.')));
      return;
    }
    if (details.isEmpty || sending) return;
    setState(() => sending = true);
    try {
      final profile = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final data = profile.data() ?? <String, dynamic>{};
      final name = (data['name'] ?? data['displayName'] ?? user.displayName ?? 'CDH User').toString();
      final ticketId = await CustomerSupportService.createTicket(
        uid: user.uid,
        userName: name,
        email: user.email ?? '',
        details: details,
      );
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: AppTheme.adaptiveSurface(const Color(0xFF080D13)),
          title: const Text('TICKET SUBMITTED'),
          content: Text('Your ticket ID is:\n\n$ticketId\n\nPlease keep this ID for future support conversations.'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not submit the ticket. Please try again.')));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SUBMIT A TICKET')),
    backgroundColor: AppTheme.adaptiveSurface(const Color(0xFF070B10)),
    body: ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 32), children: [
      const Text('NEW SUPPORT TICKET', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
      const SizedBox(height: 7),
      Text('Use this when your issue does not fit an existing Customer Support category.', style: TextStyle(color: AppTheme.textSoft, fontSize: 12, height: 1.4)),
      const SizedBox(height: 18),
      TextField(controller: controller, minLines: 8, maxLines: 14, textInputAction: TextInputAction.newline, decoration: const InputDecoration(labelText: 'DESCRIBE YOUR ISSUE', hintText: 'Enter your complete issue or question…', alignLabelWithHint: true)),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: sending ? null : _submit, icon: const Icon(Icons.send_rounded), label: Text(sending ? 'SUBMITTING…' : 'SUBMIT TICKET')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close), label: const Text('CANCEL')),
    ]),
  );
}

class MySupportTicketsPage extends StatelessWidget {
  const MySupportTicketsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('MY SUPPORT TICKETS')),
      backgroundColor: AppTheme.adaptiveSurface(const Color(0xFF070B10)),
      body: user == null ? const Center(child: Text('Please sign in.')) : StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: CustomerSupportService.userTickets(user.uid),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text('Unable to load tickets: ${snapshot.error}'));
          final docs = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
          if (docs.isEmpty) return const Center(child: Text('No support tickets yet.'));
          return ListView.builder(
            padding: const EdgeInsets.all(14), itemCount: docs.length,
            itemBuilder: (_, i) => _SupportTicketTile(doc: docs[i], isAdmin: false),
          );
        },
      ),
    );
  }
}

class _SupportTicketTile extends StatelessWidget {
  final QueryDocumentSnapshot<Map<String, dynamic>> doc;
  final bool isAdmin;
  const _SupportTicketTile({required this.doc, required this.isAdmin});
  @override
  Widget build(BuildContext context) {
    final d = doc.data();
    final ticket = (d['ticketId'] ?? doc.id).toString();
    final status = (d['status'] ?? 'open').toString();
    final details = (d['details'] ?? '').toString();
    final ts = d['createdAt'];
    final when = ts is Timestamp ? _supportTicketFormatAdminDateTime(ts.toDate()) : 'Time unavailable';
    return Card(
      color: AppTheme.adaptiveSurface(const Color(0xAA11191B)),
      child: ListTile(
        title: Text(ticket, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text('$status • $when\n${details.length > 120 ? '${details.substring(0, 120)}…' : details}', maxLines: 3, overflow: TextOverflow.ellipsis),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SupportTicketConversationPage(doc: doc, isAdmin: isAdmin))),
      ),
    );
  }
}

class SupportTicketConversationPage extends StatefulWidget {
  final QueryDocumentSnapshot<Map<String, dynamic>> doc;
  final bool isAdmin;
  const SupportTicketConversationPage({super.key, required this.doc, required this.isAdmin});
  @override
  State<SupportTicketConversationPage> createState() => _SupportTicketConversationPageState();
}

class _SupportTicketConversationPageState extends State<SupportTicketConversationPage> {
  final controller = TextEditingController();
  bool sending = false;
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  Future<void> _send() async {
    final u = FirebaseAuth.instance.currentUser;
    final text = controller.text.trim();
    if (u == null || text.isEmpty || sending) return;
    setState(() => sending = true);
    try {
      final profile = await FirebaseFirestore.instance.collection('users').doc(u.uid).get();
      final d = profile.data() ?? <String, dynamic>{};
      final name = (d['name'] ?? d['displayName'] ?? u.displayName ?? 'CDH User').toString();
      await CustomerSupportService.sendTicketMessage(ticketDocId: widget.doc.id, senderUid: u.uid, senderName: name, senderRole: widget.isAdmin ? 'admin' : 'user', text: text);
      controller.clear();
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not send the response.')));
    } finally { if (mounted) setState(() => sending = false); }
  }
  @override
  Widget build(BuildContext context) {
    final d = widget.doc.data();
    final ticket = (d['ticketId'] ?? widget.doc.id).toString();
    return Scaffold(
      appBar: AppBar(title: Text(ticket), actions: [
        if (widget.isAdmin) PopupMenuButton<String>(onSelected: (v) => CustomerSupportService.updateTicketStatus(widget.doc.id, v), itemBuilder: (_) => const [PopupMenuItem(value: 'open', child: Text('OPEN')), PopupMenuItem(value: 'awaiting_user', child: Text('AWAITING USER')), PopupMenuItem(value: 'closed', child: Text('CLOSED'))]),
      ]),
      backgroundColor: AppTheme.adaptiveSurface(const Color(0xFF070B10)),
      body: Column(children: [
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: CustomerSupportService.ticketMessages(widget.doc.id).orderBy('createdAt').snapshots(), builder: (context, snapshot) {
          final messages = snapshot.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
          return ListView.builder(reverse: false, padding: const EdgeInsets.all(14), itemCount: messages.length + 1, itemBuilder: (_, i) {
            if (i == 0) return Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14), decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.fillFaint)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${d['userName'] ?? 'User'} • ${d['email'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 6), Text((d['details'] ?? '').toString())]));
            final m = messages[i - 1].data(); final mine = (m['senderRole'] ?? '') == (widget.isAdmin ? 'admin' : 'user'); final ts = m['createdAt']; final when = ts is Timestamp ? _supportTicketFormatAdminDateTime(ts.toDate()) : '';
            return Align(
              alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                constraints: const BoxConstraints(maxWidth: 360),
                decoration: BoxDecoration(
                  color: mine ? const Color(0xFF174D3B) : const Color(0xFF20272D),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      (m['senderName'] ?? '').toString(),
                      style: TextStyle(color: AppTheme.luxuryGold, fontSize: 10, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 3),
                    Text((m['text'] ?? '').toString()),
                    if (when.isNotEmpty)
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(when, style: TextStyle(color: AppTheme.textFaint, fontSize: 9)),
                      ),
                  ],
                ),
              ),
            );
          });
        })),
        SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(10, 6, 10, 10), child: Row(children: [Expanded(child: TextField(controller: controller, minLines: 1, maxLines: 4, decoration: const InputDecoration(hintText: 'Write a response…'))), const SizedBox(width: 8), IconButton(onPressed: sending ? null : _send, icon: const Icon(Icons.send_rounded))]))),
      ]),
    );
  }
}

class _FeedTopSearchBar extends StatelessWidget {
  final VoidCallback onTap;
  const _FeedTopSearchBar({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(13),
      child: InkWell(
        borderRadius: BorderRadius.circular(13),
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 300, minHeight: 38),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(13),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withValues(alpha: 0.10),
                Colors.white.withValues(alpha: 0.045),
                Colors.black.withValues(alpha: 0.12),
              ],
            ),
            border: Border.all(color: Colors.white.withValues(alpha: 0.14)),
            boxShadow: [
              BoxShadow(color: Colors.black.withValues(alpha: 0.18), blurRadius: 10, offset: const Offset(0, 3)),
              BoxShadow(color: Colors.white.withValues(alpha: 0.035), blurRadius: 2, offset: const Offset(0, 1)),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.search_rounded, color: AppTheme.textSecondary, size: 19),
              SizedBox(width: 8),
              Flexible(
                child: Text(
                  'Search content, users & events',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: AppTheme.textSoft, fontSize: 12, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Future<void> _showFeedNotificationSettings(BuildContext context) async {
  bool push = true;
  bool feed = true;
  bool creator = true;
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0A1017)),
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (sheetContext) => StatefulBuilder(
      builder: (context, setSheetState) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 38, height: 4, decoration: BoxDecoration(color: AppTheme.borderSoft, borderRadius: BorderRadius.circular(8))),
              const SizedBox(height: 14),
              Row(children: [Icon(Icons.notifications_active_outlined, color: AppTheme.luxuryGold), SizedBox(width: 9), Text('NOTIFICATION CONTROL', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1))]),
              const SizedBox(height: 8),
              SwitchListTile.adaptive(title: const Text('Push notifications'), value: push, onChanged: (v) => setSheetState(() => push = v)),
              SwitchListTile.adaptive(title: const Text('Feed activity'), value: feed, onChanged: (v) => setSheetState(() => feed = v)),
              SwitchListTile.adaptive(title: const Text('Creator alerts'), value: creator, onChanged: (v) => setSheetState(() => creator = v)),
              const SizedBox(height: 6),
              SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.pop(sheetContext), child: const Text('DONE'))),
            ],
          ),
        ),
      ),
    ),
  );
}

class _AboutPage extends StatelessWidget {
  const _AboutPage();
  @override
  Widget build(BuildContext context) => const _AlphaDenRulesPage();
}

class _QualifiedWinInfoDialog extends StatefulWidget {
  const _QualifiedWinInfoDialog();

  @override
  State<_QualifiedWinInfoDialog> createState() => _QualifiedWinInfoDialogState();
}

class _QualifiedWinInfoDialogState extends State<_QualifiedWinInfoDialog> {
  Timer? _timer;
  double _progress = 1.0;

  @override
  void initState() {
    super.initState();
    const total = Duration(seconds: 4);
    final started = DateTime.now();
    _timer = Timer.periodic(const Duration(milliseconds: 80), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      final elapsed = DateTime.now().difference(started);
      final value = 1.0 - (elapsed.inMilliseconds / total.inMilliseconds);
      if (value <= 0) {
        timer.cancel();
        Navigator.of(context).pop();
      } else {
        setState(() => _progress = value);
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0B0F11)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: .34)),
          boxShadow: [BoxShadow(color: AppTheme.luxuryGold.withValues(alpha: .10), blurRadius: 28, spreadRadius: 1)],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.luxuryGold.withValues(alpha: .10),
                border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: .48)),
              ),
              child: Icon(Icons.insights_rounded, color: AppTheme.luxuryGold, size: 25),
            ),
            const SizedBox(height: 12),
            Text('QUALIFIED WIN TRADE', style: TextStyle(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
            const SizedBox(height: 8),
            Text(
              'A complete qualified Win Trade is counted only when TP1, TP2 and TP3 are all marked HIT.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 11.5, height: 1.45),
            ),
            const SizedBox(height: 13),
            ClipRRect(
              borderRadius: BorderRadius.circular(5),
              child: LinearProgressIndicator(
                value: _progress,
                minHeight: 3,
                backgroundColor: AppTheme.fillFaint,
                valueColor: AlwaysStoppedAnimation<Color>(AppTheme.luxuryGold),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('SKIP', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AlphaDenRulesPage extends StatelessWidget {
  const _AlphaDenRulesPage();

  Widget _section(String title, String body, {IconData icon = Icons.rule_rounded}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.adaptiveSurface(Color(0xFF303238)),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: AppTheme.borderFaint),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 30, height: 30,
          decoration: BoxDecoration(color: AppTheme.luxuryGold.withValues(alpha: .10), borderRadius: BorderRadius.circular(9)),
          child: Icon(icon, size: 16, color: AppTheme.luxuryGold),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: AppTheme.textPrimary, fontSize: 11.5, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(body, style: TextStyle(color: AppTheme.textSoft, fontSize: 10.5, height: 1.45)),
        ])),
      ]),
    );
  }

  Widget _tier({required int wins, required String title, required String body}) {
    return _WinRateProfileAura(
      winTrades: wins,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF303238)), borderRadius: BorderRadius.circular(24)),
        child: Row(children: [
          CircleAvatar(radius: 21, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF111A24)), child: Icon(Icons.person, color: AppTheme.luxuryGold, size: 21)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(color: AppTheme.textPrimary, fontSize: 12, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text(body, style: TextStyle(color: AppTheme.textSoft, fontSize: 9.5, height: 1.35)),
          ])),
          Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), decoration: BoxDecoration(color: AppTheme.fillFaint, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppTheme.borderFaint)), child: Column(children: [Text('WIN TRADES', style: TextStyle(color: AppTheme.textMuted, fontSize: 5.5, fontWeight: FontWeight.w900)), const SizedBox(height: 2), Text('$wins', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 13, fontWeight: FontWeight.w900))])),
        ]),
      ),
    );
  }

  Widget _aboutCrownTier(int referrals, String title, String range, String reward) {
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
      decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: .025), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.fillFaint)),
      child: Row(children: [
        Transform.scale(scale: .72, child: _ReferralCrownBadge(referrals: referrals)),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: TextStyle(color: AppTheme.textPrimary, fontSize: 9.5, fontWeight: FontWeight.w900)), const SizedBox(height: 2), Text(range, style: TextStyle(color: AppTheme.textMuted, fontSize: 8.5))])),
        Text(reward, style: TextStyle(color: AppTheme.luxuryGold, fontSize: 8, fontWeight: FontWeight.w900)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF030405),
      appBar: AppBar(title: const Text('ALPHA DEN • ABOUT')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 30),
        children: [
          Text('ALPHA DEN RULES', style: TextStyle(color: AppTheme.textPrimary, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          const SizedBox(height: 5),
          Text('How signal outcomes, qualified Win Trades and profile aura tiers work.', style: TextStyle(color: AppTheme.textMuted, fontSize: 11, height: 1.4)),
          const SizedBox(height: 14),
          _section('1 • Signal prices are locked', 'After a signal is published, ENTRY, LEVERAGE, TP1, TP2, TP3 and STOPLOSS values remain locked when Enter Win Ratio is opened.', icon: Icons.lock_outline_rounded),
          _section('2 • TP outcomes', 'TP1, TP2 and TP3 can each be marked HIT. A hit TP can have its recorded profit percentage. Stop Loss can record a negative percentage, and Break Even can record its outcome percentage.', icon: Icons.track_changes_rounded),
          _section('3 • Qualified Win Trade', 'A partial result does not create a Win Trade count. One complete qualified Win Trade is counted only when TP1 + TP2 + TP3 are all marked HIT for the same signal.', icon: Icons.verified_rounded),
          _section('4 • WIN percentage on the signal', 'When one or more TPs are hit, the signal WIN percentage is calculated from the average of the recorded profit percentages for the TPs that were actually hit.', icon: Icons.percent_rounded),
          _section('5 • Win-proof screenshot', 'After a TP is hit, the creator can attach a win-proof screenshot. A small preview is shown on the signal; opening it shows the full image.', icon: Icons.photo_camera_outlined),
          _section('6 • CD Feed synchronization', 'Signal outcome information is synchronized to the corresponding CD Feed copy, including TP hit states, recorded percentages and the win-proof image.', icon: Icons.sync_rounded),
          _section('7 • Win Trade aura rules', 'At 5+ qualified Win Trades the profile receives a gold glow; at 8+ it gains the stronger dual-color glow; at 10+ it receives the animated flaming aura. These milestones currently provide visual benefits only.', icon: Icons.auto_awesome_rounded),
          _section('8 • Crown / referral system', 'Crowns are separate from Win Trades and are based on qualified referrals: 0 = Brown; 1–2 = Blue; 3–4 = Purple; 5–9 = Golden; 10+ = Black + Gold with a flame aura. Referral rewards are 1=\$4, 2=\$8, 3=\$9, 4=\$12, 5=\$15, 6=\$18 and 7=\$21.', icon: Icons.workspace_premium_rounded),
          const SizedBox(height: 6),
          Text('CROWN TIERS', style: TextStyle(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const SizedBox(height: 9),
          _aboutCrownTier(0, 'BROWN CROWN', '0 qualified referrals', '\$0'),
          _aboutCrownTier(1, 'BLUE CROWN', '1–2 qualified referrals', '\$4 / \$8'),
          _aboutCrownTier(3, 'PURPLE CROWN', '3–4 qualified referrals', '\$9 / \$12'),
          _aboutCrownTier(5, 'GOLDEN CROWN', '5–7 qualified referrals', '\$15 / \$18 / \$21'),
          _aboutCrownTier(8, 'GOLDEN CROWN • ENHANCED GLOW', '8–9 qualified referrals', 'Stronger gold glow'),
          _aboutCrownTier(10, 'BLACK + GOLD CROWN', '10+ qualified referrals • corner flame aura', 'Highest tier'),
          const SizedBox(height: 8),
          _section('9 • Verified Creator / Blue Tick', 'Creators with at least 3 qualified Win Trades may apply for Verified Creator review. Approval is not automatic. The platform may require payment, location and full account/identity information for security and verification review; such information should be handled securely and may support fraud investigation and lawful action where applicable.', icon: Icons.verified_rounded),
          _section('10 • Verified Creator benefits', 'Approved verified creators can openly advertise/promote their content or services, promote their community and direct interested users toward it. A future in-app community-building feature is planned but is not currently available. The blue tick identifies an approved Verified Creator account.', icon: Icons.campaign_outlined),
          _section('11 • Verification responsibility', 'Verified status remains subject to platform review and safety requirements. Providing information does not guarantee approval; any future enforcement or legal action remains subject to applicable law and available evidence.', icon: Icons.security_rounded),
          const SizedBox(height: 6),
          Text('PROFILE AURA TIERS', style: TextStyle(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const SizedBox(height: 9),
          _tier(wins: 5, title: '5+ WIN TRADES • GOLD GLOW', body: 'The Alpha Den profile card receives a smooth luxury-gold animated glow.'),
          const SizedBox(height: 12),
          _tier(wins: 8, title: '8+ WIN TRADES • DUAL COLOR GLOW', body: 'The profile keeps the gold glow and adds the stronger cyan/red accent glow.'),
          const SizedBox(height: 12),
          _tier(wins: 10, title: '10+ WIN TRADES • FLAMING AURA', body: 'The profile receives the stronger gold, orange and red animated flaming aura around its border.'),
          const SizedBox(height: 14),
          Text('These visual tiers are based on the current Alpha Den rules implemented in the app.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textFaint, fontSize: 9.5)),
        ],
      ),
    );
  }
}

// ============================================================
// FEED SEARCH
// ============================================================

Future<void> _openFeedSearch(BuildContext context) async {
  final feedFuture = _loadSearchableFeedPosts();
  await Navigator.of(context).push(
    PageRouteBuilder<void>(
      opaque: false,
      barrierColor: const Color(0xB8000000),
      transitionDuration: const Duration(milliseconds: 280),
      pageBuilder: (_, animation, _) => _FeedSearchPage(feedFuture: feedFuture),
      transitionsBuilder: (_, animation, _, child) {
        final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
        return FadeTransition(
          opacity: curved,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.035), end: Offset.zero).animate(curved),
            child: child,
          ),
        );
      },
    ),
  );
}

Future<List<FeedPostModel>> _loadSearchableFeedPosts() async {
  try {
    return await FeedService.loadFeed(limit: 500);
  } catch (_) {
    return const <FeedPostModel>[];
  }
}

Future<void> _openPublicAlphaDenProfile(BuildContext context, String uid) async {
  final cleanUid = uid.trim();
  if (cleanUid.isEmpty) return;
  await Navigator.of(context).push(MaterialPageRoute(
    builder: (_) => _PublicAlphaDenProfilePage(uid: cleanUid),
  ));
}

class _PublicAlphaDenProfilePage extends StatefulWidget {
  final String uid;
  const _PublicAlphaDenProfilePage({required this.uid});
  @override
  State<_PublicAlphaDenProfilePage> createState() => _PublicAlphaDenProfilePageState();
}

class _PublicAlphaDenProfilePageState extends State<_PublicAlphaDenProfilePage> {
  Map<String, dynamic>? profile;
  List<Map<String, dynamic>> posts = const [];
  List<Map<String, dynamic>> reposts = const [];
  int currentTab = 0;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      var loadedProfile = await AlphaDenService.loadProfile(widget.uid);
      final loadedUserDoc = await FirebaseFirestore.instance.collection('users').doc(widget.uid).get();
      final loadedUserData = loadedUserDoc.data() ?? <String, dynamic>{};
      // Admin Alpha Den profiles are public/searchable like any other Alpha Den
      // profile. If an admin has not opened Alpha Den yet, build a read-only
      // public profile from the account data so the profile can still be visited.
      if (loadedProfile == null) {
        final email = (loadedUserData['email'] ?? '').toString().trim().toLowerCase();
        final isKnownAdmin = email == 'cryptodoctors73@gmail.com' ||
            email == 'teamcryptodoctors@gmail.com' ||
            email == 'sbroland11@gmail.com' ||
            email == 'sbroland@gmail.com';
        final fallbackName = (loadedUserData['displayName'] ?? '').toString().trim();
        loadedProfile = <String, dynamic>{
          'uid': widget.uid,
          'username': fallbackName.isEmpty ? (isKnownAdmin ? 'CRYPTO-DOCTORS-HUB ADMIN' : 'Community Member') : fallbackName,
          'name': fallbackName.isEmpty ? (isKnownAdmin ? 'CRYPTO-DOCTORS-HUB ADMIN' : 'Community Member') : fallbackName,
          'bio': isKnownAdmin ? 'Official Crypto Doctors Hub Admin' : '',
          'profilePicUrl': (loadedUserData['photoURL'] ?? '').toString(),
          'profilePicBase64': (loadedUserData['profilePicBase64'] ?? '').toString(),
          'followers': 0,
          'posts': 0,
          'likes': 0,
          'views': 0,
          'reposts': 0,
          'referrals': 0,
          'winTrades': 0,
          'verifiedCreatorApproved': loadedUserData['verifiedCreatorApproved'] == true || isKnownAdmin,
          'isPremium': loadedUserData['isPremium'] == true,
          'mentorshipApproved': loadedUserData['mentorshipApproved'] == true || loadedUserData['isMentorship'] == true || loadedUserData['mentorship'] == true || loadedUserData['studentApproved'] == true || loadedUserData['isStudent'] == true,
          'isAdminProfile': isKnownAdmin,
        };
      }
      {
        loadedProfile['isPremium'] = loadedUserData['isPremium'] == true;
        loadedProfile['hasMentorship'] = loadedUserData['mentorshipApproved'] == true || loadedUserData['isMentorship'] == true || loadedUserData['mentorship'] == true || loadedUserData['studentApproved'] == true || loadedUserData['isStudent'] == true;
        loadedProfile['premiumBadgeType'] = (loadedUserData['confirmedPremiumBadgeType'] ?? '').toString();
        loadedProfile['mentorshipBadgeType'] = (loadedUserData['confirmedMentorshipBadgeType'] ?? '').toString();
        loadedProfile['graduated'] = loadedUserData['graduated'] == true;
        loadedProfile['referralCrownType'] = (loadedUserData['confirmedReferralCrownType'] ?? '').toString();
        final alphaPic = (loadedProfile['profilePicUrl'] ?? '').toString().trim();
        final alphaPicBase64 = (loadedProfile['profilePicBase64'] ?? '').toString().trim();
        if (alphaPic.isEmpty) loadedProfile['profilePicUrl'] = (loadedUserData['photoURL'] ?? '').toString();
        if (alphaPicBase64.isEmpty) loadedProfile['profilePicBase64'] = (loadedUserData['profilePicBase64'] ?? '').toString();
      }
      List<Map<String, dynamic>> loadedPosts = const [];
      List<Map<String, dynamic>> loadedReposts = const [];
      try {
        loadedPosts = await AlphaDenService.loadPosts(widget.uid);
      } catch (_) {}
      try {
        loadedReposts = await AlphaDenService.loadPublicReposts(widget.uid);
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        profile = loadedProfile;
        posts = loadedPosts;
        reposts = loadedReposts;
        loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  List<Map<String, dynamic>> _ideas() => posts.where((data) {
    final source = (data['sourceType'] ?? '').toString();
    return source != 'article' && (data['signalAsset'] ?? '').toString().trim().isEmpty;
  }).toList();

  List<Map<String, dynamic>> _signals() => posts.where((data) {
    final source = (data['sourceType'] ?? '').toString();
    return source != 'article' && (data['signalAsset'] ?? '').toString().trim().isNotEmpty;
  }).toList();

  List<Map<String, dynamic>> _articles() => posts.where((data) => (data['sourceType'] ?? '').toString() == 'article').toList();

  @override
  Widget build(BuildContext context) {
    final p = profile ?? <String, dynamic>{};
    final username = (p['username'] ?? p['name'] ?? 'Community Member').toString();
    final handle = (p['nickname'] ?? p['handle'] ?? '').toString().replaceFirst(RegExp(r'^@'), '');
    final bio = (p['bio'] ?? '').toString();
    final followers = (p['followers'] as num?)?.toInt() ?? 0;
    final likes = (p['likes'] as num?)?.toInt() ?? 0;
    final profileReposts = (p['reposts'] as num?)?.toInt() ?? reposts.length;
    final referrals = (p['referrals'] as num?)?.toInt() ?? 0;
    final verified = p['verified'] == true || p['verifiedCreatorApproved'] == true;
    final isPremium = p['isPremium'] == true;
    final hasMentorship = p['hasMentorship'] == true || p['mentorshipApproved'] == true || p['isMentorship'] == true || p['mentorship'] == true || p['studentApproved'] == true || p['isStudent'] == true;
    final premiumBadgeType = (p['premiumBadgeType'] ?? '').toString();
    final mentorshipBadgeType = (p['mentorshipBadgeType'] ?? '').toString();
    final referralCrownType = (p['referralCrownType'] ?? '').toString();
    final flamingAuraCrown = ((p['winTrades'] as num?)?.toInt() ?? 0) >= 10;
    final picUrl = (p['profilePicUrl'] ?? '').toString();
    Uint8List? picBytes;
    final encodedPic = (p['profilePicBase64'] ?? '').toString();
    if (encodedPic.isNotEmpty) {
      try { picBytes = base64Decode(encodedPic); } catch (_) { picBytes = null; }
    }
    final tabItems = <List<Map<String, dynamic>>>[_ideas(), _signals(), _articles(), reposts];
    const tabLabels = ['IDEAS', 'SIGNALS', 'ARTICLES', 'REPOSTS'];
    final tabIcons = [Icons.lightbulb_outline, Icons.candlestick_chart_outlined, Icons.article_outlined, Icons.repeat_rounded];
    final visibleItems = tabItems[currentTab];

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: const Color(0xB0080D13),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        title: Text('ALPHA DEN PROFILE', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
      ),
      body: Stack(
        children: [
          const GalaxyBackground(animatePlanets: false, animateCryptoCoins: true, animationDuration: Duration(seconds: 45), cinematicEntrance: true),
          loading
              ? const Center(child: CircularProgressIndicator())
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                    children: [
                  _WinRateProfileAura(
                    winTrades: (p['winTrades'] as num?)?.toInt() ?? 0,
                    child: Padding(
                      padding: const EdgeInsets.all(1.5),
                      child: Column(
                        children: [
                  _AlphaDenProfileHeader(
                    username: username,
                    handle: handle,
                    name: (p['name'] ?? '').toString(),
                    age: (p['age'] ?? '').toString(),
                    sex: (p['sex'] ?? '').toString(),
                    profilePicUrl: picUrl,
                    profilePicBytes: picBytes,
                    verified: verified,
                    followers: followers,
                    posts: posts.length,
                    likes: likes,
                    views: (p['views'] as num?)?.toInt() ?? 0,
                    reposts: profileReposts,
                    referrals: referrals,
                    winTrades: (p['winTrades'] as num?)?.toInt() ?? 0,
                    bio: bio,
                    flamingAuraCrown: flamingAuraCrown,
                    isPremium: isPremium,
                    hasMentorship: hasMentorship,
                    premiumBadgeType: premiumBadgeType,
                    mentorshipBadgeType: mentorshipBadgeType,
                    graduated: (p['graduated'] == true),
                    referralCrownType: referralCrownType,
                    visitorProfile: true,
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xB80A1017)), borderRadius: BorderRadius.circular(18), border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: 0.16))),
                    child: Row(children: [
                      for (int i = 0; i < 4; i++) Expanded(child: GestureDetector(
                        onTap: () => setState(() => currentTab = i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 260),
                          curve: Curves.easeOutCubic,
                          padding: const EdgeInsets.symmetric(vertical: 11),
                          decoration: BoxDecoration(color: currentTab == i ? AppTheme.adaptiveWhite(alpha: 0.075) : Colors.transparent, borderRadius: BorderRadius.circular(13)),
                          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Icon(tabIcons[i], size: 16, color: currentTab == i ? AppTheme.luxuryGold : AppTheme.textMuted),
                            const SizedBox(width: 6),
                            Text(tabLabels[i], style: TextStyle(color: currentTab == i ? AppTheme.textPrimary : AppTheme.textMuted, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.0)),
                          ]),
                        ),
                      )),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  if (visibleItems.isEmpty)
                    Padding(padding: const EdgeInsets.all(28), child: Center(child: Text('No ${tabLabels[currentTab].toLowerCase()} yet.', style: TextStyle(color: AppTheme.textMuted))))
                  else
                    for (final data in visibleItems) _PublicAlphaDenPostTile(data: data, repostView: currentTab == 3, winTrades: (p['winTrades'] as num?)?.toInt() ?? 0),

                        ],
                      ),
                    ),
                  ),
                ],
                  ),
                ),
        ],
      ),
    );
  }
}

class _PublicAlphaDenPostTile extends StatelessWidget {
  final Map<String, dynamic> data;
  final bool repostView;
  final int winTrades;
  const _PublicAlphaDenPostTile({required this.data, this.repostView = false, this.winTrades = 0});
  @override
  Widget build(BuildContext context) {
    final text = (data['text'] ?? '').toString();
    final source = (data['sourceType'] ?? 'alpha_den').toString().toUpperCase();
    final repost = repostView || (data['originalPostId'] ?? '').toString().isNotEmpty;
    final bullish = data['bullish'] == true;
    final id = (data['id'] ?? '').toString();
    final winProof = data['winResultImageBase64'] is String && (data['winResultImageBase64'] as String).isNotEmpty ? _tryDecodeBase64(data['winResultImageBase64'] as String) : null;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: ((data['signalAsset'] ?? '').toString().trim().isNotEmpty)
          ? BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF303238)), borderRadius: BorderRadius.circular(16))
          : _regularPostGlassDecoration(borderColor: const Color(0xFF4E9FC1), radius: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Text(repost ? 'REPOSTED $source' : source, style: TextStyle(color: bullish ? AppTheme.neonGreen : const Color(0xFFE05252), fontSize: 9, fontWeight: FontWeight.w900)), const Spacer(), _signalWinBadge(tp1Hit: (data['tp1Hit'] == true), tp2Hit: (data['tp2Hit'] == true), tp3Hit: (data['tp3Hit'] == true), tp1Profit: (data['tp1Profit'] ?? '').toString(), tp2Profit: (data['tp2Profit'] ?? '').toString(), tp3Profit: (data['tp3Profit'] ?? '').toString(), stopLossHit: data['stopLossHit'] == true, stopLossProfit: (data['stopLossProfit'] ?? '').toString(), breakEven: data['breakEven'] == true, breakEvenProfit: (data['breakEvenProfit'] ?? '').toString()), const SizedBox(width: 3), if (id.isNotEmpty) IconButton(visualDensity: VisualDensity.compact, onPressed: () => _openContentReportSupportPage(context, postId: id, authorUid: (data['authorUid'] ?? '').toString()), icon: Icon(Icons.flag_outlined, size: 16, color: AppTheme.textMuted))]),
        if (source == 'ALPHA_DEN' && (data['signalAsset'] ?? '').toString().trim().isNotEmpty) ...[
          Row(children: [Expanded(child: Text('${data['signalAsset']}/USDT', style: TextStyle(color: AppTheme.textPrimary, fontSize: 17, fontWeight: FontWeight.w900))), _LiveCallBadge(text: data['signalLongDirection'] == true ? 'LONG' : 'SHORT', color: data['signalLongDirection'] == true ? AppTheme.neonGreen : const Color(0xFFE05252))]),
          const SizedBox(height: 7),
          _LiveCallValueRow(label: 'ENTRY', value: (data['signalEntry'] ?? '').toString()),
          _LiveCallValueRow(label: 'LEVERAGE', value: '${data['signalLeverage'] ?? 10}x'),
          _signalTargetRow(label: 'TP1', value: (data['signalTp1'] ?? '').toString(), hit: data['tp1Hit'] == true, profit: (data['tp1Profit'] ?? '').toString()),
          _signalTargetRow(label: 'TP2', value: (data['signalTp2'] ?? '').toString(), hit: data['tp2Hit'] == true, profit: (data['tp2Profit'] ?? '').toString()),
          _signalTargetRow(label: 'TP3', value: (data['signalTp3'] ?? '').toString(), hit: data['tp3Hit'] == true, profit: (data['tp3Profit'] ?? '').toString()),
          _signalTargetRow(label: 'STOPLOSS', value: (data['signalStopLoss'] ?? '').toString(), warning: true, hit: data['stopLossHit'] == true, profit: (data['stopLossProfit'] ?? '').toString()),
          if (data['breakEven'] == true) _signalTargetRow(label: 'BREAK EVEN', value: '', warning: true, hit: true, profit: (data['breakEvenProfit'] ?? '').toString()),
          if (data['winResultImageBase64'] is String && (data['winResultImageBase64'] as String).isNotEmpty && (data['tp1Hit'] == true || data['tp2Hit'] == true || data['tp3Hit'] == true)) ...[
            const SizedBox(height: 7),
            if (winProof != null) GestureDetector(onTap: () => showDialog<void>(context: context, builder: (_) => Dialog(backgroundColor: Colors.black, insetPadding: const EdgeInsets.all(12), child: InteractiveViewer(child: Image.memory(winProof, fit: BoxFit.contain)))), child: ClipRRect(borderRadius: BorderRadius.circular(9), child: Image.memory(winProof, width: 105, height: 72, fit: BoxFit.cover))),
          ],
        ] else if (source == 'ARTICLE' && (data['articleTitle'] ?? '').toString().isNotEmpty) ...[
          Text((data['articleTitle'] ?? '').toString(), style: TextStyle(color: AppTheme.textPrimary, fontSize: 15, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text((data['articleBody'] ?? text).toString(), style: TextStyle(color: AppTheme.textPrimary, fontSize: 13, height: 1.45)),
        ] else if (text.isNotEmpty) Text(text, style: TextStyle(color: AppTheme.textPrimary, fontSize: 13, height: 1.45)),
        const SizedBox(height: 8),
        Row(children: [Icon(Icons.favorite_border, size: 16, color: AppTheme.textSoft), const SizedBox(width: 4), Text('${(data['likesCount'] ?? data['likes'] ?? 0)}', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)), const SizedBox(width: 14), Icon(Icons.comment_outlined, size: 16, color: AppTheme.textSoft), const SizedBox(width: 4), Text('${(data['commentsCount'] ?? 0)}', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)), const SizedBox(width: 14), Icon(Icons.repeat, size: 16, color: AppTheme.textSoft), const SizedBox(width: 4), Text('${(data['repostsCount'] ?? 0)}', style: TextStyle(color: AppTheme.textMuted, fontSize: 10))]),
      ]),
    );
  }
}

_CommunityPost _feedPostToCommunity(FeedPostModel p) => _CommunityPost(
  id: p.id, authorUid: p.authorUid, username: p.authorDisplayName, profilePicUrl: p.authorPhotoUrl,
  badge: p.badge, referrals: p.referralsCount, verified: p.verified, hasMentorship: false, text: p.text,
  imageBytes: p.imageBase64 == null ? null : base64Decode(p.imageBase64!), thumbnailBytes: null,
  profilePicBytes: p.authorPhotoBase64 == null || p.authorPhotoBase64!.isEmpty ? null : _tryDecodeBase64(p.authorPhotoBase64!),
  bullish: p.bullish, hashtags: p.hashtags, coins: p.coins, createdAt: p.createdAt,
  signalAsset: p.signalAsset, signalEntry: p.signalEntry, signalLongDirection: p.signalLongDirection,
  signalLeverage: p.signalLeverage, signalTp1: p.signalTp1, signalTp2: p.signalTp2, signalTp3: p.signalTp3, signalStopLoss: p.signalStopLoss,
  sourceType: p.sourceType ?? 'community',
  sourceId: p.sourceId,
  tp1Hit: p.tp1Hit, tp2Hit: p.tp2Hit, tp3Hit: p.tp3Hit, stopLossHit: p.stopLossHit, breakEven: p.breakEven, winTradeCounted: p.winTradeCounted,
  tp1Profit: p.tp1Profit ?? '', tp2Profit: p.tp2Profit ?? '', tp3Profit: p.tp3Profit ?? '', stopLossProfit: p.stopLossProfit ?? '', breakEvenProfit: p.breakEvenProfit ?? '',
  winResultImageBytes: p.winResultImageBase64 == null || p.winResultImageBase64!.isEmpty ? null : _tryDecodeBase64(p.winResultImageBase64!), winTrades: p.winTrades,
)..likes = p.likesCount
 ..comments = p.commentsCount
 ..reposts = p.repostsCount
 ..followers = p.followersCount
 ..views = p.viewsCount;

class _EventDetailPage extends StatelessWidget {
  final FeedPostModel post;
  const _EventDetailPage({required this.post});
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.adaptiveSurface(Color(0xFF05080D)),
    appBar: AppBar(backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)), title: Text('EVENT', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900))),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Text('EVENT', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
      const SizedBox(height: 8),
      _CommunityPostCard(post: _feedPostToCommunity(post)),
    ]),
  );
}

class _FeedSearchPage extends StatefulWidget {
  final Future<List<FeedPostModel>> feedFuture;

  const _FeedSearchPage({required this.feedFuture});

  @override
  State<_FeedSearchPage> createState() => _FeedSearchPageState();
}

class _FeedSearchPageState extends State<_FeedSearchPage> {
  final TextEditingController _controller = TextEditingController();
  int _tab = 0; // 0 all, 1 content, 2 users, 3 events
  String _query = '';
  late Future<List<FeedPostModel>> _future;
  late Future<List<Map<String, String>>> _userFuture;

  @override
  void initState() {
    super.initState();
    _future = widget.feedFuture;
    _userFuture = _loadSearchUsers();
    _controller.addListener(() {
      if (!mounted) return;
      setState(() => _query = _controller.text.trim().toLowerCase());
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<List<Map<String, String>>> _loadSearchUsers() async {
    try {
      final snap = await FirebaseFirestore.instance.collection('users').limit(500).get();
      final result = <Map<String, String>>[];
      for (final doc in snap.docs) {
        final data = doc.data();
        final raw = data['alphaDenProfile'];
        final email = (data['email'] ?? '').toString().trim().toLowerCase();
        final isKnownAdmin = email == 'cryptodoctors73@gmail.com' ||
            email == 'teamcryptodoctors@gmail.com' ||
            email == 'sbroland11@gmail.com' ||
            email == 'sbroland@gmail.com';
        final profile = raw is Map ? Map<String, dynamic>.from(raw) : <String, dynamic>{};
        final name = (profile['username'] ?? profile['name'] ?? data['displayName'] ??
                (isKnownAdmin ? 'CRYPTO-DOCTORS-HUB ADMIN' : 'Community Member'))
            .toString()
            .trim();
        if (name.isEmpty) continue;
        result.add({'uid': doc.id, 'name': name, 'isAdmin': isKnownAdmin ? 'true' : 'false'});
      }
      result.sort((a, b) => a['name']!.toLowerCase().compareTo(b['name']!.toLowerCase()));
      return result;
    } catch (_) {
      return const <Map<String, String>>[];
    }
  }

  bool _matchesContent(FeedPostModel post) {
    if (_query.isEmpty) return true;
    final haystack = <String>[
      post.text,
      post.authorDisplayName,
      post.sourceType,
      post.sourceId ?? '',
      ...post.hashtags,
      ...post.coins,
    ].join(' ').toLowerCase();
    return haystack.contains(_query);
  }

  List<FeedPostModel> _filtered(List<FeedPostModel> posts) {
    if (_query.isEmpty) return posts.take(30).toList();
    return posts.where(_matchesContent).take(50).toList();
  }

  List<String> _uniqueUsers(List<FeedPostModel> posts) {
    final seen = <String>{};
    final users = <String>[];
    for (final post in posts) {
      final name = post.authorDisplayName.trim();
      if (name.isEmpty) continue;
      if (_query.isNotEmpty && !name.toLowerCase().contains(_query)) continue;
      if (seen.add(name.toLowerCase())) users.add(name);
    }
    return users.take(50).toList();
  }

  List<FeedPostModel> _events(List<FeedPostModel> posts) {
    return posts.where((post) {
      final isEvent = post.sourceType.toLowerCase() == 'event';
      final searchable = '${post.text} ${post.authorDisplayName} ${post.hashtags.join(' ')}'.toLowerCase();
      return isEvent && (_query.isEmpty || searchable.contains(_query));
    }).take(50).toList();
  }

  Widget _tabButton(String label, IconData icon, int index) {
    final selected = _tab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _tab = index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 9),
          decoration: BoxDecoration(
            color: selected ? AppTheme.neonGreen.withValues(alpha: 0.13) : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: selected ? AppTheme.neonGreen.withValues(alpha: 0.28) : Colors.transparent),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 15, color: Colors.grey.shade500),
              const SizedBox(width: 5),
              Text(label, style: TextStyle(color: Colors.grey.shade500, fontSize: 11, fontWeight: FontWeight.w800)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _resultPost(FeedPostModel post) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xFF111111),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.white.withValues(alpha: 0.10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            CircleAvatar(radius: 16, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF18232D)), child: Icon(Icons.person_outline_rounded, size: 17, color: Colors.white)),
            const SizedBox(width: 9),
            Expanded(child: Text(post.authorDisplayName.isEmpty ? 'Community Member' : post.authorDisplayName, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12))),
            Text(post.sourceType.toUpperCase(), style: TextStyle(color: AppTheme.neonGreen.withValues(alpha: 0.75), fontSize: 9, fontWeight: FontWeight.w800)),
          ]),
          if (post.text.trim().isNotEmpty) ...[
            const SizedBox(height: 9),
            Text(post.text, maxLines: 4, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white, height: 1.35, fontSize: 12)),
          ],
          if (post.hashtags.isNotEmpty || post.coins.isNotEmpty) ...[
            const SizedBox(height: 7),
            Text([...post.hashtags.map((e) => '#$e'), ...post.coins.map((e) => '\$$e')].join('  '), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.lightBlueAccent.withValues(alpha: 0.85), fontSize: 10, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: () => Navigator.pop(context)),
        title: const Text('SEARCH', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
          child: Column(
            children: [
              TextField(
                controller: _controller,
                autofocus: true,
                textInputAction: TextInputAction.search,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Search content, users, events and more',
                  hintStyle: const TextStyle(color: Colors.white),
                  prefixIcon: const Icon(Icons.search_rounded, color: Colors.white),
                  suffixIcon: _query.isEmpty ? null : IconButton(icon: const Icon(Icons.clear_rounded, color: Colors.white), onPressed: _controller.clear),
                  filled: true,
                  fillColor: AppTheme.adaptiveSurface(Color(0xB20A1018)),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.16))),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.16))),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: AppTheme.neonGreen.withValues(alpha: 0.50))),
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0x990A1018)), borderRadius: BorderRadius.circular(15), border: Border.all(color: AppTheme.adaptiveWhite(alpha: 0.08))),
                child: Row(children: [
                  _tabButton('ALL', Icons.apps_rounded, 0),
                  _tabButton('CONTENT', Icons.article_outlined, 1),
                  _tabButton('USERS', Icons.people_outline_rounded, 2),
                  _tabButton('EVENTS', Icons.event_outlined, 3),
                ]),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: FutureBuilder<List<FeedPostModel>>(
                  future: _future,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator(color: Colors.white));
                    final posts = snapshot.data ?? const <FeedPostModel>[];
                    final content = _filtered(posts);
                    final events = _events(posts);
                    if (_tab == 2) {
                      return FutureBuilder<List<Map<String, String>>>(
                        future: _userFuture,
                        builder: (context, userSnapshot) {
                          final allUsers = userSnapshot.data ?? const <Map<String, String>>[];
                          final filteredUsers = allUsers
                              .where((u) => _query.isEmpty || u['name']!.toLowerCase().contains(_query))
                              .take(50)
                              .toList();
                          if (userSnapshot.connectionState == ConnectionState.waiting) {
                            return const Center(child: CircularProgressIndicator(color: Colors.white));
                          }
                          if (filteredUsers.isEmpty) {
                            return Center(child: Text('No users found.', style: TextStyle(color: Colors.white)));
                          }
                          return ListView.separated(
                            itemCount: filteredUsers.length,
                            separatorBuilder: (_, _) => const SizedBox(height: 8),
                            itemBuilder: (_, i) => InkWell(
                              borderRadius: BorderRadius.circular(14),
                              onTap: () => _openPublicAlphaDenProfile(context, filteredUsers[i]['uid']!),
                              child: Container(
                                padding: const EdgeInsets.all(13),
                                decoration: BoxDecoration(color: const Color(0xFF111111), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.adaptiveWhite(alpha: 0.08))),
                                child: Row(children: [
                                  CircleAvatar(radius: 19, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF18232D)), child: Icon(Icons.person_outline_rounded, color: Colors.white)),
                                  const SizedBox(width: 10),
                                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    Row(children: [
                                      Flexible(child: Text(filteredUsers[i]['name']!, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
                                      if (filteredUsers[i]['isAdmin'] == 'true') ...[
                                        const SizedBox(width: 7),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                          decoration: BoxDecoration(color: AppTheme.luxuryGold.withValues(alpha: .12), borderRadius: BorderRadius.circular(7), border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: .38))),
                                          child: Text('ADMIN', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 7, fontWeight: FontWeight.w900, letterSpacing: .5)),
                                        ),
                                      ],
                                    ]),
                                    const SizedBox(height: 2),
                                    Text(filteredUsers[i]['isAdmin'] == 'true' ? 'Official Crypto Doctors Hub Alpha Den' : 'Alpha Den profile', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w600)),
                                  ])),
                                  Icon(Icons.chevron_right_rounded, color: Colors.white),
                                ]),
                              ),
                            ),
                          );
                        },
                      );
                    }
                    if (_tab == 3) {
                      if (events.isEmpty) return Center(child: Text('No events found yet.', style: TextStyle(color: Colors.white)));
                      return ListView(children: [for (final post in events) InkWell(onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => _EventDetailPage(post: post))), child: _resultPost(post))]);
                    }
                    if (content.isEmpty) return Center(child: Text(_query.isEmpty ? 'Start typing to search.' : 'No results found.', style: TextStyle(color: Colors.white)));
                    return ListView(children: [for (final post in content) _resultPost(post)]);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SUBTLE REGULAR-POST GLASS EFFECT
// ============================================================
BoxDecoration _regularPostGlassDecoration({required Color borderColor, double radius = 18}) {
  return BoxDecoration(
    color: AppTheme.adaptiveSurface(Color(0xE6303238)),
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        Color(0xEE3A3C42),
        AppTheme.adaptiveSurface(Color(0xE6303238)),
        Color(0xE833353B),
      ],
      stops: [0.0, 0.48, 1.0],
    ),
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: borderColor.withValues(alpha: .26)),
    boxShadow: const [
      BoxShadow(color: Color(0x24000000), blurRadius: 12, offset: Offset(0, 4)),
      BoxShadow(color: Color(0x12000000), blurRadius: 2, offset: Offset(0, 1)),
    ],
  );
}

// ============================================================
// ANALYSIS
// ============================================================

class _AnalysisPost {
  final String id;
  final String author;
  final String email;
  final String authorUid;
  final String profilePicUrl;
  final Uint8List? profilePicBytes;
  final int referrals;
  final bool verified;
  final int winTrades;
  String text;
  final Uint8List? imageBytes;
  final Uint8List? thumbnailBytes;
  final bool bullish;
  final DateTime createdAt;
  int views = 0;
  String? feedPostId;

  _AnalysisPost({
    required this.id,
    required this.author,
    required this.email,
    this.authorUid = '',
    this.profilePicUrl = '',
    this.profilePicBytes,
    this.referrals = 0,
    this.verified = false,
    this.winTrades = 0,
    required this.text,
    required this.imageBytes,
    required this.thumbnailBytes,
    required this.bullish,
    DateTime? createdAt,
    this.feedPostId,
    this.views = 0,
  }) : createdAt = createdAt ?? DateTime.now();
}

final ValueNotifier<List<_AnalysisPost>> _analysisPosts =
    ValueNotifier<List<_AnalysisPost>>(<_AnalysisPost>[]);

String? _analysisImageBase64(Uint8List? bytes, {int maxBytes = 600000}) {
  if (bytes == null || bytes.isEmpty || bytes.length > maxBytes) return null;
  return base64Encode(bytes);
}

_AnalysisPost _analysisPostFromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
  final data = doc.data() ?? <String, dynamic>{};
  Uint8List? decode(dynamic value) {
    final raw = (value ?? '').toString();
    if (raw.isEmpty) return null;
    try { return base64Decode(raw); } catch (_) { return null; }
  }
  final created = data['createdAt'];
  final createdAt = created is Timestamp ? created.toDate() : DateTime.tryParse((created ?? '').toString()) ?? DateTime.now();
  return _AnalysisPost(
    id: doc.id,
    author: (data['authorDisplayName'] ?? 'CRYPTO-DOCTORS-HUB ADMIN').toString(),
    email: (data['authorEmail'] ?? '').toString(),
    authorUid: (data['authorUid'] ?? '').toString(),
    profilePicUrl: (data['authorProfilePicUrl'] ?? '').toString(),
    profilePicBytes: decode(data['authorProfilePicBase64']),
    referrals: (data['authorReferrals'] as num?)?.toInt() ?? 0,
    verified: data['authorVerified'] == true,
    winTrades: (data['authorWinTrades'] as num?)?.toInt() ?? 0,
    text: (data['text'] ?? '').toString(),
    imageBytes: decode(data['imageBase64']),
    thumbnailBytes: decode(data['thumbnailBase64']),
    bullish: data['bullish'] != false,
    createdAt: createdAt,
    feedPostId: (data['feedPostId'] ?? '').toString().trim().isEmpty ? null : (data['feedPostId'] ?? '').toString(),
    views: (data['viewsCount'] as num?)?.toInt() ?? 0,
  );
}

Future<void> _loadAnalysisPosts() async {
  try {
    final snapshot = await FirebaseFirestore.instance
        .collection('analysis_posts')
        .orderBy('createdAt', descending: true)
        .limit(200)
        .get();
    _analysisPosts.value = snapshot.docs
        .where((doc) => doc.data()['isPublished'] == true)
        .map(_analysisPostFromFirestore)
        .toList();
  } catch (_) {
    // Keep the existing local state if the backend is temporarily unavailable.
  }
}

Future<void> _publishAnalysisPost(_AnalysisPost post) async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) return;

  final analysisRef = FirebaseFirestore.instance.collection('analysis_posts').doc(post.id);
  final profile = await _feedAdminProfile();
  final imageBase64 = _analysisImageBase64(post.imageBytes, maxBytes: 600000);
  // Keep the thumbnail conservative so the analysis document remains safely below Firestore's document-size limit.
  final thumbnailBase64 = _analysisImageBase64(post.thumbnailBytes, maxBytes: 180000);

  await analysisRef.set({
    'authorUid': user.uid,
    'authorDisplayName': 'CRYPTO-DOCTORS-HUB ADMIN',
    'authorEmail': (user.email ?? '').trim().toLowerCase(),
    'authorProfilePicUrl': (profile['photoUrl'] ?? '').toString(),
    'authorProfilePicBase64': _analysisImageBase64(profile['avatar'] as Uint8List?, maxBytes: 500000),
    'authorReferrals': (profile['referrals'] as num?)?.toInt() ?? 0,
    'authorVerified': profile['verified'] == true,
    'authorWinTrades': (profile['winTrades'] as num?)?.toInt() ?? 0,
    'text': post.text,
    'imageBase64': imageBase64,
    'thumbnailBase64': thumbnailBase64,
    'bullish': post.bullish,
    'createdAt': Timestamp.fromDate(post.createdAt),
    'viewsCount': 0,
    'isPublished': true,
    'sourceType': 'analysis',
  });

  // The same Analysis is automatically published into CD Feed.
  final feedId = await _publishToCommunityFeed(
    _CommunityPost(
      id: 'analysis-${post.id}', authorUid: user.uid,
      username: 'CRYPTO-DOCTORS-HUB ADMIN', nickname: 'CRYPTO-DOCTORS-HUB ADMIN',
      profilePicUrl: (profile['photoUrl'] ?? '').toString(), profilePicBytes: profile['avatar'] as Uint8List?,
      badge: (profile['badge'] ?? 'ADMIN').toString(),
      verified: profile['verified'] == true,
      referrals: (profile['referrals'] as num?)?.toInt() ?? 0,
      winTrades: (profile['winTrades'] as num?)?.toInt() ?? 0,
      isPremium: profile['isPremium'] == true,
      text: post.text,
      imageBytes: post.imageBytes,
      thumbnailBytes: post.thumbnailBytes,
      bullish: post.bullish,
      hashtags: const <String>[],
      coins: const <String>[],
      createdAt: post.createdAt,
    ),
    sourceType: 'analysis',
    sourceId: post.id,
  );

  post.feedPostId = feedId;
  await analysisRef.update({'feedPostId': feedId});

  _analysisPosts.value = <_AnalysisPost>[post, ..._analysisPosts.value.where((item) => item.id != post.id)];
}

class AnalysisPage extends StatefulWidget {
  final bool isAdmin;
  final String accountEmail;
  const AnalysisPage({super.key, required this.isAdmin, required this.accountEmail});

  @override
  State<AnalysisPage> createState() => _AnalysisPageState();
}

class _AnalysisPageState extends State<AnalysisPage> {
  bool get _canPublishAnalysis =>
      widget.isAdmin && widget.accountEmail.trim().toLowerCase() == 'cryptodoctors73@gmail.com';

  @override
  void initState() {
    super.initState();
    _loadAnalysisPosts();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
              child: Row(
                children: [
                  const Spacer(),
                  if (_canPublishAnalysis)
                    _JellyPlusButton(
                      tooltip: 'Create analysis',
                      onPressed: () async {
                        final post = await Navigator.push<_AnalysisPost>(
                          context,
                          PageRouteBuilder(
                            transitionDuration: const Duration(milliseconds: 420),
                            pageBuilder: (_, animation, _) => const _AnalysisComposerPage(),
                            transitionsBuilder: (_, animation, _, child) {
                              return FadeTransition(
                                opacity: animation,
                                child: SlideTransition(
                                  position: Tween<Offset>(begin: const Offset(0.08, 0), end: Offset.zero)
                                      .animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic)),
                                  child: child,
                                ),
                              );
                            },
                          ),
                        );
                        if (post != null && mounted) {
                          await _publishAnalysisPost(post);
                        }
                      },
                    ),
                ],
              ),
            ),
            Expanded(
              child: ValueListenableBuilder<List<_AnalysisPost>>(
                valueListenable: _analysisPosts,
                builder: (context, posts, _) {
                  return RefreshIndicator(
                    onRefresh: () async {
                      await Future<void>.delayed(const Duration(milliseconds: 300));
                      if (mounted) setState(() {});
                    },
                    child: posts.isEmpty
                        ? ListView(
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: const EdgeInsets.fromLTRB(16, 24, 16, 110),
                            children: [
                              SizedBox(height: 120),
                              Center(
                                child: Text(
                                  'No analysis published yet.',
                                  style: TextStyle(color: AppTheme.textMuted),
                                ),
                              ),
                            ],
                          )
                        : ListView.builder(
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
                            itemCount: posts.length,
                            itemBuilder: (context, index) => _AnalysisPostCard(post: posts[index]),
                          ),
                  );
                },
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _AnalysisPostCard extends StatefulWidget {
  final _AnalysisPost post;
  const _AnalysisPostCard({required this.post});

  @override
  State<_AnalysisPostCard> createState() => _AnalysisPostCardState();
}

class _AnalysisPostCardState extends State<_AnalysisPostCard> {
  Timer? _viewTimer;
  bool _liked = false;
  bool _reposted = false;
  Map<String, dynamic>? _alphaProfile;
  Uint8List? _alphaProfilePicBytes;

  @override
  void initState() {
    super.initState();
    _loadAlphaDenProfile();
    widget.post.views++;
    _viewTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted) return;
      setState(() => widget.post.views++);
    });
  }

  Future<void> _loadAlphaDenProfile() async {
    final uid = widget.post.authorUid.trim().isNotEmpty
        ? widget.post.authorUid.trim()
        : (FirebaseAuth.instance.currentUser?.uid ?? '').trim();
    if (uid.isEmpty) return;
    try {
      final loaded = await AlphaDenService.loadProfile(uid);
      if (!mounted || loaded == null) return;
      Uint8List? pic;
      final encoded = (loaded['profilePicBase64'] ?? '').toString().trim();
      if (encoded.isNotEmpty) {
        try { pic = base64Decode(encoded); } catch (_) {}
      }
      setState(() {
        _alphaProfile = loaded;
        _alphaProfilePicBytes = pic;
      });
    } catch (_) {
      // Keep the profile snapshot stored on the Analysis post as a safe fallback.
    }
  }

  @override
  void dispose() {
    _viewTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = widget.post.bullish ? AppTheme.neonGreen : const Color(0xFFE05252);
    final profile = _alphaProfile;
    final profileName = (profile?['username'] ?? profile?['name'] ?? widget.post.author).toString().trim();
    final profilePicUrl = (profile?['profilePicUrl'] ?? widget.post.profilePicUrl).toString().trim();
    final profilePicBytes = _alphaProfilePicBytes ?? widget.post.profilePicBytes;
    final profileReferrals = (profile?['referrals'] as num?)?.toInt() ?? widget.post.referrals;
    final profileWinTrades = (profile?['winTrades'] as num?)?.toInt() ?? widget.post.winTrades;
    final profileVerified = profile?['verifiedCreatorApproved'] == true || profile?['verified'] == true || widget.post.verified;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: _regularPostGlassDecoration(
        borderColor: accent,
        radius: 18,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 13, 14, 8),
            child: Row(
              children: [
                CircleAvatar(
                radius: 18,
                backgroundColor: AppTheme.adaptiveSurface(Color(0xFF111A24)),
                backgroundImage: profilePicBytes != null
                    ? MemoryImage(profilePicBytes)
                    : (profilePicUrl.isNotEmpty ? NetworkImage(profilePicUrl) : null),
                child: profilePicBytes == null && profilePicUrl.isEmpty
                    ? Icon(Icons.person, color: AppTheme.textPrimary, size: 18)
                    : null,
              ),
              const SizedBox(width: 8),
              Expanded(child: Row(children: [
                Flexible(child: Text(profileName.isEmpty ? widget.post.author : profileName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800))),
                if (profileVerified) ...[const SizedBox(width: 5), const Icon(Icons.verified, color: Color(0xFF4EA7FF), size: 16)],
                const SizedBox(width: 5),
                _ReferralCrownBadge(referrals: profileReferrals, flamingAura: profileWinTrades >= 10),
              ])),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: accent.withValues(alpha: 0.55)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(widget.post.bullish ? Icons.trending_up : Icons.trending_down, color: accent, size: 15),
                      const SizedBox(width: 4),
                      Text(widget.post.bullish ? 'BULL' : 'BEAR', style: TextStyle(color: accent, fontWeight: FontWeight.w900, fontSize: 10)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (widget.post.text.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              child: _LongContentPreview(
                text: widget.post.text,
                onShowMore: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _FullTextPostPage(title: 'CD ANALYSIS', author: widget.post.author, text: widget.post.text, imageBytes: widget.post.imageBytes))),
              ),
            ),
          if (widget.post.imageBytes != null)
            GestureDetector(
              onTap: () => showDialog<void>(
                context: context,
                builder: (_) => Dialog(
                  backgroundColor: Colors.black,
                  insetPadding: const EdgeInsets.all(12),
                  child: InteractiveViewer(
                    child: Image.memory(widget.post.imageBytes!, fit: BoxFit.contain),
                  ),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 6, 14, 10),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.memory(
                    widget.post.thumbnailBytes ?? widget.post.imageBytes!,
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: 190,
                  ),
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
            child: Row(
              children: [
                IconButton(
                  visualDensity: const VisualDensity(horizontal: -3, vertical: -3),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                  onPressed: () => setState(() { _liked = !_liked; }),
                  icon: Icon(_liked ? Icons.favorite : Icons.favorite_border, size: 17, color: _liked ? const Color(0xFFFF3B4D) : AppTheme.textSecondary),
                ),
                Text(_liked ? 'Liked' : 'Like', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)),
                const SizedBox(width: 5),
                IconButton(
                  visualDensity: const VisualDensity(horizontal: -3, vertical: -3),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                  onPressed: () async {
                    final feedPostId = widget.post.feedPostId;
                    if (feedPostId == null || feedPostId.isEmpty) return;
                    final added = await _showFeedCommentsSheet(context, postId: feedPostId, authorUid: '');
                    if (added > 0 && mounted) setState(() {});
                  },
                  icon: Icon(Icons.comment_outlined, size: 17, color: AppTheme.textSecondary),
                ),
                Text('Comment', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)),
                const SizedBox(width: 5),
                IconButton(
                  visualDensity: const VisualDensity(horizontal: -3, vertical: -3),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                  onPressed: () => setState(() => _reposted = true),
                  icon: Icon(Icons.repeat, size: 17, color: _reposted ? AppTheme.luxuryGold : AppTheme.textSecondary),
                ),
                Text(_reposted ? 'Reposted' : 'Repost', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)),
                const Spacer(),
                Icon(Icons.remove_red_eye_outlined, size: 16, color: AppTheme.textSoft),
                const SizedBox(width: 4),
                Text('${widget.post.views}', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LongContentPreview extends StatelessWidget {
  final String text;
  final VoidCallback onShowMore;
  const _LongContentPreview({required this.text, required this.onShowMore});
  @override
  Widget build(BuildContext context) {
    const limit = 360;
    final long = text.length > limit;
    final preview = long ? '${text.substring(0, limit).trimRight()}…' : text;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(preview, style: const TextStyle(fontSize: 14, height: 1.35)),
      if (long) ...[
        const SizedBox(height: 5),
        TextButton(onPressed: onShowMore, style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 30)), child: const Text('SHOW MORE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .4))),
      ],
    ]);
  }
}

class _FullTextPostPage extends StatelessWidget {
  final String title;
  final String author;
  final String text;
  final Uint8List? imageBytes;
  const _FullTextPostPage({required this.title, required this.author, required this.text, this.imageBytes});
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.adaptiveSurface(Color(0xFF070B10)),
    appBar: AppBar(title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14))),
    body: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 40), children: [
      Text(author, style: TextStyle(color: AppTheme.luxuryGold, fontSize: 11, fontWeight: FontWeight.w900)),
      const SizedBox(height: 12),
      if (imageBytes != null) ...[ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(imageBytes!, fit: BoxFit.cover)), const SizedBox(height: 14)],
      Text(text, style: TextStyle(color: AppTheme.textPrimary, fontSize: 15, height: 1.55)),
    ]),
  );
}

class _AnalysisComposerPage extends StatefulWidget {
  const _AnalysisComposerPage();

  @override
  State<_AnalysisComposerPage> createState() => _AnalysisComposerPageState();
}

class _AnalysisComposerPageState extends State<_AnalysisComposerPage> with SingleTickerProviderStateMixin {
  final TextEditingController _controller = TextEditingController();
  Uint8List? _imageBytes;
  Uint8List? _thumbnailBytes;
  final bool _bullish = true;
  late final AnimationController _entry = AnimationController(vsync: this, duration: const Duration(milliseconds: 650))..forward();

  @override
  void dispose() {
    _entry.dispose();
    _controller.dispose();
    super.dispose();
  }

  final ImagePicker _analysisImagePicker = ImagePicker();

  Future<Uint8List?> _pickImageBytes({required bool thumbnail}) async {
    try {
      // Use image_picker instead of a browser-only FileUploadInputElement so
      // Analysis images work on Android, iOS and Web. The old HTML picker was
      // the reason the buttons could appear to do nothing on the phone.
      final picked = await _analysisImagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: thumbnail ? 72 : 82,
        maxWidth: thumbnail ? 720 : 1600,
        maxHeight: thumbnail ? 720 : 1600,
      );
      if (picked == null) return null;

      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty) return null;

      final limit = thumbnail ? 180000 : 600000;
      if (bytes.length > limit) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                thumbnail
                    ? 'Thumbnail is too large. Please choose a smaller image.'
                    : 'Image is too large. Please choose a smaller image.',
              ),
            ),
          );
        }
        return null;
      }
      return bytes;
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not insert image: $e')),
        );
      }
      return null;
    }
  }

  Future<void> _pickOriginal() async {
    final bytes = await _pickImageBytes(thumbnail: false);
    if (bytes != null && mounted) setState(() => _imageBytes = bytes);
  }

  Future<void> _pickThumbnail() async {
    final bytes = await _pickImageBytes(thumbnail: true);
    if (bytes != null && mounted) setState(() => _thumbnailBytes = bytes);
  }

  void _publish() {
    if (_controller.text.trim().isEmpty && _imageBytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add analysis text or a chart/image before publishing.')));
      return;
    }
    Navigator.pop(
      context,
      _AnalysisPost(
        id: '${DateTime.now().microsecondsSinceEpoch}',
        author: 'CRYPTO-DOCTORS-HUB ADMIN',
        email: '',
        text: _controller.text.trim(),
        imageBytes: _imageBytes,
        thumbnailBytes: _thumbnailBytes,
        bullish: _bullish,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final accent = _bullish ? AppTheme.neonGreen : const Color(0xFFE05252);
    return Scaffold(
      appBar: AppBar(
        title: const Text('CREATE ANALYSIS'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12, top: 8, bottom: 8),
            child: FilledButton(
              onPressed: _publish,
              style: FilledButton.styleFrom(backgroundColor: AppTheme.luxuryGold, foregroundColor: Colors.black),
              child: const Text('PUBLISH', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          const GalaxyBackground(animatePlanets: true, cinematicEntrance: false),
          SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _entry, curve: Curves.easeOut),
              child: SlideTransition(
                position: Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero).animate(CurvedAnimation(parent: _entry, curve: Curves.easeOutCubic)),
                child: Column(
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
                        child: TextField(
                          controller: _controller,
                          expands: true,
                          maxLines: null,
                          minLines: null,
                          textAlignVertical: TextAlignVertical.top,
                          decoration: InputDecoration(
                            hintText: 'Write your market analysis...',
                            filled: true,
                            fillColor: AppTheme.adaptiveSurface(Color(0xB5090D12)),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: accent.withValues(alpha: 0.25))),
                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: accent.withValues(alpha: 0.25))),
                            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: accent.withValues(alpha: 0.65))),
                            contentPadding: const EdgeInsets.all(18),
                          ),
                        ),
                      ),
                    ),
                    if (_imageBytes != null || _thumbnailBytes != null)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        child: Row(
                          children: [
                            if (_imageBytes != null)
                              ClipRRect(
                                borderRadius: BorderRadius.circular(9),
                                child: Image.memory(_imageBytes!, width: 74, height: 52, fit: BoxFit.cover),
                              ),
                            if (_thumbnailBytes != null) ...[
                              const SizedBox(width: 8),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(9),
                                child: Image.memory(_thumbnailBytes!, width: 74, height: 52, fit: BoxFit.cover),
                              ),
                            ],
                          ],
                        ),
                      ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
                      child: Row(
                        children: [
                          IconButton(
                            tooltip: 'Add original chart or image',
                            onPressed: _pickOriginal,
                            icon: const Icon(Icons.image_outlined, size: 25),
                            color: AppTheme.textSecondary,
                          ),
                          IconButton(
                            tooltip: 'Add thumbnail',
                            onPressed: _pickThumbnail,
                            icon: const Icon(Icons.photo_size_select_actual_outlined, size: 24),
                            color: AppTheme.textSecondary,
                          ),
                          const Spacer(),
                          Icon(Icons.remove_red_eye_outlined, color: AppTheme.textMuted, size: 22),
                          const SizedBox(width: 4),
                          Text('0', style: TextStyle(color: AppTheme.textMuted, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}


// ============================================================
// LIVE CALLS
// ============================================================

class _LiveCallPost {
  final String id;
  final String asset;
  final String entry;
  final bool longDirection;
  final bool bullish;
  final String tp1;
  final String tp2;
  final String tp3;
  final String stopLoss;
  final int leverage;
  final Uint8List? imageBytes;
  final DateTime createdAt;
  int goodReactions;
  int badReactions;
  bool tp1Hit, tp2Hit, tp3Hit, stopLossHit, breakEven, winTradeCounted;
  String tp1Profit, tp2Profit, tp3Profit, stopLossProfit, breakEvenProfit;
  bool tradeClosed = false;
  bool closedGreen = false;
  double finalProfitPercentage = 0;
  String resultPercentage = '';
  int dailySequence = 0;
  String accessTier = '';

  _LiveCallPost({
    required this.id,
    required this.asset,
    required this.entry,
    required this.longDirection,
    required this.bullish,
    required this.tp1,
    required this.tp2,
    required this.tp3,
    required this.stopLoss,
    required this.leverage,
    required this.imageBytes,
    DateTime? createdAt,
    this.goodReactions = 0,
    this.badReactions = 0,
    this.tp1Hit = false, this.tp2Hit = false, this.tp3Hit = false, this.stopLossHit = false, this.breakEven = false, this.winTradeCounted = false,
    this.tp1Profit = '', this.tp2Profit = '', this.tp3Profit = '', this.stopLossProfit = '', this.breakEvenProfit = '',
    this.tradeClosed = false, this.closedGreen = false,
    this.finalProfitPercentage = 0, this.resultPercentage = '',
    this.dailySequence = 0, this.accessTier = '',
  }) : createdAt = createdAt ?? DateTime.now();
}

final ValueNotifier<List<_LiveCallPost>> _liveCallPosts =
    ValueNotifier<List<_LiveCallPost>>(<_LiveCallPost>[]);


String? _liveCallImageBase64(Uint8List? bytes) => bytes == null || bytes.isEmpty || bytes.length > 600000 ? null : base64Encode(bytes);
DateTime _liveCallDate(dynamic v) => v is Timestamp ? v.toDate() : DateTime.tryParse((v ?? '').toString()) ?? DateTime.now();
Uint8List? _decodeLiveCallImage(dynamic v) { final raw=(v??'').toString(); if(raw.isEmpty)return null; try{return base64Decode(raw);}catch(_){return null;} }
_LiveCallPost _liveCallFromFirestore(DocumentSnapshot<Map<String,dynamic>> doc){final d=doc.data()??{};return _LiveCallPost(id:doc.id,asset:(d['asset']??'').toString(),entry:(d['entry']??'').toString(),longDirection:d['longDirection']!=false,bullish:d['bullish']!=false,tp1:(d['tp1']??'').toString(),tp2:(d['tp2']??'').toString(),tp3:(d['tp3']??'').toString(),stopLoss:(d['stopLoss']??'').toString(),leverage:(d['leverage'] as num?)?.toInt()??10,imageBytes:_decodeLiveCallImage(d['imageBase64']),createdAt:_liveCallDate(d['createdAt']),goodReactions:(d['goodReactions'] as num?)?.toInt()??0,badReactions:(d['badReactions'] as num?)?.toInt()??0,tp1Hit:d['tp1Hit']==true,tp2Hit:d['tp2Hit']==true,tp3Hit:d['tp3Hit']==true,stopLossHit:d['stopLossHit']==true,breakEven:d['breakEven']==true,winTradeCounted:d['winTradeCounted']==true,tp1Profit:(d['tp1Profit']??'').toString(),tp2Profit:(d['tp2Profit']??'').toString(),tp3Profit:(d['tp3Profit']??'').toString(),stopLossProfit:(d['stopLossProfit']??'').toString(),breakEvenProfit:(d['breakEvenProfit']??'').toString(),tradeClosed:d['tradeClosed']==true,closedGreen:d['closedGreen']==true,finalProfitPercentage:(d['finalProfitPercentage'] as num?)?.toDouble()??0,resultPercentage:(d['resultPercentage']??'').toString(),dailySequence:(d['dailySequence'] as num?)?.toInt()??0,accessTier:(d['accessTier']??'').toString());}
Map<String,dynamic> _liveCallPublicData(_LiveCallPost p){
  final tier=p.accessTier.isEmpty?(p.dailySequence>2?'premium':'free'):p.accessTier;
  final d=<String,dynamic>{
    'createdAt':Timestamp.fromDate(p.createdAt),
    'goodReactions':p.goodReactions,
    'badReactions':p.badReactions,
    'tradeClosed':p.tradeClosed,
    'closedGreen':p.closedGreen,
    'finalProfitPercentage':p.finalProfitPercentage,
    'resultPercentage':p.resultPercentage,
    'dailySequence':p.dailySequence,
    'accessTier':tier,
    'isPublished':true,
  };
  // Public outcome fields are safe to expose. Protected Entry / target prices /
  // Stop Loss / Leverage / image data remain in premiumData/details.
  d.addAll({
    'asset': p.asset,
    'tp1Hit': p.tp1Hit,
    'tp2Hit': p.tp2Hit,
    'tp3Hit': p.tp3Hit,
    'stopLossHit': p.stopLossHit,
    'breakEven': p.breakEven,
    'tp1Profit': p.tp1Profit,
    'tp2Profit': p.tp2Profit,
    'tp3Profit': p.tp3Profit,
    'stopLossProfit': p.stopLossProfit,
    'breakEvenProfit': p.breakEvenProfit,
  });
  // Direction, coin name and public result metadata are always readable.
  // Premium pricing/details stay protected only while the signal is active.
  // Once any TP/SL is hit or Admin officially closes the trade, the complete
  // signal becomes public so Free users can see the original signal content
  // behind the light result blur/tick.
  d['longDirection'] = p.longDirection;
  d['tradeName'] = p.asset;
  final revealFullSignal = p.tp1Hit || p.tp2Hit || p.tp3Hit || p.stopLossHit || p.tradeClosed;
  if(tier!='premium' || revealFullSignal){
    d.addAll({
      'entry':p.entry,'bullish':p.bullish,
      'tp1':p.tp1,'tp2':p.tp2,'tp3':p.tp3,'stopLoss':p.stopLoss,'leverage':p.leverage,
      'imageBase64':_liveCallImageBase64(p.imageBytes),
      'winTradeCounted':p.winTradeCounted,
    });
  }
  return d;
}
Map<String,dynamic> _liveCallProtectedData(_LiveCallPost p)=>{
  'asset':p.asset,'entry':p.entry,'longDirection':p.longDirection,'bullish':p.bullish,
  'tp1':p.tp1,'tp2':p.tp2,'tp3':p.tp3,'stopLoss':p.stopLoss,'leverage':p.leverage,
  'imageBase64':_liveCallImageBase64(p.imageBytes),'tp1Hit':p.tp1Hit,'tp2Hit':p.tp2Hit,
  'tp3Hit':p.tp3Hit,'stopLossHit':p.stopLossHit,'breakEven':p.breakEven,
  'winTradeCounted':p.winTradeCounted,'tp1Profit':p.tp1Profit,'tp2Profit':p.tp2Profit,
  'tp3Profit':p.tp3Profit,'stopLossProfit':p.stopLossProfit,'breakEvenProfit':p.breakEvenProfit,
};
Map<String,dynamic> _liveCallData(_LiveCallPost p)=>_liveCallPublicData(p);
Future<void> _persistLiveCall(_LiveCallPost p) async{
  final db=FirebaseFirestore.instance;
  final ref=db.collection('live_calls').doc(p.id);
  await ref.set(_liveCallPublicData(p));
  if(p.accessTier=='premium') await ref.collection('premiumData').doc('details').set(_liveCallProtectedData(p));
}
Future<void> _updateLiveCallBackend(_LiveCallPost p) async{
  final db=FirebaseFirestore.instance;
  final ref=db.collection('live_calls').doc(p.id);
  await ref.update(_liveCallPublicData(p));
  if(p.accessTier=='premium') await ref.collection('premiumData').doc('details').set(_liveCallProtectedData(p),SetOptions(merge:true));
}
String _liveCallProfit(String entry,String target,bool longDir,int leverage){final e=double.tryParse(entry.replaceAll(',','').trim());final t=double.tryParse(target.replaceAll(',','').trim());if(e==null||t==null||e==0)return '';final move=longDir?((t-e)/e)*100:((e-t)/e)*100;final raw=move*leverage;return raw.roundToDouble()==raw?raw.toStringAsFixed(0):raw.toStringAsFixed(2);}
bool _liveCallWin(_LiveCallPost p)=>p.tp1Hit||p.tp2Hit||p.tp3Hit;
bool _liveCallLoss(_LiveCallPost p)=>!_liveCallWin(p)&&p.stopLossHit;
Future<void> _recordLiveParticipant(String id,bool like) async{final u=FirebaseAuth.instance.currentUser;if(u==null)return;final db=FirebaseFirestore.instance;final participantRef=db.collection('live_calls').doc(id).collection('participants').doc(u.uid);final journalRef=db.collection('users').doc(u.uid).collection('tradingJournal').doc(id);if(!like){try{await participantRef.delete();}catch(_){ }try{await journalRef.delete();}catch(_){ }return;}try{final call=await db.collection('live_calls').doc(id).get();final data=call.data()??<String,dynamic>{};final publicAsset=(data['asset']??'').toString();final longDirection=data['longDirection']!=false;await participantRef.set({'uid':u.uid,'tookTrade':true,'reaction':'like','likedAt':FieldValue.serverTimestamp(),'signalCreatedAt':data['createdAt']??FieldValue.serverTimestamp(),'asset':publicAsset,'tradeName':publicAsset,'longDirection':longDirection,'updatedAt':FieldValue.serverTimestamp()},SetOptions(merge:true));await journalRef.set({'liveCallId':id,'tookTrade':true,'interaction':'like','status':'OPEN','asset':publicAsset,'tradeName':publicAsset,'longDirection':longDirection,'signalCreatedAt':data['createdAt']??FieldValue.serverTimestamp(),'likedAt':FieldValue.serverTimestamp(),'updatedAt':FieldValue.serverTimestamp()},SetOptions(merge:true));}catch(_){}}
Future<Map<String,dynamic>> _feedAdminProfile() async{final u=FirebaseAuth.instance.currentUser;if(u==null)return {};try{final d=(await FirebaseFirestore.instance.collection('users').doc(u.uid).get()).data()??{};Uint8List? a;final x=(d['appAvatarBase64']??'').toString();if(x.isNotEmpty){try{a=base64Decode(x);}catch(_){}}return {
      'uid': u.uid,
      'photoUrl': (d['profilePicUrl'] ?? d['photoURL'] ?? u.photoURL ?? '').toString().trim(),
      'avatar': a,
      'referrals': (d['referrals'] as num?)?.toInt() ?? 0,
      'verified': d['verifiedCreatorApproved'] == true || d['verified'] == true,
      'winTrades': (d['winTrades'] as num?)?.toInt() ?? 0,
      'isPremium': d['isPremium'] == true,
      'badge': _referralBadgeLabel((d['referrals'] as num?)?.toInt() ?? 0),
    };}catch(_){return {'uid':u.uid,'photoUrl':(u.photoURL??'').trim()};}}
Future<void> _recordJournalAggregates(_LiveCallPost p,double finalPct) async{try{final db=FirebaseFirestore.instance;final closedAt=DateTime.now();final weekStart=closedAt.subtract(Duration(days:closedAt.weekday-DateTime.monday));final keys=<String,String>{'daily':'${closedAt.year}-${closedAt.month.toString().padLeft(2,'0')}-${closedAt.day.toString().padLeft(2,'0')}','weekly':'${weekStart.year}-${weekStart.month.toString().padLeft(2,'0')}-${weekStart.day.toString().padLeft(2,'0')}','monthly':'${closedAt.year}-${closedAt.month.toString().padLeft(2,'0')}','yearly':'${closedAt.year}'};final batch=db.batch();for(final e in keys.entries){final ref=db.collection('journalCommunityAggregates').doc('${e.key}_${e.value}');batch.set(ref,{'period':e.key,'periodKey':e.value,'sumProfitPercentage':FieldValue.increment(finalPct),'closedTradeCount':FieldValue.increment(1),'updatedAt':FieldValue.serverTimestamp()},SetOptions(merge:true));}final participants=await db.collection('live_calls').doc(p.id).collection('participants').get();for(final d in participants.docs){if(d.data()['reaction']!='like')continue;for(final e in keys.entries){final ref=db.collection('users').doc(d.id).collection('journalAggregates').doc('${e.key}_${e.value}');batch.set(ref,{'period':e.key,'periodKey':e.value,'sumProfitPercentage':FieldValue.increment(finalPct),'closedTradeCount':FieldValue.increment(1),'updatedAt':FieldValue.serverTimestamp()},SetOptions(merge:true));}}await batch.commit();}catch(_){} }

Future<void> _finalizeLiveJournal(_LiveCallPost p,double finalPct) async {
  try {
    final db = FirebaseFirestore.instance;
    final docs = await db.collection('live_calls').doc(p.id).collection('participants').get();
    final batch = db.batch();
    final r = finalPct > 0 ? 'WIN' : finalPct < 0 ? 'LOSS' : p.breakEven ? 'BREAK EVEN' : 'CLOSED';
    final pct = '${finalPct >= 0 ? '+' : ''}${finalPct.toStringAsFixed(2)}%';
    for (final d in docs.docs) {
      if (d.data()['reaction'] != 'like') continue;
      final ref = db.collection('users').doc(d.id).collection('tradingJournal').doc(p.id);
      batch.update(ref, {
        'officialResult': r,
        'resultPercentage': pct,
        'finalProfitPercentage': finalPct,
        'closedGreen': p.closedGreen,
        'status': 'CLOSED',
        'asset': p.asset,
        'tradeName': p.asset,
        'longDirection': p.longDirection,
        'signalCreatedAt': p.createdAt,
        'tp1Hit': p.tp1Hit,
        'tp2Hit': p.tp2Hit,
        'tp3Hit': p.tp3Hit,
        'tp1Profit': p.tp1Profit,
        'tp2Profit': p.tp2Profit,
        'tp3Profit': p.tp3Profit,
        'closedAt': FieldValue.serverTimestamp(),
      });
    }
    await batch.commit();
  } catch (_) {}
}

Future<List<_LiveCallPost>> _liveCallsForDayFromBackend(DateTime day) async {
  try {
    // Query only published Live Calls first so Firestore security rules can
    // prove that every document returned by the query is readable. The date
    // filtering is then done locally. This also avoids making the publishing
    // sequence depend on an extra composite query.
    final snap = await FirebaseFirestore.instance
        .collection('live_calls')
        .where('isPublished', isEqualTo: true)
        .limit(200)
        .get();
    final start = DateTime(day.year, day.month, day.day);
    final end = start.add(const Duration(days: 1));
    final result = snap.docs
        .map(_liveCallFromFirestore)
        .where((p) => !p.createdAt.isBefore(start) && p.createdAt.isBefore(end))
        .toList();
    result.sort((a, b) {
      final c = a.createdAt.compareTo(b.createdAt);
      return c != 0 ? c : a.id.compareTo(b.id);
    });
    return result;
  } catch (_) {
    return <_LiveCallPost>[];
  }
}

Future<void> _publishLiveCall(_LiveCallPost post) async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) throw StateError('You must be signed in to publish a Live Call.');
  await user.getIdToken(true);
  try {
    final todayCalls = await _liveCallsForDayFromBackend(post.createdAt);
    final sequence = todayCalls.length + 1;
    post.dailySequence = sequence;
    post.accessTier = sequence > 2 ? 'premium' : 'free';
    await _persistLiveCall(post);
    _liveCallPosts.value = <_LiveCallPost>[post, ..._liveCallPosts.value];

    if (sequence > 2) return;
    final profile = await _feedAdminProfile();
    await _publishToCommunityFeed(_CommunityPost(id:'live-call-${post.id}',authorUid:user.uid,username:'CRYPTO-DOCTORS-HUB ADMIN',nickname:'CRYPTO-DOCTORS-HUB ADMIN',profilePicUrl:(profile['photoUrl']??'').toString(),profilePicBytes:profile['avatar'] as Uint8List?,badge:'ADMIN',referrals:0,verified:true,text:'${post.asset} /USDT • ${post.longDirection?'LONG':'SHORT'} • ENTRY ${post.entry} • ${post.leverage}x • TP1 ${post.tp1} • TP2 ${post.tp2} • TP3 ${post.tp3} • STOPLOSS ${post.stopLoss}',imageBytes:post.imageBytes,thumbnailBytes:post.imageBytes,bullish:post.bullish,hashtags:const [],coins:[post.asset],signalAsset:post.asset,signalEntry:post.entry,signalLongDirection:post.longDirection,signalLeverage:post.leverage,signalTp1:post.tp1,signalTp2:post.tp2,signalTp3:post.tp3,signalStopLoss:post.stopLoss,createdAt:post.createdAt),sourceType:'live_call',sourceId:post.id);
  } catch (e) {
    rethrow;
  }
}

Widget _lockedSignalValue(String label, String value) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.adaptiveSurface(Color(0xFF171A1F)),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.borderFaint),
      ),
      child: Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(color: AppTheme.textMuted, fontSize: 10, fontWeight: FontWeight.w700))),
          Flexible(child: Text(value, textAlign: TextAlign.right, style: TextStyle(color: AppTheme.textPrimary, fontSize: 11, fontWeight: FontWeight.w800))),
          const SizedBox(width: 5),
          Icon(Icons.lock_outline_rounded, size: 12, color: AppTheme.textFaint),
        ],
      ),
    ),
  );
}

class LiveCallsPage extends StatefulWidget {
  final bool isAdmin; final bool isPremium; final VoidCallback? onCreate;
  const LiveCallsPage({super.key,required this.isAdmin,required this.isPremium,this.onCreate});
  @override State<LiveCallsPage> createState()=>_LiveCallsPageState();
}

class _LiveCallsPageState extends State<LiveCallsPage> {
  bool _sameDay(DateTime a,DateTime b)=>a.year==b.year&&a.month==b.month&&a.day==b.day;

  Future<void> refresh() async {
    try {
      final snap = await FirebaseFirestore.instance.collection('live_calls').where('isPublished',isEqualTo:true).limit(200).get();
      var posts = snap.docs.map(_liveCallFromFirestore).toList();
      if (widget.isAdmin || widget.isPremium) posts = await _loadLiveCallPostsWithPremiumDetails(snap.docs);
      if (posts.isNotEmpty) _liveCallPosts.value = posts;
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Live Calls refresh failed: $e')));
    }
  }
  Future<void> _outcome(BuildContext context,_LiveCallPost p) async{
    bool a=p.tp1Hit,b=p.tp2Hit,c=p.tp3Hit,sl=p.stopLossHit,be=p.breakEven;
    final tp1Profit=TextEditingController(text:p.tp1Profit.isNotEmpty?p.tp1Profit:_liveCallProfit(p.entry,p.tp1,p.longDirection,p.leverage));
    final tp2Profit=TextEditingController(text:p.tp2Profit.isNotEmpty?p.tp2Profit:_liveCallProfit(p.entry,p.tp2,p.longDirection,p.leverage));
    final tp3Profit=TextEditingController(text:p.tp3Profit.isNotEmpty?p.tp3Profit:_liveCallProfit(p.entry,p.tp3,p.longDirection,p.leverage));
    final stopLossProfit=TextEditingController(text:p.stopLossProfit.isNotEmpty?p.stopLossProfit:_liveCallProfit(p.entry,p.stopLoss,p.longDirection,p.leverage).replaceFirst(RegExp(r'^-'),''));
    final r=await showDialog<Map<String,String>>(context:context,builder:(dc)=>StatefulBuilder(builder:(context,set)=>AlertDialog(backgroundColor:AppTheme.adaptiveSurface(Color(0xFF0B0F11)),title:const Text('ENTER LIVE CALL RESULT',style:TextStyle(fontWeight:FontWeight.w900)),content:SingleChildScrollView(child:Column(children:[
      _lockedSignalValue('ENTRY',p.entry),_lockedSignalValue('LEVERAGE','${p.leverage}x'),
      _lockedSignalValue('TP1',p.tp1),
      Row(children:[Expanded(child:CheckboxListTile(contentPadding:EdgeInsets.zero,dense:true,value:a,title:const Text('TP1 HIT',style:TextStyle(color:Color(0xFF39E75F),fontWeight:FontWeight.w800,fontSize:11)),onChanged:(v)=>set(()=>a=v==true))),SizedBox(width:96,child:TextField(controller:tp1Profit,enabled:a,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Profit %',prefixText:'+')))]),
      _lockedSignalValue('TP2',p.tp2),
      Row(children:[Expanded(child:CheckboxListTile(contentPadding:EdgeInsets.zero,dense:true,value:b,title:const Text('TP2 HIT',style:TextStyle(color:Color(0xFF39E75F),fontWeight:FontWeight.w800,fontSize:11)),onChanged:(v)=>set(()=>b=v==true))),SizedBox(width:96,child:TextField(controller:tp2Profit,enabled:b,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Profit %',prefixText:'+')))]),
      _lockedSignalValue('TP3',p.tp3),
      Row(children:[Expanded(child:CheckboxListTile(contentPadding:EdgeInsets.zero,dense:true,value:c,title:const Text('TP3 HIT',style:TextStyle(color:Color(0xFF39E75F),fontWeight:FontWeight.w800,fontSize:11)),onChanged:(v)=>set(()=>c=v==true))),SizedBox(width:96,child:TextField(controller:tp3Profit,enabled:c,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Profit %',prefixText:'+')))]),
      _lockedSignalValue('STOPLOSS',p.stopLoss),
      Row(children:[Expanded(child:CheckboxListTile(contentPadding:EdgeInsets.zero,dense:true,value:sl,title:const Text('STOP LOSS HIT',style:TextStyle(color:Color(0xFFE05252),fontWeight:FontWeight.w800,fontSize:11)),onChanged:(v)=>set(()=>sl=v==true))),SizedBox(width:96,child:TextField(controller:stopLossProfit,enabled:sl,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Loss %',prefixText:'-')))]),
      CheckboxListTile(contentPadding:EdgeInsets.zero,dense:true,value:be,title:Text('BREAK EVEN',style:TextStyle(color:AppTheme.textSecondary,fontWeight:FontWeight.w800,fontSize:11)),onChanged:(v)=>set(()=>be=v==true)),
      Text('Enter the actual percentage for each hit target. These values are used for the signal result and final Journal calculation.',style:TextStyle(color:AppTheme.textFaint,fontSize:9)),
    ])),actions:[TextButton(onPressed:()=>Navigator.pop(dc),child:const Text('CANCEL')),FilledButton(onPressed:()=>Navigator.pop(dc,{'tp1Hit':a.toString(),'tp2Hit':b.toString(),'tp3Hit':c.toString(),'stopLossHit':sl.toString(),'breakEven':be.toString(),'tp1Profit':tp1Profit.text.trim(),'tp2Profit':tp2Profit.text.trim(),'tp3Profit':tp3Profit.text.trim(),'stopLossProfit':stopLossProfit.text.trim()}),child:const Text('SAVE'))])));
    await Future<void>.delayed(const Duration(milliseconds: 450));
    if (!mounted) { tp1Profit.dispose(); tp2Profit.dispose(); tp3Profit.dispose(); stopLossProfit.dispose(); return; }
    tp1Profit.dispose();tp2Profit.dispose();tp3Profit.dispose();stopLossProfit.dispose();
    if(r==null)return;
    p.tp1Hit=r['tp1Hit']=='true';p.tp2Hit=r['tp2Hit']=='true';p.tp3Hit=r['tp3Hit']=='true';p.stopLossHit=r['stopLossHit']=='true';p.breakEven=r['breakEven']=='true';
    p.tp1Profit=p.tp1Hit?r['tp1Profit']??'':'';p.tp2Profit=p.tp2Hit?r['tp2Profit']??'':'';p.tp3Profit=p.tp3Hit?r['tp3Profit']??'':'';p.stopLossProfit=p.stopLossHit?(r['stopLossProfit']??'').replaceFirst(RegExp(r'^[+-]'),''):'';p.breakEvenProfit=p.breakEven?'0':'';p.winTradeCounted=_liveCallWin(p);
    try{await _updateLiveCallBackend(p);}catch(_){} _liveCallPosts.value=List<_LiveCallPost>.from(_liveCallPosts.value);
  }
  Future<void> _close(BuildContext context,_LiveCallPost p,bool green) async{
    if(!widget.isAdmin||p.tradeClosed)return;
    double finalPct;
    if(green){
      final avg=_averageHitProfit(tp1Hit:p.tp1Hit,tp2Hit:p.tp2Hit,tp3Hit:p.tp3Hit,tp1Profit:p.tp1Profit,tp2Profit:p.tp2Profit,tp3Profit:p.tp3Profit);
      final controller=TextEditingController(text:avg.replaceAll('%','').replaceFirst('+',''));
      final entered=await showDialog<double>(context:context,builder:(dc)=>AlertDialog(backgroundColor:AppTheme.adaptiveSurface(Color(0xFF0B0F11)),title:const Text('TRADE CLOSED — GREEN',style:TextStyle(fontWeight:FontWeight.w900)),content:TextField(controller:controller,autofocus:true,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Final Profit %',prefixText:'+')),actions:[TextButton(onPressed:()=>Navigator.pop(dc),child:const Text('CANCEL')),FilledButton(onPressed:()=>Navigator.pop(dc,double.tryParse(controller.text.trim().replaceAll('%','').replaceFirst('+',''))),child:const Text('CLOSE TRADE'))]));
      controller.dispose();
      if(!mounted || entered==null || !entered.isFinite)return;
      finalPct=entered.abs();
    }else{
      finalPct=-_parseSignalPercent(p.stopLossProfit).abs();
      if(finalPct==0){
        finalPct=await _askFinalLossPercentage(context, fallback:_parseSignalPercent(p.stopLossProfit).abs());
        if(finalPct==0)return;
      }
    }
    p.tradeClosed=true;p.closedGreen=green;p.finalProfitPercentage=finalPct;p.resultPercentage='${finalPct>=0?'+':''}${finalPct.toStringAsFixed(2)}%';
    try{
      await FirebaseFirestore.instance.collection('live_calls').doc(p.id).update({..._liveCallData(p),'finalProfitPercentage':finalPct,'resultPercentage':p.resultPercentage,'officialResult':finalPct>0?'WIN':finalPct<0?'LOSS':'CLOSED','closedAt':FieldValue.serverTimestamp()});
      await _finalizeLiveJournal(p,finalPct);
      await _recordJournalAggregates(p,finalPct);
      _liveCallPosts.value=List<_LiveCallPost>.from(_liveCallPosts.value);
    }catch(e){
      p.tradeClosed=false;
      p.closedGreen=false;
      p.finalProfitPercentage=0;
      p.resultPercentage='';
      if(context.mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Could not close this trade. Please try again.')));}
    }
  }
  Future<double> _askFinalLossPercentage(BuildContext context,{double fallback=0}) async{
    final controller=TextEditingController(text:fallback>0?fallback.toStringAsFixed(fallback.roundToDouble()==fallback?0:2):'');
    final value=await showDialog<double>(context:context,builder:(dc)=>AlertDialog(backgroundColor:AppTheme.adaptiveSurface(Color(0xFF0B0F11)),title:const Text('TRADE CLOSED — RED',style:TextStyle(fontWeight:FontWeight.w900)),content:TextField(controller:controller,autofocus:true,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Final Loss %',prefixText:'-')),actions:[TextButton(onPressed:()=>Navigator.pop(dc),child:const Text('CANCEL')),FilledButton(onPressed:()=>Navigator.pop(dc,double.tryParse(controller.text.trim().replaceAll('%','').replaceFirst('-','').replaceFirst('+',''))),child:const Text('CLOSE TRADE'))]));
    controller.dispose();
    if (!mounted) return 0;
    return value==null || !value.isFinite ? 0 : -value.abs();
  }
  Future<void> _edit(BuildContext context,_LiveCallPost p) async{if(p.tradeClosed)return;final u=await Navigator.push<_LiveCallPost>(context,MaterialPageRoute(builder:(_)=>_LiveCallComposerPage(existingPost:p)));if(u==null)return;try{await _updateLiveCallBackend(u);}catch(_){}_liveCallPosts.value=_liveCallPosts.value.map((x)=>x.id==p.id?u:x).toList();}
  Future<void> _premium(BuildContext context) async{await showDialog<void>(context:context,builder:(dc)=>AlertDialog(backgroundColor:AppTheme.adaptiveSurface(Color(0xFF0B0F11)),title:const Text('Become Premium',style:TextStyle(fontWeight:FontWeight.w900)),content:Text('This Live Call is Premium. Payment is reviewed by an Admin before access is granted.',style:TextStyle(color:AppTheme.textSecondary)),actions:[TextButton(onPressed:()=>Navigator.pop(dc),child:const Text('CANCEL')),FilledButton(onPressed:(){Navigator.pop(dc);Navigator.push(context,MaterialPageRoute(builder:(_)=>const CentralPaymentPage(product:'premium',planId:'premium_monthly')));},child:const Text('BECOME PREMIUM'))]));}
  late final Stream<DocumentSnapshot<Map<String,dynamic>>> _userStream;
  late final Stream<QuerySnapshot<Map<String,dynamic>>> _allStream;

  @override
  void initState(){
    super.initState();
    final uid=FirebaseAuth.instance.currentUser?.uid;
    _userStream=uid==null
        ? const Stream<DocumentSnapshot<Map<String,dynamic>>>.empty()
        : FirebaseFirestore.instance.collection('users').doc(uid).snapshots();
    // Keep the listener dependent only on the published flag. Ordering is
    // performed locally below, so a missing/still-building composite index
    // can never make the Live Calls list disappear. The existing index is
    // still valid and can remain in Firestore.
    _allStream=FirebaseFirestore.instance
        .collection('live_calls')
        .where('isPublished',isEqualTo:true)
        .limit(200)
        .snapshots();
  }

  @override Widget build(BuildContext context){
    return StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
      stream:_userStream,
      builder:(context,userSnap){
        final premium=userSnap.data?.data()?['isPremium']==true;
        final canReadAll=widget.isAdmin||premium;
        if(canReadAll){
          return StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
            stream:_allStream,
            builder:(context,snap)=>_renderLiveCallSnapshot(context,snap,premiumOverride:canReadAll),
          );
        }
        // Free users can read the public Live Call metadata for every
        // published signal. Premium signal details are not stored in this
        // document, so the card remains locked/blurred until Premium access.
        return StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
          stream:_allStream,
          builder:(context,snap){
            // During a listener reconnect/error, keep the last successful
            // Live Calls list instead of replacing it with an empty list.
            if(snap.hasError || !snap.hasData){
              return _renderLiveCallPosts(context,_liveCallPosts.value,premiumOverride:false);
            }
            final docs=snap.data!.docs;
            final posts=docs.where((d)=>d.data()['isPublished']==true).map(_liveCallFromFirestore).toList()
              ..sort((a,b){final c=b.createdAt.compareTo(a.createdAt);return c!=0?c:b.id.compareTo(a.id);});
            return _renderLiveCallPosts(context,posts,premiumOverride:false);
          },
        );
      },
    );
  }
  Widget _renderLiveCallSnapshot(BuildContext context, AsyncSnapshot<QuerySnapshot<Map<String,dynamic>>> snap,{required bool premiumOverride}){
    final docs=snap.hasData?snap.data!.docs.where((d)=>d.data()['isPublished']==true).toList():<QueryDocumentSnapshot<Map<String,dynamic>>>[];
    docs.sort((a,b){final ad=_liveCallDate(a.data()['createdAt']);final bd=_liveCallDate(b.data()['createdAt']);final c=bd.compareTo(ad);return c!=0?c:b.id.compareTo(a.id);});
    if(!snap.hasData)return _renderLiveCallPosts(context, _liveCallPosts.value,premiumOverride:premiumOverride);
    if(!premiumOverride)return _renderLiveCallPosts(context, docs.map(_liveCallFromFirestore).toList(),premiumOverride:false);
    return FutureBuilder<List<_LiveCallPost>>(
      future:_loadLiveCallPostsWithPremiumDetails(docs),
      builder:(context,detailsSnap){
        final posts=detailsSnap.hasData?detailsSnap.data!:docs.map(_liveCallFromFirestore).toList();
        return _renderLiveCallPosts(context, posts,premiumOverride:true);
      },
    );
  }

  Future<List<_LiveCallPost>> _loadLiveCallPostsWithPremiumDetails(List<QueryDocumentSnapshot<Map<String,dynamic>>> docs) async{
    final posts=< _LiveCallPost>[];
    for(final doc in docs){
      var post=_liveCallFromFirestore(doc);
      // Some older Live Call documents do not carry accessTier even though
      // their daily sequence makes them Premium. This method is reached only
      // after the current user has been authorized as Premium/Admin, so it is
      // safe to fetch the protected details for either representation.
      final isPremiumCall = post.accessTier == 'premium' ||
          (post.accessTier.isEmpty && post.dailySequence > 2);
      if(isPremiumCall || post.entry.trim().isEmpty){
        try{
          final detail=await doc.reference.collection('premiumData').doc('details').get();
          final d=detail.data();
          if(d!=null){
            final merged=<String,dynamic>{...doc.data(),...d};
            post=_liveCallFromMap(doc.id,merged);
          }
        }catch(_){ }
      }
      posts.add(post);
    }
    return posts;
  }

  _LiveCallPost _liveCallFromMap(String id,Map<String,dynamic> d)=>_LiveCallPost(
    id:id,asset:(d['asset']??'').toString(),entry:(d['entry']??'').toString(),longDirection:d['longDirection']!=false,bullish:d['bullish']!=false,
    tp1:(d['tp1']??'').toString(),tp2:(d['tp2']??'').toString(),tp3:(d['tp3']??'').toString(),stopLoss:(d['stopLoss']??'').toString(),
    leverage:(d['leverage'] as num?)?.toInt()??10,imageBytes:_decodeLiveCallImage(d['imageBase64']),createdAt:_liveCallDate(d['createdAt']),
    goodReactions:(d['goodReactions'] as num?)?.toInt()??0,badReactions:(d['badReactions'] as num?)?.toInt()??0,tp1Hit:d['tp1Hit']==true,tp2Hit:d['tp2Hit']==true,tp3Hit:d['tp3Hit']==true,
    stopLossHit:d['stopLossHit']==true,breakEven:d['breakEven']==true,winTradeCounted:d['winTradeCounted']==true,tp1Profit:(d['tp1Profit']??'').toString(),
    tp2Profit:(d['tp2Profit']??'').toString(),tp3Profit:(d['tp3Profit']??'').toString(),stopLossProfit:(d['stopLossProfit']??'').toString(),breakEvenProfit:(d['breakEvenProfit']??'').toString(),
    tradeClosed:d['tradeClosed']==true,closedGreen:d['closedGreen']==true,finalProfitPercentage:(d['finalProfitPercentage'] as num?)?.toDouble()??0,resultPercentage:(d['resultPercentage']??'').toString(),
    dailySequence:(d['dailySequence'] as num?)?.toInt()??0,accessTier:(d['accessTier']??'').toString(),
  );
  Widget _renderLiveCallPosts(BuildContext context,List<_LiveCallPost> posts,{required bool premiumOverride}){
    if(posts.isNotEmpty)_liveCallPosts.value=posts;
    final now=DateTime.now();
    final today=posts.where((p)=>_sameDay(p.createdAt,now)).toList();
    return _body(context,posts,today,widget.isAdmin||premiumOverride);
  }
  Widget _body(BuildContext context,List<_LiveCallPost> posts,List<_LiveCallPost> today,bool premium){
    final sequenceById = <String,int>{};
    final groups = <String,List<_LiveCallPost>>{};
    for (final p in posts) { final key='${p.createdAt.year}-${p.createdAt.month}-${p.createdAt.day}'; (groups[key]??=<_LiveCallPost>[]).add(p); }
    for (final group in groups.values) { group.sort((a,b){final c=a.createdAt.compareTo(b.createdAt);return c!=0?c:a.id.compareTo(b.id);}); for(var i=0;i<group.length;i++){final p=group[i];final seq=p.dailySequence>0?p.dailySequence:i+1;sequenceById[p.id]=seq;if(p.dailySequence!=seq){p.dailySequence=seq;p.accessTier=seq>2?'premium':'free';}} }
    return RefreshIndicator(onRefresh:refresh,child:ListView(physics:const AlwaysScrollableScrollPhysics(),padding:const EdgeInsets.fromLTRB(16,10,16,110),children:[Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:Text('LIVE CALLS',style:TextStyle(color:AppTheme.textPrimary,fontSize:16,fontWeight:FontWeight.w900,letterSpacing:1))),_LiveCallsStats(total:today.length,wins:today.where(_liveCallWin).length,losses:today.where(_liveCallLoss).length),const SizedBox(width:6),if(widget.isAdmin&&widget.onCreate!=null)_JellyPlusButton(tooltip:'Create live call',onPressed:widget.onCreate!)]),const SizedBox(height:8),if(posts.isEmpty)Padding(padding:EdgeInsets.only(top:230),child:Center(child:Text('No live calls published yet.',style:TextStyle(color:AppTheme.textMuted)))),...posts.map((p){final sequence=sequenceById[p.id]??0;final premiumOnly=!widget.isAdmin&&!premium&&((p.accessTier=='premium')||(p.accessTier.isEmpty&&sequence>2)||sequence>2);final hasTpHit=p.tp1Hit||p.tp2Hit||p.tp3Hit;final locked=premiumOnly&&!hasTpHit&&!p.tradeClosed;return _LiveCallCard(post:p,locked:locked,resultRevealed:premiumOnly&&(hasTpHit||p.tradeClosed),canEdit:widget.isAdmin,onOpenPremium:()=>_premium(context),onEdit:widget.isAdmin?()=>_edit(context,p):null,onEnterWinRatio:widget.isAdmin?()=>_outcome(context,p):null,onCloseGreen:widget.isAdmin?()=>_close(context,p,true):null,onCloseRed:widget.isAdmin?()=>_close(context,p,false):null,onReaction:(good)async{try{await _recordLiveParticipant(p.id,good);}catch(_){}});})] ));}
}

class _LiveCallsStats extends StatelessWidget{final int total,wins,losses;const _LiveCallsStats({required this.total,required this.wins,required this.losses});Widget _b(String l,String v,Color c,double w)=>Container(width:w,padding:const EdgeInsets.symmetric(horizontal:5,vertical:4),decoration:BoxDecoration(color:c.withValues(alpha:.10),borderRadius:BorderRadius.circular(8),border:Border.all(color:c.withValues(alpha:.42))),child:Column(children:[Text(l,style:TextStyle(color:c,fontSize:5.5,fontWeight:FontWeight.w900)),const SizedBox(height:2),Text(v,style:TextStyle(color:c,fontSize:12,fontWeight:FontWeight.w900))]));@override Widget build(BuildContext context)=>Column(mainAxisSize:MainAxisSize.min,children:[_b('TOTAL TRADED','$total',AppTheme.luxuryGold,72),const SizedBox(height:3),Row(mainAxisSize:MainAxisSize.min,children:[_b('WINS','$wins',const Color(0xFF39E75F),46),const SizedBox(width:3),_b('LOSS','$losses',const Color(0xFFE05252),46)])]);}

class _LiveCallCard extends StatefulWidget {
  final _LiveCallPost post;
  final bool locked;
  final bool resultRevealed;
  final bool canEdit;
  final VoidCallback onOpenPremium;
  final VoidCallback? onEdit;
  final VoidCallback? onEnterWinRatio;
  final VoidCallback? onCloseGreen;
  final VoidCallback? onCloseRed;
  final Future<void> Function(bool good)? onReaction;

  const _LiveCallCard({
    required this.post,
    required this.locked,
    this.resultRevealed = false,
    required this.canEdit,
    required this.onOpenPremium,
    this.onEdit,
    this.onEnterWinRatio,
    this.onCloseGreen,
    this.onCloseRed,
    this.onReaction,
  });

  @override
  State<_LiveCallCard> createState() => _LiveCallCardState();
}

class _LiveCallCardState extends State<_LiveCallCard> {
  bool good = false, bad = false;

  void react(bool g) {
    setState(() {
      if (g) {
        good = !good;
        if (good) {
          widget.post.goodReactions++;
        } else if (widget.post.goodReactions > 0) {
          widget.post.goodReactions--;
        }
      } else {
        bad = !bad;
        if (bad) {
          widget.post.badReactions++;
        } else if (widget.post.badReactions > 0) {
          widget.post.badReactions--;
        }
      }
    });
    widget.onReaction?.call(g);
  }

  @override
  Widget build(BuildContext context) {
    final dir = widget.post.longDirection ? AppTheme.neonGreen : const Color(0xFFE05252);
    final closed = widget.post.closedGreen ? const Color(0xFF39E75F) : const Color(0xFFE05252);
    final avg = _averageHitProfit(tp1Hit: widget.post.tp1Hit, tp2Hit: widget.post.tp2Hit, tp3Hit: widget.post.tp3Hit, tp1Profit: widget.post.tp1Profit, tp2Profit: widget.post.tp2Profit, tp3Profit: widget.post.tp3Profit);
    final overall = widget.post.tradeClosed && widget.post.resultPercentage.trim().isNotEmpty ? widget.post.resultPercentage : avg;
    final overallColor = overall.trim().startsWith('-') ? const Color(0xFFE05252) : const Color(0xFF39E75F);
    final hasPublicTp = widget.post.tp1Hit || widget.post.tp2Hit || widget.post.tp3Hit;
    final hasPublicSl = widget.post.stopLossHit;
    final showPublicResult = hasPublicTp || hasPublicSl || widget.post.tradeClosed;
    // Protected details are present only when the user is allowed to read
    // premiumData/details.  A TP hit/closure should add only the subtle
    // result blur; it must never hide the already-authorized signal content.
    // For Free users the protected Entry/TP/SL/Leverage/image remain absent,
    // while public TP-hit information stays visible.
    final detailsAvailable = widget.post.entry.trim().isNotEmpty;

    final card = Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: AppTheme.adaptiveSurface(Color(0xFF303238)),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: (widget.post.tradeClosed ? closed : dir).withValues(alpha: .28)),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(
              child: widget.locked
                  ? ImageFiltered(
                      imageFilter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                      child: Text(widget.post.asset.isEmpty ? 'PREMIUM SIGNAL' : '${widget.post.asset} /USDT', style: TextStyle(color: AppTheme.textPrimary, fontSize: 21, fontWeight: FontWeight.w900)),
                    )
                  : Text(widget.post.asset.isEmpty ? 'LIVE SIGNAL' : '${widget.post.asset} /USDT', style: TextStyle(color: AppTheme.textPrimary, fontSize: 21, fontWeight: FontWeight.w900)),
            ),
            if (overall.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                decoration: BoxDecoration(color: overallColor.withValues(alpha: .10), borderRadius: BorderRadius.circular(7), border: Border.all(color: overallColor.withValues(alpha: .5))),
                child: Text(overall, style: TextStyle(color: overallColor, fontSize: 10, fontWeight: FontWeight.w900)),
              ),
            const SizedBox(width: 5),
            _LiveCallBadge(text: widget.locked ? 'PREMIUM' : (widget.post.longDirection ? 'LONG' : 'SHORT'), color: dir),
            if (widget.canEdit)
              PopupMenuButton<String>(
                color: AppTheme.adaptiveSurface(Color(0xFF0B0F11)),
                onSelected: (v) {
                  if (v == 'edit') widget.onEdit?.call();
                  if (v == 'ratio') widget.onEnterWinRatio?.call();
                  if (v == 'green') widget.onCloseGreen?.call();
                  if (v == 'red') widget.onCloseRed?.call();
                },
                itemBuilder: (_) => [
                  if (!widget.post.tradeClosed) const PopupMenuItem(value: 'edit', child: Text('Edit live call')),
                  if (!widget.post.tradeClosed) const PopupMenuItem(value: 'ratio', child: Text('TP / RESULT MANAGEMENT')),
                  if (!widget.post.tradeClosed) const PopupMenuDivider(),
                  if (!widget.post.tradeClosed) const PopupMenuItem(value: 'green', child: Text('🟢 Trade Closed — Green')),
                  if (!widget.post.tradeClosed) const PopupMenuItem(value: 'red', child: Text('🔴 Trade Closed — Red')),
                ],
                icon: Icon(Icons.more_vert_rounded, size: 20, color: AppTheme.textSecondary),
              ),
          ]),
          if (widget.post.tradeClosed)
            Padding(
              padding: const EdgeInsets.only(top: 7),
              child: Row(children: [
                Icon(Icons.check_circle_rounded, color: closed, size: 20),
                const SizedBox(width: 6),
                Text(widget.post.closedGreen ? 'TRADE CLOSED — GREEN' : 'TRADE CLOSED — RED', style: TextStyle(color: closed, fontSize: 10, fontWeight: FontWeight.w900)),
              ]),
            ),
          const SizedBox(height: 11),
          _LiveCallValueRow(label: 'ENTRY', value: detailsAvailable ? (widget.locked ? '••••••' : widget.post.entry) : '••••••'),
          Row(children: [Text('LEVERAGE', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, fontWeight: FontWeight.w900)), const SizedBox(width: 8), Text(!detailsAvailable || widget.locked ? '••••' : '${widget.post.leverage}x', style: TextStyle(color: _leverageColor(widget.post.leverage), fontWeight: FontWeight.w900))]),
          _signalTargetRow(label: 'TP1', value: detailsAvailable ? (widget.locked ? '••••••' : widget.post.tp1) : '••••••', hit: widget.post.tp1Hit, profit: detailsAvailable && !widget.locked ? widget.post.tp1Profit : ''),
          _signalTargetRow(label: 'TP2', value: detailsAvailable ? (widget.locked ? '••••••' : widget.post.tp2) : '••••••', hit: widget.post.tp2Hit, profit: detailsAvailable && !widget.locked ? widget.post.tp2Profit : ''),
          _signalTargetRow(label: 'TP3', value: detailsAvailable ? (widget.locked ? '••••••' : widget.post.tp3) : '••••••', hit: widget.post.tp3Hit, profit: detailsAvailable && !widget.locked ? widget.post.tp3Profit : ''),
          _signalTargetRow(label: 'STOPLOSS', value: detailsAvailable ? (widget.locked ? '••••••' : widget.post.stopLoss) : '••••••', warning: true, hit: widget.post.stopLossHit, profit: detailsAvailable && !widget.locked ? widget.post.stopLossProfit : ''),
          if (widget.post.breakEven) _signalTargetRow(label: 'BREAK EVEN', value: '', warning: true, hit: true, profit: widget.post.breakEvenProfit),
          if (detailsAvailable && widget.post.imageBytes != null)
            Padding(padding: const EdgeInsets.only(top: 10), child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(widget.post.imageBytes!, width: double.infinity, height: 220, fit: BoxFit.cover))),
          const SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            _LiveCallReactionButton(icon: Icons.thumb_up_alt_rounded, label: 'LIKE', count: widget.post.goodReactions, active: good, activeColor: const Color(0xFF39E75F), onTap: widget.post.tradeClosed ? () {} : () => react(true)),
            const SizedBox(width: 8),
            _LiveCallReactionButton(icon: Icons.thumb_down_alt_rounded, label: 'DISLIKE', count: widget.post.badReactions, active: bad, activeColor: const Color(0xFFE05252), onTap: widget.post.tradeClosed ? () {} : () => react(false)),
          ]),
        ]),
      ),
    );

    final visibleCard = widget.locked
        ? ImageFiltered(imageFilter: ui.ImageFilter.blur(sigmaX: 5.5, sigmaY: 5.5), child: card)
        : widget.resultRevealed
            ? ImageFiltered(imageFilter: ui.ImageFilter.blur(sigmaX: 1.15, sigmaY: 1.15), child: card)
            : card;

    return Stack(children: [
      visibleCard,
      if (widget.post.tradeClosed)
        Positioned(
          top: 12,
          left: 12,
          child: IgnorePointer(
            child: _LiveCallStatusOverlay(
              label: 'CLOSED',
              color: closed,
              icon: Icons.check_rounded,
            ),
          ),
        )
      else if (widget.locked)
        const Positioned(
          top: 12,
          left: 12,
          child: IgnorePointer(
            child: _LiveCallStatusOverlay(
              label: 'ACTIVE',
              color: Color(0xFF39E75F),
              icon: Icons.radio_button_checked_rounded,
            ),
          ),
        ),
      if (widget.post.tradeClosed)
        Positioned.fill(child: IgnorePointer(child: Center(child: _LiveCallResultTick(color: closed, icon: Icons.check_rounded))))
      else if (widget.resultRevealed && hasPublicTp)
        Positioned.fill(child: IgnorePointer(child: Center(child: _LiveCallResultTick(color: const Color(0xFF39E75F), icon: Icons.check_rounded)))),
      if (widget.locked && showPublicResult)
        Positioned(top: 66, left: 14, right: 14, child: IgnorePointer(child: Wrap(spacing: 6, runSpacing: 6, children: [
          if (widget.post.tp1Hit) _LiveCallPublicResultChip(label: 'TP1 HIT', profit: widget.post.tp1Profit, icon: Icons.check_rounded, color: const Color(0xFF39E75F)),
          if (widget.post.tp2Hit) _LiveCallPublicResultChip(label: 'TP2 HIT', profit: widget.post.tp2Profit, icon: Icons.check_rounded, color: const Color(0xFF39E75F)),
          if (widget.post.tp3Hit) _LiveCallPublicResultChip(label: 'TP3 HIT', profit: widget.post.tp3Profit, icon: Icons.check_rounded, color: const Color(0xFF39E75F)),
          if (widget.post.stopLossHit) _LiveCallPublicResultChip(label: 'STOP LOSS', profit: widget.post.stopLossProfit, icon: Icons.priority_high_rounded, color: const Color(0xFFE05252)),
        ]))),
      if (widget.locked)
        Positioned.fill(child: Material(color: Colors.transparent, child: InkWell(borderRadius: BorderRadius.circular(18), onTap: widget.onOpenPremium, child: const Center(child: _LiveCall3DLock())))),
    ]);
  }
}

class _LiveCallStatusOverlay extends StatelessWidget {
  final String label;
  final Color color;
  final IconData icon;

  const _LiveCallStatusOverlay({
    required this.label,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: AppTheme.adaptiveSurface(Color(0xF20B0F11)),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withValues(alpha: .95), width: 1.4),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: .28),
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 13),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: .7,
            ),
          ),
        ],
      ),
    );
  }
}

class _LiveCallResultTick extends StatefulWidget {
  final Color color;
  final IconData icon;
  const _LiveCallResultTick({required this.color, required this.icon});
  @override State<_LiveCallResultTick> createState() => _LiveCallResultTickState();
}

class _LiveCallResultTickState extends State<_LiveCallResultTick> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  @override void initState() { super.initState(); _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 850))..forward(); }
  @override void dispose() { _controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final pulse = 0.75 + (_controller.value * 0.25);
        final scale = Curves.elasticOut.transform(_controller.value.clamp(0.0, 1.0).toDouble());
        return Transform.scale(
          scale: scale,
          child: Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xCC090D12), border: Border.all(color: widget.color, width: 2.2), boxShadow: [BoxShadow(color: widget.color.withValues(alpha: .30 * pulse), blurRadius: 22, spreadRadius: 4)]),
            child: Icon(widget.icon, color: widget.color, size: 42),
          ),
        );
      },
    );
  }
}

class _LiveCallPublicResultChip extends StatelessWidget{
 final String label;final String profit;final IconData icon;final Color color;
 const _LiveCallPublicResultChip({required this.label,required this.profit,required this.icon,required this.color});
 @override Widget build(BuildContext context){final clean=profit.replaceFirst(RegExp(r'^[+-]'),'');final prefix=color==const Color(0xFFE05252)?'-':'+';return Container(padding:const EdgeInsets.symmetric(horizontal:7,vertical:5),decoration:BoxDecoration(color:AppTheme.adaptiveSurface(Color(0xFF171A1F)).withValues(alpha:.96),borderRadius:BorderRadius.circular(8),border:Border.all(color:color.withValues(alpha:.85),width:1.2),boxShadow:[BoxShadow(color:color.withValues(alpha:.20),blurRadius:10)]),child:Row(mainAxisSize:MainAxisSize.min,children:[Icon(icon,size:13,color:color),const SizedBox(width:4),Text(label,style:TextStyle(color:color,fontSize:8,fontWeight:FontWeight.w900)),if(clean.isNotEmpty)...[const SizedBox(width:4),Text('$prefix$clean%',style:TextStyle(color:color,fontSize:9,fontWeight:FontWeight.w900))]]));}
}

class _LiveCallBadge extends StatelessWidget {
  final String text;
  final Color color;

  const _LiveCallBadge({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withValues(alpha: 0.55)),
      ),
      child: Text(
        text,
        style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w900),
      ),
    );
  }
}

class _LiveCallValueRow extends StatelessWidget {
  final String label;
  final String value;
  final bool warning;

  const _LiveCallValueRow({
    required this.label,
    required this.value,
    this.warning = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 76,
            child: Text(
              label,
              style: TextStyle(
                color: warning ? const Color(0xFFE05252) : AppTheme.textMuted,
                fontSize: 10,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 14,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

Color _leverageColor(int leverage) {
  if (leverage <= 30) return AppTheme.neonGreen;
  if (leverage <= 60) return const Color(0xFFFFD54A);
  return const Color(0xFFE05252);
}

class _LiveCallReactionButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final int count;
  final bool active;
  final Color activeColor;
  final VoidCallback onTap;

  const _LiveCallReactionButton({
    required this.icon,
    required this.label,
    required this.count,
    required this.active,
    required this.activeColor,
    required this.onTap,
  });

  @override
  State<_LiveCallReactionButton> createState() => _LiveCallReactionButtonState();
}

class _LiveCallReactionButtonState extends State<_LiveCallReactionButton> {
  bool _bounce = false;

  void _tap() {
    setState(() => _bounce = true);
    widget.onTap();
    Future<void>.delayed(const Duration(milliseconds: 180), () {
      if (mounted) setState(() => _bounce = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _tap,
      child: AnimatedScale(
        scale: _bounce ? 1.16 : 1,
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutBack,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
          decoration: BoxDecoration(
            color: widget.active
                ? widget.activeColor.withValues(alpha: 0.16)
                : AppTheme.adaptiveWhite(alpha: 0.04),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: widget.active
                  ? widget.activeColor.withValues(alpha: 0.6)
                  : AppTheme.borderFaint,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(widget.icon, size: 17, color: widget.active ? widget.activeColor : AppTheme.textSoft),
              const SizedBox(width: 4),
              Text(
                '${widget.label} ${widget.count}',
                style: TextStyle(
                  color: widget.active ? widget.activeColor : AppTheme.textSoft,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LiveCall3DLock extends StatefulWidget {
  const _LiveCall3DLock();

  @override
  State<_LiveCall3DLock> createState() => _LiveCall3DLockState();
}

class _LiveCall3DLockState extends State<_LiveCall3DLock>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return SizedBox(
          width: 118,
          height: 118,
          child: Stack(
            alignment: Alignment.center,
            children: [
              CustomPaint(
                size: const Size(118, 118),
                painter: _LiveCallLockOrbitPainter(progress: _controller.value),
              ),
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xDD090D12),
                  border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: 0.75), width: 1.2),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.luxuryGold.withValues(alpha: 0.24),
                      blurRadius: 20,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Icon(Icons.lock_rounded, color: AppTheme.luxuryGold, size: 28),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _LiveCallLockOrbitPainter extends CustomPainter {
  final double progress;

  _LiveCallLockOrbitPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final rings = <({double w, double h, double rotation, Color color})>[
      (w: 102, h: 34, rotation: -0.32, color: AppTheme.luxuryGold),
      (w: 88, h: 44, rotation: 0.72, color: AppTheme.neonGreen),
      (w: 74, h: 54, rotation: -1.08, color: const Color(0xFF7C83D8)),
    ];

    for (var i = 0; i < rings.length; i++) {
      final ring = rings[i];
      final rect = Rect.fromCenter(
        center: center,
        width: ring.w,
        height: ring.h,
      );
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1
        ..color = ring.color.withValues(alpha: 0.55);
      canvas.save();
      canvas.translate(center.dx, center.dy);
      canvas.rotate(ring.rotation + progress * (i.isEven ? 1.0 : -1.0));
      canvas.translate(-center.dx, -center.dy);
      canvas.drawOval(rect, paint);

      final angle = progress * math.pi * 2 * (i.isEven ? 1 : -1) + i * 1.7;
      final x = center.dx + math.cos(angle) * ring.w / 2;
      final y = center.dy + math.sin(angle) * ring.h / 2;
      final dot = Paint()..color = ring.color;
      canvas.drawCircle(Offset(x, y), 3.1, dot);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _LiveCallLockOrbitPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

class _LiveCallsPaymentPage extends StatelessWidget {
  const _LiveCallsPaymentPage();

  @override
  Widget build(BuildContext context) => const CentralPaymentPage(product: 'premium', planId: 'premium_monthly');
}

class _LiveCallComposerPage extends StatefulWidget{final _LiveCallPost? existingPost;const _LiveCallComposerPage({this.existingPost});@override State<_LiveCallComposerPage> createState()=>_LiveCallComposerPageState();}
class _LiveCallComposerPageState extends State<_LiveCallComposerPage> with SingleTickerProviderStateMixin{
 final a=TextEditingController(),e=TextEditingController(),t1=TextEditingController(),t2=TextEditingController(),t3=TextEditingController(),sl=TextEditingController();Uint8List? img;bool longDir=true;int lev=10;late final AnimationController anim=AnimationController(vsync:this,duration:const Duration(milliseconds:650))..forward();
 @override void initState(){super.initState();final p=widget.existingPost;if(p!=null){a.text=p.asset;e.text=p.entry;t1.text=p.tp1;t2.text=p.tp2;t3.text=p.tp3;sl.text=p.stopLoss;longDir=p.longDirection;lev=p.leverage;img=p.imageBytes;}}
 @override void dispose(){anim.dispose();a.dispose();e.dispose();t1.dispose();t2.dispose();t3.dispose();sl.dispose();super.dispose();}
 Future<Uint8List?> pick()async{final input=html.FileUploadInputElement()..accept='image/*';input.click();await input.onChange.first;final f=input.files?.isNotEmpty==true?input.files!.first:null;if(f==null)return null;final r=html.FileReader();r.readAsArrayBuffer(f);await r.onLoad.first;return r.result is ByteBuffer?(r.result as ByteBuffer).asUint8List():null;}
 void publish(){final asset=a.text.trim().toUpperCase();if(asset.isEmpty||e.text.trim().isEmpty||t1.text.trim().isEmpty||t2.text.trim().isEmpty||t3.text.trim().isEmpty||sl.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Fill Asset, Entry, TP1, TP2, TP3 and Stoploss before publishing.')));return;}Navigator.pop(context,_LiveCallPost(id:widget.existingPost?.id??'${DateTime.now().microsecondsSinceEpoch}',asset:asset,entry:e.text.trim(),longDirection:longDir,bullish:true,tp1:t1.text.trim(),tp2:t2.text.trim(),tp3:t3.text.trim(),stopLoss:sl.text.trim(),leverage:lev,imageBytes:img,createdAt:widget.existingPost?.createdAt,goodReactions:widget.existingPost?.goodReactions??0,badReactions:widget.existingPost?.badReactions??0,tp1Hit:widget.existingPost?.tp1Hit??false,tp2Hit:widget.existingPost?.tp2Hit??false,tp3Hit:widget.existingPost?.tp3Hit??false,stopLossHit:widget.existingPost?.stopLossHit??false,breakEven:widget.existingPost?.breakEven??false,winTradeCounted:widget.existingPost?.winTradeCounted??false,tp1Profit:widget.existingPost?.tp1Profit??'',tp2Profit:widget.existingPost?.tp2Profit??'',tp3Profit:widget.existingPost?.tp3Profit??'',stopLossProfit:widget.existingPost?.stopLossProfit??'',breakEvenProfit:widget.existingPost?.breakEvenProfit??'',tradeClosed:widget.existingPost?.tradeClosed??false,closedGreen:widget.existingPost?.closedGreen??false,finalProfitPercentage:widget.existingPost?.finalProfitPercentage??0,resultPercentage:widget.existingPost?.resultPercentage??'',dailySequence:widget.existingPost?.dailySequence??0,accessTier:widget.existingPost?.accessTier??''));}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.existingPost==null?'CREATE LIVE CALL':'EDIT LIVE CALL'),actions:[Padding(padding:const EdgeInsets.only(right:12,top:8,bottom:8),child:FilledButton(onPressed:publish,style:FilledButton.styleFrom(backgroundColor:AppTheme.luxuryGold,foregroundColor:Colors.black),child:const Text('PUBLISH')))]),body:ListView(padding:const EdgeInsets.fromLTRB(16,14,16,30),children:[TextField(controller:a,decoration:const InputDecoration(labelText:'ASSET')),const SizedBox(height:10),TextField(controller:e,decoration:const InputDecoration(labelText:'ENTRY')),const SizedBox(height:10),Text('DIRECTION',style:TextStyle(color:AppTheme.textMuted,fontSize:10,fontWeight:FontWeight.w900)),RadioGroup<bool>(groupValue:longDir,onChanged:(v)=>setState(()=>longDir=v??true),child:Row(children:[Expanded(child:RadioListTile<bool>(value:true,title:const Text('LONG'))),Expanded(child:RadioListTile<bool>(value:false,title:const Text('SHORT')))])),Text('LEVERAGE ${lev}x',style:TextStyle(color:_leverageColor(lev),fontWeight:FontWeight.w900)),Slider(min:10,max:100,divisions:9,value:lev.toDouble(),onChanged:(v)=>setState(()=>lev=(v.round()~/10)*10)),TextField(controller:t1,decoration:const InputDecoration(labelText:'TP1')),TextField(controller:t2,decoration:const InputDecoration(labelText:'TP2')),TextField(controller:t3,decoration:const InputDecoration(labelText:'TP3')),TextField(controller:sl,decoration:const InputDecoration(labelText:'STOPLOSS')),IconButton(onPressed:()async{final b=await pick();if(b!=null)setState(()=>img=b);},icon:const Icon(Icons.image_outlined)),if(img!=null)Image.memory(img!,height:100,fit:BoxFit.cover)]));}


class _GuidePageData {
  final String heading;
  final String body;
  const _GuidePageData(this.heading, this.body);
}

class _SectionGuidePage extends StatefulWidget {
  final String title;
  final String intro;
  final List<_GuidePageData> pages;
  const _SectionGuidePage({required this.title, required this.intro, required this.pages});

  @override
  State<_SectionGuidePage> createState() => _SectionGuidePageState();
}

class _SectionGuidePageState extends State<_SectionGuidePage> {
  final PageController _controller = PageController();
  int _index = 0;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF070B10)),
      appBar: AppBar(
        title: Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
              child: Text(widget.intro, textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondary, fontSize: 12, height: 1.45)),
            ),
            Padding(
              padding: EdgeInsets.only(top: 2),
              child: Text('SWIPE LEFT / RIGHT TO READ', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1)),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: widget.pages.length,
                onPageChanged: (value) => setState(() => _index = value),
                itemBuilder: (context, index) {
                  final page = widget.pages[index];
                  return Padding(
                    padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(22, 24, 22, 24),
                      decoration: BoxDecoration(
                        color: AppTheme.adaptiveSurface(Color(0xFF10161D)),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: AppTheme.adaptiveWhite(alpha: .08)),
                        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .24), blurRadius: 22, spreadRadius: 1)],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('SECTION ${index + 1}', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
                          const SizedBox(height: 12),
                          Text(page.heading, style: TextStyle(color: AppTheme.textPrimary, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: .4)),
                          const SizedBox(height: 16),
                          Text(page.body, style: TextStyle(color: AppTheme.textSecondary, fontSize: 14, height: 1.65)),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
              child: Row(
                children: [
                  IconButton(
                    onPressed: _index == 0 ? null : () => _controller.previousPage(duration: const Duration(milliseconds: 260), curve: Curves.easeOutCubic),
                    icon: const Icon(Icons.chevron_left_rounded),
                  ),
                  Expanded(
                    child: Center(
                      child: Text('${_index + 1} / ${widget.pages.length}', style: TextStyle(color: AppTheme.textSoft, fontSize: 11, fontWeight: FontWeight.w800)),
                    ),
                  ),
                  IconButton(
                    onPressed: _index == widget.pages.length - 1 ? null : () => _controller.nextPage(duration: const Duration(milliseconds: 260), curve: Curves.easeOutCubic),
                    icon: const Icon(Icons.chevron_right_rounded),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// JOURNAL
// ============================================================

Future<void> _repairClosedLiveCallPublicNames() async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null || !await _hasFirebaseAdminClaim(user)) return;
  try {
    final snap = await FirebaseFirestore.instance
        .collection('live_calls')
        .where('isPublished', isEqualTo: true)
        .limit(500)
        .get();
    for (final doc in snap.docs) {
      final data = doc.data();
      final revealed = data['tradeClosed'] == true || data['tp1Hit'] == true || data['tp2Hit'] == true || data['tp3Hit'] == true || data['stopLossHit'] == true;
      if (!revealed) continue;
      final current = (data['asset'] ?? data['tradeName'] ?? '').toString().trim();
      final hasFullSignal = (data['entry'] ?? '').toString().trim().isNotEmpty &&
          (data['tp1'] ?? '').toString().trim().isNotEmpty &&
          (data['stopLoss'] ?? '').toString().trim().isNotEmpty;
      if (current.isNotEmpty && current.toUpperCase() != 'UNKNOWN' && hasFullSignal) continue;
      try {
        final detail = await doc.reference.collection('premiumData').doc('details').get();
        final d = detail.data();
        final asset = (d?['asset'] ?? d?['tradeName'] ?? '').toString().trim();
        if (asset.isEmpty || asset.toUpperCase() == 'UNKNOWN') continue;
        await doc.reference.update({
          'asset': asset,
          'tradeName': asset,
          'entry': d?['entry'],
          'longDirection': d?['longDirection'],
          'bullish': d?['bullish'],
          'tp1': d?['tp1'],
          'tp2': d?['tp2'],
          'tp3': d?['tp3'],
          'stopLoss': d?['stopLoss'],
          'leverage': d?['leverage'],
          'imageBase64': d?['imageBase64'],
          'winTradeCounted': d?['winTradeCounted'],
        });
      } catch (_) {}
    }
  } catch (_) {}
}

class JournalPage extends StatefulWidget {
  const JournalPage({super.key});
  @override
  State<JournalPage> createState() => _JournalPageState();
}

class _JournalPageState extends State<JournalPage> {
  Map<String, double> _community = {'daily': 0, 'monthly': 0, 'yearly': 0};
  Map<String, double> _personal = {'daily': 0, 'monthly': 0, 'yearly': 0};
  bool _loading = true;
  final _helpTitle = 'TRADING JOURNAL INFORMATION & GUIDE';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    unawaited(_repairClosedLiveCallPublicNames());
    final u = FirebaseAuth.instance.currentUser;
    if (u == null) return;
    try {
      final c = await TradingJournalService.loadCommunityPerformance();
      final p = await TradingJournalService.loadPersonalPerformance(u.uid);
      if (mounted) setState(() { _community = c; _personal = p; _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _communityOpen(String period, String title) async {
    final enter = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)),
        title: const Text('Enter to see all results', style: TextStyle(fontWeight: FontWeight.w900)),
        content: Text('$title contains the official, closed Live Call history used for the community calculation.', style: TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('CANCEL')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('ENTER')),
        ],
      ),
    );
    if (enter == true && mounted) {
      await Navigator.push(context, MaterialPageRoute(builder: (_) => _CommunityJournalResultsPage(period: period, title: title)));
    }
  }

  Future<void> _personalOpen(String period, String title) async {
    final enter = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)),
        title: const Text('Enter to see your results', style: TextStyle(fontWeight: FontWeight.w900)),
        content: Text('$title contains your private liked Live Call history after the trades were officially closed by Admin.', style: TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('CANCEL')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('ENTER')),
        ],
      ),
    );
    if (enter == true && mounted) {
      await Navigator.push(context, MaterialPageRoute(builder: (_) => _PersonalLiveCallResultsPage(period: period, title: title)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final communityTiles = [
      ('DAILY COMMUNITY PROFIT', 'daily'),
      ('WEEKLY COMMUNITY PROFIT', 'weekly'),
      ('MONTHLY COMMUNITY PROFIT', 'monthly'),
      ('YEARLY COMMUNITY PROFIT', 'yearly'),
    ];
    final personalTiles = [
      ('YOUR DAILY PROFIT', 'daily'),
      ('YOUR WEEKLY PROFIT', 'weekly'),
      ('YOUR MONTHLY PROFIT', 'monthly'),
      ('YOUR YEARLY PROFIT', 'yearly'),
    ];
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 110),
        children: [
          Row(children: [
            Expanded(child: Text('TRADING JOURNAL', style: TextStyle(color: AppTheme.textPrimary, fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1))),

          ]),
          const SizedBox(height: 4),
          _JournalActionTile(title: 'PERSONAL', subtitle: 'Private Trading Journal & Trading Task', icon: Icons.person_outline_rounded, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _PersonalTradingJournalPage()))),
          const SizedBox(height: 14),
          Text('COMMUNITY', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const SizedBox(height: 8),
          StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
            stream: FirebaseFirestore.instance.collection('journalCommunityAggregates').where('period', whereIn: const ['daily','weekly','monthly','yearly']).snapshots(),
            builder: (context, snap) {
              final now=DateTime.now();
              final weekStart=DateTime(now.year,now.month,now.day).subtract(Duration(days:now.weekday-DateTime.monday));
              final keys={'daily':'${now.year}-${now.month.toString().padLeft(2,'0')}-${now.day.toString().padLeft(2,'0')}','weekly':'${weekStart.year}-${weekStart.month.toString().padLeft(2,'0')}-${weekStart.day.toString().padLeft(2,'0')}','monthly':'${now.year}-${now.month.toString().padLeft(2,'0')}','yearly':'${now.year}'};
              final live=<String,double>{};
              for(final d in snap.data?.docs??const <QueryDocumentSnapshot<Map<String,dynamic>>>[]){final x=d.data();final period=(x['period']??'').toString();if(keys[period]==x['periodKey']){final count=(x['closedTradeCount'] as num?)?.toDouble()??0;live[period]=count==0?0:((x['sumProfitPercentage'] as num?)?.toDouble()??0)/count;}}
              return Column(children:[for(final item in communityTiles) ...[_JournalStatTile(title:item.$1,value:_formatJournalPercent(live[item.$2] ?? _community[item.$2] ?? 0),onTap:()=>_communityOpen(item.$2,item.$1)),const SizedBox(height:10)]],);
            },
          ),
          const SizedBox(height: 7),
          Text('PERSONAL', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const SizedBox(height: 8),
          for (final item in personalTiles) ...[
            _JournalStatTile(title: item.$1, value: _loading ? '...' : _formatJournalPercent(_personal[item.$2] ?? 0), onTap: () => _personalOpen(item.$2, item.$1)),
            const SizedBox(height: 10),
          ],
        ],
      ),
    );
  }
}

String _formatJournalPercent(double value) {
  final sign = value > 0 ? '+' : '';
  return '$sign${value.toStringAsFixed(2)}%';
}

class _JournalStatTile extends StatelessWidget {
  final String title;
  final String value;
  final VoidCallback? onTap;
  const _JournalStatTile({required this.title, required this.value, this.onTap});
  @override
  Widget build(BuildContext context) {
    final positive = !value.trim().startsWith('-') && !value.trim().startsWith('−');
    final body = Container(
      height: 70,
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 7),
      decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF303238)), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.adaptiveWhite(alpha: .07))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w800, fontSize: 10))),
          const SizedBox(width: 5),
          Icon(Icons.percent_rounded, color: AppTheme.textMuted, size: 14),
        ]),
        const Spacer(),
        Align(alignment: Alignment.centerRight, child: Text(value, style: TextStyle(color: positive ? const Color(0xFF39E75F) : const Color(0xFFE05252), fontSize: 18, fontWeight: FontWeight.w900))),
      ]),
    );
    return InkWell(onTap: onTap, borderRadius: BorderRadius.circular(12), child: body);
  }
}

class _JournalActionTile extends StatelessWidget {
  final String title, subtitle;
  final IconData icon;
  final VoidCallback onTap;
  const _JournalActionTile({required this.title, required this.subtitle, required this.icon, required this.onTap});
  @override Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF303238)), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.adaptiveWhite(alpha: .07))), child: Row(children: [Container(width: 38, height: 38, decoration: BoxDecoration(color: AppTheme.luxuryGold.withValues(alpha: .10), shape: BoxShape.circle), child: Icon(icon, color: AppTheme.luxuryGold, size: 19)), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: TextStyle(color: AppTheme.textPrimary, fontSize: 12, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(subtitle, style: TextStyle(color: AppTheme.textMuted, fontSize: 10))])), Icon(Icons.arrow_forward_ios_rounded, color: AppTheme.textVeryFaint, size: 12)])));
}

class _JournalGuideSection extends StatelessWidget {
  final String title, body;
  const _JournalGuideSection({required this.title, required this.body});
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: TextStyle(color: AppTheme.neonGreen, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: .6)), const SizedBox(height: 5), Text(body, style: TextStyle(color: AppTheme.textSecondary, fontSize: 12, height: 1.5))]));
}

class _CommunityJournalResultsPage extends StatelessWidget {
  final String period, title;
  const _CommunityJournalResultsPage({required this.period, required this.title});

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.adaptiveSurface(Color(0xFF070B10)),
    appBar: AppBar(
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
      actions: [
        IconButton(
          tooltip: 'Refresh',
          onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => _CommunityJournalResultsPage(period: period, title: title))),
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
    ),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: TradingJournalService.closedLiveCallsStream(period),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Journal history could not be loaded. Pull to refresh or use the refresh button.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textMuted))));
        final now = DateTime.now();
        final today = DateTime(now.year, now.month, now.day);
        final start = period == 'daily' ? today : period == 'weekly' ? today.subtract(Duration(days: today.weekday - DateTime.monday)) : period == 'monthly' ? DateTime(now.year, now.month) : DateTime(now.year);
        final end = period == 'daily' ? start.add(const Duration(days: 1)) : period == 'weekly' ? start.add(const Duration(days: 7)) : period == 'monthly' ? DateTime(start.year, start.month + 1) : DateTime(start.year + 1);
        DateTime? readDate(dynamic raw) => raw is Timestamp ? raw.toDate() : DateTime.tryParse((raw ?? '').toString());
        final docs = (snapshot.data?.docs ?? []).where((d) {
          final data = d.data();
          if (data['tradeClosed'] != true) return false;
          final closedAt = readDate(data['closedAt']);
          return closedAt != null && !closedAt.isBefore(start) && closedAt.isBefore(end);
        }).toList()
          ..sort((a,b) => (readDate(b.data()['closedAt']) ?? DateTime(0)).compareTo(readDate(a.data()['closedAt']) ?? DateTime(0)));
        if (docs.isEmpty) return RefreshIndicator(onRefresh: () async => Future<void>.delayed(const Duration(milliseconds: 250)), child: ListView(physics: const AlwaysScrollableScrollPhysics(), children: [SizedBox(height: 220), Center(child: Text('No officially closed Live Call results for this period.', style: TextStyle(color: AppTheme.textMuted)))]));
        return RefreshIndicator(onRefresh: () async => Future<void>.delayed(const Duration(milliseconds: 250)), child: ListView(physics: const AlwaysScrollableScrollPhysics(), padding: const EdgeInsets.fromLTRB(16, 12, 16, 30), children: [for (final d in docs) _CommunityResultCard(data: d.data())]));
      },
    ),
  );
}

String _journalTradeName(Map<String, dynamic> data) {
  const keys = <String>[
    'tradeName',
    'asset',
    'signalAsset',
    'coin',
    'symbol',
    'assetName',
  ];
  for (final key in keys) {
    final value = (data[key] ?? '').toString().trim();
    if (value.isNotEmpty && value.toUpperCase() != 'UNKNOWN') {
      return value.replaceAll(RegExp(r'/USDT$', caseSensitive: false), '').trim();
    }
  }
  return 'LIVE CALL';
}

class _CommunityResultCard extends StatelessWidget {
  final Map<String,dynamic> data;
  const _CommunityResultCard({required this.data});
  DateTime? _date(dynamic v) => v is Timestamp ? v.toDate() : DateTime.tryParse((v ?? '').toString());
  String _stamp(dynamic v) { final d=_date(v); if(d==null)return '—'; return '${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')} ${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}'; }
  @override Widget build(BuildContext context) {
    final green = data['closedGreen'] == true;
    final c = green ? const Color(0xFF39E75F) : const Color(0xFFE05252);
    final raw = (data['finalProfitPercentage'] ?? data['resultPercentage'] ?? '0').toString().replaceAll('%','');
    final value = double.tryParse(raw.replaceAll('+','')) ?? 0;
    final p = '${value>=0?'+':''}${value.toStringAsFixed(2)}%';
    final hits=<String>[];
    if(data['tp1Hit']==true) hits.add('TP1 +${(data['tp1Profit']??'').toString().replaceFirst(RegExp(r'^\+'),'')}%');
    if(data['tp2Hit']==true) hits.add('TP2 +${(data['tp2Profit']??'').toString().replaceFirst(RegExp(r'^\+'),'')}%');
    if(data['tp3Hit']==true) hits.add('TP3 +${(data['tp3Profit']??'').toString().replaceFirst(RegExp(r'^\+'),'')}%');
    return Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.fromLTRB(12,11,12,11), decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF303238)), borderRadius: BorderRadius.circular(12), border: Border.all(color: c.withValues(alpha:.20))), child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Expanded(child:Text('${_journalTradeName(data)} /USDT',maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(color:AppTheme.textPrimary,fontSize:12,fontWeight:FontWeight.w900))),Text(p,style:TextStyle(color:c,fontSize:14,fontWeight:FontWeight.w900))]),
      const SizedBox(height:4),
      Text(data['longDirection'] == true ? 'LONG' : 'SHORT',style:TextStyle(color:data['longDirection'] == true ? const Color(0xFF39E75F) : const Color(0xFFE05252),fontSize:9,fontWeight:FontWeight.w900,letterSpacing:.5)),
      const SizedBox(height:6),
      Text('POSTED  ${_stamp(data['createdAt'])}',style:TextStyle(color:AppTheme.textMuted,fontSize:8,fontWeight:FontWeight.w700)),
      Text('CLOSED  ${_stamp(data['closedAt'])}',style:TextStyle(color:AppTheme.textMuted,fontSize:8,fontWeight:FontWeight.w700)),
      if(hits.isNotEmpty)...[const SizedBox(height:7),Wrap(spacing:5,runSpacing:5,children:[for(final h in hits)_ResultChip(h,const Color(0xFF39E75F))])],
      const SizedBox(height:6),
      Text(green?'TRADE CLOSED — GREEN':'TRADE CLOSED — RED',style:TextStyle(color:c,fontSize:8,fontWeight:FontWeight.w900,letterSpacing:.4)),
    ]));
  }
}

class _ResultChip extends StatelessWidget { final String text; final Color color; const _ResultChip(this.text,this.color); @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.symmetric(horizontal:7,vertical:4),decoration:BoxDecoration(color:color.withValues(alpha:.10),borderRadius:BorderRadius.circular(7),border:Border.all(color:color.withValues(alpha:.45))),child:Text(text,style:TextStyle(color:color,fontSize:8,fontWeight:FontWeight.w900))); }

class _PersonalLiveCallResultsPage extends StatelessWidget {
  final String period, title;
  const _PersonalLiveCallResultsPage({required this.period, required this.title});
  DateTime? _date(dynamic v) => v is Timestamp ? v.toDate() : DateTime.tryParse((v ?? '').toString());
  bool _inPeriod(DateTime d, DateTime now) {
    if(period=='daily') return d.year==now.year && d.month==now.month && d.day==now.day;
    if(period=='weekly') {
      final today=DateTime(now.year,now.month,now.day);
      final start=today.subtract(Duration(days:today.weekday-DateTime.monday));
      final end=start.add(const Duration(days:7));
      return !d.isBefore(start) && d.isBefore(end);
    }
    if(period=='monthly') return d.year==now.year && d.month==now.month;
    return d.year==now.year;
  }
  @override Widget build(BuildContext context) {
    final u=FirebaseAuth.instance.currentUser;
    if(u==null)return Scaffold(backgroundColor:AppTheme.adaptiveSurface(Color(0xFF070B10)),body:Center(child:Text('Sign in to view your personal history.')));
    return Scaffold(backgroundColor:AppTheme.adaptiveSurface(Color(0xFF070B10)),appBar:AppBar(title:Text(title,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:14))),body:StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirebaseFirestore.instance.collection('users').doc(u.uid).collection('tradingJournal').where('status',isEqualTo:'CLOSED').snapshots(),builder:(context,snapshot){
      if(snapshot.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());
      final now=DateTime.now();
      final docs=(snapshot.data?.docs??[]).where((d){final x=d.data();if(x['interaction']!='like')return false;final date=_date(x['closedAt']);return date!=null&&_inPeriod(date,now);}).toList()..sort((a,b){final da=_date(a.data()['closedAt'])??DateTime(0);final db=_date(b.data()['closedAt'])??DateTime(0);return db.compareTo(da);});
      if(docs.isEmpty)return Center(child:Text('No liked Live Call results for this period.',style:TextStyle(color:AppTheme.textMuted)));
      return ListView(padding:const EdgeInsets.fromLTRB(16,12,16,30),children:[for(final d in docs)_PersonalLiveCallResultCard(data:d.data())]);
    }));
  }
}

class _PersonalLiveCallResultCard extends StatelessWidget {
  final Map<String,dynamic> data;
  const _PersonalLiveCallResultCard({required this.data});
  DateTime? _date(dynamic v)=>v is Timestamp?v.toDate():DateTime.tryParse((v??'').toString());
  String _stamp(dynamic v){final d=_date(v);if(d==null)return '—';return '${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')} ${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';}
  @override Widget build(BuildContext context){
    final value=(data['finalProfitPercentage'] as num?)?.toDouble() ?? double.tryParse((data['resultPercentage']??'0').toString().replaceAll('%','')) ?? 0;
    final c=value>=0?const Color(0xFF39E75F):const Color(0xFFE05252);
    final hits=<String>[];
    if(data['tp1Hit']==true) hits.add('TP1 +${(data['tp1Profit']??'').toString().replaceFirst(RegExp(r'^\+'),'')}%');
    if(data['tp2Hit']==true) hits.add('TP2 +${(data['tp2Profit']??'').toString().replaceFirst(RegExp(r'^\+'),'')}%');
    if(data['tp3Hit']==true) hits.add('TP3 +${(data['tp3Profit']??'').toString().replaceFirst(RegExp(r'^\+'),'')}%');
    return Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.fromLTRB(12,11,12,11),decoration:BoxDecoration(color:AppTheme.adaptiveSurface(Color(0xFF303238)),borderRadius:BorderRadius.circular(12),border:Border.all(color:c.withValues(alpha:.20))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Expanded(child:Text('${_journalTradeName(data)} /USDT',maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(color:AppTheme.textPrimary,fontSize:12,fontWeight:FontWeight.w900))),Text('${value>=0?'+':''}${value.toStringAsFixed(2)}%',style:TextStyle(color:c,fontSize:14,fontWeight:FontWeight.w900))]),
      const SizedBox(height:4),
      Text(data['longDirection'] == true ? 'LONG' : 'SHORT',style:TextStyle(color:data['longDirection'] == true ? const Color(0xFF39E75F) : const Color(0xFFE05252),fontSize:9,fontWeight:FontWeight.w900,letterSpacing:.5)),
      const SizedBox(height:6),
      Text('POSTED  ${_stamp(data['signalCreatedAt'])}',style:TextStyle(color:AppTheme.textMuted,fontSize:8,fontWeight:FontWeight.w700)),
      Text('CLOSED  ${_stamp(data['closedAt'])}',style:TextStyle(color:AppTheme.textMuted,fontSize:8,fontWeight:FontWeight.w700)),
      if(hits.isNotEmpty)...[const SizedBox(height:7),Wrap(spacing:5,runSpacing:5,children:[for(final h in hits)_ResultChip(h,const Color(0xFF39E75F))])],
      const SizedBox(height:6),
      Text('${data['officialResult']??(value>=0?'WIN':'LOSS')}',style:TextStyle(color:c,fontSize:8,fontWeight:FontWeight.w900,letterSpacing:.4)),
    ]));
  }
}

class _PersonalTradingJournalPage extends StatefulWidget { const _PersonalTradingJournalPage(); @override State<_PersonalTradingJournalPage> createState()=>_PersonalTradingJournalPageState(); }
class _PersonalTradingJournalPageState extends State<_PersonalTradingJournalPage> {
  Map<String,dynamic> settings = {};
  Map<String,dynamic> today = {};
  List<Map<String,dynamic>> history = [];
  final actual = TextEditingController();
  final manual = TextEditingController();

  @override void initState(){super.initState(); _load();}
  @override void dispose(){actual.dispose(); manual.dispose(); super.dispose();}

  Future<void> _load() async {
    final u=FirebaseAuth.instance.currentUser; if(u==null)return;
    try {
      var s=await TradingJournalService.loadTaskSettings(u.uid);
      if(s.isNotEmpty){
        final portfolio=(s['portfolio'] as num?)?.toDouble() ?? 0;
        final monthlyTarget=(s['monthlyTargetPct'] as num?)?.toDouble() ?? 0;
        if(portfolio>0 && monthlyTarget>0){
          final normalized=TradingJournalService.calculatePlan({'portfolio':portfolio,'monthlyTargetPct':monthlyTarget});
          s=<String,dynamic>{'portfolio':portfolio,'monthlyTargetPct':monthlyTarget,...normalized};
          await TradingJournalService.saveTaskSettings(u.uid,s);
          await TradingJournalService.syncTodayTask(u.uid,s);
        }
        final generated=await TradingJournalService.ensureTodayTask(u.uid,s);
        if(generated && mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('You have a new Trading Task')));}
      }
      final h=await TradingJournalService.loadPersonalDays(u.uid);
      final d=await TradingJournalService.loadToday(u.uid);
      if(mounted)setState((){settings=s;history=h;today=d;});
    } catch (_) {}
  }

  void _showDailyTaskCompletedPopup() {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF5A5D63),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: AppTheme.adaptiveWhite(alpha: .28)),
        ),
        title: Center(
          child: Text(
            'DAILY TASK COMPLETED 🎉',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900, fontSize: 16),
          ),
        ),
        content: Text(
          'Enjoy and come back tomorrow. ✨\n\nDo not overtrade. 🛡️📈\nYou completed today\'s task — protect your progress and let tomorrow be tomorrow.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppTheme.textPrimary, fontSize: 13, height: 1.5, fontWeight: FontWeight.w700),
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('ENJOY THE WIN ✨'),
          ),
        ],
      ),
    );
  }

  Future<void> _setup() async {
    if ((today['status'] ?? '') == 'TASK COMPLETED') {
      _showDailyTaskCompletedPopup();
      return;
    }
    final result=await showDialog<Map<String,double>>(context:context,builder:(_)=>const _TaskSetupDialog());
    if(result==null)return;
    final u=FirebaseAuth.instance.currentUser; if(u==null)return;
    final plan=TradingJournalService.calculatePlan(result);
    final all=<String,dynamic>{...result,...plan};
    await TradingJournalService.saveTaskSettings(u.uid, all);
    await TradingJournalService.syncTodayTask(u.uid, all);
    await _load();
  }

  Future<void> _saveActual() async {
    final u=FirebaseAuth.instance.currentUser; if(u==null)return;
    final v=double.tryParse(actual.text.trim()); if(v==null)return;
    try {
      await TradingJournalService.saveTodayProfit(u.uid,v);
      if (!mounted) return;
      actual.clear();
      await _load();
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Could not save today's result. Please try again.")));
    }
  }

  Future<void> _saveManual() async {
    final u = FirebaseAuth.instance.currentUser;
    if (u == null) return;
    final v = double.tryParse(manual.text.trim());
    if (v == null || !v.isFinite) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid profit or loss amount.')));
      return;
    }
    try {
      await TradingJournalService.saveManualProfit(u.uid, v);
      if (!mounted) return;
      manual.clear();
      await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save Manual Entry Profit. Please try again.')));
    }
  }

  Future<void> _editManualProfit(double currentValue) async {
    final controller=TextEditingController(text:currentValue.toStringAsFixed(2));
    final value=await showDialog<double>(
      context:context,
      builder:(dialogContext)=>AlertDialog(
        backgroundColor:AppTheme.adaptiveSurface(Color(0xFF101419)),
        title:const Text('EDIT PERSONAL PROFIT',style:TextStyle(fontWeight:FontWeight.w900)),
        content:TextField(
          controller:controller,
          autofocus:true,
          keyboardType:const TextInputType.numberWithOptions(decimal:true,signed:true),
          decoration:const InputDecoration(labelText:'Profit / Loss (USDT)'),
        ),
        actions:[
          TextButton(onPressed:()=>Navigator.pop(dialogContext),child:const Text('CANCEL')),
          FilledButton(onPressed:(){final v=double.tryParse(controller.text.trim());if(v!=null)Navigator.pop(dialogContext,v);},child:const Text('SAVE')),
        ],
      ),
    );
    controller.dispose();
    if(value==null || !mounted)return;
    final u = FirebaseAuth.instance.currentUser;
    if (u == null || !value.isFinite) return;
    try {
      await TradingJournalService.saveManualProfit(u.uid, value);
      if (mounted) await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save Manual Entry Profit. Please try again.')));
    }
  }

  @override
  Widget build(BuildContext context){
    final dailyTarget=(today['dailyTargetPct'] as num?)?.toDouble() ?? (settings['dailyTargetPct'] as num?)?.toDouble() ?? 0;
    final targetUsd=(today['dailyTargetUsd'] as num?)?.toDouble() ?? (settings['dailyTargetUsd'] as num?)?.toDouble() ?? 0;
    final actualValue=(today['actualProfitUsd'] as num?)?.toDouble();
    final done=actualValue!=null && actualValue.toStringAsFixed(2).compareTo(targetUsd.toStringAsFixed(2))>=0;
    double dayValue(Map<String,dynamic> d)=>((d['actualProfitUsd'] ?? d['manualProfitUsd']) as num?)?.toDouble() ?? 0;
    final now=DateTime.now();
    final calendarTradingDays=DateTime(now.year,now.month+1,0).day;
    final tradedDays=history.where((d){
      final x=DateTime.tryParse((d['date']??'').toString());
      return x!=null && x.year==now.year && x.month==now.month && (d['actualProfitUsd'] != null || d['manualProfitUsd'] != null);
    }).length + ((today['actualProfitUsd'] != null || today['manualProfitUsd'] != null) && !history.any((d)=>(d['date']??'').toString()==TradingJournalService.dateKey()) ? 1 : 0);
    final dailyProfit=dayValue(today);
    final monthlyProfit=history.where((d){final x=DateTime.tryParse((d['date']??'').toString());return x!=null&&x.year==now.year&&x.month==now.month;}).fold<double>(0,(a,d)=>a+dayValue(d));
    final yearlyProfit=history.where((d){final x=DateTime.tryParse((d['date']??'').toString());return x!=null&&x.year==now.year;}).fold<double>(0,(a,d)=>a+dayValue(d));
    return Scaffold(
      backgroundColor:AppTheme.adaptiveSurface(Color(0xFF070B10)),
      appBar:AppBar(title:const Text('PERSONAL TRADING JOURNAL',style:TextStyle(fontWeight:FontWeight.w900,fontSize:14)),actions:[IconButton(tooltip:'Refresh',onPressed:_load,icon:const Icon(Icons.refresh_rounded))]),
      body:RefreshIndicator(onRefresh:_load,child:ListView(
        padding:const EdgeInsets.fromLTRB(16,12,16,30),
        children:[
          Row(children:[
            Expanded(child:InkWell(borderRadius:BorderRadius.circular(12),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const _PersonalLiveCallResultsPage(period:'daily',title:'YOUR DAILY LIVE CALLS'))),child:_PersonalProfitTile(title:'DAILY PROFIT',value:dailyProfit,percent:_portfolioPct(dailyProfit,settings)))),
            const SizedBox(width:8),
            Expanded(child:InkWell(borderRadius:BorderRadius.circular(12),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const _PersonalLiveCallResultsPage(period:'monthly',title:'YOUR MONTHLY LIVE CALLS'))),child:_PersonalProfitTile(title:'MONTHLY PROFIT',value:monthlyProfit,percent:_portfolioPct(monthlyProfit,settings)))),
            const SizedBox(width:8),
            Expanded(child:InkWell(borderRadius:BorderRadius.circular(12),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const _PersonalLiveCallResultsPage(period:'yearly',title:'YOUR YEARLY LIVE CALLS'))),child:_PersonalProfitTile(title:'YEARLY PROFIT',value:yearlyProfit,percent:_portfolioPct(yearlyProfit,settings)))),
          ]),
          const SizedBox(height:14),
          _JournalActionTile(title:'TRADING TASK',subtitle:settings.isEmpty?'Set up your private trading plan':done?'Today\'s task completed • locked until tomorrow':'Update your private trading plan',icon:done?Icons.lock_rounded:Icons.track_changes_rounded,onTap:done?_showDailyTaskCompletedPopup:_setup),
          if(settings.isNotEmpty)...[
            const SizedBox(height:14),
            _PrivatePlanCard(settings:settings, tradedDays:tradedDays, calendarTradingDays:calendarTradingDays, locked:done, onLockedTap:_showDailyTaskCompletedPopup),
            const SizedBox(height:12),
            Container(
              padding:const EdgeInsets.all(14),
              decoration:BoxDecoration(color:AppTheme.adaptiveSurface(Color(0xFF303238)),borderRadius:BorderRadius.circular(14),border:Border.all(color:AppTheme.adaptiveWhite(alpha:.07))),
              child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text("TODAY'S TRADING TASK",style:TextStyle(color:AppTheme.luxuryGold,fontSize:11,fontWeight:FontWeight.w900)),
                const SizedBox(height:7),
                Text('Target: ${targetUsd.toStringAsFixed(2)} USDT / ${dailyTarget.toStringAsFixed(2)}%',style:TextStyle(color:AppTheme.textPrimary,fontSize:16,fontWeight:FontWeight.w900)),
                const SizedBox(height:10),
                InkWell(
                  onTap: done ? _showDailyTaskCompletedPopup : null,
                  borderRadius: BorderRadius.circular(10),
                  child: IgnorePointer(
                    ignoring: done,
                    child: TextField(controller:actual,keyboardType:const TextInputType.numberWithOptions(decimal:true,signed:true),decoration:InputDecoration(labelText:'Actual profit today (USDT)',enabled:!done)),
                  ),
                ),
                const SizedBox(height:8),
                FilledButton(onPressed:done?_showDailyTaskCompletedPopup:_saveActual,child:Text(done?'DAILY TASK COMPLETED':'SAVE TODAY\'S RESULT')),
                if(actualValue!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(done?'TASK COMPLETED':'TARGET NOT REACHED',style:TextStyle(color:done?AppTheme.neonGreen:const Color(0xFFE05252),fontWeight:FontWeight.w900))),
              ]),
            ),
            const SizedBox(height:12),
            _RiskManagementCard(settings:settings),
          ],
          const SizedBox(height:14),
          Text('PERSONAL PROFIT ENTRY',style:TextStyle(color:AppTheme.luxuryGold,fontSize:11,fontWeight:FontWeight.w900)),
          const SizedBox(height:7),
          _PersonalManualProfitBox(
            value: today['manualProfitUsd'] as num?,
            controller: manual,
            onSave: _saveManual,
            onEdit: _editManualProfit,
          ),
          const SizedBox(height:14),
          Text('CALENDAR HISTORY',style:TextStyle(color:AppTheme.luxuryGold,fontSize:11,fontWeight:FontWeight.w900)),
          const SizedBox(height:7),
          _PersonalCalendar(history:history),
          const SizedBox(height:14),
          Text('HISTORICAL DAILY RESULTS',style:TextStyle(color:AppTheme.luxuryGold,fontSize:11,fontWeight:FontWeight.w900)),
          const SizedBox(height:7),
          ...history.take(31).map((d)=>_PersonalDayRow(data:d)),
        ],
      )),
    );
  }
}

double _portfolioPct(double value, Map<String,dynamic> settings) {
  final portfolio = (settings['portfolio'] as num?)?.toDouble() ?? 0;
  return portfolio > 0 ? (value / portfolio) * 100 : 0;
}

class _PersonalProfitTile extends StatelessWidget {
  final String title; final double value; final double percent;
  const _PersonalProfitTile({required this.title,required this.value,required this.percent});
  @override Widget build(BuildContext context){
    final c=value>=0?const Color(0xFF39E75F):const Color(0xFFE05252);
    return Container(height:76,padding:const EdgeInsets.fromLTRB(8,8,8,7),decoration:BoxDecoration(color:AppTheme.adaptiveSurface(Color(0xFF303238)),borderRadius:BorderRadius.circular(12),border:Border.all(color:AppTheme.adaptiveWhite(alpha:.07))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(title,maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(color:AppTheme.textPrimary,fontSize:8,fontWeight:FontWeight.w800)),
      const Spacer(),
      Align(alignment:Alignment.centerRight,child:Text('${value>=0?'+':''}${value.toStringAsFixed(2)} USDT',style:TextStyle(color:c,fontSize:11,fontWeight:FontWeight.w900))),
      const SizedBox(height:2),
      Align(alignment:Alignment.centerRight,child:Text('${percent>=0?'+':''}${percent.toStringAsFixed(2)}%',style:TextStyle(color:c,fontSize:10,fontWeight:FontWeight.w900))),
    ]));
  }
}

class _PrivatePlanCard extends StatelessWidget {
  final Map<String, dynamic> settings;
  final int tradedDays;
  final int calendarTradingDays;
  final bool locked;
  final VoidCallback onLockedTap;
  const _PrivatePlanCard({required this.settings, required this.tradedDays, required this.calendarTradingDays, required this.locked, required this.onLockedTap});

  @override
  Widget build(BuildContext context) {
    double n(String k) => (settings[k] as num?)?.toDouble() ?? 0;
    final tiles = <Map<String,String>>[
      {'title':'PORTFOLIO','value':'${n('portfolio').toStringAsFixed(2)} USDT'},
      {'title':'MONTHLY TARGET','value':'${n('monthlyTargetPct').toStringAsFixed(2)}%'},
      {'title':'MONTHLY PROFIT','value':'${n('monthlyTargetUsd').toStringAsFixed(2)} USDT'},
      {'title':'TRADING DAYS','value':'$calendarTradingDays DAYS'},
      {'title':'TRADED DAYS','value':'$tradedDays DAYS'},
      {'title':'TRADES / DAY','value':n('tradesPerDay').toStringAsFixed(0)},
      {'title':'DAILY TARGET','value':'${n('dailyTargetUsd').toStringAsFixed(2)} USDT / ${n('dailyTargetPct').toStringAsFixed(2)}%'},
      {'title':'RISK / TRADE','value':'${n('riskPerTradePct').toStringAsFixed(2)}%  •  ${(n('riskPerTradeUsd')).toStringAsFixed(2)} USDT'},
      {'title':'STOP-LOSS','value':'${n('stopLossPct').toStringAsFixed(2)}%'},
      {'title':'RISK / REWARD','value':'1:${n('riskReward').toStringAsFixed(1)}'},
      {'title':'MAX DAILY LOSS','value':'${n('maxDailyRiskPct').toStringAsFixed(2)}%  •  ${n('maxDailyRiskUsd').toStringAsFixed(2)} USDT'},
      {'title':'PROFIT / TRADE','value':'${n('profitTargetPerTradeUsd').toStringAsFixed(2)} USDT'},
      {'title':'POSITION NOTIONAL','value':'${n('suggestedPositionNotional').toStringAsFixed(2)} USDT'},
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('CALCULATED TRADING TASK', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 11, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: tiles.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: 1.08,
          ),
          itemBuilder: (_, i) => _TaskValueTile(title: tiles[i]['title']!, value: tiles[i]['value']!, locked: locked, onLockedTap: onLockedTap),
        ),
      ],
    );
  }
}

class _TaskValueTile extends StatelessWidget {
  final String title, value;
  final bool locked;
  final VoidCallback onLockedTap;
  const _TaskValueTile({required this.title, required this.value, required this.locked, required this.onLockedTap});

  @override
  Widget build(BuildContext context) {
    final tile = Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: AppTheme.adaptiveSurface(Color(0xFF303238)),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: AppTheme.adaptiveWhite(alpha: .07)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppTheme.textFaint, fontSize: 7, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(value, maxLines: 2, style: TextStyle(color: AppTheme.textPrimary, fontSize: 10, fontWeight: FontWeight.w800, height: 1.15)),
          ),
          if (locked) ...[
            const SizedBox(height: 4),
            Icon(Icons.lock_rounded, color: AppTheme.textFaint, size: 11),
          ],
        ],
      ),
    );
    return InkWell(onTap: locked ? onLockedTap : null, borderRadius: BorderRadius.circular(9), child: tile);
  }
}

class _PersonalManualProfitBox extends StatelessWidget {
  final num? value;
  final TextEditingController controller;
  final VoidCallback onSave;
  final Future<void> Function(double value) onEdit;
  const _PersonalManualProfitBox({required this.value, required this.controller, required this.onSave, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    final saved = value != null;
    if (!saved) {
      return Row(children:[
        Expanded(child:TextField(controller:controller,keyboardType:const TextInputType.numberWithOptions(decimal:true,signed:true),decoration:const InputDecoration(labelText:'Profit / Loss (USDT)'))),
        const SizedBox(width:8),
        FilledButton(onPressed:onSave,child:const Text('SAVE')),
      ]);
    }
    final v=value!.toDouble();
    final color=v>=0?AppTheme.neonGreen:const Color(0xFFE05252);
    return Container(
      width:double.infinity,
      padding:const EdgeInsets.fromLTRB(13,11,10,12),
      decoration:BoxDecoration(color:const Color(0xFF25272C),borderRadius:BorderRadius.circular(11),border:Border.all(color:AppTheme.adaptiveWhite(alpha:.08))),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[
          Expanded(child:Text('SAVED PERSONAL PROFIT',style:TextStyle(color:AppTheme.textMuted,fontSize:8,fontWeight:FontWeight.w900))),
          IconButton(onPressed:()=>onEdit(v),padding:EdgeInsets.zero,constraints:const BoxConstraints.tightFor(width:30,height:30),icon:Icon(Icons.edit_rounded,color:AppTheme.textMuted,size:15),tooltip:'Edit'),
        ]),
        Text('${v>=0?'+':''}${v.toStringAsFixed(2)} USDT',style:TextStyle(color:color,fontSize:16,fontWeight:FontWeight.w900)),
      ]),
    );
  }
}

class _RiskManagementCard extends StatelessWidget {
  final Map<String, dynamic> settings;
  const _RiskManagementCard({required this.settings});

  @override
  Widget build(BuildContext context) {
    double n(String k) => (settings[k] as num?)?.toDouble() ?? 0;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.adaptiveSurface(Color(0xFF303238)),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.adaptiveWhite(alpha: .07)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('RISK MANAGEMENT PLAN', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 11, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('Suggested risk per trade: ${n('riskPerTradePct').toStringAsFixed(2)}% (${(n('portfolio') * n('riskPerTradePct') / 100).toStringAsFixed(2)} USDT)', style: TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
          Text('Maximum daily loss: ${n('maxDailyRiskPct').toStringAsFixed(2)}% (${(n('portfolio') * n('maxDailyRiskPct') / 100).toStringAsFixed(2)} USDT)', style: TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
          const SizedBox(height: 3),
          Text('Baseline framework: 0.50% risk per trade and 1.00% maximum daily loss. The calculator reduces these limits when needed so the daily loss budget never exceeds the calculated daily target.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.45)),
          Text('Position risk is constrained by the stop-loss and predefined risk amount; do not increase leverage just to reach a target.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.45)),
          const SizedBox(height: 7),
          Text('Risk guidance: use a logical stop, size the position from the amount you can lose, limit total daily exposure, avoid revenge trading and stop when your predefined daily loss limit is reached.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.45)),
        ],
      ),
    );
  }
}
class _PersonalCalendar extends StatelessWidget {
  final List<Map<String, dynamic>> history;
  const _PersonalCalendar({required this.history});

  @override
  Widget build(BuildContext context) {
    final by = <String, Map<String, dynamic>>{};
    for (final d in history) {
      by[(d['date'] ?? '').toString()] = d;
    }
    final now = DateTime.now();
    final days = DateTime(now.year, now.month + 1, 0).day;
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: days,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 7,
        crossAxisSpacing: 5,
        mainAxisSpacing: 5,
        childAspectRatio: .86,
      ),
      itemBuilder: (_, i) {
        final day = i + 1;
        final key = '${now.year}-${now.month.toString().padLeft(2, '0')}-${day.toString().padLeft(2, '0')}';
        final d = by[key];
        final profit = d == null ? null : ((d['actualProfitUsd'] ?? d['manualProfitUsd']) as num?)?.toDouble();
        final active = d != null;
        final profitColor = profit == null ? AppTheme.textMuted : profit >= 0 ? const Color(0xFF39E75F) : const Color(0xFFE05252);
        return InkWell(
          onTap: active ? () => showDialog<void>(context: context,builder: (_) => AlertDialog(
            backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)),
            title: Text(key),
            content: Text('Daily Target: ${(d['dailyTargetUsd'] ?? 0)} USDT\nActual Profit: ${(d['actualProfitUsd'] ?? d['manualProfitUsd'] ?? 0)} USDT\nStatus: ${(d['status'] ?? 'No result')}'),
            actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('CLOSE'))],
          )) : null,
          borderRadius: BorderRadius.circular(7),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
            decoration: BoxDecoration(
              color: active ? profitColor.withValues(alpha:.08) : AppTheme.adaptiveSurface(Color(0xFF202228)),
              borderRadius: BorderRadius.circular(7),
              border: Border.all(color: active ? profitColor.withValues(alpha:.40) : AppTheme.fillFaint),
            ),
            child: Column(mainAxisAlignment:MainAxisAlignment.center,children:[
              Text('$day',style:TextStyle(color:active?profitColor:AppTheme.textMuted,fontWeight:FontWeight.w800,fontSize:9)),
              if(profit!=null)...[
                const SizedBox(height:3),
                FittedBox(child:Text('${profit>=0?'+':''}${profit.toStringAsFixed(2)}',style:TextStyle(color:profitColor,fontWeight:FontWeight.w900,fontSize:8))),
                const SizedBox(height:1),
                Text('USDT',style:TextStyle(color:AppTheme.textFaint,fontSize:6,fontWeight:FontWeight.w800)),
              ],
            ]),
          ),
        );
      },
    );
  }
}
class _PersonalDayRow extends StatelessWidget {
  final Map<String, dynamic> data;
  const _PersonalDayRow({required this.data});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF202228)), borderRadius: BorderRadius.circular(9)),
        child: Row(
          children: [
            Expanded(child: Text('${data['date']}', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10, fontWeight: FontWeight.w800))),
            Text('${data['actualProfitUsd'] ?? data['manualProfitUsd'] ?? 0} USDT', style: const TextStyle(color: Color(0xFF39E75F), fontSize: 10, fontWeight: FontWeight.w900)),
            const SizedBox(width: 8),
            Text('${data['status'] ?? ''}', style: TextStyle(color: AppTheme.textMuted, fontSize: 9)),
          ],
        ),
      );
}
class _TaskSetupDialog extends StatefulWidget {
  const _TaskSetupDialog();

  @override
  State<_TaskSetupDialog> createState() => _TaskSetupDialogState();
}

class _TaskSetupDialogState extends State<_TaskSetupDialog> {
  final p = TextEditingController(text: '500');
  final m = TextEditingController(text: '20');

  @override
  void dispose() {
    p.dispose();
    m.dispose();
    super.dispose();
  }

  Widget f(String label, TextEditingController c) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextField(
      controller: c,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(labelText: label),
    ),
  );

  @override
  Widget build(BuildContext context) => AlertDialog(
    backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)),
    title: const Text('TRADING TASK CALCULATOR', style: TextStyle(fontWeight: FontWeight.w900)),
    content: SizedBox(
      width: 390,
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Enter only the two things you control. The calculator fills the trading and risk parameters automatically.', style: TextStyle(color: AppTheme.textSoft, fontSize: 11, height: 1.45)),
            const SizedBox(height: 14),
            f('Current Portfolio / USDT', p),
            f('Monthly Profit Target %', m),
            const SizedBox(height: 2),
            Text('AUTO-CALCULATED', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .6)),
            const SizedBox(height: 5),
            Text('Calendar days • 3 trades/day • max 0.50% baseline risk/trade • 1% stop-loss • 1:2 risk/reward • daily loss capped at 1% and never above the daily target', style: TextStyle(color: AppTheme.textFaint, fontSize: 10, height: 1.45)),
          ],
        ),
      ),
    ),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCEL')),
      FilledButton(
        onPressed: () {
          final portfolio = double.tryParse(p.text.trim()) ?? 0;
          final monthly = double.tryParse(m.text.trim()) ?? 0;
          if (portfolio <= 0 || monthly <= 0) return;
          Navigator.pop(context, {'portfolio': portfolio, 'monthlyTargetPct': monthly});
        },
        child: const Text('CALCULATE TASK'),
      ),
    ],
  );
}
// MENTORSHIP
// ============================================================

class MentorshipPage extends StatefulWidget {
  final bool isAdmin;
  const MentorshipPage({super.key, this.isAdmin = false});

  @override
  State<MentorshipPage> createState() => _MentorshipPageState();
}

class _MentorshipPageState extends State<MentorshipPage> {
  bool _loading = true;
  bool _student = false;
  String _selectedPlan = '';
  String _paymentStatus = '';
  int _paidWeeks = 0;
  DateTime? _nextInstallmentDueAt;
  DateTime? _installmentGraceEndsAt;
  bool _mentorshipPaymentLocked = false;
  String _installmentNotice = '';
  List<QueryDocumentSnapshot<Map<String, dynamic>>> _lessons = [];
  List<QueryDocumentSnapshot<Map<String, dynamic>>> _schedules = [];
  List<QueryDocumentSnapshot<Map<String, dynamic>>> _students = [];

  static const _oneTime = 'one_time';
  static const _installment = 'installment';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final uid = AuthService.currentUser?.uid;
    if (uid == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      final data = await MentorshipService.loadMyMentorship(uid) ?? {};
      _student = data['mentorshipApproved'] == true || data['studentApproved'] == true || data['isStudent'] == true;
      _selectedPlan = (data['mentorshipPaymentPlan'] ?? '').toString();
      _paymentStatus = (data['mentorshipPaymentStatus'] ?? '').toString();
      _paidWeeks = (data['installmentPaidWeeks'] as num?)?.toInt() ?? 0;
      _nextInstallmentDueAt = data['installmentNextDueAt'] is Timestamp ? (data['installmentNextDueAt'] as Timestamp).toDate() : null;
      _installmentGraceEndsAt = data['installmentGraceEndsAt'] is Timestamp ? (data['installmentGraceEndsAt'] as Timestamp).toDate() : null;
      _mentorshipPaymentLocked = false;
      _installmentNotice = '';
      if (_student && !_mentorshipPaymentLocked && !widget.isAdmin) {
        try {
          final name = (data['displayName'] ?? data['name'] ?? AuthService.currentUser?.displayName ?? 'Mentorship Student').toString();
          await MentorshipService.ensureChatMember(uid: uid, name: name);
        } catch (_) {}
      }
      if (_student && _selectedPlan == _installment) {
        final now = DateTime.now();
        if (_paidWeeks >= 4) {
          _paymentStatus = 'completed';
        } else if (_installmentGraceEndsAt == null) {
          _mentorshipPaymentLocked = true;
          _installmentNotice = 'Your first installment payment is required to unlock Mentorship.';
        } else if (now.isAfter(_installmentGraceEndsAt!)) {
          _mentorshipPaymentLocked = true;
          _paymentStatus = 'overdue';
          _installmentNotice = 'Your 24-hour payment grace period has expired. Mentorship is locked until the next installment is paid.';
        } else if (_nextInstallmentDueAt != null && now.isAfter(_nextInstallmentDueAt!)) {
          final remaining = _installmentGraceEndsAt!.difference(now);
          _paymentStatus = 'warning';
          _installmentNotice = 'Your next \$20 installment is due. You have ${remaining.inHours.clamp(0, 24)} hours remaining before Mentorship locks.';
        }
      }
      _lessons = widget.isAdmin ? await MentorshipService.loadLessons() : [];
      if (widget.isAdmin) {
        _students = await MentorshipService.loadStudents();
        _schedules = await MentorshipService.loadSchedules();
      } else if (_student) {
        _schedules = await MentorshipService.loadSchedules(studentUid: uid);
      }
    } catch (_) {}
    if (mounted) {
      setState(() => _loading = false);
      if (_paymentStatus == 'warning' && _installmentNotice.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          showDialog<void>(
            context: context,
            builder: (_) => AlertDialog(
              backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)),
              title: const Text('INSTALLMENT PAYMENT WARNING', style: TextStyle(fontWeight: FontWeight.w900)),
              content: Text(_installmentNotice),
              actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
            ),
          );
        });
      }
    }
  }

  Future<void> _choosePlan(String plan) async {
    final uid = AuthService.currentUser?.uid;
    if (uid == null) return;
    try {
      await MentorshipService.choosePaymentPlan(uid: uid, plan: plan);
      if (mounted) {
        setState(() {
          _selectedPlan = plan;
          _paymentStatus = 'selected';
        });
        if (mounted) {
          final paymentPlanId = plan == _oneTime ? 'mentorship_one_time' : 'mentorship_installment';
          await Navigator.push(context, MaterialPageRoute(builder: (_) => CentralPaymentPage(product: 'mentorship', planId: paymentPlanId)));
        }
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not save payment plan: $e')));
    }
  }

  Future<void> _lessonEditor({int? number}) async {
    final n = number ?? ((_lessons.length + 1).clamp(1, 99));
    final existing = _lessons.where((d) => (d.data()['sessionNumber'] as num?)?.toInt() == n).firstOrNull;
    final data = existing?.data() ?? <String, dynamic>{};
    final title = TextEditingController(text: (data['title'] ?? 'Session $n').toString());
    final content = TextEditingController();
    final video = TextEditingController();
    bool published = data['isPublished'] != false;
    if (existing != null) {
      try {
        final details = await MentorshipService.loadLessonContent(existing.id);
        content.text = (details?['content'] ?? '').toString();
        video.text = (details?['videoUrl'] ?? '').toString();
      } catch (_) {}
    }
    if (!mounted) return;
    final save = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)),
        title: Text('MANAGE SESSION $n', style: const TextStyle(fontWeight: FontWeight.w900)),
        content: SingleChildScrollView(child: Column(children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Lesson title')),
          const SizedBox(height: 10),
          TextField(controller: content, minLines: 4, maxLines: 10, decoration: const InputDecoration(labelText: 'Lesson content / notes')),
          const SizedBox(height: 10),
          TextField(controller: video, decoration: const InputDecoration(labelText: 'Video / lesson URL')),
          const SizedBox(height: 8),
          SwitchListTile(value: published, onChanged: (v) => setDialogState(() => published = v), title: const Text('Published'), contentPadding: EdgeInsets.zero),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('SAVE')),
        ],
      )),
    );
    if (save != true) return;
    try {
      await MentorshipService.saveLesson(number: n, title: title.text, content: content.text, videoUrl: video.text, published: published);
      await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not save lesson: $e')));
    }
  }

  Future<void> _approveStudent(String uid, bool approved, {String name = '', String country = '', String timezone = ''}) async {
    try {
      await MentorshipService.adminSetStudent(uid: uid, approved: approved, name: name, country: country, timezone: timezone);
      await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not update student: $e')));
    }
  }

  Future<void> _scheduleEditor({QueryDocumentSnapshot<Map<String, dynamic>>? existing}) async {
    final d = existing?.data() ?? <String, dynamic>{};
    final students = _students.where((x) => x.data()['status'] == 'approved').toList();
    if (students.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Approve a Mentorship student first.')));
      return;
    }
    String studentUid = (d['studentUid'] ?? students.first.id).toString();
    String studentName = (d['studentName'] ?? '').toString();
    String country = (d['country'] ?? '').toString();
    String timezone = (d['timezone'] ?? '').toString();
    String details = (d['details'] ?? '').toString();
    String meet = (d['meetUrl'] ?? '').toString();
    DateTime when = (d['scheduledAt'] is Timestamp) ? (d['scheduledAt'] as Timestamp).toDate() : DateTime.now().add(const Duration(hours: 1));
    final name = TextEditingController(text: studentName);
    final countryC = TextEditingController(text: country);
    final zone = TextEditingController(text: timezone);
    final info = TextEditingController(text: details);
    final meetC = TextEditingController(text: meet);
    String selectedUid = studentUid;
    final ok = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)),
      title: const Text('PRIVATE STUDENT CLASS', style: TextStyle(fontWeight: FontWeight.w900)),
      content: SingleChildScrollView(child: Column(children: [
        DropdownButtonFormField<String>(initialValue: selectedUid, items: [for (final s in students) DropdownMenuItem(value: s.id, child: Text((s.data()['name'] ?? s.id).toString()))], onChanged: (v) { if (v != null) { setDialogState(() { selectedUid = v; name.text = (students.firstWhere((s) => s.id == v).data()['name'] ?? '').toString(); }); } }, decoration: const InputDecoration(labelText: 'Student')),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Student name')),
        TextField(controller: countryC, decoration: const InputDecoration(labelText: 'Country')),
        TextField(controller: zone, decoration: const InputDecoration(labelText: 'Timezone')),
        const SizedBox(height: 8),
        ListTile(contentPadding: EdgeInsets.zero, title: Text('Class time: ${when.toLocal()}'), trailing: const Icon(Icons.schedule_rounded), onTap: () async { final date = await showDatePicker(context: context, initialDate: when, firstDate: DateTime.now().subtract(const Duration(days: 1)), lastDate: DateTime.now().add(const Duration(days: 365))); if (date == null || !context.mounted) return; final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(when)); if (time != null) setDialogState(() => when = DateTime(date.year, date.month, date.day, time.hour, time.minute)); }),
        TextField(controller: info, minLines: 2, maxLines: 5, decoration: const InputDecoration(labelText: 'Live class details')),
        TextField(controller: meetC, decoration: const InputDecoration(labelText: 'Google Meet link')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('SAVE SCHEDULE'))],
    )));
    if (ok != true) return;
    try {
      await MentorshipService.saveSchedule(id: existing?.id ?? '', studentUid: selectedUid, studentName: name.text, country: countryC.text, timezone: zone.text, classDateTime: when, details: info.text, meetUrl: meetC.text);
      await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not save schedule: $e')));
    }
  }

  Widget _paymentCard() {
    final selectedOne = _selectedPlan == _oneTime;
    final selectedInstall = _selectedPlan == _installment;
    return GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text('PAYMENT', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900, fontSize: 16))), if (widget.isAdmin) _JellyPlusButton(color: AppTheme.textPrimary, tooltip: 'Manage mentorship payments', onPressed: _showAdminPayments)]),
      const SizedBox(height: 6),
      Text('Choose Your Payment Plan', style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w700)),
      const SizedBox(height: 6),
      Text('Installment rule: after each verified \$20 payment, you get 7 days. When the week ends, a 24-hour warning/grace period starts. If the next payment is not recorded within that 24 hours, Mentorship locks again until the next payment. This rule applies only to the installment plan.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.35)),
      const SizedBox(height: 12),
      _PlanChoice(title: 'Pay Once — \$80', subtitle: 'Paid once • \$80 total', selected: selectedOne, onTap: () => _choosePlan(_oneTime)),
      const SizedBox(height: 8),
      _PlanChoice(title: 'Select Installment Plan', subtitle: '4 weeks • \$20 per week • \$100 total', selected: selectedInstall, onTap: () => _choosePlan(_installment)),
      if (_selectedPlan.isNotEmpty) ...[
        const SizedBox(height: 10),
        Text('Selected: ${selectedOne ? 'ONE-TIME — \$80 TOTAL' : 'INSTALLMENT — \$20/WEEK — \$100 TOTAL'}', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900)),
        if (_paymentStatus.isNotEmpty) Text('Status: ${_paymentStatus.toUpperCase()}', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)),
        if (selectedInstall && _paidWeeks < 4) ...[
          const SizedBox(height: 8),
          Text('Installments paid: $_paidWeeks / 4', style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w700)),
          if (_nextInstallmentDueAt != null) Text('Next installment: ${_nextInstallmentDueAt!.toLocal()}', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)),
          if (_installmentNotice.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_installmentNotice, style: TextStyle(color: _mentorshipPaymentLocked ? const Color(0xFFE05252) : const Color(0xFFFFD166), fontWeight: FontWeight.w800, fontSize: 11))),
        ],
      ],
    ]));
  }

  void _showAdminPayments() {
    showModalBottomSheet<void>(context: context, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0B0F11)), isScrollControlled: true, builder: (_) => FutureBuilder<List<QueryDocumentSnapshot<Map<String, dynamic>>>>(future: FirebaseFirestore.instance.collection('mentorshipPayments').get().then((s) => s.docs), builder: (context, snap) {
      final docs = snap.data ?? [];
      return ListView(padding: const EdgeInsets.all(16), children: [
        const Text('MENTORSHIP PAYMENTS', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        for (final d in docs) _adminPaymentTile(d),
      ]);
    }));
  }

  Widget _adminPaymentTile(QueryDocumentSnapshot<Map<String, dynamic>> d) {
    final data = d.data();
    final plan = (data['plan'] ?? '').toString();
    final paidWeeks = (data['paidWeeks'] as num?)?.toInt() ?? 0;
    final status = (data['paymentStatus'] ?? '').toString();
    return Card(
      color: AppTheme.adaptiveSurface(Color(0xFF12171A)),
      child: ListTile(
        title: Text(d.id, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('$plan • $status${plan == _installment ? ' • $paidWeeks/4 paid' : ''}'),
        trailing: plan == _installment && paidWeeks < 4
            ? FilledButton(
                onPressed: () async {
                  try {
                    await MentorshipService.adminRecordInstallmentPayment(d.id);
                    if (mounted) {
                      Navigator.pop(context);
                      await _load();
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Installment marked as paid. The next 7-day period has started.')));
                    }
                  } catch (e) {
                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not record payment: $e')));
                  }
                },
                child: const Text('MARK PAID'),
              )
            : Text('\$${data['totalAmount'] ?? ''}'),
      ),
    );
  }


  Future<void> _openLesson(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final details = await MentorshipService.loadLessonContent(doc.id) ?? {};
    if (!mounted) return;
    showDialog<void>(context: context, builder: (_) => AlertDialog(backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)), title: Text((doc.data()['title'] ?? 'Lesson').toString()), content: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text((details['content'] ?? 'No lesson content uploaded yet.').toString()), if ((details['videoUrl'] ?? '').toString().isNotEmpty) ...[const SizedBox(height: 14), SelectableText('Video: ${details['videoUrl']}')]]),), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CLOSE'))]));
  }

  static const List<Map<String, String>> _mentorshipAreas = [
    {'key': 'lectures', 'title': 'LECTURES', 'subtitle': 'Video lessons and course material', 'icon': 'school'},
    {'key': 'assignments', 'title': 'DAILY ASSIGNMENTS', 'subtitle': 'Daily student tasks and submissions', 'icon': 'assignment'},
    {'key': 'backtesting', 'title': 'BACK TESTING', 'subtitle': 'Written backtesting classes and records', 'icon': 'analytics'},
    {'key': 'paper_money', 'title': 'PAPER MONEY', 'subtitle': 'Practice trading tasks and targets', 'icon': 'payments'},
  ];

  IconData _areaIcon(String key) {
    switch (key) {
      case 'assignments': return Icons.assignment_rounded;
      case 'backtesting': return Icons.analytics_rounded;
      case 'paper_money': return Icons.payments_rounded;
      default: return Icons.school_rounded;
    }
  }

  Widget _mentorshipAreaCard(Map<String, String> area) {
    final unlocked = widget.isAdmin || _student;
    final key = area['key']!;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: unlocked ? () => _openMentorshipArea(key, area['title']!) : null,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(children: [
          ImageFiltered(
            imageFilter: ui.ImageFilter.blur(sigmaX: unlocked ? 0 : 1.15, sigmaY: unlocked ? 0 : 1.15),
            child: GlassCard(child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 13),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(_areaIcon(key), color: AppTheme.textPrimary, size: 28),
                  const SizedBox(height: 9),
                  Expanded(
                    child: Align(
                      alignment: Alignment.bottomLeft,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            area['title']!,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: AppTheme.textPrimary,
                              fontWeight: FontWeight.w900,
                              fontSize: 13,
                              height: 1.15,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            area['subtitle']!,
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: AppTheme.textMuted,
                              fontSize: 9.5,
                              height: 1.25,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )),
          ),
          if (!unlocked) const Positioned.fill(child: IgnorePointer(child: Center(child: _LiveCall3DLock()))),
          if (widget.isAdmin) Positioned(top: 8, right: 8, child: _JellyPlusButton(color: AppTheme.textPrimary, tooltip: 'Add content', onPressed: () => _openMentorshipArea(key, area['title']!, openEditor: true))),
        ]),
      ),
    );
  }

  Future<void> _openMentorshipArea(String category, String title, {bool openEditor = false}) async {
    final items = await MentorshipService.loadCategoryContent(category);
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => _MentorshipAreaPage(category: category, title: title, items: items, isAdmin: widget.isAdmin, isStudent: _student, paymentLocked: _mentorshipPaymentLocked)));
    await _load();
  }

  Widget _mentorshipChatCard() {
    final unlocked = widget.isAdmin || (_student && !_mentorshipPaymentLocked);
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: unlocked ? () async {
        final uid = AuthService.currentUser?.uid;
        if (!widget.isAdmin && uid != null) {
          try {
            final data = await MentorshipService.loadMyMentorship(uid) ?? {};
            final name = (data['displayName'] ?? data['name'] ?? AuthService.currentUser?.displayName ?? 'Mentorship Student').toString();
            await MentorshipService.ensureChatMember(uid: uid, name: name);
          } catch (_) {}
        }
        if (!mounted) return;
        await Navigator.push(context, MaterialPageRoute(builder: (_) => _MentorshipChatRoomPage(isAdmin: widget.isAdmin, isStudent: _student && !_mentorshipPaymentLocked)));
      } : null,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(children: [
          GlassCard(child: Padding(
            padding: const EdgeInsets.fromLTRB(15, 15, 15, 14),
            child: Row(children: [
              Container(width: 48, height: 48, decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), border: Border.all(color: AppTheme.textPrimary.withOpacity(.22)), color: AppTheme.textPrimary.withOpacity(.06)), child: Icon(Icons.forum_rounded, color: AppTheme.textPrimary, size: 25)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('STUDENT CHAT ROOM', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900, fontSize: 15)),
                const SizedBox(height: 4),
                Text('Mentorship student group • 24/7 discussion & screenshot sharing', style: TextStyle(color: AppTheme.textMuted, fontSize: 10.5, height: 1.25)),
              ])),
              Icon(unlocked ? Icons.chevron_right_rounded : Icons.lock_outline_rounded, color: AppTheme.textPrimary, size: 22),
            ]),
          )),
          if (!unlocked) const Positioned.fill(child: IgnorePointer(child: Center(child: _LiveCall3DLock()))),
        ]),
      ),
    );
  }

  Widget _helpButton() => IconButton(tooltip: 'Mentorship information', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _MentorshipInfoPage())), icon: Icon(Icons.help_outline_rounded, color: AppTheme.textPrimary));

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(onRefresh: _load, child: ListView(physics: const AlwaysScrollableScrollPhysics(), padding: const EdgeInsets.fromLTRB(16, 8, 16, 110), children: [
      Row(children: [Expanded(child: Text('MENTORSHIP', style: TextStyle(color: AppTheme.textPrimary, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 1))), _helpButton()]),
      const SizedBox(height: 8),
      _paymentCard(),
      const SizedBox(height: 14),
      _mentorshipChatCard(),
      const SizedBox(height: 14),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('DAILY LESSONS', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900, fontSize: 16)), const SizedBox(height: 5), Text('25-session Mentorship learning area', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)), const SizedBox(height: 12), if (_loading) const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator())), GridView.count(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.74, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), children: [for (final area in _mentorshipAreas) _mentorshipAreaCard(area)])])),
      if (widget.isAdmin) ...[
        const SizedBox(height: 14),
        GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text('STUDENT MANAGEMENT', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900, fontSize: 16))), _JellyPlusButton(color: AppTheme.textPrimary, tooltip: 'Manage student', onPressed: _showStudentManager)]), const SizedBox(height: 8), for (final s in _students.take(20)) ListTile(contentPadding: EdgeInsets.zero, title: Text((s.data()['name'] ?? s.id).toString()), subtitle: Text('${s.data()['status'] ?? 'inactive'} • ${s.data()['country'] ?? ''} • ${s.data()['timezone'] ?? ''}'), trailing: Icon((s.data()['status'] ?? '') == 'approved' ? Icons.verified : Icons.lock_outline, color: AppTheme.textPrimary))])),
        const SizedBox(height: 14),
        GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text('PRIVATE CLASS SCHEDULE', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900, fontSize: 16))), _JellyPlusButton(color: AppTheme.textPrimary, tooltip: 'Add class schedule', onPressed: () => _scheduleEditor())]), const SizedBox(height: 8), for (final s in _schedules) ListTile(contentPadding: EdgeInsets.zero, title: Text('${s.data()['studentName'] ?? ''} • ${(s.data()['scheduledAt'] is Timestamp) ? (s.data()['scheduledAt'] as Timestamp).toDate().toLocal() : ''}'), subtitle: Text('${s.data()['country'] ?? ''} • ${s.data()['timezone'] ?? ''}'), trailing: IconButton(onPressed: () => _scheduleEditor(existing: s), icon: Icon(Icons.edit, color: AppTheme.textPrimary)))])),
      ],
      if (!widget.isAdmin && _student) ...[
        const SizedBox(height: 14),
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('YOUR LIVE CLASSES', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900, fontSize: 16)),
              const SizedBox(height: 8),
              for (final s in _schedules)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text('${s.data()['studentName'] ?? 'Mentorship Class'} • ${(s.data()['scheduledAt'] is Timestamp) ? (s.data()['scheduledAt'] as Timestamp).toDate().toLocal() : ''}'),
                  subtitle: Text('${s.data()['country'] ?? ''} • ${s.data()['timezone'] ?? ''}'),
                  trailing: Icon(Icons.video_call, color: AppTheme.textPrimary),
                ),
            ],
          ),
        ),
      ],
    ]));
  }

  Future<void> _showStudentManager() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const _StudentManagementPage()));
    if (mounted) await _load();
  }
}

class _StudentManagementPage extends StatefulWidget {
  const _StudentManagementPage();

  @override
  State<_StudentManagementPage> createState() => _StudentManagementPageState();
}

class _StudentManagementPageState extends State<_StudentManagementPage> {
  List<QueryDocumentSnapshot<Map<String, dynamic>>> _entries = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final entries = await MentorshipService.loadStudentDirectory();
      if (!mounted) return;
      setState(() {
        _entries = entries;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Unable to load the Student Directory.')));
    }
  }

  Map<String, dynamic>? _entryFor(int slot) {
    final id = 'student_${slot.toString().padLeft(2, '0')}';
    for (final doc in _entries) {
      if (doc.id == id) return doc.data();
    }
    return null;
  }

  Future<void> _editSlot(int slot) async {
    final data = _entryFor(slot) ?? <String, dynamic>{};
    final uid = TextEditingController(text: (data['studentUid'] ?? '').toString());
    final name = TextEditingController(text: (data['studentName'] ?? '').toString());
    final age = TextEditingController(text: (data['age'] ?? '').toString());
    final country = TextEditingController(text: (data['country'] ?? '').toString());
    bool saving = false;

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          backgroundColor: AppTheme.adaptiveSurface(const Color(0xFF101419)),
          title: Text('STUDENT ${slot.toString().padLeft(2, '0')}'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: uid, decoration: const InputDecoration(labelText: 'Student UID')),
                const SizedBox(height: 8),
                TextField(controller: name, decoration: const InputDecoration(labelText: 'Student Name')),
                const SizedBox(height: 8),
                TextField(controller: age, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Age')),
                const SizedBox(height: 8),
                TextField(controller: country, decoration: const InputDecoration(labelText: 'Country')),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: saving ? null : () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
            FilledButton(
              onPressed: saving
                  ? null
                  : () async {
                      if ([uid.text, name.text, age.text, country.text].any((v) => v.trim().isEmpty)) {
                        ScaffoldMessenger.of(dialogContext).showSnackBar(const SnackBar(content: Text('Please enter UID, name, age and country.')));
                        return;
                      }
                      setDialogState(() => saving = true);
                      try {
                        await MentorshipService.saveStudentDirectoryEntry(
                          slot: slot,
                          studentUid: uid.text,
                          studentName: name.text,
                          age: age.text,
                          country: country.text,
                        );
                        if (dialogContext.mounted) Navigator.pop(dialogContext, true);
                      } catch (e) {
                        if (dialogContext.mounted) {
                          setDialogState(() => saving = false);
                          ScaffoldMessenger.of(dialogContext).showSnackBar(SnackBar(content: Text('Save failed: $e')));
                        }
                      }
                    },
              child: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('SAVE'),
            ),
          ],
        ),
      ),
    );

    uid.dispose();
    name.dispose();
    age.dispose();
    country.dispose();
    if (saved == true && mounted) {
      await _load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Student ${slot.toString().padLeft(2, '0')} saved.')));
    }
  }

  Widget _slotCard(int slot) {
    final data = _entryFor(slot);
    final filled = data != null;
    final number = slot.toString().padLeft(2, '0');
    return GlassCard(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(child: Text('STUDENT $number', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900, fontSize: 14))),
              Icon(filled ? Icons.verified_rounded : Icons.person_add_alt_1_rounded, color: AppTheme.textPrimary, size: 20),
            ]),
            const SizedBox(height: 10),
            if (filled) ...[
              Text((data!['studentName'] ?? '').toString(), style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w800, fontSize: 13)),
              const SizedBox(height: 4),
              Text('UID: ${(data['studentUid'] ?? '').toString()}', style: TextStyle(color: AppTheme.textSoft, fontSize: 10)),
              Text('Age: ${(data['age'] ?? '').toString()} • Country: ${(data['country'] ?? '').toString()}', style: TextStyle(color: AppTheme.textSoft, fontSize: 10)),
              const SizedBox(height: 10),
              SizedBox(width: double.infinity, child: OutlinedButton(onPressed: () => _editSlot(slot), child: const Text('EDIT / SAVE'))),
            ] else ...[
              Text('No student saved in this slot.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)),
              const SizedBox(height: 10),
              SizedBox(width: double.infinity, child: FilledButton(onPressed: () => _editSlot(slot), child: const Text('ENTER DETAILS'))),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.adaptiveSurface(Colors.black),
      appBar: AppBar(
        title: const Text('STUDENT MANAGEMENT'),
        backgroundColor: AppTheme.adaptiveSurface(Colors.black),
        foregroundColor: AppTheme.textPrimary,
        actions: [IconButton(onPressed: _load, tooltip: 'Refresh', icon: const Icon(Icons.refresh_rounded))],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 30),
                children: [
                  GlassCard(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Text('MENTORSHIP STUDENT DIRECTORY\n25 dedicated student slots. Each slot stores Student UID, Student Name, Age and Country securely in Firebase. Private Class Schedule remains separate.', style: TextStyle(color: AppTheme.textSoft, height: 1.4, fontSize: 11)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  for (int slot = 1; slot <= 25; slot++) ...[
                    _slotCard(slot),
                    const SizedBox(height: 10),
                  ],
                ],
              ),
            ),
    );
  }
}

class _MentorshipImageThumb extends StatefulWidget {
  final String path;
  final String name;
  const _MentorshipImageThumb({required this.path, required this.name});
  @override
  State<_MentorshipImageThumb> createState() => _MentorshipImageThumbState();
}
class _MentorshipImageThumbState extends State<_MentorshipImageThumb> {
  Uint8List? bytes;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async { try { final b = await MentorshipService.downloadMentorshipFile(widget.path); if (mounted) setState(() => bytes = b); } catch (_) {} }
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 8), child: bytes == null ? const SizedBox(height: 100, child: Center(child: CircularProgressIndicator())) : ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(bytes!, fit: BoxFit.cover, width: double.infinity, height: 180)));
}

class _PlanChoice extends StatelessWidget {
  final String title, subtitle;
  final bool selected;
  final VoidCallback onTap;
  const _PlanChoice({required this.title, required this.subtitle, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: selected ? AppTheme.adaptiveWhite(alpha: .10) : AppTheme.adaptiveSurface(Color(0xFF12171A)), borderRadius: BorderRadius.circular(14), border: Border.all(color: selected ? AppTheme.textPrimary : AppTheme.borderSoft, width: selected ? 1.5 : 1)), child: Row(children: [Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off, color: AppTheme.textPrimary), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900)), const SizedBox(height: 2), Text(subtitle, style: TextStyle(color: AppTheme.textSoft, fontSize: 11))]))])));
}

class _MentorshipAreaPage extends StatefulWidget {
  final String category;
  final String title;
  final List<QueryDocumentSnapshot<Map<String, dynamic>>> items;
  final bool isAdmin;
  final bool isStudent;
  final bool paymentLocked;
  const _MentorshipAreaPage({required this.category, required this.title, required this.items, required this.isAdmin, required this.isStudent, this.paymentLocked = false});
  @override
  State<_MentorshipAreaPage> createState() => _MentorshipAreaPageState();
}

class _MentorshipAreaPageState extends State<_MentorshipAreaPage> {
  late List<QueryDocumentSnapshot<Map<String, dynamic>>> _items;

  @override
  void initState() { super.initState(); _items = [...widget.items]; }

  Future<void> _refresh() async {
    final items = await MentorshipService.loadCategoryContent(widget.category);
    if (mounted) setState(() => _items = items);
  }

  Future<void> _editor({int? number}) async {
    final n = number ?? ((_items.length + 1).clamp(1, 25));
    final existing = _items.where((d) => (d.data()['contentNumber'] as num?)?.toInt() == n).firstOrNull;
    final data = existing?.data() ?? <String, dynamic>{};
    final title = TextEditingController(text: (data['title'] ?? '${widget.title} $n').toString());
    final notes = TextEditingController();
    final video = TextEditingController();
    List<Map<String, dynamic>> pdfFiles = [];
    List<Map<String, dynamic>> imageFiles = [];
    bool published = data['isPublished'] != false;
    if (existing != null) {
      final details = await MentorshipService.loadLessonContent(existing.id) ?? {};
      notes.text = (details['notes'] ?? details['content'] ?? '').toString();
      video.text = (details['videoUrl'] ?? '').toString();
      pdfFiles = ((details['pdfFiles'] as List?) ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      imageFiles = ((details['imageFiles'] as List?) ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    }
    if (!mounted) return;
    final save = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)),
      title: Text('MANAGE ${widget.title} $n', style: const TextStyle(fontWeight: FontWeight.w900)),
      content: SingleChildScrollView(child: Column(children: [
        TextField(controller: title, decoration: const InputDecoration(labelText: 'Title / heading')),
        const SizedBox(height: 10),
        TextField(controller: notes, minLines: 5, maxLines: 12, decoration: InputDecoration(labelText: widget.category == 'lectures' ? 'Notes / video summary' : 'Written task / class notes')),
        if (widget.category != 'assignments') ...[
          const SizedBox(height: 10),
          TextField(controller: video, decoration: const InputDecoration(labelText: 'External video URL (optional)')),
        ],
        const SizedBox(height: 12),
        if (widget.category != 'lectures') FilledButton.icon(onPressed: () async {
          try {
            final picked = await FilePicker.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
            if (picked.isEmpty) return;
            final f = picked.first;
            final bytes = await f.readAsBytes();
            final path = await MentorshipService.uploadMentorshipFile(category: widget.category, contentId: MentorshipService.contentDocId(widget.category, n), fileName: f.name, bytes: bytes, contentType: 'application/pdf');
            setDialogState(() => pdfFiles.add({'name': f.name, 'path': path}));
          } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF upload failed: $e'))); }
        }, icon: const Icon(Icons.picture_as_pdf_rounded), label: const Text('ADD PDF')),
        if (widget.category != 'lectures' && pdfFiles.isNotEmpty) ...[
          const SizedBox(height: 6),
          for (final f in pdfFiles) ListTile(contentPadding: EdgeInsets.zero, dense: true, leading: Icon(Icons.picture_as_pdf, color: AppTheme.textPrimary), title: Text((f['name'] ?? 'PDF').toString()), trailing: IconButton(onPressed: () => setDialogState(() => pdfFiles.remove(f)), icon: Icon(Icons.close, color: AppTheme.textMuted))),
        ],
        if (widget.category != 'assignments') FilledButton.icon(onPressed: () async {
          try {
            final picked = await FilePicker.pickFiles(type: FileType.image);
            if (picked.isEmpty) return;
            final f = picked.first;
            final bytes = await f.readAsBytes();
            final path = await MentorshipService.uploadMentorshipFile(category: widget.category, contentId: MentorshipService.contentDocId(widget.category, n), fileName: f.name, bytes: bytes, contentType: 'image/${f.extension ?? 'jpeg'}');
            setDialogState(() => imageFiles.add({'name': f.name, 'path': path}));
          } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Picture upload failed: $e'))); }
        }, icon: const Icon(Icons.image_rounded), label: const Text('ADD PICTURE')),
        if (imageFiles.isNotEmpty) ...[
          const SizedBox(height: 6),
          for (final f in imageFiles) ListTile(contentPadding: EdgeInsets.zero, dense: true, leading: Icon(Icons.image, color: AppTheme.textPrimary), title: Text((f['name'] ?? 'Picture').toString()), trailing: IconButton(onPressed: () => setDialogState(() => imageFiles.remove(f)), icon: Icon(Icons.close, color: AppTheme.textMuted))),
        ],
        const SizedBox(height: 8),
        SwitchListTile(value: published, onChanged: (v) => setDialogState(() => published = v), title: const Text('Published'), contentPadding: EdgeInsets.zero),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('SAVE'))],
    )));
    if (save != true) return;
    try {
      await MentorshipService.saveCategoryContent(category: widget.category, number: n, title: title.text, notes: notes.text, videoUrl: video.text, published: published, pdfFiles: pdfFiles, imageFiles: imageFiles);
      await _refresh();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not save content: $e')));
    }
  }

  Future<void> _openItem(QueryDocumentSnapshot<Map<String, dynamic>> item) async {
    final details = await MentorshipService.loadLessonContent(item.id) ?? {};
    if (!mounted) return;
    final video = (details['videoUrl'] ?? '').toString().trim();
    final notes = (details['notes'] ?? details['content'] ?? 'No notes uploaded yet.').toString();
    final pdfFiles = ((details['pdfFiles'] as List?) ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    final imageFiles = ((details['imageFiles'] as List?) ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    showDialog<void>(context: context, builder: (_) => AlertDialog(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)),
      title: Text((item.data()['title'] ?? 'Content').toString()),
      content: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(notes, style: TextStyle(color: AppTheme.textPrimary, height: 1.4)),
        if (video.isNotEmpty) ...[const SizedBox(height: 16), Text('VIDEO', style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w900)), const SizedBox(height: 6), FilledButton.icon(onPressed: () async { final uri = Uri.tryParse(video); if (uri == null) { if (!context.mounted) return; ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open video URL.'))); return; } final opened = await launchUrl(uri, mode: LaunchMode.externalApplication); if (!context.mounted) return; if (!opened) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open video URL.'))); }, icon: const Icon(Icons.play_circle_fill_rounded), label: const Text('OPEN VIDEO'))],
        if (pdfFiles.isNotEmpty) ...[const SizedBox(height: 16), Text('PDF FILES', style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w900)), for (final f in pdfFiles) ListTile(contentPadding: EdgeInsets.zero, leading: Icon(Icons.picture_as_pdf, color: AppTheme.textPrimary), title: Text((f['name'] ?? 'PDF').toString()), onTap: () => _openPdf((f['path'] ?? '').toString(), (f['name'] ?? 'PDF').toString()))],
        if (imageFiles.isNotEmpty) ...[const SizedBox(height: 16), Text('PICTURES', style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w900)), const SizedBox(height: 8), for (final f in imageFiles) _MentorshipImageThumb(path: (f['path'] ?? '').toString(), name: (f['name'] ?? 'Picture').toString())],
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CLOSE'))],
    ));
  }

  Future<void> _openPdf(String path, String name) async {
    if (path.trim().isEmpty) return;
    try {
      final bytes = await MentorshipService.downloadMentorshipFile(path);
      if (!mounted) return;
      await Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: Text(name)), body: SfPdfViewer.memory(bytes))));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not open PDF: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final unlocked = widget.isAdmin || (widget.isStudent && !widget.paymentLocked);
    return Scaffold(
      appBar: AppBar(title: Text(widget.title), actions: [if (widget.isAdmin) IconButton(tooltip: 'Add content', onPressed: () => _editor(), icon: Icon(Icons.add_rounded, color: AppTheme.textPrimary))]),
      body: RefreshIndicator(onRefresh: _refresh, child: GridView.builder(
        padding: const EdgeInsets.all(16),
        physics: const AlwaysScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.88),
        itemCount: 25,
        itemBuilder: (context, index) {
          final n = index + 1;
          final doc = _items.where((d) => (d.data()['contentNumber'] as num?)?.toInt() == n).firstOrNull;
          final title = (doc?.data()['title'] ?? '${widget.title} $n').toString();
          final published = doc?.data()['isPublished'] != false;
          final canOpen = unlocked && published && doc != null;
          final Widget adminButton = widget.isAdmin
              ? Positioned(
                  top: 6,
                  right: 6,
                  child: _JellyPlusButton(
                    color: AppTheme.textPrimary,
                    tooltip: 'Upload content',
                    onPressed: () => _editor(number: n),
                  ),
                )
              : const SizedBox.shrink();

          return InkWell(
            onTap: canOpen ? () => _openItem(doc) : null,
            borderRadius: BorderRadius.circular(16),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Stack(
                children: [
                  ImageFiltered(
                    imageFilter: ui.ImageFilter.blur(
                      sigmaX: canOpen ? 0 : 0.65,
                      sigmaY: canOpen ? 0 : 0.65,
                    ),
                    child: GlassCard(
                      child: Padding(
                        padding: const EdgeInsets.all(13),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              widget.category == 'lectures'
                                  ? Icons.play_circle_fill_rounded
                                  : Icons.menu_book_rounded,
                              color: AppTheme.textPrimary,
                              size: 28,
                            ),
                            const Spacer(),
                            Text(
                              title,
                              style: TextStyle(
                                color: AppTheme.textPrimary,
                                fontWeight: FontWeight.w900,
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              doc == null
                                  ? 'Coming soon'
                                  : (published
                                      ? (unlocked ? 'Open content' : 'Locked')
                                      : 'Coming soon'),
                              style: TextStyle(
                                color: AppTheme.textMuted,
                                fontSize: 9,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  // The four category cards are the only lock surface. Admins and approved students never see a lock inside the content page.
                  adminButton,
                ],
              ),
            ),
          );
        },
      )),
    );
  }
}

class _MentorshipInfoPage extends StatelessWidget {
  const _MentorshipInfoPage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MENTORSHIP INFORMATION'),
        actions: [
          IconButton(
            tooltip: 'Enroll now',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const _MentorshipPaymentPlansPage()),
            ),
            icon: const Icon(Icons.arrow_forward_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
        children: [
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ABOUT MENTORSHIP', style: TextStyle(color: AppTheme.textPrimary, fontSize: 18, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('Mentorship is a structured educational program with daily lessons, practical application, backtesting and scheduled live classes.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('COURSE DURATION & STRUCTURE', style: TextStyle(color: AppTheme.textPrimary, fontSize: 17, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('3 months overall Mentorship program:\n• Approximately 1.5 months of structured learning/course material\n• Approximately 1.5 months of backtesting and practical application\n\nLessons continue to be uploaded to the Mentorship section as the program progresses.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('TOPICS COVERED', style: TextStyle(color: AppTheme.textPrimary, fontSize: 17, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('SMC — Smart Money Concepts\nICT — Inner Circle Trader concepts\nLIT\nSMT — Smart Money Technique/divergence concepts\nMarket structure\nPrice action\nLiquidity concepts\nEntries and trade planning\nBacktesting\nRisk management\nOther relevant concepts included in the actual curriculum.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('DAILY LESSONS & LIVE CLASSES', style: TextStyle(color: AppTheme.textPrimary, fontSize: 17, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('The Mentorship area contains daily learning content and practical student tasks. Each student receives a class schedule arranged around their country, timezone and mutually scheduled available time.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('PRACTICAL & BACKTESTING', style: TextStyle(color: AppTheme.textPrimary, fontSize: 17, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('The program includes practical application and a dedicated backtesting portion. The Mentorship section provides the established learning areas for lectures, daily assignments, back testing and paper-money practice tasks.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ACCESS & MENTORSHIP RULES', style: TextStyle(color: AppTheme.textPrimary, fontSize: 17, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('Non-students can see the Mentorship section and lesson titles, but lessons remain locked. Approved Mentorship students receive Student status and can access unlocked lessons. Admin can manage lessons and private student schedules. One student\'s schedule is not visible to another student.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
                SizedBox(height: 12),
                Text('INSTALLMENT RULE', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900)),
                SizedBox(height: 5),
                Text('After each verified \$20 payment, the installment student gets 7 days. When the week ends, a 24-hour warning/grace period starts. If the next payment is not recorded within that 24 hours, Mentorship locks again until the next payment. This rule applies only to the installment plan.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('PAYMENT OPTIONS', style: TextStyle(color: AppTheme.textPrimary, fontSize: 17, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('ONE-TIME PAYMENT\n• \$80 total\n• Paid once\n\nINSTALLMENT PAYMENT\n• \$20 per week\n• 4 weekly payments\n• \$100 total\n\nThe installment plan costs \$100 total rather than \$80.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('BADGE RECOGNITION', style: TextStyle(color: AppTheme.textPrimary, fontSize: 17, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('After secure payment verification, the corresponding badge is prepared for collection through Updates → Mail. The badge is not applied merely because payment was confirmed. The user must Collect the prepared badge, view the Alpha Den profile preview, and Confirm.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
                SizedBox(height: 10),
                Text('• Premium Monthly — normal Premium Star / PREMIUM label.\n• Premium Lifetime — Purple Star / LIFETIME label; no PREMIUM text beside it.\n• Mentorship One-Time — normal blue Student icon / STUDENT label.\n• Mentorship Installment — white Student icon / STUDENT 1 installment indicator.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
                SizedBox(height: 8),
                Text('The confirmed badge is stored with the account and restored across sessions and devices. Badge entitlement remains controlled by the secure backend; the client cannot grant itself a badge.', style: TextStyle(color: AppTheme.textMuted, fontSize: 11, height: 1.4)),
              ],
            ),
          ),
          const SizedBox(height: 22),
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const _MentorshipPaymentPlansPage()),
            ),
            icon: const Icon(Icons.school_rounded),
            label: const Text('ENROLL NOW FOR MENTORSHIP'),
          ),
        ],
      ),
    );
  }
}

class _MentorshipPaymentPlansPage extends StatelessWidget {
  const _MentorshipPaymentPlansPage();

  Future<void> _selectPlan(BuildContext context, String plan) async {
    final uid = AuthService.currentUser?.uid;
    if (uid == null) return;
    try {
      await MentorshipService.choosePaymentPlan(uid: uid, plan: plan);
      if (!context.mounted) return;
      final paymentPlanId = plan == 'one_time' ? 'mentorship_one_time' : 'mentorship_installment';
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => CentralPaymentPage(product: 'mentorship', planId: paymentPlanId)),
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not save payment plan: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('MENTORSHIP PAYMENT')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        children: [
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('CHOOSE YOUR MENTORSHIP PLAN', style: TextStyle(color: AppTheme.textPrimary, fontSize: 18, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('Select one of the existing Mentorship payment options below. Your selection will continue into the existing Firebase payment flow.', style: TextStyle(color: AppTheme.textSecondary, height: 1.45)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _MentorshipPlanTile(
            title: 'PAY ONCE — \$80',
            subtitle: 'Paid once • \$80 total',
            iconColor: const Color(0xFF8DB0FF),
            onTap: () => _selectPlan(context, 'one_time'),
          ),
          const SizedBox(height: 10),
          _MentorshipPlanTile(
            title: 'INSTALLMENT PLAN — \$20/WEEK',
            subtitle: '4 weekly payments • \$100 total',
            iconColor: AppTheme.textPrimary,
            onTap: () => _selectPlan(context, 'installment'),
          ),
          const SizedBox(height: 14),
          GlassCard(
            child: Text('Installment rule: after each verified \$20 payment, you get 7 days. When the week ends, a 24-hour warning/grace period starts. If the next payment is not recorded within that 24 hours, Mentorship locks again until the next payment. This rule applies only to the installment plan.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.45)),
          ),
        ],
      ),
    );
  }
}

class _MentorshipPlanTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final Color iconColor;
  final VoidCallback onTap;

  const _MentorshipPlanTile({required this.title, required this.subtitle, required this.iconColor, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Icon(Icons.school_rounded, color: iconColor, size: 30),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(subtitle, style: TextStyle(color: AppTheme.textSoft, fontSize: 11)),
              ])),
              Icon(Icons.chevron_right_rounded, color: AppTheme.textSecondary),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// PERSONAL
// ============================================================

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String _displayName = '';
  Uint8List? _appAvatarBytes;
  bool _loading = true;
  bool _isPremium = false;
  bool _hasMentorship = false;
  String _premiumBadgeType = '';
  String _mentorshipBadgeType = '';
  bool _graduated = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final user = AuthService.currentUser;
    if (user == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      final data = await ProfileService.loadUserProfile(user.uid);
      _displayName = (data?['displayName'] ?? '').toString().trim();
      _isPremium = data?['isPremium'] == true;
      _hasMentorship = data?['mentorshipApproved'] == true || data?['isMentorship'] == true || data?['mentorship'] == true || data?['studentApproved'] == true || data?['isStudent'] == true;
      _premiumBadgeType = (data?['confirmedPremiumBadgeType'] ?? '').toString();
      _mentorshipBadgeType = (data?['confirmedMentorshipBadgeType'] ?? '').toString();
      _graduated = data?['graduated'] == true;
      final appAvatar = ((data?['appAvatarBase64'] ?? '').toString().isNotEmpty)
          ? (data?['appAvatarBase64'] ?? '').toString()
          : await ProfileService.loadAppAvatar(uid: user.uid);
      if (appAvatar.isNotEmpty) {
        try { _appAvatarBytes = base64Decode(appAvatar); } catch (_) {}
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _openEditProfile() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _EditProfilePage()));
    if (mounted) await _load();
  }

  Future<void> _openReferral() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _ReferralCenterPage()));
  }

  Future<void> _openPaymentDetails() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _UserPayoutPaymentDetailsPage()));
  }

  Future<void> _logoutProfile() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        title: const Text('LOG OUT'),
        content: const Text('Are you sure you want to log out of CRYPTO-DOCTORS-HUB?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFB83A3A), foregroundColor: AppTheme.textPrimary, minimumSize: const Size(110, 44)),
            child: const Text('LOG OUT'),
          ),
        ],
      ),
    );
    if (shouldLogout != true) return;
    try {
      await AuthService.signOut();
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('We could not log you out right now. Please try again.')));
      return;
    }
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (route) => false);
  }

  Widget _option({required IconData icon, required String title, required String subtitle, required VoidCallback onTap}) {
    final isLight = Theme.of(context).brightness == Brightness.light;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isLight
              ? [
                  Theme.of(context).colorScheme.surface.withValues(alpha: .92),
                  Theme.of(context).colorScheme.surface.withValues(alpha: .78),
                ]
              : const [
                  Color(0xCC4A4F55),
                  Color(0xAA30343A),
                  Color(0xB52A2E33),
                ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.adaptiveWhite(alpha: isLight ? .14 : .13)),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: isLight ? .10 : .20), blurRadius: 18, offset: const Offset(0, 6)),
          BoxShadow(color: AppTheme.adaptiveWhite(alpha: isLight ? .05 : .025), blurRadius: 8, offset: const Offset(0, -1)),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        leading: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: .72),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: AppTheme.adaptiveWhite(alpha: .18)),
          ),
          child: Icon(icon, color: AppTheme.textPrimary, size: 21),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(subtitle, style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .55), fontSize: 10)),
        trailing: Icon(Icons.chevron_right_rounded, color: AppTheme.textPrimary),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final onSurface = Theme.of(context).colorScheme.onSurface;
    return Scaffold(
      appBar: AppBar(
        title: const Text('PROFILE'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xCC4A4F55),
                        Color(0xAA30343A),
                        Color(0xB52A2E33),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppTheme.adaptiveWhite(alpha: .13)),
                    boxShadow: [
                      BoxShadow(color: Colors.black.withValues(alpha: .20), blurRadius: 18, offset: const Offset(0, 6)),
                      BoxShadow(color: AppTheme.adaptiveWhite(alpha: .025), blurRadius: 8, offset: const Offset(0, -1)),
                    ],
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF16231A)),
                        backgroundImage: _appAvatarBytes == null ? null : MemoryImage(_appAvatarBytes!),
                        child: _appAvatarBytes == null ? Icon(Icons.person_rounded, color: AppTheme.textPrimary, size: 30) : null,
                      ),
                      const SizedBox(width: 13),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(_displayName.isEmpty ? 'My Profile' : _displayName, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 3),
                          Text('Account settings & creator profile', style: TextStyle(color: onSurface.withValues(alpha: .58), fontSize: 10)),
                          if (_isPremium || _hasMentorship) ...[
                            const SizedBox(height: 7),
                            _ProfileEntitlementBadges(isPremium: _isPremium, hasMentorship: _hasMentorship, premiumBadgeType: _premiumBadgeType, mentorshipBadgeType: _mentorshipBadgeType, graduated: _graduated),
                          ],
                        ]),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                _option(icon: Icons.edit_rounded, title: 'Edit Profile', subtitle: 'Name, nickname, avatar and profile picture', onTap: _openEditProfile),
                const SizedBox(height: 10),
                _option(icon: Icons.card_giftcard_rounded, title: 'Referral', subtitle: 'Referral code, crowns, rewards and referral details', onTap: _openReferral),
                const SizedBox(height: 10),
                _option(icon: Icons.palette_outlined, title: 'Theme', subtitle: 'Light • Dark • Current', onTap: () => _openThemePage(context)),
                const SizedBox(height: 10),
                _option(icon: Icons.account_balance_wallet_outlined, title: 'Payment Details', subtitle: 'Current payment methods and account details', onTap: _openPaymentDetails),
                const SizedBox(height: 10),
                _option(icon: Icons.subscriptions_outlined, title: 'Subscriptions', subtitle: 'Mentorship • Premium Access • Verified Blue Tick', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _SubscriptionsPage()))),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xCC4A4F55),
                        Color(0xAA30343A),
                        Color(0xB52A2E33),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppTheme.adaptiveWhite(alpha: .13)),
                    boxShadow: [
                      BoxShadow(color: Colors.black.withValues(alpha: .20), blurRadius: 18, offset: const Offset(0, 6)),
                      BoxShadow(color: AppTheme.adaptiveWhite(alpha: .025), blurRadius: 8, offset: const Offset(0, -1)),
                    ],
                  ),
                  child: ListTile(
                    onTap: _logoutProfile,
                    leading: Icon(Icons.logout_rounded, color: AppTheme.textPrimary),
                    title: const Text('Log Out', style: TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('Sign out of this account', style: TextStyle(color: onSurface.withValues(alpha: .55))),
                    trailing: Icon(Icons.chevron_right, color: AppTheme.textPrimary),
                  ),
                ),
              ],
            ),
    );
  }
}

Future<void> _openThemePage(BuildContext context) async {
  await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _ThemePage()));
}

class _EditProfilePage extends StatefulWidget {
  const _EditProfilePage();
  @override
  State<_EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<_EditProfilePage> {
  final _nameController = TextEditingController();
  final _nicknameController = TextEditingController();
  Uint8List? _appAvatarBytes;
  Uint8List? _profileImageBytes;
  DateTime? _nicknameChangedAt;
  DateTime? _profilePicChangedAt;
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _nicknameController.dispose();
    super.dispose();
  }

  DateTime? _timestamp(dynamic value) => value is Timestamp ? value.toDate() : null;

  Future<void> _load() async {
    final user = AuthService.currentUser;
    if (user == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      final data = await ProfileService.loadUserProfile(user.uid);
      final alpha = data?['alphaDenProfile'];
      final profile = alpha is Map ? Map<String, dynamic>.from(alpha) : <String, dynamic>{};
      _nameController.text = (data?['displayName'] ?? profile['name'] ?? '').toString();
      _nicknameController.text = (profile['nickname'] ?? profile['handle'] ?? '').toString().replaceFirst(RegExp(r'^@'), '');
      _nicknameChangedAt = _timestamp(profile['nicknameChangedAt']);
      _profilePicChangedAt = _timestamp(profile['profilePicChangedAt']);
      final avatar = ((data?['appAvatarBase64'] ?? '').toString().isNotEmpty)
          ? (data?['appAvatarBase64'] ?? '').toString()
          : await ProfileService.loadAppAvatar(uid: user.uid);
      final pic = (data?['profilePicBase64'] ?? profile['profilePicBase64'] ?? '').toString();
      if (avatar.isNotEmpty) { try { _appAvatarBytes = base64Decode(avatar); } catch (_) {} }
      if (pic.isNotEmpty) { try { _profileImageBytes = base64Decode(pic); } catch (_) {} }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  bool _locked(DateTime? changedAt) => changedAt != null && DateTime.now().difference(changedAt).inHours < 24 * 7;

  String _lockMessage(String label, DateTime changedAt) {
    final remaining = const Duration(days: 7) - DateTime.now().difference(changedAt);
    final days = remaining.inHours <= 0 ? 0 : (remaining.inHours / 24).ceil();
    return '$label can be changed again in about $days day${days == 1 ? '' : 's'}.';
  }

  Future<void> _pickAppAvatar() async {
    try {
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 68, maxWidth: 768, maxHeight: 768);
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length > 600000) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please choose a smaller avatar (under 600 KB).')));
        return;
      }
      final user = AuthService.currentUser;
      if (user == null) return;
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'appAvatarBase64': base64Encode(bytes),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (mounted) setState(() => _appAvatarBytes = bytes);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save the avatar. Please try again.')));
    }
  }

  Future<void> _pickProfilePicture() async {
    final changedAt = _profilePicChangedAt;
    if (changedAt != null && _locked(changedAt)) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_lockMessage('Profile picture', changedAt))));
      return;
    }
    try {
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 68, maxWidth: 1280, maxHeight: 1280);
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length > 700000) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please choose a smaller profile image (under 700 KB).')));
        return;
      }
      final user = AuthService.currentUser;
      if (user == null) return;
      final now = DateTime.now();
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'profilePicBase64': base64Encode(bytes),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'alphaDenProfile': {
          'profilePicBase64': base64Encode(bytes),
          'profilePicChangedAt': Timestamp.fromDate(now),
        },
      }, SetOptions(merge: true));
      _profilePicChangedAt = now;
      if (mounted) setState(() => _profileImageBytes = bytes);
      final data = await ProfileService.loadUserProfile(user.uid);
      final alpha = data?['alphaDenProfile'];
      if (alpha is Map) {
        await AlphaDenService.syncPublicProfileToPosts(
          uid: user.uid,
          username: (alpha['username'] ?? _nicknameController.text.trim()).toString(),
          profilePicUrl: (alpha['profilePicUrl'] ?? '').toString(),
          profilePicBase64: base64Encode(bytes),
          referrals: (alpha['referrals'] as num?)?.toInt() ?? 0,
          winTrades: (alpha['winTrades'] as num?)?.toInt() ?? 0,
          verified: alpha['verifiedCreatorApproved'] == true,
        );
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save the profile picture. Please try again.')));
    }
  }

  Future<void> _save() async {
    final user = AuthService.currentUser;
    if (user == null || _saving) return;
    final name = _nameController.text.trim();
    var nickname = _nicknameController.text.trim();
    if (name.length > 40) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Name must be 40 characters or less.')));
      return;
    }
    if (nickname.isNotEmpty && nickname.length > 30) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nickname must be 30 characters or less.')));
      return;
    }
    final oldNickname = _nicknameController.text.trim();
    if (nickname != oldNickname && _nicknameChangedAt != null && _locked(_nicknameChangedAt)) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_lockMessage('Nickname', _nicknameChangedAt!))));
      return;
    }
    setState(() => _saving = true);
    try {
      final existing = await ProfileService.loadUserProfile(user.uid) ?? <String, dynamic>{};
      final rawAlpha = existing['alphaDenProfile'];
      final alpha = rawAlpha is Map ? Map<String, dynamic>.from(rawAlpha) : <String, dynamic>{};
      final now = DateTime.now();
      alpha['uid'] = user.uid;
      alpha['name'] = name;
      final existingUsername = (alpha['username'] ?? 'userxxxx').toString().trim();
      alpha['username'] = existingUsername.startsWith('@') ? existingUsername : '@$existingUsername';
      alpha['usernameNormalized'] = alpha['username'].toString().replaceFirst(RegExp(r'^@'), '').toLowerCase();
      alpha['nickname'] = nickname;
      alpha['handle'] = nickname;
      alpha['updatedAt'] = FieldValue.serverTimestamp();
      if (nickname != oldNickname) alpha['nicknameChangedAt'] = Timestamp.fromDate(now);
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'uid': user.uid,
        'displayName': name,
        'alphaDenProfile': alpha,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      final finalData = await ProfileService.loadUserProfile(user.uid);
      final finalAlphaRaw = finalData?['alphaDenProfile'];
      final finalAlpha = finalAlphaRaw is Map ? Map<String, dynamic>.from(finalAlphaRaw) : alpha;
      await AlphaDenService.syncPublicProfileToPosts(
        uid: user.uid,
        username: (finalAlpha['username'] ?? 'userxxxx').toString(),
        profilePicUrl: (finalAlpha['profilePicUrl'] ?? '').toString(),
        profilePicBase64: (finalData?['profilePicBase64'] ?? finalAlpha['profilePicBase64'] ?? '').toString(),
        referrals: (finalAlpha['referrals'] as num?)?.toInt() ?? 0,
        winTrades: (finalAlpha['winTrades'] as num?)?.toInt() ?? 0,
        verified: finalAlpha['verifiedCreatorApproved'] == true,
      );
      if (mounted) {
        _nicknameChangedAt = nickname != oldNickname ? now : _nicknameChangedAt;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile saved successfully.')));
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('We could not save your profile right now. Please try again.')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _photoCard({required String title, required String subtitle, required Uint8List? bytes, required VoidCallback onTap, required IconData fallback}) {
    return GlassCard(
      child: Row(children: [
        CircleAvatar(radius: 31, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF16231A)), backgroundImage: bytes == null ? null : MemoryImage(bytes), child: bytes == null ? Icon(fallback, color: AppTheme.neonGreen, size: 28) : null),
        const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(subtitle, style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .55), fontSize: 10))])),
        IconButton(onPressed: onTap, icon: Icon(Icons.photo_library_outlined, color: AppTheme.luxuryGold)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('EDIT PROFILE')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
              children: [
                _photoCard(title: 'APP AVATAR', subtitle: 'Your separate in-app avatar', bytes: _appAvatarBytes, onTap: _pickAppAvatar, fallback: Icons.person_rounded),
                const SizedBox(height: 10),
                _photoCard(title: 'PROFILE PICTURE', subtitle: 'Shown on your Alpha Den profile and posts', bytes: _profileImageBytes, onTap: _pickProfilePicture, fallback: Icons.account_circle_rounded),
                const SizedBox(height: 12),
                GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('NAME', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.0)),
                  const SizedBox(height: 7),
                  TextField(controller: _nameController, maxLength: 40, decoration: const InputDecoration(hintText: 'Your name / display name', counterText: '')),
                  const SizedBox(height: 12),
                  const Text('ALPHA DEN NICKNAME', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.0)),
                  const SizedBox(height: 7),
                  TextField(controller: _nicknameController, maxLength: 30, decoration: const InputDecoration(hintText: 'Your nickname', counterText: '')),
                  const SizedBox(height: 6),
                  Text('Nickname changes remain subject to the existing 7-day profile rule.', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .50), fontSize: 9.5)),
                  const SizedBox(height: 14),
                  SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.save_outlined), label: Text(_saving ? 'SAVING...' : 'SAVE PROFILE'))),
                ])),
              ],
            ),
    );
  }
}

class _ReferralCenterPage extends StatelessWidget {
  const _ReferralCenterPage();

  Future<void> _copyLink(BuildContext context, String link) async {
    await Clipboard.setData(ClipboardData(text: link));
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Personal referral link copied.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = AuthService.currentUser?.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('REFERRAL')),
      body: uid == null
          ? const Center(child: Text('Please sign in again.'))
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
              children: [
                FutureBuilder<Map<String, dynamic>?>(
                  future: ProfileService.loadUserProfile(uid),
                  builder: (context, snapshot) {
                    final data = snapshot.data ?? <String, dynamic>{};
                    final alphaRaw = data['alphaDenProfile'];
                    final alpha = alphaRaw is Map ? Map<String, dynamic>.from(alphaRaw) : <String, dynamic>{};
                    final name = (data['displayName'] ?? alpha['name'] ?? 'My Profile').toString();
                    final nickname = (alpha['username'] ?? '').toString();
                    final referrals = (alpha['referrals'] as num?)?.toInt() ?? 0;
                    Uint8List? pic;
                    final raw = (data['profilePicBase64'] ?? alpha['profilePicBase64'] ?? '').toString();
                    if (raw.isNotEmpty) { try { pic = base64Decode(raw); } catch (_) {} }
                    return GlassCard(child: Column(children: [
                      CircleAvatar(radius: 39, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF16231A)), backgroundImage: pic == null ? null : MemoryImage(pic), child: pic == null ? Icon(Icons.person_rounded, color: AppTheme.neonGreen, size: 36) : null),
                      const SizedBox(height: 9),
                      Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                      if (nickname.isNotEmpty) ...[const SizedBox(height: 2), Text('@$nickname', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .58), fontSize: 10))],
                      const SizedBox(height: 12),
                      FutureBuilder<String>(
                        future: ProfileService.ensureReferralCode(uid),
                        builder: (context, codeSnapshot) {
                          final code = codeSnapshot.data ?? 'Generating…';
                          return Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), decoration: BoxDecoration(color: AppTheme.luxuryGold.withValues(alpha: .08), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: .28))), child: Row(children: [Icon(Icons.link_rounded, color: AppTheme.luxuryGold, size: 19), const SizedBox(width: 8), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('YOUR PERSONAL REFERRAL CODE', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1.0)), const SizedBox(height: 2), Text(code, style: TextStyle(color: AppTheme.luxuryGold, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.1))])), IconButton(onPressed: codeSnapshot.hasData ? () async { await Clipboard.setData(ClipboardData(text: code)); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Referral code copied.'))); } : null, icon: const Icon(Icons.copy_rounded))]));
                        },
                      ),
                      const SizedBox(height: 9),
                      Text('$referrals qualified referrals', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .55), fontSize: 9.5)),
                    ]));
                  },
                ),
                const SizedBox(height: 12),
                FutureBuilder<String>(
                  future: ProfileService.ensureReferralCode(uid).then(ReferralService.buildReferralLink),
                  builder: (context, snapshot) {
                    final link = snapshot.data ?? '';
                    return GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('PERSONAL REFERRAL LINK', style: TextStyle(color: AppTheme.luxuryGold, fontWeight: FontWeight.w900, letterSpacing: .8)),
                      const SizedBox(height: 5),
                      Text('This is your personal referral link. Send this link to the person BEFORE they create their CDH account. The link carries your referral code automatically. You do not need to create a new code each time.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.4)),
                      const SizedBox(height: 10),
                      Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: .025), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.fillFaint)), child: SelectableText(link.isEmpty ? 'Preparing your personal link…' : link, style: TextStyle(color: AppTheme.textPrimary, fontSize: 10, height: 1.35))),
                      const SizedBox(height: 9),
                      SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: link.isEmpty ? null : () => _copyLink(context, link), icon: const Icon(Icons.copy_rounded, size: 17), label: const Text('COPY LINK'))),
                      const SizedBox(height: 6),
                      Text('Production note: the public referral URL must be connected to the published Android App Link / iOS Universal Link and store fallback before release.', style: TextStyle(color: AppTheme.textVeryFaint, fontSize: 8.5, height: 1.35)),
                    ]));
                  },
                ),
                const SizedBox(height: 12),
                const ReferralCard(),
                const SizedBox(height: 12),
                const _ReferralRulesCard(),
              ],
            ),
    );
  }
}

class _ReferralRulesCard extends StatelessWidget {
  const _ReferralRulesCard();

  @override
  Widget build(BuildContext context) {
    const rules = [
      ('WHAT IS A REFERRAL?', 'A referral is a user who joins Crypto Doctors Hub through another user’s personal referral link and is securely associated with that referrer.'),
      ('QUALIFIED REFERRAL', 'A referral becomes qualified only after the referred user successfully creates an account and a Premium purchase is genuinely confirmed by the secure payment backend. Sign-up alone does not qualify.'),
      ('PREMIUM MONTHLY — \$15', 'A qualified monthly Premium purchase releases the \$4 instant qualified-referral reward. The applicable recurring monthly incentive continues only while the referred user remains in the referral group.'),
      ('PREMIUM LIFETIME — \$50', 'A confirmed one-time Lifetime Premium purchase releases a \$12 referral reward once. There is no recurring monthly Premium incentive from the Lifetime plan.'),
      ('MENTORSHIP ONE-TIME — \$80', 'A confirmed one-time Mentorship purchase releases a \$20 referral reward once. No recurring incentive is generated from the one-time Mentorship plan.'),
      ('MENTORSHIP INSTALLMENT — \$20 × 4', 'The total referral incentive is \$20. A \$5 reward is released only after each corresponding installment is genuinely confirmed: \$5 + \$5 + \$5 + \$5.'),
      ('MONTHLY REFERRAL INCENTIVE', 'For eligible recurring Premium referrals, the monthly incentive has no fixed number of months. It continues while the referred user remains part of the referrer’s referral group.'),
      ('LEAVING THE REFERRAL GROUP', 'If the referred user leaves the referral group, future recurring incentives stop. Legitimately earned rewards from before leaving remain recorded.'),
      ('CROWN / USDT REWARDS', 'The existing Crown referral rewards remain: 1 qualified referral = \$4, 2 = \$8, 3 = \$9, 4 = \$12, 5 = \$15, 6 = \$18 and 7 = \$21. These existing Crown/USDT rules are separate from the product-specific rewards above.'),
      ('SECURE PAYMENT RULE', 'Referral rewards are not granted because a user merely opens a payment page or says they paid. The secure payment backend must genuinely confirm the applicable payment before the reward is released.'),
      ('ANTI-FRAUD', 'Self-referrals, duplicate rewards, manipulated relationships and rewards without confirmed payment are not eligible. Referral transactions are intended to remain permanently recorded with the relevant users, product, plan, payment reference, amount, status and timestamp.'),
    ];
    return GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('REFERRAL RULES', style: TextStyle(color: AppTheme.luxuryGold, fontWeight: FontWeight.w900, letterSpacing: .8)),
      const SizedBox(height: 9),
      for (final rule in rules) ...[
        Text(rule.$1, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w900)),
        const SizedBox(height: 3),
        Text(rule.$2, style: TextStyle(color: AppTheme.textMuted, fontSize: 9.5, height: 1.4)),
        const SizedBox(height: 10),
      ],
      Text('REWARD SUMMARY', style: TextStyle(color: AppTheme.textPrimary, fontSize: 12, fontWeight: FontWeight.w900)),
      const SizedBox(height: 7),
      Text('Premium Monthly — \$4 instantly when qualified + applicable recurring incentive\nPremium Lifetime — \$12 one-time\nMentorship One-Time — \$20 one-time\nMentorship Installment — \$5 per confirmed installment, \$20 total\nExisting Crown/USDT — configured Crown amounts and rules remain unchanged.', style: TextStyle(color: AppTheme.textSecondary, fontSize: 9.5, height: 1.5)),
    ]));
  }
}

class _ThemePage extends StatelessWidget {
  const _ThemePage();

  Future<void> _select(BuildContext context, String value) async {
    appThemePreference.value = value;
    final user = AuthService.currentUser;
    if (user != null) await ProfileService.saveThemePreference(uid: user.uid, preference: value);
  }

  Widget _choice(BuildContext context, String value, String title, String subtitle, IconData icon) {
    return ValueListenableBuilder<String>(
      valueListenable: appThemePreference,
      builder: (context, current, _) {
        final active = current == value;
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: GlassCard(child: ListTile(
            leading: Icon(icon, color: active ? AppTheme.luxuryGold : null),
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            subtitle: Text(subtitle, style: TextStyle(fontSize: 10, color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .55))),
            trailing: active ? Icon(Icons.check_circle_rounded, color: AppTheme.luxuryGold) : const Icon(Icons.radio_button_unchecked_rounded),
            onTap: () => _select(context, value),
          )),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('THEME')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
        children: [
          Text('CHOOSE INTERFACE', style: TextStyle(color: AppTheme.luxuryGold, fontWeight: FontWeight.w900, letterSpacing: 1.0)),
          const SizedBox(height: 5),
          Text('The selected theme is saved to your account and restored on the next login.', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .55), fontSize: 10)),
          const SizedBox(height: 12),
          _choice(context, 'light', 'LIGHT', 'Creamy white interface with matching light surfaces and controls', Icons.light_mode_rounded),
          _choice(context, 'dark', 'DARK', 'Matte black interface', Icons.dark_mode_rounded),
          _choice(context, 'current', 'CURRENT', 'Keep the original CRYPTO-DOCTORS-HUB interface', Icons.auto_awesome_rounded),
        ],
      ),
    );
  }
}


class _AdminReferralSettingsPage extends StatefulWidget {
  const _AdminReferralSettingsPage();
  @override State<_AdminReferralSettingsPage> createState() => _AdminReferralSettingsPageState();
}

class _AdminReferralSettingsPageState extends State<_AdminReferralSettingsPage> {
  final _url = TextEditingController();
  final _monthly = TextEditingController();
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { _url.dispose(); _monthly.dispose(); super.dispose(); }

  Future<void> _load() async {
    try {
      final data = await ReferralService.loadSettings();
      _url.text = (data['publicReferralUrl'] ?? '').toString();
      _monthly.text = (data['monthlyRecurringRewardUsd'] ?? '').toString();
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    if (_saving) return;
    final base = _url.text.trim();
    final monthly = double.tryParse(_monthly.text.trim()) ?? 0;
    final uri = Uri.tryParse(base);
    if (base.isNotEmpty && (uri == null || !uri.hasScheme || uri.host.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid HTTPS referral URL.')));
      return;
    }
    if (monthly < 0) return;
    setState(() => _saving = true);
    try {
      await FirebaseFirestore.instance.collection('referralSettings').doc('config').set({
        'publicReferralUrl': base,
        'monthlyRecurringRewardUsd': monthly,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Referral settings saved and synced.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not save referral settings: $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('REFERRAL SETTINGS')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('PERSONAL REFERRAL LINK', style: TextStyle(color: AppTheme.luxuryGold, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('Set the production HTTPS URL that carries ?ref=USERCODE. This URL must be configured as the Android App Link / iOS Universal Link and store fallback before publishing.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.4)),
                const SizedBox(height: 10),
                TextField(controller: _url, decoration: const InputDecoration(labelText: 'Production referral URL', hintText: 'https://your-official-domain.example/')), 
                const SizedBox(height: 16),
                Text('MONTHLY RECURRING REFERRAL INCENTIVE', style: TextStyle(color: AppTheme.luxuryGold, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('This amount is intentionally configurable because the requirements specify an applicable monthly incentive but do not specify its dollar amount. The secure backend reads this value when issuing each monthly cycle.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, height: 1.4)),
                const SizedBox(height: 10),
                TextField(controller: _monthly, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Monthly reward (USD)', hintText: '0.00')), 
                const SizedBox(height: 14),
                SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.save_outlined), label: Text(_saving ? 'SAVING...' : 'SAVE REFERRAL SETTINGS'))),
              ])),
            ]),
    );
  }
}

class _AdminPaymentSettingsPage extends StatefulWidget {
  const _AdminPaymentSettingsPage();
  @override State<_AdminPaymentSettingsPage> createState() => _AdminPaymentSettingsPageState();
}

class _AdminPaymentSettingsPageState extends State<_AdminPaymentSettingsPage> {
  final List<Map<String, dynamic>> _methods = [];
  final Map<String, Map<String, dynamic>> _plans = {};
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      await PaymentService.ensureDefaultPaymentMethods();
      final data = await PaymentService.loadConfig();
      final methods = ((data['paymentMethods'] as List?) ?? const []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      if (methods.isEmpty) {
        methods.addAll(PaymentService.defaultPaymentMethods());
      } else {
        final existingIds = methods.map((m) => (m['id'] ?? '').toString()).toSet();
        for (final fallback in PaymentService.defaultPaymentMethods()) {
          if (!existingIds.contains((fallback['id'] ?? '').toString())) methods.add(Map<String, dynamic>.from(fallback));
        }
      }
      final plans = Map<String, dynamic>.from((data['plans'] as Map?) ?? {});
      if (plans.isEmpty) {
        plans.addAll({
          'premium_monthly': {'name': 'Premium Monthly', 'amount': 15, 'currency': 'USD', 'description': 'Premium access for one month.', 'enabled': true},
          'premium_one_time': {'name': 'Premium Lifetime', 'amount': 50, 'currency': 'USD', 'description': 'One-time lifetime Premium access.', 'enabled': true},
          'mentorship_one_time': {'name': 'Mentorship One-Time', 'amount': 80, 'currency': 'USD', 'description': 'One-time Mentorship payment.', 'enabled': true},
          'mentorship_installment': {'name': 'Mentorship Installment', 'amount': 100, 'currency': 'USD', 'description': '4 weekly payments of \$20.', 'enabled': true},
          'verified_creator_monthly': {'name': 'Verified Creator', 'amount': 5, 'currency': 'USD', 'description': 'Verified Creator application payment • monthly.', 'enabled': true},
        });
      }
      if (!mounted) return;
      setState(() {
        _methods..clear()..addAll(methods);
        _plans..clear()..addAll(plans.map((k,v) => MapEntry(k, Map<String,dynamic>.from((v as Map?) ?? {}))));
        _loading = false;
      });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _editMethod([Map<String, dynamic>? existing]) async {
    final id = TextEditingController(text: (existing?['id'] ?? 'method_${DateTime.now().millisecondsSinceEpoch}').toString());
    final name = TextEditingController(text: (existing?['name'] ?? '').toString());
    final type = TextEditingController(text: (existing?['type'] ?? 'wallet').toString());
    final details = TextEditingController(text: (existing?['details'] ?? '').toString());
    bool enabled = existing?['enabled'] != false;
    final result = await showDialog<bool>(context: context, builder: (dc) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)),
      title: Text(existing == null ? 'ADD PAYMENT METHOD' : 'EDIT PAYMENT METHOD'),
      content: SingleChildScrollView(child: Column(children: [
        TextField(controller: id, decoration: const InputDecoration(labelText: 'Internal ID')),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Display name')),
        TextField(controller: type, decoration: const InputDecoration(labelText: 'Type / network')),
        TextField(controller: details, maxLines: 3, decoration: const InputDecoration(labelText: 'Account number / wallet / payment details')),
        SwitchListTile(value: enabled, onChanged: (v) => setDialogState(() => enabled = v), title: const Text('Enabled')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(dc, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(dc, true), child: const Text('SAVE'))],
    )));
    if (result != true) return;
    final value = {'id': id.text.trim(), 'name': name.text.trim(), 'type': type.text.trim(), 'details': details.text.trim(), 'enabled': enabled};
    if (value['id'].toString().isEmpty || value['name'].toString().isEmpty || value['details'].toString().isEmpty) return;
    await PaymentService.saveMethod(id: value['id'] as String, name: value['name'] as String, type: value['type'] as String, details: value['details'] as String, enabled: enabled);
    await _load();
  }

  Future<void> _editPlan(String id) async {
    final old = _plans[id] ?? <String,dynamic>{};
    final name = TextEditingController(text: (old['name'] ?? id).toString());
    final amount = TextEditingController(text: (old['amount'] ?? (id == 'premium_monthly' ? 15 : id == 'mentorship_one_time' ? 80 : id == 'mentorship_installment' ? 100 : id == 'verified_creator_monthly' ? 5 : '')).toString());
    final currency = TextEditingController(text: (old['currency'] ?? 'USD').toString());
    final description = TextEditingController(text: (old['description'] ?? '').toString());
    bool enabled = old['enabled'] != false;
    final result = await showDialog<bool>(context: context, builder: (dc) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF101419)), title: Text('EDIT $id'),
      content: SingleChildScrollView(child: Column(children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Plan name')), TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Amount')), TextField(controller: currency, decoration: const InputDecoration(labelText: 'Currency')), TextField(controller: description, maxLines: 2, decoration: const InputDecoration(labelText: 'Description')), SwitchListTile(value: enabled, onChanged: (v) => setDialogState(() => enabled = v), title: const Text('Enabled'))])),
      actions: [TextButton(onPressed: () => Navigator.pop(dc, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(dc, true), child: const Text('SAVE'))],
    )));
    if (result != true) return;
    final parsed = double.tryParse(amount.text.trim());
    if (parsed == null) return;
    await PaymentService.savePlan(id: id, name: name.text, amount: parsed, currency: currency.text, description: description.text, enabled: enabled);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final planIds = ['premium_monthly','premium_one_time','mentorship_one_time','mentorship_installment','verified_creator_monthly'];
    return Scaffold(appBar: AppBar(title: const Text('PAYMENT SETTINGS')), body: _loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(16), children: [
      const Text('PAYMENT METHODS', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      Text('These values are stored in Firebase. Enabled users see the current values immediately; changing them later updates the same central payment page for everyone.', style: TextStyle(color: AppTheme.textMuted, fontSize: 11, height: 1.4)),
      const SizedBox(height: 12),
      for (final m in _methods) Card(color: AppTheme.adaptiveSurface(Color(0xFF11171B)), child: ListTile(leading: Icon(Icons.account_balance_wallet_outlined, color: AppTheme.luxuryGold), title: Text((m['name'] ?? 'Payment method').toString()), subtitle: Text('${m['type'] ?? ''}\n${m['details'] ?? ''}', style: TextStyle(color: AppTheme.textMuted)), isThreeLine: true, trailing: IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => _editMethod(m)))),
      OutlinedButton.icon(onPressed: () => _editMethod(), icon: const Icon(Icons.add), label: const Text('ADD PAYMENT METHOD')),
      const SizedBox(height: 24),
      const Text('PAYMENT PLANS', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      for (final id in planIds) Card(color: AppTheme.adaptiveSurface(Color(0xFF11171B)), child: ListTile(title: Text((_plans[id]?['name'] ?? id).toString()), subtitle: Text('${_plans[id]?['amount'] ?? 'Not configured'} ${_plans[id]?['currency'] ?? 'USD'} • ${_plans[id]?['description'] ?? ''}', style: TextStyle(color: AppTheme.textMuted)), trailing: IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => _editPlan(id)))),
    ]));
  }
}

class CentralPaymentPage extends StatefulWidget {
  final String product;
  final String? planId;
  const CentralPaymentPage({super.key, required this.product, this.planId});

  @override
  State<CentralPaymentPage> createState() => _CentralPaymentPageState();
}

class _CentralPaymentPageState extends State<CentralPaymentPage> {
  final ImagePicker _imagePicker = ImagePicker();
  final TextEditingController _referenceController = TextEditingController();
  Map<String, dynamic>? _selectedMethod;
  XFile? _proofFile;
  Uint8List? _proofBytes;
  bool _submitting = false;
  bool _notifyingAdmin = false;
  String? _statusMessage;
  String? _requestId;

  @override
  void dispose() {
    _referenceController.dispose();
    super.dispose();
  }

  Future<void> _pickProofFromGallery() async {
    try {
      final file = await _imagePicker.pickImage(source: ImageSource.gallery, imageQuality: 88, maxWidth: 2200, maxHeight: 2200);
      if (file == null) return;
      final bytes = await file.readAsBytes();
      if (bytes.length > 5 * 1024 * 1024) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Screenshot is too large. Please choose an image under 5 MB.')));
        return;
      }
      setState(() {
        _proofFile = file;
        _proofBytes = bytes;
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not import screenshot: $e')));
    }
  }

  Future<void> _notifyAdmin(Map<String, dynamic> plan) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please sign in first.')));
      return;
    }
    if (_selectedMethod == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select the payment method you plan to use.')));
      return;
    }
    setState(() { _notifyingAdmin = true; _statusMessage = null; });
    try {
      final userSnap = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final userData = userSnap.data() ?? <String, dynamic>{};
      final username = (userData['username'] ?? userData['alphaUsername'] ?? userData['nickname'] ?? userData['displayName'] ?? user.email?.split('@').first ?? 'User').toString();
      final planId = (widget.planId ?? '').trim();
      final requestId = await PaymentService.notifyAdminIntent(
        uid: user.uid, username: username, email: user.email ?? '', product: widget.product,
        planId: planId, planName: (plan['name'] ?? planId).toString(),
        amount: planId == 'mentorship_installment' ? 20 : ((plan['amount'] as num?)?.toDouble() ?? 0),
        currency: (plan['currency'] ?? 'USD').toString(),
        methodId: (_selectedMethod!['id'] ?? '').toString(),
        methodName: (_selectedMethod!['name'] ?? '').toString(),
        methodType: (_selectedMethod!['type'] ?? '').toString(),
      );
      if (mounted) setState(() {
        _requestId = requestId;
        _statusMessage = 'Admin has been notified. You can now make the payment and upload the screenshot below.';
      });
    } catch (e) {
      if (mounted) setState(() => _statusMessage = 'Could not notify Admin: $e');
    } finally {
      if (mounted) setState(() => _notifyingAdmin = false);
    }
  }

  Future<void> _submit(Map<String, dynamic> plan, List<Map<String, dynamic>> methods) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please sign in before submitting payment proof.')));
      return;
    }
    if (_selectedMethod == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select the payment method you used.')));
      return;
    }
    if (_proofBytes == null || _proofFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please import your payment screenshot from the gallery.')));
      return;
    }

    setState(() {
      _submitting = true;
      _statusMessage = null;
    });
    try {
      final userSnap = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final userData = userSnap.data() ?? <String, dynamic>{};
      final username = (userData['username'] ?? userData['alphaUsername'] ?? userData['nickname'] ?? userData['displayName'] ?? user.email?.split('@').first ?? 'User').toString();
      final planId = (widget.planId ?? '').trim();
      int installmentNumber = 0;
      if (widget.product == 'mentorship' && planId == 'mentorship_installment') {
        final paymentSnap = await FirebaseFirestore.instance.collection('mentorshipPayments').doc(user.uid).get();
        final paidWeeks = (paymentSnap.data()?['paidWeeks'] as num?)?.toInt() ?? 0;
        installmentNumber = paidWeeks + 1;
      }

      final ext = _proofFile!.name.contains('.') ? _proofFile!.name.split('.').last : 'jpg';
      final proofUrl = await PaymentService.uploadPaymentProof(uid: user.uid, bytes: _proofBytes!, extension: ext);
      final requestId = await PaymentService.submitPaymentProof(
        uid: user.uid,
        username: username,
        email: user.email ?? '',
        product: widget.product,
        planId: planId,
        planName: (plan['name'] ?? planId).toString(),
        amount: planId == 'mentorship_installment' ? 20 : ((plan['amount'] as num?)?.toDouble() ?? 0),
        currency: (plan['currency'] ?? 'USD').toString(),
        methodId: (_selectedMethod!['id'] ?? '').toString(),
        methodName: (_selectedMethod!['name'] ?? '').toString(),
        methodType: (_selectedMethod!['type'] ?? '').toString(),
        transactionReference: _referenceController.text,
        proofUrl: proofUrl,
        installmentNumber: installmentNumber,
        requestId: _requestId,
      );
      if (!mounted) return;
      setState(() {
        _statusMessage = 'Payment proof submitted successfully. Request ID: $requestId.\nStatus: PENDING ADMIN REVIEW.';
        _proofFile = null;
        _proofBytes = null;
        _referenceController.clear();
        _requestId = null;
      });
    } catch (e) {
      if (mounted) setState(() => _statusMessage = 'Payment submission failed: $e');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('PAYMENT')),
      body: StreamBuilder<Map<String, dynamic>>(
        stream: PaymentService.watchConfig(),
        builder: (context, snap) {
          final data = snap.data ?? const <String, dynamic>{};
          final methods = ((data['paymentMethods'] as List?) ?? const [])
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .where((m) => m['enabled'] != false)
              .toList();
          final plans = Map<String, dynamic>.from((data['plans'] as Map?) ?? {});
          final id = widget.planId ?? (widget.product == 'premium' ? 'premium_monthly' : widget.product == 'mentorship' ? 'mentorship_one_time' : widget.product == 'verified_creator' ? 'verified_creator_monthly' : null);
          final plan = id == null ? <String, dynamic>{} : Map<String, dynamic>.from((plans[id] as Map?) ?? {});
          final amount = id == 'mentorship_installment' ? 20 : ((plan['amount'] as num?)?.toDouble() ?? 0);
          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Icon(widget.product == 'mentorship' ? Icons.school_rounded : widget.product == 'verified_creator' ? Icons.verified_rounded : Icons.workspace_premium_rounded, color: id == 'premium_one_time' ? const Color(0xFFB56CFF) : id == 'mentorship_installment' ? AppTheme.textPrimary : id == 'mentorship_one_time' ? const Color(0xFF8DB0FF) : AppTheme.luxuryGold, size: 54),
              const SizedBox(height: 10),
              Text(widget.product == 'mentorship' ? 'MENTORSHIP PAYMENT' : widget.product == 'verified_creator' ? 'VERIFIED CREATOR PAYMENT' : 'PREMIUM PAYMENT', textAlign: TextAlign.center, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
              if (plan.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text('${plan['name'] ?? id} • $amount ${plan['currency'] ?? 'USD'}', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.luxuryGold, fontWeight: FontWeight.w900)),
                if ((plan['description'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(plan['description'].toString(), textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textMuted, fontSize: 11))),
              ],
              const SizedBox(height: 20),
              if (methods.isEmpty)
                GlassCard(child: Text('Payment methods have not been configured by Admin yet.', style: TextStyle(color: AppTheme.textSecondary, height: 1.4)))
              else ...[
                const Text('1. PAY USING ONE OF THE METHODS BELOW', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .4)),
                const SizedBox(height: 8),
                for (final method in methods)
                  Card(
                    color: AppTheme.adaptiveSurface(const Color(0xFF11171B)),
                    child: ListTile(
                      leading: Radio<Map<String, dynamic>>(value: method, groupValue: _selectedMethod, onChanged: (v) => setState(() => _selectedMethod = v)),
                      title: Text((method['name'] ?? 'Payment method').toString(), style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: SelectableText((method['details'] ?? '').toString(), style: TextStyle(color: AppTheme.textSecondary)),
                      trailing: Text((method['type'] ?? '').toString(), style: TextStyle(color: AppTheme.textFaint, fontSize: 9)),
                      onTap: () => setState(() => _selectedMethod = method),
                    ),
                  ),
                const SizedBox(height: 16),
                const Text('2. NOTIFY ADMIN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .4)),
                const SizedBox(height: 6),
                Text('Tell Admin which payment you are about to make. This creates a live payment alert in the Admin Dashboard.', style: TextStyle(color: AppTheme.textMuted, fontSize: 10.5, height: 1.35)),
                const SizedBox(height: 8),
                SizedBox(width: double.infinity, child: OutlinedButton.icon(
                  onPressed: _notifyingAdmin || _submitting || _requestId != null || user == null || plan.isEmpty ? null : () => _notifyAdmin(plan),
                  icon: _notifyingAdmin ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.notifications_active_outlined),
                  label: Text(_notifyingAdmin ? 'NOTIFYING ADMIN...' : _requestId != null ? 'ADMIN NOTIFIED' : 'NOTIFY ADMIN — I WANT TO PAY'),
                )),
                const SizedBox(height: 16),
                const Text('3. IMPORT PAYMENT SCREENSHOT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .4)),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: AppTheme.adaptiveSurface(const Color(0xFF10161A)), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.fillFaint)),
                  child: Column(children: [
                    if (_proofBytes != null) ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.memory(_proofBytes!, height: 190, width: double.infinity, fit: BoxFit.contain)),
                    if (_proofBytes != null) const SizedBox(height: 10),
                    OutlinedButton.icon(onPressed: _submitting ? null : _pickProofFromGallery, icon: const Icon(Icons.photo_library_outlined), label: Text(_proofBytes == null ? 'IMPORT FROM GALLERY' : 'CHANGE SCREENSHOT')),
                    const SizedBox(height: 5),
                    Text('JPG / PNG / WEBP • maximum 5 MB', style: TextStyle(color: AppTheme.textFaint, fontSize: 10)),
                  ]),
                ),
                const SizedBox(height: 16),
                const Text('4. TRANSACTION / PAYMENT REFERENCE (OPTIONAL)', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .4)),
                const SizedBox(height: 8),
                TextField(controller: _referenceController, maxLines: 2, decoration: const InputDecoration(hintText: 'Paste transaction hash, reference number, or payment ID')),
                const SizedBox(height: 18),
                SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _submitting || user == null || methods.isEmpty || plan.isEmpty ? null : () => _submit(plan, methods), icon: _submitting ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.send_rounded), label: Text(_submitting ? 'SUBMITTING...' : 'SEND PAYMENT PROOF FOR REVIEW'))),
                if (_statusMessage != null) ...[
                  const SizedBox(height: 12),
                  Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppTheme.adaptiveSurface(const Color(0xFF10161A)), borderRadius: BorderRadius.circular(12)), child: Text(_statusMessage!, style: TextStyle(color: _statusMessage!.contains('failed') ? Colors.redAccent : AppTheme.textSecondary, fontSize: 11, height: 1.4))),
                ],
                const SizedBox(height: 18),
                if (user != null)
                  StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                    stream: PaymentService.watchMyRequests(user.uid),
                    builder: (context, requestSnap) {
                      final requests = requestSnap.data?.docs ?? const <QueryDocumentSnapshot<Map<String, dynamic>>>[];
                      if (requests.isEmpty) return const SizedBox.shrink();
                      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('YOUR PAYMENT REQUESTS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .4)),
                        const SizedBox(height: 8),
                        for (final doc in requests) ...[
                          Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: AppTheme.adaptiveSurface(const Color(0xFF10161A)), borderRadius: BorderRadius.circular(12)), child: Text('${doc.data()['planName'] ?? doc.data()['planId']} • ${doc.data()['amount'] ?? ''} ${doc.data()['currency'] ?? ''}\nStatus: ${(doc.data()['status'] ?? 'pending').toString().toUpperCase()}', style: const TextStyle(fontSize: 11, height: 1.4))),
                        ],
                      ]);
                    },
                  ),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _SubscriptionsPage extends StatelessWidget {
  const _SubscriptionsPage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SUBSCRIPTIONS')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          GlassCard(
            child: ListTile(
              leading: Icon(Icons.workspace_premium_rounded, color: AppTheme.luxuryGold),
              title: const Text('Premium Access'),
              subtitle: Text('Choose your configured Premium plan.', style: TextStyle(color: AppTheme.textMuted)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CentralPaymentPage(product: 'premium', planId: 'premium_monthly'))),
            ),
          ),
          const SizedBox(height: 10),
          const SizedBox(height: 10),
          GlassCard(
            child: ListTile(
              leading: Icon(Icons.all_inclusive_rounded, color: AppTheme.luxuryGold),
              title: const Text('Premium Lifetime'),
              subtitle: Text('\$50 one-time • lifetime access.', style: TextStyle(color: AppTheme.textMuted)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CentralPaymentPage(product: 'premium', planId: 'premium_one_time'))),
            ),
          ),
          GlassCard(
            child: ListTile(
              leading: Icon(Icons.school_rounded, color: AppTheme.luxuryGold),
              title: const Text('Mentorship'),
              subtitle: Text('\$80 one-time or \$20 weekly installment plan.', style: TextStyle(color: AppTheme.textMuted)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _MentorshipPaymentPlansPage())),
            ),
          ),
          const SizedBox(height: 10),
          GlassCard(
            child: ListTile(
              leading: const Icon(Icons.verified_rounded, color: Color(0xFF4EA7FF)),
              title: const Text('Apply for Verified Blue Tick'),
              subtitle: Text('Open the existing Alpha Den verification flow.', style: TextStyle(color: AppTheme.textMuted)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _VerifiedCreatorPaymentPage(paymentSubmitted: false, onPaymentSubmitted: _noopPaymentCallback))),
            ),
          ),
        ],
      ),
    );
  }
}

void _noopPaymentCallback() {}

class PersonalPage extends StatefulWidget {
  const PersonalPage({super.key});

  @override
  State<PersonalPage> createState() => _PersonalPageState();
}

class _PersonalPageState extends State<PersonalPage> {
  String _displayName = '';
  Uint8List? _profileImageBytes;
  Uint8List? _appAvatarBytes;

  @override
  void initState() {
    super.initState();
    _loadDisplayName();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Refresh after returning to this page so the latest Firestore display
    // name is always reflected without changing the locked Personal UI.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _loadDisplayName();
    });
  }

  Future<void> _loadDisplayName() async {
    final user = AuthService.currentUser;
    if (user == null) return;

    try {
      final data = await ProfileService.loadUserProfile(user.uid);
      final displayName = (data?['displayName'] as String?)?.trim() ?? '';
      Uint8List? imageBytes;
      Uint8List? appAvatarBytes;
      final savedImage = (data?['profilePicBase64'] ?? '').toString();
      final savedAppAvatar = ((data?['appAvatarBase64'] ?? '').toString().isNotEmpty)
          ? (data?['appAvatarBase64'] ?? '').toString()
          : await ProfileService.loadAppAvatar(uid: user.uid);
      if (savedImage.isNotEmpty) { try { imageBytes = base64Decode(savedImage); } catch (_) {} }
      if (savedAppAvatar.isNotEmpty) { try { appAvatarBytes = base64Decode(savedAppAvatar); } catch (_) {} }
      if (!mounted) return;
      setState(() { _displayName = displayName; _profileImageBytes = imageBytes; _appAvatarBytes = appAvatarBytes; });
    } catch (_) {
      // Keep the Personal page usable if the profile read is temporarily unavailable.
    }
  }

  Future<void> _pickAppAvatar() async {
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 72,
        maxWidth: 1024,
        maxHeight: 1024,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length > 600000) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please choose a smaller avatar (under 600 KB).')));
        return;
      }
      final user = AuthService.currentUser;
      if (user == null) return;
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'appAvatarBase64': base64Encode(bytes),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (!mounted) return;
      setState(() => _appAvatarBytes = bytes);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('App avatar saved.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save the app avatar. Please try again.')));
    }
  }

  Future<void> _openProfile() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ProfilePage()),
    );
    if (mounted) {
      await _loadDisplayName();
    }
  }

  Future<void> _logout(BuildContext context) async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0B0F11)),
        title: const Text('LOG OUT'),
        content: const Text('Are you sure you want to log out of CRYPTO-DOCTORS-HUB?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFB83A3A), foregroundColor: AppTheme.textPrimary, minimumSize: const Size(110, 44)),
            child: const Text('LOG OUT'),
          ),
        ],
      ),
    );

    if (shouldLogout != true) return;

    try {
      await AuthService.signOut();
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('We could not log you out right now. Please try again.')),
      );
      return;
    }

    if (!context.mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async { await _loadDisplayName(); },
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        children: [
        GlassCard(
          child: ListTile(
            leading: GestureDetector(
              onTap: _pickAppAvatar,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: AppTheme.adaptiveSurface(Color(0xFF303238)),
                    backgroundImage: _appAvatarBytes != null
                        ? MemoryImage(_appAvatarBytes!)
                        : (_profileImageBytes != null ? MemoryImage(_profileImageBytes!) : null),
                    child: _appAvatarBytes == null && _profileImageBytes == null
                        ? Icon(Icons.person, color: AppTheme.textPrimary)
                        : null,
                  ),
                  Positioned(
                    right: -2, bottom: -2,
                    child: Container(
                      width: 17, height: 17,
                      decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF0B0F11)), shape: BoxShape.circle, border: Border.all(color: AppTheme.luxuryGold, width: .8)),
                      child: Icon(Icons.camera_alt_rounded, size: 9, color: AppTheme.luxuryGold),
                    ),
                  ),
                ],
              ),
            ),
            title: Text(
              _displayName.isEmpty ? 'My Profile' : _displayName,
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
            subtitle: Text(
              _displayName.isEmpty
                  ? 'Tap the avatar to set your in-app avatar'
                  : 'Tap the avatar to set your in-app avatar',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: _openProfile,
          ),
        ),

        SizedBox(height: 12),

        GlassCard(
          child: ListTile(
            leading: CircleAvatar(
              radius: 22,
              backgroundColor: AppTheme.adaptiveSurface(Color(0xFF303238)),
              backgroundImage: _appAvatarBytes != null ? MemoryImage(_appAvatarBytes!) : null,
              child: _appAvatarBytes == null ? Icon(Icons.face_retouching_natural_rounded, color: AppTheme.luxuryGold) : null,
            ),
            title: const Text('IN-APP AVATAR', style: TextStyle(fontWeight: FontWeight.w900)),
            subtitle: const Text('Import a picture from your gallery for the Personal/CD Feed avatar.'),
            trailing: Icon(Icons.photo_library_outlined, color: AppTheme.luxuryGold),
            onTap: _pickAppAvatar,
          ),
        ),

        SizedBox(height: 12),

        ReferralCard(),

        SizedBox(height: 12),

        GlassCard(
          child: Column(
            children: [
              ListTile(
                leading: Icon(
                  Icons.workspace_premium,
                  color: AppTheme.luxuryGold,
                ),
                title: Text(
                  'Premium Community',
                ),
                subtitle: Text(
                  '\$15/month • \$50 lifetime',
                ),
              ),
              Divider(),
              ListTile(
                leading: Icon(
                  Icons.notifications_outlined,
                ),
                title: Text('Notifications'),
                trailing: Icon(
                  Icons.chevron_right,
                ),
              ),
              Divider(),
              ListTile(
                leading: Icon(
                  Icons.dark_mode_outlined,
                ),
                title: Text('Theme'),
                subtitle: Text(
                  'Dark luxury mode',
                ),
              ),
            ],
          ),
        ),

        SizedBox(height: 18),

        GlassCard(
          child: ListTile(
            onTap: () => _logout(context),
            leading: Icon(Icons.logout_rounded, color: Color(0xFFE05252)),
            title: Text('Log Out', style: TextStyle(color: Color(0xFFE05252), fontWeight: FontWeight.w800)),
            subtitle: Text('Sign out of this account'),
            trailing: Icon(Icons.chevron_right, color: Color(0xFFE05252)),
          ),
        ),

        SizedBox(height: 28),
        ],
      ),
    );
  }
}

// ============================================================
// ALPHA DEN
// ============================================================

class AlphaDenLoadingPage extends StatefulWidget {
  final bool isAdmin;

  const AlphaDenLoadingPage({super.key, this.isAdmin = false});

  @override
  State<AlphaDenLoadingPage> createState() => _AlphaDenLoadingPageState();
}

class _AlphaDenLoadingPageState extends State<AlphaDenLoadingPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
    _timer = Timer(const Duration(milliseconds: 3000), () {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 900),
          pageBuilder: (_, _, _) => AlphaDenPage(isAdmin: widget.isAdmin),
          transitionsBuilder: (_, animation, _, child) => FadeTransition(
            opacity: CurvedAnimation(parent: animation, curve: Curves.easeInOut),
            child: child,
          ),
        ),
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const GalaxyBackground(animatePlanets: true, cinematicEntrance: true),
          Center(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                final pulse = 0.92 + math.sin(_controller.value * math.pi * 2) * 0.10;
                return Transform.scale(
                  scale: pulse,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('ALPHA DEN', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 38, fontWeight: FontWeight.w900, letterSpacing: 5)),
                      const SizedBox(height: 10),
                      Text('YOUR WAY TO WEB 3.0 🌐', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
                      const SizedBox(height: 34),
                      SizedBox(width: 220, height: 170, child: AlphaDenOrb(icon: Icons.blur_circular, color: AppTheme.luxuryGold)),
                      const SizedBox(height: 18),
                      Text('LOADING…', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 2)),
                      const SizedBox(height: 12),
                      SizedBox(width: 230, child: LinearProgressIndicator(minHeight: 3, backgroundColor: AppTheme.borderFaint, color: AppTheme.luxuryGold)),
                      const SizedBox(height: 18),
                      Text('Ideas  •  Profiles  •  Community', style: TextStyle(color: AppTheme.textMuted, fontSize: 12)),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class AlphaDenPage extends StatefulWidget {
  final bool isAdmin;

  const AlphaDenPage({super.key, this.isAdmin = false});

  @override
  State<AlphaDenPage> createState() => _AlphaDenPageState();
}

class _AlphaDenPageState extends State<AlphaDenPage> {
  static final Set<String> _usedAlphaDenHandles = <String>{'@userxxxx'};
  String username = '@userxxxx';
  String handle = '';
  String name = 'Hassan';
  String age = '';
  String sex = '';
  String bio = 'Building my edge in the Alpha Den.';
  String profilePicUrl = '';
  Uint8List? profilePicBytes;
  int followers = 0;
  int posts = 0;
  int likes = 0;
  int views = 0;
  int reposts = 0;
  int referrals = 0;
  int winTrades = 0;
  bool verificationPaymentSubmitted = false;
  bool verifiedCreatorApproved = false;
  bool isPremium = false;
  String premiumBadgeType = '';
  String mentorshipBadgeType = '';
  String referralCrownType = '';
  bool graduated = false;
  bool hasMentorship = false;
  DateTime? _profilePicChangedAt;
  DateTime? _usernameChangedAt;
  DateTime? _nicknameChangedAt;
  DateTime? _bioChangedAt;
  DateTime? _sexChangedAt;
  DateTime? _ageSetAt;
  final List<_AlphaDenPost> _ideas = [];
  final List<_AlphaDenArticle> _articles = [];
  final List<_AlphaDenRepost> _repostItems = [];
  final Set<int> _likedIdeas = <int>{};
  final Set<String> _likedArticles = <String>{};
  late final PageController _alphaDenPageController;
  int _alphaDenPage = 0;
  bool _alphaDenMenuOpen = false;
  OverlayEntry? _alphaDenMenuEntry;

  @override
  void initState() {
    super.initState();
    _alphaDenPageController = PageController();
    _loadAlphaDenData();
  }

  String? _legacySignalField(String text, String label) {
    final match = RegExp(r'(?:^|•|\n)\s*' + RegExp.escape(label) + r'\s+([^•\n]+)', caseSensitive: false).firstMatch(text);
    return match?.group(1)?.trim();
  }

  Map<String, dynamic> _recoverLegacySignal(Map<String, dynamic> data) {
    final raw = (data['text'] ?? '').toString();
    final hasStructured = data['signalAsset'] != null || data['signalEntry'] != null || data['signalTp1'] != null;
    if (hasStructured || raw.trim().isEmpty) return data;
    final assetMatch = RegExp(r'^\s*([A-Za-z0-9._-]+)\s*/\s*USDT', caseSensitive: false).firstMatch(raw);
    final direction = RegExp(r'\b(LONG|SHORT)\b', caseSensitive: false).firstMatch(raw)?.group(1)?.toUpperCase();
    final leverageRaw = _legacySignalField(raw, 'LEVERAGE');
    final leverage = leverageRaw == null ? null : int.tryParse(leverageRaw.replaceAll(RegExp(r'[^0-9]'), ''));
    return <String, dynamic>{
      ...data,
      'signalAsset': assetMatch?.group(1)?.toUpperCase(),
      'signalEntry': _legacySignalField(raw, 'ENTRY'),
      'signalLongDirection': direction == null ? null : direction == 'LONG',
      'signalLeverage': leverage,
      'signalTp1': _legacySignalField(raw, 'TP1'),
      'signalTp2': _legacySignalField(raw, 'TP2'),
      'signalTp3': _legacySignalField(raw, 'TP3'),
      'signalStopLoss': _legacySignalField(raw, 'STOPLOSS'),
    };
  }

  Future<void> _loadAlphaDenData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final profile = await AlphaDenService.loadProfile(user.uid);
      final userDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final userData = userDoc.data() ?? <String,dynamic>{};
      isPremium = userData['isPremium'] == true;
      hasMentorship = userData['mentorshipApproved'] == true || userData['isMentorship'] == true || userData['mentorship'] == true || userData['studentApproved'] == true || userData['isStudent'] == true;
      premiumBadgeType = (userData['confirmedPremiumBadgeType'] ?? '').toString();
      mentorshipBadgeType = (userData['confirmedMentorshipBadgeType'] ?? '').toString();
      graduated = userData['graduated'] == true;
      referralCrownType = (userData['confirmedReferralCrownType'] ?? '').toString();
      final savedPosts = await AlphaDenService.loadPosts(user.uid);
      final savedReposts = await AlphaDenService.loadMyReposts(user.uid);
      if (!mounted) return;
      if (profile != null) {
        final savedUsername = (profile['username'] ?? '').toString().trim();
        if (savedUsername.isNotEmpty) {
          username = savedUsername.startsWith('@') ? savedUsername : '@$savedUsername';
        }
        final savedNickname = (profile['nickname'] ?? profile['handle'] ?? '').toString().trim();
        handle = savedNickname.replaceFirst(RegExp(r'^@'), '');
        name = (profile['name'] as String?) ?? name;
        age = (profile['age'] as String?) ?? age;
        sex = (profile['sex'] as String?) ?? sex;
        bio = (profile['bio'] as String?) ?? bio;
        profilePicUrl = (profile['profilePicUrl'] as String?) ?? profilePicUrl;
        final savedProfilePic = (profile['profilePicBase64'] ?? '').toString();
        if (savedProfilePic.isNotEmpty) {
          try { profilePicBytes = base64Decode(savedProfilePic); } catch (_) { profilePicBytes = null; }
        }
        followers = (profile['followers'] as num?)?.toInt() ?? followers;
        posts = (profile['posts'] as num?)?.toInt() ?? posts;
        likes = (profile['likes'] as num?)?.toInt() ?? likes;
        views = (profile['views'] as num?)?.toInt() ?? views;
        reposts = (profile['reposts'] as num?)?.toInt() ?? reposts;
        referrals = (profile['referrals'] as num?)?.toInt() ?? referrals;
        winTrades = (profile['winTrades'] as num?)?.toInt() ?? winTrades;
        verifiedCreatorApproved = (profile['verifiedCreatorApproved'] as bool?) ?? verifiedCreatorApproved;
        DateTime? readTimestamp(dynamic value) => value is Timestamp ? value.toDate() : null;
        _profilePicChangedAt = readTimestamp(profile['profilePicChangedAt']);
        _usernameChangedAt = readTimestamp(profile['usernameChangedAt']);
        _nicknameChangedAt = readTimestamp(profile['nicknameChangedAt']);
        _bioChangedAt = readTimestamp(profile['bioChangedAt']);
        _sexChangedAt = readTimestamp(profile['sexChangedAt']);
        _ageSetAt = readTimestamp(profile['ageSetAt']);
        if (widget.isAdmin) {
          verifiedCreatorApproved = true;
          winTrades = winTrades < 10 ? 10 : winTrades;
        }
        _usedAlphaDenHandles.add(handle);
      } else {
        if (widget.isAdmin) {
          verifiedCreatorApproved = true;
          winTrades = 10;
        }
        await _persistAlphaProfile();
      }
      if (widget.isAdmin) {
        try { await _persistAlphaProfile(); } catch (_) {}
      }
      _ideas.clear();
      _articles.clear();
      _repostItems.clear();
      for (final rawRepost in savedReposts) {
        _repostItems.add(_AlphaDenRepost.fromMap(rawRepost));
      }
      for (final rawData in savedPosts) {
        final data = _recoverLegacySignal(rawData);
        final sourceType = (data['sourceType'] ?? 'alpha_den').toString();
        if (sourceType == 'article') {
          final rawArticle = (data['text'] ?? '').toString();
          final parts = rawArticle.split('\n\n');
          _articles.add(_AlphaDenArticle(
            id: (data['sourceId'] ?? data['id'] ?? '').toString(),
            title: (data['articleTitle'] ?? (parts.isNotEmpty ? parts.first : 'Alpha Den Article')).toString(),
            body: (data['articleBody'] ?? (parts.length > 1 ? parts.sublist(1).join('\n\n') : rawArticle)).toString(),
            imageBytes: (data['imageBase64'] is String && (data['imageBase64'] as String).isNotEmpty) ? base64Decode(data['imageBase64'] as String) : null,
            hashtags: List<String>.from((data['hashtags'] as List?) ?? const []),
            coins: List<String>.from((data['coins'] as List?) ?? const []),
            bullish: data['bullish'] != false,
            likes: (data['likesCount'] as num?)?.toInt() ?? 0,
            comments: (data['commentsCount'] as num?)?.toInt() ?? 0,
            reposts: (data['repostsCount'] as num?)?.toInt() ?? 0,
          ));
          continue;
        }
        _ideas.add(_AlphaDenPost(
          id: (data['id'] ?? data['sourceId'] ?? '').toString(),
          authorUid: (data['authorUid'] ?? '').toString(),
          text: (data['text'] as String?) ?? '',
          imageBytes: (data['imageBase64'] is String && (data['imageBase64'] as String).isNotEmpty) ? base64Decode(data['imageBase64'] as String) : null,
          bullish: (data['bullish'] as bool?) ?? true,
          hashtags: List<String>.from((data['hashtags'] as List?) ?? const []),
          coins: List<String>.from((data['coins'] as List?) ?? const []),
          signalAsset: data['signalAsset'] as String?,
          signalEntry: data['signalEntry'] as String?,
          signalLongDirection: data['signalLongDirection'] as bool?,
          signalLeverage: (data['signalLeverage'] as num?)?.toInt(),
          signalTp1: data['signalTp1'] as String?,
          signalTp2: data['signalTp2'] as String?,
          signalTp3: data['signalTp3'] as String?,
          signalStopLoss: data['signalStopLoss'] as String?,
          tp1Hit: data['tp1Hit'] == true, tp2Hit: data['tp2Hit'] == true, tp3Hit: data['tp3Hit'] == true, stopLossHit: data['stopLossHit'] == true, breakEven: data['breakEven'] == true, winTradeCounted: data['winTradeCounted'] == true,
          tp1Profit: (data['tp1Profit'] ?? '').toString(), tp2Profit: (data['tp2Profit'] ?? '').toString(), tp3Profit: (data['tp3Profit'] ?? '').toString(), stopLossProfit: (data['stopLossProfit'] ?? '').toString(), breakEvenProfit: (data['breakEvenProfit'] ?? '').toString(),
          winResultImageBytes: data['winResultImageBase64'] is String && (data['winResultImageBase64'] as String).isNotEmpty ? _tryDecodeBase64(data['winResultImageBase64'] as String) : null,
        ));
      }
      posts = _ideas.length + _articles.length;
      setState(() {});
    } catch (_) {
      // Keep the existing UI usable if the backend is temporarily unavailable.
    }
  }

  Future<Uint8List?> _pickWinProofImageBytes() async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 50,
        maxWidth: 900,
        maxHeight: 900,
      );
      if (picked == null) return null;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length > 100000) return null;
      return bytes;
    } catch (_) {
      return null;
    }
  }

  Future<void> _enterSignalOutcome(_AlphaDenPost post) async {
    if (!post.isSignal || post.id.isEmpty) return;
    bool tp1Hit = post.tp1Hit, tp2Hit = post.tp2Hit, tp3Hit = post.tp3Hit;
    bool stopLossHit = post.stopLossHit, breakEven = post.breakEven;
    Uint8List? winProofImageBytes = post.winResultImageBytes;
    final tp1Profit = TextEditingController(text: post.tp1Profit);
    final tp2Profit = TextEditingController(text: post.tp2Profit);
    final tp3Profit = TextEditingController(text: post.tp3Profit);
    final stopLossProfit = TextEditingController(text: post.stopLossProfit);
    final breakEvenProfit = TextEditingController(text: post.breakEvenProfit);
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0B0F11)),
          title: const Text('ENTER WIN RATIO', style: TextStyle(fontWeight: FontWeight.w900)),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              _lockedSignalValue('ENTRY', post.signalEntry ?? ''),
              _lockedSignalValue('LEVERAGE', '${post.signalLeverage ?? 10}x'),
              _lockedSignalValue('TP1', post.signalTp1 ?? ''),
              Row(children: [
                Expanded(child: CheckboxListTile(contentPadding: EdgeInsets.zero, dense: true, value: tp1Hit, activeColor: AppTheme.neonGreen, title: const Text('TP1 HIT', style: TextStyle(fontSize: 11)), onChanged: (v) => setDialogState(() => tp1Hit = v == true))),
                SizedBox(width: 92, child: TextField(controller: tp1Profit, enabled: tp1Hit, decoration: const InputDecoration(labelText: 'Profit %', prefixText: '+'))),
              ]),
              _lockedSignalValue('TP2', post.signalTp2 ?? ''),
              Row(children: [
                Expanded(child: CheckboxListTile(contentPadding: EdgeInsets.zero, dense: true, value: tp2Hit, activeColor: AppTheme.neonGreen, title: const Text('TP2 HIT', style: TextStyle(fontSize: 11)), onChanged: (v) => setDialogState(() => tp2Hit = v == true))),
                SizedBox(width: 92, child: TextField(controller: tp2Profit, enabled: tp2Hit, decoration: const InputDecoration(labelText: 'Profit %', prefixText: '+'))),
              ]),
              _lockedSignalValue('TP3', post.signalTp3 ?? ''),
              Row(children: [
                Expanded(child: CheckboxListTile(contentPadding: EdgeInsets.zero, dense: true, value: tp3Hit, activeColor: AppTheme.neonGreen, title: const Text('TP3 HIT', style: TextStyle(fontSize: 11)), onChanged: (v) => setDialogState(() => tp3Hit = v == true))),
                SizedBox(width: 92, child: TextField(controller: tp3Profit, enabled: tp3Hit, decoration: const InputDecoration(labelText: 'Profit %', prefixText: '+'))),
              ]),
              Divider(color: AppTheme.borderFaint),
              _lockedSignalValue('STOPLOSS', post.signalStopLoss ?? ''),
              Row(children: [
                Expanded(child: CheckboxListTile(contentPadding: EdgeInsets.zero, dense: true, value: stopLossHit, activeColor: const Color(0xFFE05252), title: const Text('STOP LOSS HIT', style: TextStyle(fontSize: 11, color: Color(0xFFE05252))), onChanged: (v) => setDialogState(() => stopLossHit = v == true))),
                SizedBox(width: 92, child: TextField(controller: stopLossProfit, enabled: stopLossHit, decoration: const InputDecoration(labelText: 'Loss %', prefixText: '-'))),
              ]),
              Row(children: [
                Expanded(child: CheckboxListTile(contentPadding: EdgeInsets.zero, dense: true, value: breakEven, activeColor: const Color(0xFFE05252), title: const Text('BREAK EVEN', style: TextStyle(fontSize: 11, color: Color(0xFFE05252))), onChanged: (v) => setDialogState(() => breakEven = v == true))),
                SizedBox(width: 92, child: TextField(controller: breakEvenProfit, enabled: breakEven, decoration: const InputDecoration(labelText: 'Loss %', prefixText: '-'))),
              ]),
              const SizedBox(height: 8),
              if (tp1Hit || tp2Hit || tp3Hit) ...[
                Row(children: [
                  Expanded(child: OutlinedButton.icon(
                    onPressed: () async {
                      final picked = await _pickWinProofImageBytes();
                      if (picked != null) setDialogState(() => winProofImageBytes = picked);
                    },
                    icon: const Icon(Icons.add_photo_alternate_outlined, size: 16),
                    label: Text(winProofImageBytes == null ? 'ADD WIN PROOF SCREENSHOT' : 'CHANGE WIN PROOF'),
                  )),
                  if (winProofImageBytes != null) ...[
                    const SizedBox(width: 6),
                    IconButton(onPressed: () => setDialogState(() => winProofImageBytes = null), icon: const Icon(Icons.delete_outline, color: Color(0xFFE05252))),
                  ],
                ]),
                if (winProofImageBytes != null) ...[
                  const SizedBox(height: 7),
                  ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.memory(winProofImageBytes!, height: 90, width: double.infinity, fit: BoxFit.cover)),
                ],
              ],
              const SizedBox(height: 4),
              Text('ENTRY, TP and STOPLOSS prices are locked after publishing.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textFaint, fontSize: 9)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () { FocusManager.instance.primaryFocus?.unfocus(); SystemChannels.textInput.invokeMethod<void>('TextInput.hide'); Navigator.of(dialogContext).pop(); }, child: const Text('CANCEL')),
            FilledButton(onPressed: () { FocusManager.instance.primaryFocus?.unfocus(); SystemChannels.textInput.invokeMethod<void>('TextInput.hide'); Navigator.of(dialogContext).pop({'tp1Hit': tp1Hit, 'tp2Hit': tp2Hit, 'tp3Hit': tp3Hit, 'stopLossHit': stopLossHit, 'breakEven': breakEven, 'tp1Profit': tp1Profit.text.trim(), 'tp2Profit': tp2Profit.text.trim(), 'tp3Profit': tp3Profit.text.trim(), 'stopLossProfit': stopLossProfit.text.trim(), 'breakEvenProfit': breakEvenProfit.text.trim(), 'winResultImageBase64': _safeImageBase64(winProofImageBytes) ?? ''}); }, child: const Text('SAVE')),
          ],
        ),
      ),
    );
    if (result == null || !mounted) {
      // Do not dispose text controllers while the dialog route is still
      // deactivating. Waiting a little longer avoids the Flutter
      // InheritedElement/_dependents assertion seen on CANCEL.
      await Future<void>.delayed(const Duration(milliseconds: 650));
      tp1Profit.dispose(); tp2Profit.dispose(); tp3Profit.dispose(); stopLossProfit.dispose(); breakEvenProfit.dispose();
      return;
    }
    await Future<void>.delayed(const Duration(milliseconds: 500));
    tp1Profit.dispose(); tp2Profit.dispose(); tp3Profit.dispose(); stopLossProfit.dispose(); breakEvenProfit.dispose();
    if (!mounted) return;
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final outcome = await AlphaDenService.updateSignalOutcome(uid: user.uid, postId: post.id, outcome: result);
      post.tp1Hit = result['tp1Hit'] == true; post.tp2Hit = result['tp2Hit'] == true; post.tp3Hit = result['tp3Hit'] == true;
      post.stopLossHit = result['stopLossHit'] == true; post.breakEven = result['breakEven'] == true;
      post.tp1Profit = (result['tp1Profit'] ?? '').toString(); post.tp2Profit = (result['tp2Profit'] ?? '').toString(); post.tp3Profit = (result['tp3Profit'] ?? '').toString(); post.stopLossProfit = (result['stopLossProfit'] ?? '').toString(); post.breakEvenProfit = (result['breakEvenProfit'] ?? '').toString(); post.winResultImageBytes = (result['winResultImageBase64'] ?? '').toString().isEmpty ? null : _tryDecodeBase64((result['winResultImageBase64'] ?? '').toString());
      post.winTradeCounted = post.winTradeCounted || outcome['counted'] == true;
      if (outcome['counted'] == true) { winTrades += 1; await _persistAlphaProfile(); }
      final feedIndex = _communityFeed.value.indexWhere((item) => item.id == post.id);
      if (feedIndex >= 0) {
        final feedPost = _communityFeed.value[feedIndex];
        feedPost.tp1Hit = post.tp1Hit; feedPost.tp2Hit = post.tp2Hit; feedPost.tp3Hit = post.tp3Hit;
        feedPost.stopLossHit = post.stopLossHit; feedPost.breakEven = post.breakEven;
        feedPost.winTradeCounted = post.winTradeCounted;
        feedPost.tp1Profit = post.tp1Profit; feedPost.tp2Profit = post.tp2Profit; feedPost.tp3Profit = post.tp3Profit;
        feedPost.stopLossProfit = post.stopLossProfit; feedPost.breakEvenProfit = post.breakEvenProfit;
        feedPost.winResultImageBytes = post.winResultImageBytes;
        feedPost.winTrades = winTrades;
        _communityFeed.value = List<_CommunityPost>.from(_communityFeed.value);
      }
      if (mounted) setState(() {});
      if (result['tp1Hit'] == true && mounted) {
        await _showQualifiedWinInfo();
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save the signal result.')));
    }
  }

  Future<void> _showQualifiedWinInfo() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (_) => const _QualifiedWinInfoDialog(),
    );
  }

  Widget _compactAlphaAction(BuildContext sheetContext, String value, IconData icon, String label, {Color? color}) {
    final actionColor = color ?? AppTheme.textSecondary;
    return InkWell(
      onTap: () => Navigator.pop(sheetContext, value),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: double.infinity, height: 34,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: .025), borderRadius: BorderRadius.circular(10), border: Border.all(color: AppTheme.fillFaint)),
        child: Row(children: [Icon(icon, size: 15, color: actionColor), const SizedBox(width: 8), Text(label, style: TextStyle(color: actionColor, fontSize: 10.5, fontWeight: FontWeight.w800)), const Spacer(), Icon(Icons.chevron_right_rounded, size: 14, color: AppTheme.borderSoft)]),
      ),
    );
  }

  Future<void> _showAlphaPostActions(_AlphaDenPost post) async {
    final currentUid = FirebaseAuth.instance.currentUser?.uid ?? '';
    final isOwner = currentUid.isNotEmpty && currentUid == post.authorUid;
    final canAdminDelete = widget.isAdmin && !isOwner;
    if (!isOwner && !canAdminDelete) {
      await _openContentReportSupportPage(context, postId: post.id, authorUid: post.authorUid);
      return;
    }
    final action = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (isOwner) ...[
              _compactAlphaAction(sheetContext, 'edit', Icons.edit_outlined, 'Edit post'),
              const SizedBox(height: 4),
              if (post.isSignal) ...[
                _compactAlphaAction(sheetContext, 'win_ratio', Icons.insights_outlined, 'Enter Win Ratio', color: AppTheme.neonGreen),
                const SizedBox(height: 4),
              ],
              _compactAlphaAction(sheetContext, 'report', Icons.flag_outlined, 'Report post'),
              const SizedBox(height: 4),
              _compactAlphaAction(sheetContext, 'delete', Icons.delete_outline, 'Delete post', color: const Color(0xFFE05252)),
            ] else if (canAdminDelete) ...[
              _compactAlphaAction(sheetContext, 'admin_delete', Icons.delete_forever_outlined, 'Admin delete Alpha Den post', color: const Color(0xFFE05252)),
            ],
          ]),
        ),
      ),
    );
    if (!mounted || action == null) return;
    // Let the bottom-sheet reverse animation fully deactivate before opening
    // another route/dialog. This prevents Navigator dependent-tree assertions
    // when SAVE/DELETE is tapped immediately after the sheet closes.
    await Future<void>.delayed(const Duration(milliseconds: 360));
    if (!mounted) return;

    if (action == 'win_ratio') {
      await _enterSignalOutcome(post);
      return;
    }

    if (action == 'report') {
      await _openContentReportSupportPage(context, postId: post.id, authorUid: post.authorUid);
      return;
    }

    if (action == 'admin_delete' || action == 'delete') {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('DELETE POST'),
          content: Text(action == 'admin_delete' ? 'Delete this Alpha Den post as an administrator? This will also remove its CD Feed copy.' : 'Delete this Alpha Den post? This will also remove its CD Feed copy.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('DELETE')),
          ],
        ),
      );
      if (confirmed != true || !mounted) return;
      final user = FirebaseAuth.instance.currentUser;
      if (user == null || post.id.isEmpty) return;
      try {
        await FeedService.deletePost(post.id, authorUid: post.authorUid, requesterUid: user.uid, adminDelete: action == 'admin_delete' && widget.isAdmin);
        setState(() {
          _ideas.removeWhere((item) => item.id == post.id);
          posts = _ideas.length + _articles.length;
        });
        await _persistAlphaProfile();
      } catch (_) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not delete this post.')));
      }
      return;
    }

    final controller = TextEditingController(text: post.text);
    String? updatedText;
    try {
      updatedText = await showDialog<String>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('EDIT POST'),
          content: TextField(controller: controller, autofocus: true, maxLines: 5, decoration: const InputDecoration(hintText: 'Post text')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim()), child: const Text('SAVE')),
          ],
        ),
      );
    } finally {
      controller.dispose();
    }
    if (!mounted || updatedText == null || updatedText.isEmpty || post.id.isEmpty) return;
    final editedText = updatedText;
    await Future<void>.delayed(Duration.zero);
    if (!mounted) return;
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      await FeedService.updatePost(post.id, authorUid: user.uid, text: updatedText);
      final index = _ideas.indexOf(post);
      if (index >= 0) {
        setState(() {
          _ideas[index] = _AlphaDenPost(
            id: post.id, authorUid: post.authorUid, text: editedText, imageBytes: post.imageBytes,
            thumbnailBytes: post.thumbnailBytes, bullish: post.bullish, hashtags: List<String>.from(post.hashtags),
            coins: List<String>.from(post.coins), signalAsset: post.signalAsset, signalEntry: post.signalEntry,
            signalLongDirection: post.signalLongDirection, signalLeverage: post.signalLeverage, signalTp1: post.signalTp1,
            signalTp2: post.signalTp2, signalTp3: post.signalTp3, signalStopLoss: post.signalStopLoss,
          );
        });
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not update this post.')));
    }
  }

  Future<void> _persistAlphaProfile() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final profileImage = _safeImageBase64(profilePicBytes);
      await AlphaDenService.saveProfile(
        uid: user.uid, username: username, handle: handle, name: name, age: age, sex: sex,
        bio: bio, profilePicUrl: profilePicUrl, followers: followers, posts: posts, likes: likes,
        views: views, referrals: referrals, verified: verifiedCreatorApproved, winTrades: winTrades,
        profilePicBase64: profileImage,
        profilePicChangedAt: _profilePicChangedAt, nicknameChangedAt: _nicknameChangedAt,
        bioChangedAt: _bioChangedAt, sexChangedAt: _sexChangedAt, ageSetAt: _ageSetAt,
      );
      try {
        await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'alphaDenProfile': {
            'username': username.startsWith('@') ? username : '@$username',
            'usernameNormalized': username.replaceFirst(RegExp(r'^@'), '').trim().toLowerCase(),
            'nickname': handle.replaceFirst(RegExp(r'^@'), ''),
            'handle': handle.replaceFirst(RegExp(r'^@'), ''),
            if (_usernameChangedAt != null) 'usernameChangedAt': Timestamp.fromDate(_usernameChangedAt!),
            if (_nicknameChangedAt != null) 'nicknameChangedAt': Timestamp.fromDate(_nicknameChangedAt!),
            'flamingAuraCrown': widget.isAdmin,
          },
        }, SetOptions(merge: true));
      } catch (_) {}
      try {
        await AlphaDenService.syncPublicProfileToPosts(
          uid: user.uid, username: username, profilePicUrl: profilePicUrl,
          profilePicBase64: profileImage, referrals: referrals, verified: verifiedCreatorApproved, winTrades: winTrades,
        );
      } catch (_) {}
    } catch (_) {}
  }

  Future<void> _toggleAlphaDenRepost({required String postId, required Map<String, dynamic> snapshot, _AlphaDenRepost? existing}) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || postId.trim().isEmpty) return;
    try {
      if (existing != null) {
        await AlphaDenService.deleteRepost(uid: user.uid, postId: postId);
        reposts = reposts > 0 ? reposts - 1 : 0;
        await _persistAlphaProfile();
        if (!mounted) return;
        setState(() => _repostItems.removeWhere((item) => item.originalPostId == postId));
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Repost removed.')));
      } else {
        await AlphaDenService.createRepost(uid: user.uid, postId: postId, snapshot: snapshot);
        reposts += 1;
        await _persistAlphaProfile();
        if (!mounted) return;
        setState(() => _repostItems.insert(0, _AlphaDenRepost.fromMap({...snapshot, 'originalPostId': postId, 'reposterUid': user.uid, 'createdAt': Timestamp.now()})));
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Reposted to your Alpha Den.')));
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not update the repost. Please try again.')));
    }
  }

  Map<String, dynamic> _repostSnapshotForPost(_AlphaDenPost post) => <String, dynamic>{
    'originalAuthorUid': post.authorUid,
    'sourceType': post.isSignal ? 'alpha_den_signal' : 'alpha_den',
    'sourceId': post.id,
    'text': post.text,
    'bullish': post.bullish,
    'hashtags': post.hashtags,
    'coins': post.coins,
    'signalAsset': post.signalAsset,
    'signalEntry': post.signalEntry,
    'signalLongDirection': post.signalLongDirection,
    'signalLeverage': post.signalLeverage,
    'signalTp1': post.signalTp1,
    'signalTp2': post.signalTp2,
    'signalTp3': post.signalTp3,
    'signalStopLoss': post.signalStopLoss,
    'tp1Hit': post.tp1Hit, 'tp2Hit': post.tp2Hit, 'tp3Hit': post.tp3Hit, 'stopLossHit': post.stopLossHit, 'breakEven': post.breakEven, 'winTradeCounted': post.winTradeCounted, 'tp1Profit': post.tp1Profit, 'tp2Profit': post.tp2Profit, 'tp3Profit': post.tp3Profit, 'stopLossProfit': post.stopLossProfit, 'breakEvenProfit': post.breakEvenProfit,
    if (post.winResultImageBytes != null) 'winResultImageBase64': base64Encode(post.winResultImageBytes!),
  };

  Map<String, dynamic> _repostSnapshotForArticle(_AlphaDenArticle article) => <String, dynamic>{
    'originalAuthorUid': FirebaseAuth.instance.currentUser?.uid ?? '',
    'sourceType': 'article',
    'sourceId': article.id,
    'articleTitle': article.title,
    'articleBody': article.body,
    'text': '${article.title}\n\n${article.body}',
    'bullish': article.bullish,
    'hashtags': article.hashtags,
    'coins': article.coins,
    if (article.imageBytes != null) 'imageBase64': base64Encode(article.imageBytes!),
  };

  @override
  void dispose() {
    _alphaDenMenuEntry?.remove();
    _alphaDenMenuEntry = null;
    _alphaDenPageController.dispose();
    super.dispose();
  }

  bool _withinSevenDays(DateTime? changedAt) => changedAt != null && DateTime.now().difference(changedAt).inHours < 24 * 7;

  Future<bool> _checkSevenDayLock(DateTime? changedAt, String label) async {
    if (!_withinSevenDays(changedAt)) return true;
    final remaining = const Duration(days: 7);
    final elapsed = DateTime.now().difference(changedAt!);
    final left = remaining - elapsed;
    final days = left.inHours ~/ 24;
    final hours = left.inHours % 24;
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$label can be changed again in ${days}d ${hours}h.')));
    }
    return false;
  }

  Future<void> _editProfilePicture() async {
    if (!await _checkSevenDayLock(_profilePicChangedAt, 'Profile picture')) return;
    if (!mounted) return;
    final urlController = TextEditingController(text: profilePicUrl);
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
        title: const Text('EDIT PROFILE PICTURE'),
        content: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.62),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
            if (profilePicBytes != null)
              ClipOval(child: Image.memory(profilePicBytes!, width: 86, height: 86, fit: BoxFit.cover))
            else if (profilePicUrl.trim().isNotEmpty)
              ClipOval(child: Image.network(profilePicUrl, width: 86, height: 86, fit: BoxFit.cover, errorBuilder: (_, _, _) => const Icon(Icons.person, size: 60)))
            else
              const CircleAvatar(radius: 43, child: Icon(Icons.person, size: 42)),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: () async {
                final bytes = await _pickImageBytes();
                if (!mounted || bytes == null) {
                  if (mounted && bytes == null) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please choose an image under 600 KB.')));
                  }
                  return;
                }
                setState(() { profilePicBytes = bytes; profilePicUrl = ''; _profilePicChangedAt = DateTime.now(); });
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              },
              icon: const Icon(Icons.photo_library_outlined),
              label: const Text('IMPORT FROM GALLERY'),
            ),
            const SizedBox(height: 10),
              TextField(controller: urlController, decoration: const InputDecoration(labelText: 'Or use profile picture URL')),
              const SizedBox(height: 4),
            ],
          ),
        ),
      ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')),
          ElevatedButton(onPressed: () { setState(() { profilePicUrl = urlController.text.trim(); if (profilePicUrl.isNotEmpty) profilePicBytes = null; _profilePicChangedAt = DateTime.now(); }); Navigator.pop(dialogContext); }, child: const Text('SAVE')),
        ],
      ),
    );
    await WidgetsBinding.instance.endOfFrame;
    await WidgetsBinding.instance.endOfFrame;
    urlController.dispose();
  }

  Future<void> _editUsername() async {
    if (!await _checkSevenDayLock(_usernameChangedAt, 'Username')) return;
    if (!mounted) return;
    final controller = TextEditingController(text: username.startsWith('@') ? username : '@$username');
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
        title: const Text('EDIT USERNAME'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 20,
          decoration: const InputDecoration(hintText: 'unique username'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')),
          ElevatedButton(
            onPressed: () async {
              var value = controller.text.trim().toLowerCase();
              if (!value.startsWith('@')) value = '@$value';
              if (!RegExp(r'^@[a-z0-9_]{1,20}$').hasMatch(value)) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Username: start with @ and use lowercase letters, numbers, and _ only.')));
                return;
              }
              if (value == (username.startsWith('@') ? username : '@$username').trim().toLowerCase()) {
                if (dialogContext.mounted) Navigator.pop(dialogContext);
                return;
              }
              final user = FirebaseAuth.instance.currentUser;
              if (user == null) return;
              try {
                final taken = await FirebaseFirestore.instance
                    .collection('users')
                    .where('alphaDenProfile.usernameNormalized', isEqualTo: value.replaceFirst(RegExp(r'^@'), ''))
                    .limit(2)
                    .get();
                final takenByOther = taken.docs.any((doc) => doc.id != user.uid);
                if (takenByOther) {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('That username is already taken.')));
                  return;
                }
                final now = DateTime.now();
                setState(() { username = value; _usernameChangedAt = now; });
                await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
                  'alphaDenProfile': {
                    'username': value,
                    'usernameNormalized': value.replaceFirst(RegExp(r'^@'), ''),
                    'nickname': handle.replaceFirst(RegExp(r'^@'), ''),
                    'handle': handle.replaceFirst(RegExp(r'^@'), ''),
                    'usernameChangedAt': Timestamp.fromDate(now),
                  },
                }, SetOptions(merge: true));
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              } catch (_) {
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not update the username right now. Please try again.')));
              }
            },
            child: const Text('SAVE'),
          ),
        ],
      ),
    );
    await WidgetsBinding.instance.endOfFrame;
    await WidgetsBinding.instance.endOfFrame;
    controller.dispose();
    await _persistAlphaProfile();
  }

  Future<void> _editNickname() async {
    if (!await _checkSevenDayLock(_nicknameChangedAt, 'Nickname')) return;
    if (!mounted) return;
    final controller = TextEditingController(text: handle);
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
        title: const Text('EDIT NICKNAME'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 30,
          decoration: const InputDecoration(hintText: 'Enter your nickname'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')),
          ElevatedButton(
            onPressed: () {
              final value = controller.text.trim();
              if (value.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nickname cannot be empty.')));
                return;
              }
              if (value.length > 30) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nickname must be 30 characters or less.')));
                return;
              }
              if (!mounted) return;
              setState(() { handle = value; _nicknameChangedAt = DateTime.now(); });
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            child: const Text('SAVE'),
          ),
        ],
      ),
    );
    await WidgetsBinding.instance.endOfFrame;
    await WidgetsBinding.instance.endOfFrame;
    controller.dispose();
    await _persistAlphaProfile();
  }

  Future<void> _editBio() async {
    if (!await _checkSevenDayLock(_bioChangedAt, 'Bio')) return;
    if (!mounted) return;
    final controller = TextEditingController(text: bio);
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
        title: const Text('BIO'),
        content: TextField(controller: controller, autofocus: true, maxLines: 6, maxLength: 300, decoration: const InputDecoration(hintText: 'Write about yourself…')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')),
          ElevatedButton(onPressed: () { setState(() { bio = controller.text.trim(); _bioChangedAt = DateTime.now(); }); Navigator.pop(dialogContext); }, child: const Text('SAVE')),
        ],
      ),
    );
    await WidgetsBinding.instance.endOfFrame;
    await WidgetsBinding.instance.endOfFrame;
    controller.dispose();
  }

  Future<void> _editSex() async {
    if (sex.trim().isNotEmpty || _sexChangedAt != null) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sex can only be set once and cannot be changed.')));
      return;
    }
    final selected = await showDialog<String>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
        title: const Text('SEX'),
        children: [
          SimpleDialogOption(onPressed: () => Navigator.pop(dialogContext, 'Male'), child: const Text('Male')),
          SimpleDialogOption(onPressed: () => Navigator.pop(dialogContext, 'Female'), child: const Text('Female')),
        ],
      ),
    );
    if (selected != null && mounted) setState(() { sex = selected; _sexChangedAt = DateTime.now(); });
  }

  Future<void> _editAge() async {
    if (age.trim().isNotEmpty || _ageSetAt != null) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Age can only be set once and cannot be changed.')));
      return;
    }
    final controller = TextEditingController(text: age);
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
        title: const Text('AGE'),
        content: TextField(controller: controller, autofocus: true, keyboardType: TextInputType.number, maxLength: 3, decoration: const InputDecoration(hintText: 'Enter your age')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')),
          ElevatedButton(onPressed: () { final value = controller.text.trim(); if (value.isEmpty) return; setState(() { age = value; _ageSetAt = DateTime.now(); }); Navigator.pop(dialogContext); }, child: const Text('SAVE')),
        ],
      ),
    );
    await WidgetsBinding.instance.endOfFrame;
    await WidgetsBinding.instance.endOfFrame;
    controller.dispose();
  }

  Future<void> _openAlphaDenCreateMenu() async {
    if (!mounted) return;
    await showGeneralDialog<void>(
      context: context,
      useRootNavigator: true,
      barrierLabel: 'Create post',
      barrierDismissible: true,
      barrierColor: Colors.black.withValues(alpha: 0.28),
      transitionDuration: const Duration(milliseconds: 360),
      pageBuilder: (dialogContext, animation, secondaryAnimation) {
        return SafeArea(
          child: Align(
            alignment: Alignment.bottomRight,
            child: Padding(
              padding: const EdgeInsets.only(right: 10, bottom: 84, left: 150),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _JellyCreateChoice(
                    icon: Icons.article_outlined,
                    title: 'ADD ARTICLE',
                    color: const Color(0xFF63C7FF),
                    onTap: () { Navigator.of(dialogContext).pop(); _openAlphaDenArticleComposer(); },
                  ),
                  const SizedBox(height: 9),
                  _JellyCreateChoice(
                    icon: Icons.lightbulb_outline,
                    title: 'POST IDEA',
                    color: AppTheme.luxuryGold,
                    onTap: () { Navigator.of(dialogContext).pop(); _createPostIdea(); },
                  ),
                  const SizedBox(height: 9),
                  _JellyCreateChoice(
                    icon: Icons.candlestick_chart_outlined,
                    title: 'POST SIGNAL',
                    color: AppTheme.neonGreen,
                    onTap: () { Navigator.of(dialogContext).pop(); _createPostSignal(); },
                  ),
                ],
              ),
            ),
          ),
        );
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutBack, reverseCurve: Curves.easeInCubic);
        return FadeTransition(
          opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0.12, 0.08), end: Offset.zero).animate(curved),
            child: child,
          ),
        );
      },
    );
  }

  Future<void> _createPostSignal() async {
    final post = await Navigator.push<_AlphaDenPost>(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, animation, _) => const _AlphaDenSignalComposerPage(),
        transitionsBuilder: (_, animation, _, child) => FadeTransition(
          opacity: CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
          child: ScaleTransition(
            scale: Tween<double>(begin: 0.94, end: 1.0).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutBack)),
            child: child,
          ),
        ),
      ),
    );
    if (post == null || !mounted) return;
    setState(() { _ideas.insert(0, post); posts = _ideas.length + _articles.length; });
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await AlphaDenService.createPost(
        uid: user.uid, text: _alphaDenSignalSummary(post), bullish: post.bullish, isSignal: true,
        signalAsset: post.signalAsset, signalEntry: post.signalEntry, signalLongDirection: post.signalLongDirection,
        signalLeverage: post.signalLeverage, signalTp1: post.signalTp1, signalTp2: post.signalTp2,
        signalTp3: post.signalTp3, signalStopLoss: post.signalStopLoss, hashtags: post.hashtags, coins: post.coins,
      );
    }
    await _persistAlphaProfile();
    final publishedId = await _publishToCommunityFeed(
      _CommunityPost(
        id: 'alpha-signal-${DateTime.now().microsecondsSinceEpoch}', username: username, nickname: handle, profilePicUrl: profilePicUrl,
        profilePicBytes: profilePicBytes, badge: _referralBadgeLabel(referrals), referrals: referrals, verified: verifiedCreatorApproved, isPremium: isPremium, winTrades: winTrades,
        text: _alphaDenSignalSummary(post), imageBytes: post.imageBytes, thumbnailBytes: null, bullish: post.bullish,
        hashtags: List<String>.from(post.hashtags), coins: post.signalAsset == null ? const <String>[] : <String>[post.signalAsset!],
        signalAsset: post.signalAsset, signalEntry: post.signalEntry, signalLongDirection: post.signalLongDirection,
        signalLeverage: post.signalLeverage, signalTp1: post.signalTp1, signalTp2: post.signalTp2, signalTp3: post.signalTp3,
        signalStopLoss: post.signalStopLoss, createdAt: DateTime.now(),
        tp1Hit: post.tp1Hit, tp2Hit: post.tp2Hit, tp3Hit: post.tp3Hit, stopLossHit: post.stopLossHit, breakEven: post.breakEven, winTradeCounted: post.winTradeCounted,
        tp1Profit: post.tp1Profit, tp2Profit: post.tp2Profit, tp3Profit: post.tp3Profit,
      ),
      sourceType: 'alpha_den',
    );
    final signalIndex = _ideas.indexOf(post);
    if (signalIndex >= 0 && mounted) {
      setState(() => _ideas[signalIndex] = post.copyWith(id: publishedId));
    }
  }

  Future<void> _createPostIdea() async {
    final post = await Navigator.of(context).push<_AlphaDenPost>(PageRouteBuilder<_AlphaDenPost>(
      transitionDuration: const Duration(milliseconds: 520),
      reverseTransitionDuration: const Duration(milliseconds: 360),
      pageBuilder: (_, animation, _) => const _AlphaDenPostComposerPage(),
      transitionsBuilder: (_, animation, _, child) {
        final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
        return FadeTransition(
          opacity: curved,
          child: ScaleTransition(
            scale: Tween<double>(begin: 0.96, end: 1.0).animate(curved),
            child: child,
          ),
        );
      },
    ));
    if (!mounted || post == null) return;
    setState(() {
      _ideas.insert(0, post);
      posts = _ideas.length;
    });
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await AlphaDenService.createPost(
        uid: user.uid, text: post.text, bullish: post.bullish, isSignal: false,
        hashtags: post.hashtags, coins: post.coins,
      );
    }
    await _persistAlphaProfile();
    final publishedId = await _publishToCommunityFeed(
      _CommunityPost(
        id: '${DateTime.now().microsecondsSinceEpoch}',
        username: username,
        nickname: handle,
        profilePicUrl: profilePicUrl,
        profilePicBytes: profilePicBytes,
        badge: _referralBadgeLabel(referrals),
        verified: verifiedCreatorApproved,
        referrals: referrals,
        winTrades: winTrades,
        text: post.text,
        imageBytes: post.imageBytes,
        thumbnailBytes: post.thumbnailBytes,
        bullish: post.bullish,
        hashtags: List<String>.from(post.hashtags),
        coins: List<String>.from(post.coins),
        createdAt: DateTime.now(),
      ),
    );
    final ideaIndex = _ideas.indexOf(post);
    if (ideaIndex >= 0 && mounted) {
      setState(() => _ideas[ideaIndex] = post.copyWith(id: publishedId));
    }
  }

  Future<void> _showAlphaArticleActions(_AlphaDenArticle article) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (sheetContext) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 8),
        ListTile(leading: const Icon(Icons.delete_outline, color: Color(0xFFE05252)), title: const Text('Delete article', style: TextStyle(color: Color(0xFFE05252))), onTap: () => Navigator.pop(sheetContext, 'delete')),
        const SizedBox(height: 8),
      ])),
    );
    if (!mounted || action != 'delete') return;
    await Future<void>.delayed(const Duration(milliseconds: 360));
    if (!mounted) return;
    final confirmed = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('DELETE ARTICLE'), content: const Text('Delete this Alpha Den article? This will also remove its CD Feed copy.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('DELETE'))]));
    if (confirmed != true || !mounted) return;
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || article.id.isEmpty) return;
    try {
      final safeId = article.id.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
      await FeedService.deletePost('article_$safeId', authorUid: user.uid);
      setState(() { _articles.removeWhere((item) => item.id == article.id); posts = _ideas.length + _articles.length; });
      await _persistAlphaProfile();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Article deleted.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not delete this article.')));
    }
  }

  void _openAlphaDenMenu() {
    if (!mounted) return;
    if (_alphaDenMenuEntry != null) {
      _closeAlphaDenMenu();
      return;
    }

    setState(() => _alphaDenMenuOpen = true);
    final overlay = Overlay.of(context, rootOverlay: true);
    final entry = OverlayEntry(
      builder: (_) => _buildAlphaDenSettingsMenu(),
    );
    _alphaDenMenuEntry = entry;
    overlay.insert(entry);
  }

  void _closeAlphaDenMenu() {
    final entry = _alphaDenMenuEntry;
    _alphaDenMenuEntry = null;
    if (entry != null) {
      entry.remove();
    }
    if (mounted && _alphaDenMenuOpen) {
      setState(() => _alphaDenMenuOpen = false);
    }
  }

  Future<void> _selectAlphaDenMenuAction(String action) async {
    if (!mounted) return;
    _closeAlphaDenMenu();
    await WidgetsBinding.instance.endOfFrame;
    if (!mounted) return;

    switch (action) {
      case 'username':
        await _editUsername();
        break;
      case 'profile':
        await _editProfilePicture();
        break;
      case 'nickname':
        await _editNickname();
        break;
      case 'bio':
        await _editBio();
        break;
      case 'sex':
        await _editSex();
        break;
      case 'age':
        await _editAge();
        break;
      case 'verified':
        await _showVerifiedCreatorDialog();
        break;
      case 'reset':
        await _resetAlphaDenProfile();
        break;
    }
    if (mounted) await _persistAlphaProfile();
  }

  Widget _buildAlphaDenSettingsMenu() {
    final topOffset = MediaQuery.paddingOf(context).top + kToolbarHeight;
    return Positioned(
      top: topOffset,
      left: 0,
      right: 0,
      bottom: 0,
      child: Stack(
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _closeAlphaDenMenu,
            child: Container(color: Colors.black54),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SafeArea(
              top: false,
              child: Material(
                color: Colors.transparent,
                child: Container(
                  width: double.infinity,
                  constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.82),
                  decoration: BoxDecoration(
                    color: AppTheme.adaptiveSurface(Color(0xFF070B10)),
                    borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
                  ),
                  child: SingleChildScrollView(
                    physics: const ClampingScrollPhysics(),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const SizedBox(height: 8),
                        Container(width: 38, height: 4, decoration: BoxDecoration(color: AppTheme.textVeryFaint, borderRadius: BorderRadius.all(Radius.circular(4)))),
                        const SizedBox(height: 8),
                        ListTile(leading: Icon(Icons.camera_alt_outlined, color: AppTheme.luxuryGold), title: const Text('Edit profile pic'), onTap: () => _selectAlphaDenMenuAction('profile')),
                        ListTile(leading: Icon(Icons.alternate_email_rounded, color: AppTheme.luxuryGold), title: const Text('USERNAME'), onTap: () => _selectAlphaDenMenuAction('username')),
                        ListTile(leading: Icon(Icons.badge_outlined, color: AppTheme.luxuryGold), title: const Text('NICKNAME'), onTap: () => _selectAlphaDenMenuAction('nickname')),
                        ListTile(leading: Icon(Icons.edit_note_outlined, color: AppTheme.luxuryGold), title: const Text('BIO'), onTap: () => _selectAlphaDenMenuAction('bio')),
                        ListTile(leading: Icon(Icons.wc_outlined, color: AppTheme.luxuryGold), title: const Text('SEX'), onTap: () => _selectAlphaDenMenuAction('sex')),
                        ListTile(leading: Icon(Icons.cake_outlined, color: AppTheme.luxuryGold), title: const Text('age'), onTap: () => _selectAlphaDenMenuAction('age')),
                        if (widget.isAdmin)
                          ListTile(leading: const Icon(Icons.restart_alt_rounded, color: Color(0xFFE05252)), title: const Text('RESET ALPHA DEN PROFILE', style: TextStyle(color: Color(0xFFE05252))), onTap: () => _selectAlphaDenMenuAction('reset')),
                        ListTile(
                          leading: Icon(verifiedCreatorApproved ? Icons.verified : Icons.verified_outlined, color: verifiedCreatorApproved ? const Color(0xFF4EA7FF) : const Color(0xFFE5A66A)),
                          title: Text(verifiedCreatorApproved ? 'Verified Creator • Approved' : 'Verified Creator • Apply'),
                          onTap: () => _selectAlphaDenMenuAction('verified'),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _resetAlphaDenProfile() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
        title: const Text('RESET ALPHA DEN PROFILE'),
        content: const Text('This will clear your Alpha Den username, nickname, bio, profile picture, age, sex, verification state, referral display and Win Trade profile progress. Your account itself will not be deleted.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('RESET')),
        ],
      ),
    );
    if (confirmed != true) return;
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'alphaDenProfile': FieldValue.delete(),
      }, SetOptions(merge: true));
      if (!mounted) return;
      setState(() {
        username = '@userxxxx';
        handle = '';
        name = '';
        age = '';
        sex = '';
        bio = '';
        profilePicUrl = '';
        profilePicBytes = null;
        followers = 0;
        posts = 0;
        likes = 0;
        views = 0;
        reposts = 0;
        referrals = 0;
        winTrades = 0;
        verifiedCreatorApproved = false;
        verificationPaymentSubmitted = false;
        _profilePicChangedAt = null;
        _usernameChangedAt = null;
        _nicknameChangedAt = null;
        _bioChangedAt = null;
        _sexChangedAt = null;
        _ageSetAt = null;
        if (widget.isAdmin) {
          verifiedCreatorApproved = true;
          winTrades = 10;
        }
        _ideas.clear();
        _articles.clear();
        _repostItems.clear();
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Alpha Den profile reset. You can create it again from scratch.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not reset the Alpha Den profile right now.')));
    }
  }

  Future<void> _showVerifiedCreatorDialog() async {
    if (verifiedCreatorApproved) {
      await showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
          title: const Text('VERIFIED CREATOR'),
          content: const Text('Your payment has been accepted and the verified creator status is active. The blue tick is displayed on your profile and posts.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CLOSE'))],
        ),
      );
      return;
    }
    // The application page is intentionally open so creators can read the full
    // requirements and payment/security terms before submitting. Eligibility
    // is still stated as 3+ qualified Win Trades and approval is not automatic.
    await Navigator.of(context).push<void>(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 420),
      pageBuilder: (_, animation, _) => _VerifiedCreatorPaymentPage(
        paymentSubmitted: verificationPaymentSubmitted,
        onPaymentSubmitted: () {
          if (mounted) setState(() => verificationPaymentSubmitted = true);
        },
      ),
      transitionsBuilder: (_, animation, _, child) => FadeTransition(opacity: CurvedAnimation(parent: animation, curve: Curves.easeOutCubic), child: child),
    ));
  }

  Future<void> _openAlphaDenArticleComposer() async {
    final article = await Navigator.of(context).push<_AlphaDenArticle>(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, animation, _) => const _AlphaDenArticleComposerPage(),
        transitionsBuilder: (_, animation, _, child) => FadeTransition(
          opacity: CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0.05, 0), end: Offset.zero).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic)),
            child: child,
          ),
        ),
      ),
    );
    if (article == null || !mounted) return;
    setState(() { _articles.insert(0, article); posts = _ideas.length + _articles.length; });
    await _persistAlphaProfile();
    final publishedId = await _publishToCommunityFeed(
      _CommunityPost(
        id: 'alpha-article-${article.id}', username: username, nickname: handle, profilePicUrl: profilePicUrl, profilePicBytes: profilePicBytes,
        badge: _referralBadgeLabel(referrals), referrals: referrals, verified: verifiedCreatorApproved, winTrades: winTrades, text: '${article.title}\n\n${article.body}',
        imageBytes: article.imageBytes, thumbnailBytes: null, bullish: article.bullish, hashtags: List<String>.from(article.hashtags), coins: List<String>.from(article.coins), createdAt: DateTime.now(),
      ),
      sourceType: 'article',
      sourceId: article.id,
    );
    if (publishedId.isNotEmpty && mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new), onPressed: () => Navigator.pop(context)),
        title: Text('A L P H A  D E N', style: TextStyle(color: AppTheme.textPrimary, fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: 4.5)),
        actions: [IconButton(tooltip: 'More', icon: const Icon(Icons.more_horiz), onPressed: _openAlphaDenMenu)],
      ),
      body: Stack(
        children: [
          GalaxyBackground(animatePlanets: false, animateCryptoCoins: true, animationDuration: const Duration(seconds: 45), cinematicEntrance: true, pauseMotion: _alphaDenMenuOpen),
          SafeArea(
            child: RefreshIndicator(
              onRefresh: () async {
                await _loadAlphaDenData();
                await Future<void>.delayed(const Duration(milliseconds: 250));
              },
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
                children: [
                  _WinRateProfileAura(
                    winTrades: winTrades,
                    child: Padding(
                      padding: const EdgeInsets.all(1.5),
                      child: Column(
                        children: [
                _AlphaDenProfileHeader(
                  username: username,
                  handle: handle,
                  name: name,
                  age: age,
                  sex: sex,
                  profilePicUrl: profilePicUrl,
                  profilePicBytes: profilePicBytes,
                  verified: verifiedCreatorApproved,
                  followers: followers,
                  posts: posts,
                  likes: likes,
                  views: views,
                  reposts: reposts,
                  referrals: referrals,
                  winTrades: winTrades,
                  bio: bio,
                  flamingAuraCrown: winTrades >= 10,
                  isPremium: isPremium,
                  hasMentorship: hasMentorship,
                  premiumBadgeType: premiumBadgeType,
                  mentorshipBadgeType: mentorshipBadgeType,
                  graduated: graduated,
                  referralCrownType: referralCrownType,
                ),
                const SizedBox(height: 14),
                _AlphaDenSectionTabs(
                  currentIndex: _alphaDenPage,
                  onTap: (index) => _alphaDenPageController.animateToPage(index, duration: const Duration(milliseconds: 420), curve: Curves.easeOutCubic),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 500,
                  child: PageView(
                    controller: _alphaDenPageController,
                    physics: const BouncingScrollPhysics(),
                    onPageChanged: (index) => setState(() => _alphaDenPage = index),
                    children: [
                      _AlphaDenIdeasPage(ideas: _ideas, likedIdeas: _likedIdeas, onLike: (index) {
                        setState(() {
                          if (_likedIdeas.contains(index)) { _likedIdeas.remove(index); likes = likes > 0 ? likes - 1 : 0; }
                          else { _likedIdeas.add(index); likes += 1; }
                        });
                      }, onRepost: (index) { final post = _ideas[index]; _toggleAlphaDenRepost(postId: post.id, snapshot: _repostSnapshotForPost(post)); }),
                      _AlphaDenSignalsPage(signals: _ideas.where((post) => post.isSignal).toList(), onRepost: (index) { final signals = _ideas.where((post) => post.isSignal).toList(); final post = signals[index]; _toggleAlphaDenRepost(postId: post.id, snapshot: _repostSnapshotForPost(post)); }),
                      _AlphaDenArticlesPage(articles: _articles, likedArticles: _likedArticles, onLike: (id) { final article = _articles.firstWhere((a) => a.id == id); setState(() { if (_likedArticles.contains(id)) { _likedArticles.remove(id); article.likes = article.likes > 0 ? article.likes - 1 : 0; } else { _likedArticles.add(id); article.likes += 1; } }); }, onRepost: (id) { final article = _articles.firstWhere((a) => a.id == id); _toggleAlphaDenRepost(postId: 'article_${article.id}', snapshot: _repostSnapshotForArticle(article)); }),
                      _AlphaDenRepostsPage(items: _repostItems, onDelete: (item) => _toggleAlphaDenRepost(postId: item.originalPostId, snapshot: item.toMap(), existing: item)),
                    ],
                  ),
                ),

                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            right: 0,
            top: MediaQuery.sizeOf(context).height * 0.70 - 29,
            child: _AlphaDenPlusButton(onPressed: _openAlphaDenCreateMenu),
          ),
        ],
      ),
    );
  }
}

class _WinRateProfileAura extends StatefulWidget {
  final int winTrades;
  final Widget child;
  const _WinRateProfileAura({required this.winTrades, required this.child});

  @override
  State<_WinRateProfileAura> createState() => _WinRateProfileAuraState();
}

class _WinRateProfileAuraState extends State<_WinRateProfileAura> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2200),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final wins = widget.winTrades;
    if (wins < 5) return widget.child;
    final tier8 = wins >= 8;
    final tier10 = wins >= 10;

    return AnimatedBuilder(
      animation: _controller,
      child: widget.child,
      builder: (context, child) {
        final pulse = 0.72 + (math.sin(_controller.value * math.pi * 2) + 1) * 0.14;
        final gold = AppTheme.luxuryGold.withValues(alpha: pulse);
        final cyan = const Color(0xFF59D7FF).withValues(alpha: tier8 ? pulse * 0.62 : 0.0);
        final red = const Color(0xFFFF4D5E).withValues(alpha: tier8 ? pulse * (tier10 ? 0.90 : 0.62) : 0.0);
        final orange = const Color(0xFFFF8A3D).withValues(alpha: tier10 ? pulse * 0.82 : 0.0);
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(29),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: tier10
                  ? [const Color(0x22FFD54A), const Color(0x12000000), const Color(0x22FF4D5E)]
                  : tier8
                      ? [const Color(0x1459D7FF), const Color(0x10000000), const Color(0x14FF4D5E)]
                      : [const Color(0x18FFD54A), const Color(0x0A000000), const Color(0x10FFD54A)],
            ),
            boxShadow: [
              BoxShadow(color: gold, blurRadius: tier10 ? 30 : 20, spreadRadius: tier10 ? 2 : 1),
              if (tier8) BoxShadow(color: cyan, blurRadius: 28, spreadRadius: 1),
              if (tier8) BoxShadow(color: red, blurRadius: tier10 ? 38 : 22, spreadRadius: tier10 ? 4 : 1),
              if (tier10) BoxShadow(color: orange, blurRadius: 48, spreadRadius: 5),
              BoxShadow(color: Colors.black.withValues(alpha: .55), blurRadius: 10, offset: const Offset(0, 7)),
            ],
          ),
          child: DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(26),
              border: Border.all(color: tier10 ? red : tier8 ? cyan : gold, width: tier10 ? 1.35 : 1.05),
            ),
            child: Stack(
              children: [
                Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: _WinRateDepthPainter(progress: _controller.value, tier8: tier8, tier10: tier10)))),
                if (tier10) Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: _WinRateFlameAuraPainter(progress: _controller.value)))),
                child!,
              ],
            ),
          ),
        );
      },
    );
  }
}

class _WinRateDepthPainter extends CustomPainter {
  final double progress;
  final bool tier8;
  final bool tier10;
  const _WinRateDepthPainter({required this.progress, required this.tier8, required this.tier10});
  @override
  void paint(Canvas canvas, Size size) {
    final pulse = .5 + .5 * math.sin(progress * math.pi * 2);
    final p = Paint()..style = PaintingStyle.stroke..strokeWidth = tier10 ? 1.4 : 1.0..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3.5);
    p.color = (tier10 ? const Color(0xFFFF8A3D) : tier8 ? const Color(0xFF59D7FF) : AppTheme.luxuryGold).withValues(alpha: .20 + pulse * .14);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(2, 2, size.width - 4, size.height - 4), const Radius.circular(25)), p);
    final hi = Paint()..style = PaintingStyle.stroke..strokeWidth = .8..color = AppTheme.adaptiveWhite(alpha: .10 + pulse * .08);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(4, 4, size.width - 8, size.height - 8), const Radius.circular(23)), hi);
  }
  @override
  bool shouldRepaint(covariant _WinRateDepthPainter oldDelegate) => oldDelegate.progress != progress || oldDelegate.tier8 != tier8 || oldDelegate.tier10 != tier10;
}

class _WinRateFlameAuraPainter extends CustomPainter {
  final double progress;
  const _WinRateFlameAuraPainter({required this.progress});
  @override
  void paint(Canvas canvas, Size size) {
    final t = progress * math.pi * 2;
    void flame(Offset base, double w, double h, double phase, bool up) {
      final sway = math.sin(t + phase) * w * .18;
      final dir = up ? -1.0 : 1.0;
      final tip = Offset(base.dx + sway, base.dy + dir * h);
      final path = Path()
        ..moveTo(base.dx - w * .5, base.dy)
        ..quadraticBezierTo(base.dx - w * .18, base.dy + dir * h * .42, tip.dx, tip.dy)
        ..quadraticBezierTo(base.dx + w * .18, base.dy + dir * h * .42, base.dx + w * .5, base.dy)
        ..close();
      canvas.drawPath(path, Paint()..color = const Color(0xFFFF3B24).withValues(alpha: .30)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3.5));
      final mid = Path()
        ..moveTo(base.dx - w * .34, base.dy)
        ..quadraticBezierTo(base.dx - w * .10, base.dy + dir * h * .30, tip.dx, tip.dy + dir * 2)
        ..quadraticBezierTo(base.dx + w * .10, base.dy + dir * h * .30, base.dx + w * .34, base.dy)
        ..close();
      canvas.drawPath(mid, Paint()..color = const Color(0xFFFF8A21).withValues(alpha: .55)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2));
      final inner = Path()
        ..moveTo(base.dx - w * .18, base.dy)
        ..quadraticBezierTo(base.dx, base.dy + dir * h * .26, tip.dx, tip.dy + dir * 4)
        ..quadraticBezierTo(base.dx, base.dy + dir * h * .26, base.dx + w * .18, base.dy)
        ..close();
      canvas.drawPath(inner, Paint()..color = const Color(0xFFFFD54A).withValues(alpha: .76));
    }
    for (var i = 0; i < 11; i++) {
      final x = size.width * (i + .5) / 11;
      flame(Offset(x, 2), 12, 12 + 6 * ((i + 1) % 3), t + i, true);
      flame(Offset(x, size.height - 2), 12, 10 + 5 * ((i + 2) % 3), t + i * 1.7, false);
    }
    for (var i = 0; i < 7; i++) {
      final y = size.height * (i + .5) / 7;
      flame(Offset(2, y), 10, 11 + 5 * (i % 3), t + i * 1.3, false);
      flame(Offset(size.width - 2, y), 10, 11 + 5 * ((i + 1) % 3), t + i * 1.8, false);
    }
  }
  @override
  bool shouldRepaint(covariant _WinRateFlameAuraPainter oldDelegate) => oldDelegate.progress != progress;
}

Future<void> _showProfileBadgeInfo(
  BuildContext context, {
  required String name,
  required String meaning,
  required String requirement,
  required String earned,
}) async {
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 360),
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
        decoration: BoxDecoration(
          color: const Color(0xF20B1117),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: .22)),
          boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 24, offset: Offset(0, 10))],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(child: Text(name, style: TextStyle(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: .3))),
              IconButton(
                visualDensity: VisualDensity.compact,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                onPressed: () => Navigator.pop(dialogContext),
                icon: Icon(Icons.close_rounded, size: 17, color: AppTheme.textMuted),
              ),
            ]),
            const SizedBox(height: 10),
            _profileInfoLine('MEANING', meaning),
            if (requirement.trim().isNotEmpty) ...[
              const SizedBox(height: 8),
              _profileInfoLine('REQUIREMENT', requirement),
            ],
            if (earned.trim().isNotEmpty) ...[
              const SizedBox(height: 8),
              _profileInfoLine('HOW EARNED', earned),
            ],
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CLOSE')),
            ),
          ],
        ),
      ),
    ),
  );
}

Widget _profileInfoLine(String label, String value) => Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    Text(label, style: TextStyle(color: AppTheme.luxuryGold, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .8)),
    const SizedBox(height: 3),
    Text(value, style: TextStyle(color: AppTheme.textSecondary, fontSize: 10.5, height: 1.4)),
  ],
);

String _officialCrownName(int referrals) {
  if (referrals >= 10) return 'BLACK + GOLD CROWN';
  if (referrals >= 5 && referrals <= 9) return 'GOLDEN CROWN';
  if (referrals >= 3 && referrals <= 4) return 'PURPLE CROWN';
  if (referrals >= 1 && referrals <= 2) return 'BLUE CROWN';
  return 'BROWN CROWN';
}

String _crownRequirement(int referrals) {
  if (referrals >= 10) return '10+ qualified referrals.';
  if (referrals >= 8) return '8–9 qualified referrals; this is the enhanced GOLDEN CROWN glow tier.';
  if (referrals >= 5) return '5–7 qualified referrals.';
  if (referrals >= 3) return '3–4 qualified referrals.';
  if (referrals >= 1) return '1–2 qualified referrals.';
  return '0 qualified referrals.';
}

Future<void> _showCrownInfo(BuildContext context, int referrals) => _showProfileBadgeInfo(
  context,
  name: _officialCrownName(referrals),
  meaning: 'Referral-based Alpha Den crown tier.',
  requirement: _crownRequirement(referrals),
  earned: 'The crown reflects the account’s current qualified referral count. At 10+ qualified referrals the BLACK + GOLD CROWN includes the existing corner flame aura.',
);

Future<void> _showPremiumInfo(BuildContext context, String badgeType) => _showProfileBadgeInfo(
  context,
  name: badgeType == 'premium_lifetime' ? 'LIFETIME PREMIUM' : 'PREMIUM',
  meaning: badgeType == 'premium_lifetime' ? 'Purple Lifetime Star badge.' : 'Normal Premium Star badge.',
  requirement: badgeType == 'premium_lifetime' ? 'Lifetime Premium access must be confirmed for the account.' : 'Monthly Premium access must be confirmed for the account.',
  earned: badgeType == 'premium_lifetime' ? 'Granted after the Lifetime Premium entitlement is confirmed.' : 'Granted after the Monthly Premium entitlement is confirmed.',
);

Future<void> _showStudentInfo(BuildContext context, String badgeType) => _showProfileBadgeInfo(
  context,
  name: _studentBadgeLabel(badgeType),
  meaning: _studentBadgeMeaning(badgeType),
  requirement: _studentBadgeRequirement(badgeType),
  earned: _studentBadgeEarned(badgeType),
);

String _studentBadgeLabel(String badgeType) {
  switch (badgeType) {
    case 'mentorship_installment_1': return 'STUDENT 1';
    case 'mentorship_installment_2': return 'STUDENT 2';
    case 'mentorship_installment_3': return 'STUDENT 3';
    case 'mentorship_installment_4': return 'STUDENT 4';
    case 'mentorship_installment': return 'STUDENT 1';
    default: return 'STUDENT';
  }
}

String _studentBadgeMeaning(String badgeType) {
  if (badgeType == 'mentorship_installment_4') return 'Fourth installment progress badge with the white Student 4 cap. The separate Graduated badge is awarded by Admin.';
  if (badgeType.startsWith('mentorship_installment_')) return 'Mentorship installment progress badge for the completed payment stage.';
  if (badgeType == 'mentorship_installment') return 'Mentorship installment Student 1 badge.';
  return 'Mentorship One-Time Student badge.';
}

String _studentBadgeRequirement(String badgeType) {
  switch (badgeType) {
    case 'mentorship_installment_1': return 'First \$20 installment must be verified.';
    case 'mentorship_installment_2': return 'Second \$20 installment must be verified.';
    case 'mentorship_installment_3': return 'Third \$20 installment must be verified.';
    case 'mentorship_installment_4': return 'Fourth and final \$20 installment must be verified.';
    case 'mentorship_installment': return 'Mentorship Installment entitlement must be confirmed.';
    default: return 'Mentorship One-Time entitlement must be confirmed.';
  }
}

String _studentBadgeEarned(String badgeType) {
  if (badgeType == 'mentorship_installment_4') return 'After the fourth installment is confirmed, the white Student 4 cap is shown. Graduation is a separate Admin-awarded badge.';
  final match = RegExp(r'mentorship_installment_([1-3])').firstMatch(badgeType);
  if (match != null) return 'After installment ${match.group(1)} is confirmed from Mail, the corresponding Student ${match.group(1)} cap is shown on the Alpha Den profile.';
  if (badgeType == 'mentorship_installment') return 'Granted after the installment mentorship entitlement is confirmed.';
  return 'Granted after the one-time mentorship entitlement is confirmed.';
}

Future<void> _showVerifiedCreatorInfo(BuildContext context) => _showProfileBadgeInfo(
  context,
  name: 'VERIFIED CREATOR',
  meaning: 'Approved Verified Creator account identified by the blue tick.',
  requirement: 'At least 3 qualified Win Trades are required to submit an application; approval is reviewed by the platform.',
  earned: 'Granted after Verified Creator review and approval. Approval is not automatic.',
);

int _referralsForConfirmedCrown(String type) {
  switch (type) {
    case 'referral_crown_blue': return 1;
    case 'referral_crown_purple': return 3;
    case 'referral_crown_gold': return 5;
    case 'referral_crown_black_gold': return 10;
    default: return 0;
  }
}

class _AlphaDenProfileHeader extends StatelessWidget {
  final String username, handle, name, age, sex, profilePicUrl, bio;
  final Uint8List? profilePicBytes;
  final bool verified;
  final int followers, posts, likes, views, reposts, referrals, winTrades;
  final bool flamingAuraCrown;
  final bool isPremium;
  final bool hasMentorship;
  final String premiumBadgeType;
  final String mentorshipBadgeType;
  final bool graduated;
  final String referralCrownType;
  final bool visitorProfile;

  const _AlphaDenProfileHeader({
    required this.username,
    required this.handle,
    required this.name,
    required this.age,
    required this.sex,
    required this.profilePicUrl,
    required this.profilePicBytes,
    required this.verified,
    required this.followers,
    required this.posts,
    required this.likes,
    required this.views,
    required this.reposts,
    required this.referrals,
    required this.winTrades,
    required this.bio,
    this.flamingAuraCrown = false,
    this.isPremium = false,
    this.hasMentorship = false,
    this.premiumBadgeType = '',
    this.mentorshipBadgeType = '',
    this.graduated = false,
    this.referralCrownType = '',
    this.visitorProfile = false,
  });

  @override
  Widget build(BuildContext context) {
    final hasPic = profilePicUrl.trim().isNotEmpty;
    return Container(
      padding: EdgeInsets.fromLTRB(16, visitorProfile ? 10 : 14, 10, 14),
      decoration: BoxDecoration(
        color: AppTheme.adaptiveSurface(Color(0xFF303238)),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: 0.38)),
        boxShadow: [BoxShadow(color: AppTheme.luxuryGold.withValues(alpha: 0.08), blurRadius: 30, spreadRadius: 2)],
      ),
      child: Column(
        children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Transform.translate(
              offset: Offset(0, visitorProfile ? -3 : 0),
              child: Container(
                width: 66, height: 66,
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppTheme.luxuryGold, width: 1.4), boxShadow: [BoxShadow(color: AppTheme.luxuryGold.withValues(alpha: 0.22), blurRadius: 20)]),
                child: ClipOval(
                  child: profilePicBytes != null
                      ? Image.memory(profilePicBytes!, fit: BoxFit.cover)
                      : hasPic
                          ? Image.network(profilePicUrl, fit: BoxFit.cover, errorBuilder: (_, _, _) => Icon(Icons.person, color: AppTheme.luxuryGold, size: 34))
                          : Icon(Icons.person, color: AppTheme.luxuryGold, size: 34),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Transform.translate(
                offset: Offset(0, visitorProfile ? -3 : 0),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Wrap(
                    crossAxisAlignment: WrapCrossAlignment.center,
                    spacing: 3,
                    runSpacing: 3,
                    children: [
                      Text(
                        handle.trim().isNotEmpty ? handle : name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                      ),
                      if (referralCrownType.isNotEmpty)
                        InkWell(
                          onTap: () => _showCrownInfo(context, _referralsForConfirmedCrown(referralCrownType)),
                          borderRadius: BorderRadius.circular(9),
                          child: Padding(
                            padding: const EdgeInsets.all(1),
                            child: _ReferralCrownBadge(referrals: _referralsForConfirmedCrown(referralCrownType), flamingAura: referralCrownType == 'referral_crown_black_gold'),
                          ),
                        ),
                      if (isPremium)
                        _CompactProfileBadge(child: _ProfileEntitlementBadgeChip(isPremium: true, hasMentorship: false, premiumBadgeType: premiumBadgeType, mentorshipBadgeType: '')),
                      if (hasMentorship)
                        _CompactProfileBadge(child: _ProfileEntitlementBadgeChip(isPremium: false, hasMentorship: true, premiumBadgeType: '', mentorshipBadgeType: mentorshipBadgeType)),
                      if (graduated)
                        _CompactProfileBadge(child: _GraduatedProfileBadge()),
                      if (verified)
                        InkWell(
                          onTap: () => _showVerifiedCreatorInfo(context),
                          borderRadius: BorderRadius.circular(9),
                          child: const Padding(padding: EdgeInsets.all(1), child: Icon(Icons.verified, color: Color(0xFF4EA7FF), size: 17)),
                        ),
                      SizedBox(
                        width: 25, height: 25,
                        child: IconButton(
                          tooltip: 'Alpha Den rules and benefits',
                          padding: EdgeInsets.zero,
                          visualDensity: VisualDensity.compact,
                          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _AlphaDenRulesPage())),
                          icon: Container(
                            width: 19, height: 19, alignment: Alignment.center,
                            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppTheme.textFaint), color: AppTheme.adaptiveWhite(alpha: .04)),
                            child: Transform.translate(offset: const Offset(2, -2), child: Text('?', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10, fontWeight: FontWeight.w900))),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  if (username.trim().isNotEmpty) Text(username.startsWith('@') ? username : '@$username', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12, fontWeight: FontWeight.w700)),
                  if (age.isNotEmpty || sex.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text([if (age.isNotEmpty) '$age years', if (sex.isNotEmpty) sex].join('  •  '), style: TextStyle(color: AppTheme.textFaint, fontSize: 10)),
                  ],
                ]),
              ),
            ),
            Transform.translate(
              offset: Offset(0, visitorProfile ? -3 : 0),
              child: Container(width: 54, padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4), decoration: BoxDecoration(color: const Color(0x1AFFFFFF), borderRadius: BorderRadius.circular(8), border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: 0.4))), child: Column(mainAxisSize: MainAxisSize.min, children: [Text('WIN TRADES', style: TextStyle(color: AppTheme.textMuted, fontSize: 5.5, fontWeight: FontWeight.w900, letterSpacing: .3)), const SizedBox(height: 1), Text('$winTrades', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 13, fontWeight: FontWeight.w900))])),
            ),
          ]),
          const SizedBox(height: 10),
          Align(alignment: Alignment.centerLeft, child: Text(bio, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppTheme.textSoft, fontSize: 12, height: 1.35))),
          const SizedBox(height: 14),
          Row(children: [
            _ProfileStat(label: 'FOLLOWERS', value: '$followers'),
            _ProfileStat(label: 'POSTS', value: '$posts'),
            _ProfileStat(label: 'LIKES', value: '$likes'),
            _ProfileStat(label: 'REPOSTS', value: '$reposts'),
          ]),
        ],
      ),
    );
  }
}

class _CompactProfileBadge extends StatelessWidget {
  final Widget child;
  const _CompactProfileBadge({required this.child});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(horizontal: 0.5), child: child);
}

class _ProfileEntitlementBadgeChip extends StatelessWidget {
  final bool isPremium;
  final bool hasMentorship;
  final String premiumBadgeType;
  final String mentorshipBadgeType;
  const _ProfileEntitlementBadgeChip({
    required this.isPremium,
    required this.hasMentorship,
    this.premiumBadgeType = '',
    this.mentorshipBadgeType = '',
    this.graduated = false,
  });

  @override
  Widget build(BuildContext context) {
    if (isPremium) {
      final lifetime = premiumBadgeType == 'premium_lifetime';
      final accent = lifetime ? const Color(0xFFB56CFF) : AppTheme.luxuryGold;
      return InkWell(
        onTap: () => _showPremiumInfo(context, premiumBadgeType),
        borderRadius: BorderRadius.circular(9),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: .12),
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: accent.withValues(alpha: .38)),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(lifetime ? '★' : '⭐', style: TextStyle(color: accent, fontSize: 11, fontWeight: FontWeight.w900)),
            const SizedBox(width: 2),
            Text(lifetime ? 'LIFETIME' : 'PREMIUM', style: TextStyle(color: accent, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .25)),
          ]),
        ),
      );
    }
    if (hasMentorship) {
      final installment = mentorshipBadgeType.startsWith('mentorship_installment');
      final accent = installment ? Colors.white : const Color(0xFF8DB0FF);
      final badgeTextColor = accent;
      final badgeFill = accent.withValues(alpha: .08);
      return InkWell(
        onTap: () => _showStudentInfo(context, mentorshipBadgeType),
        borderRadius: BorderRadius.circular(9),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
          decoration: BoxDecoration(
            color: badgeFill,
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: accent.withValues(alpha: .42)),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.school_rounded, color: accent, size: 14),
            const SizedBox(width: 2),
            Text(installment ? _studentBadgeLabel(mentorshipBadgeType) : 'STUDENT', style: TextStyle(color: badgeTextColor, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .25)),
          ]),
        ),
      );
    }
    return const SizedBox.shrink();
  }
}

class _ProfileEntitlementBadges extends StatelessWidget {
  final bool isPremium;
  final bool hasMentorship;
  final String premiumBadgeType;
  final String mentorshipBadgeType;
  final bool graduated;

  const _ProfileEntitlementBadges({
    required this.isPremium,
    required this.hasMentorship,
    this.premiumBadgeType = '',
    this.mentorshipBadgeType = '',
    this.graduated = false,
  });

  @override
  Widget build(BuildContext context) {
    final lifetime = premiumBadgeType == 'premium_lifetime';
    final installment = mentorshipBadgeType.startsWith('mentorship_installment');
    final badgeAccent = Colors.white;
    final badgeFill = Colors.white.withValues(alpha: .08);
    return Wrap(
      spacing: 7,
      runSpacing: 5,
      children: [
        if (isPremium && premiumBadgeType.isNotEmpty)
          InkWell(
            onTap: () => _showPremiumInfo(context, premiumBadgeType),
            borderRadius: BorderRadius.circular(10),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
              decoration: BoxDecoration(
                color: (lifetime ? const Color(0xFFB56CFF) : AppTheme.luxuryGold).withValues(alpha: .12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: (lifetime ? const Color(0xFFB56CFF) : AppTheme.luxuryGold).withValues(alpha: .38)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Text(lifetime ? '★' : '⭐', style: TextStyle(color: lifetime ? const Color(0xFFB56CFF) : AppTheme.luxuryGold, fontSize: 13, fontWeight: FontWeight.w900)),
                const SizedBox(width: 4),
                Text(lifetime ? 'LIFETIME' : 'PREMIUM', style: TextStyle(color: lifetime ? const Color(0xFFB56CFF) : AppTheme.luxuryGold, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .4)),
              ]),
            ),
          ),
        if (hasMentorship && mentorshipBadgeType.isNotEmpty)
          InkWell(
            onTap: () => _showStudentInfo(context, mentorshipBadgeType),
            borderRadius: BorderRadius.circular(10),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
              decoration: BoxDecoration(
                color: badgeFill,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: badgeAccent.withValues(alpha: .42)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.school_rounded, color: badgeAccent, size: 16),
                const SizedBox(width: 4),
                Text(installment ? _studentBadgeLabel(mentorshipBadgeType) : 'STUDENT', style: TextStyle(color: badgeAccent, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .35)),
              ]),
            ),
          ),
        if (graduated) _GraduatedProfileBadge(),
      ],
    );
  }
}

class _GraduatedProfileBadge extends StatelessWidget {
  const _GraduatedProfileBadge();
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: () => _showProfileBadgeInfo(context, name: 'GRADUATED', meaning: 'Official Graduated badge awarded separately by CDH Admin.', requirement: 'Admin must assign one of the 25 official Graduated badges and the user must collect it.', earned: 'Stored permanently on the Firebase user profile as graduated = true.'),
    borderRadius: BorderRadius.circular(10),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: .92), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.black.withValues(alpha: .45))),
      child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.school_rounded, color: Colors.black, size: 16), SizedBox(width: 4), Text('GRADUATED', style: TextStyle(color: Colors.black, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .35))]),
    ),
  );
}

class _ProfileStat extends StatelessWidget {
  final String label, value;
  const _ProfileStat({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Expanded(child: Column(children: [
    Text(value, style: TextStyle(color: AppTheme.luxuryGold, fontSize: 21, fontWeight: FontWeight.w900)),
    const SizedBox(height: 2),
    Text(label, style: TextStyle(color: AppTheme.textMuted, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.0)),
  ]));
}

class _VerifiedCreatorPaymentPage extends StatelessWidget {
  final bool paymentSubmitted;
  final VoidCallback onPaymentSubmitted;
  const _VerifiedCreatorPaymentPage({required this.paymentSubmitted, required this.onPaymentSubmitted});

  @override
  Widget build(BuildContext context) {
    return const CentralPaymentPage(product: 'verified_creator', planId: 'verified_creator_monthly');
  }
}

class _PostNewIdeaTwinkle extends StatefulWidget {
  const _PostNewIdeaTwinkle();

  @override
  State<_PostNewIdeaTwinkle> createState() => _PostNewIdeaTwinkleState();
}

class _PostNewIdeaTwinkleState extends State<_PostNewIdeaTwinkle>
    with SingleTickerProviderStateMixin {
  late final AnimationController _twinkleController;

  @override
  void initState() {
    super.initState();
    _twinkleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _twinkleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: AnimatedBuilder(
        animation: _twinkleController,
        builder: (context, child) {
          final glow = 0.35 + (_twinkleController.value * 0.45);
          return Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.auto_awesome, size: 13, color: AppTheme.adaptiveWhite(alpha: glow)),
              const SizedBox(width: 8),
              Text(
                'Post new idea',
                style: TextStyle(
                  color: AppTheme.adaptiveWhite(alpha: 0.42 + _twinkleController.value * 0.18),
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.auto_awesome, size: 10, color: AppTheme.adaptiveWhite(alpha: glow * 0.8)),
            ],
          );
        },
      ),
    );
  }
}

class _AlphaDenPost {
  final String id;
  final String authorUid;
  final String text;
  final Uint8List? imageBytes;
  final Uint8List? thumbnailBytes;
  final bool bullish;
  final List<String> hashtags;
  final List<String> coins;
  final String? signalAsset;
  final String? signalEntry;
  final bool? signalLongDirection;
  final int? signalLeverage;
  final String? signalTp1;
  final String? signalTp2;
  final String? signalTp3;
  final String? signalStopLoss;
  bool tp1Hit, tp2Hit, tp3Hit, stopLossHit, breakEven, winTradeCounted;
  String tp1Profit, tp2Profit, tp3Profit, stopLossProfit, breakEvenProfit;
  Uint8List? winResultImageBytes;

  _AlphaDenPost({
    this.id = '',
    this.authorUid = '',
    required this.text,
    this.imageBytes,
    this.thumbnailBytes,
    required this.bullish,
    required this.hashtags,
    required this.coins,
    this.signalAsset,
    this.signalEntry,
    this.signalLongDirection,
    this.signalLeverage,
    this.signalTp1,
    this.signalTp2,
    this.signalTp3,
    this.signalStopLoss,
    this.tp1Hit = false, this.tp2Hit = false, this.tp3Hit = false, this.stopLossHit = false, this.breakEven = false, this.winTradeCounted = false,
    this.tp1Profit = '', this.tp2Profit = '', this.tp3Profit = '', this.stopLossProfit = '', this.breakEvenProfit = '',
    this.winResultImageBytes,
  });

  _AlphaDenPost copyWith({String? id}) => _AlphaDenPost(
    id: id ?? this.id,
    authorUid: authorUid,
    text: text,
    imageBytes: imageBytes,
    thumbnailBytes: thumbnailBytes,
    bullish: bullish,
    hashtags: List<String>.from(hashtags),
    coins: List<String>.from(coins),
    signalAsset: signalAsset,
    signalEntry: signalEntry,
    signalLongDirection: signalLongDirection,
    signalLeverage: signalLeverage,
    signalTp1: signalTp1,
    signalTp2: signalTp2,
    signalTp3: signalTp3,
    signalStopLoss: signalStopLoss,
    tp1Hit: tp1Hit, tp2Hit: tp2Hit, tp3Hit: tp3Hit, stopLossHit: stopLossHit, breakEven: breakEven, winTradeCounted: winTradeCounted,
    tp1Profit: tp1Profit, tp2Profit: tp2Profit, tp3Profit: tp3Profit, stopLossProfit: stopLossProfit, breakEvenProfit: breakEvenProfit,
    winResultImageBytes: winResultImageBytes,
  );

  bool get isSignal => signalAsset != null;
}

String _alphaDenSignalSummary(_AlphaDenPost post) {
  final asset = post.signalAsset ?? '';
  final direction = post.signalLongDirection == true ? 'LONG' : 'SHORT';
  final leverage = post.signalLeverage == null ? '' : '${post.signalLeverage}x';
  return '$asset /USDT • $direction • ENTRY ${post.signalEntry ?? ''} • LEVERAGE $leverage • TP1 ${post.signalTp1 ?? ''} • TP2 ${post.signalTp2 ?? ''} • TP3 ${post.signalTp3 ?? ''} • STOPLOSS ${post.signalStopLoss ?? ''}';
}

class _AlphaDenSignalComposerPage extends StatefulWidget {
  const _AlphaDenSignalComposerPage();

  @override
  State<_AlphaDenSignalComposerPage> createState() => _AlphaDenSignalComposerPageState();
}

class _AlphaDenSignalComposerPageState extends State<_AlphaDenSignalComposerPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _assetController = TextEditingController();
  final TextEditingController _entryController = TextEditingController();
  final TextEditingController _tp1Controller = TextEditingController();
  final TextEditingController _tp2Controller = TextEditingController();
  final TextEditingController _tp3Controller = TextEditingController();
  final TextEditingController _stopController = TextEditingController();

  Uint8List? _imageBytes;
  bool _longDirection = true;
  final bool _bullish = true;
  int _leverage = 10;
  late final AnimationController _entry = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 650),
  )..forward();

  @override
  void dispose() {
    _entry.dispose();
    _assetController.dispose();
    _entryController.dispose();
    _tp1Controller.dispose();
    _tp2Controller.dispose();
    _tp3Controller.dispose();
    _stopController.dispose();
    super.dispose();
  }

  Future<Uint8List?> _pickImageBytes() async {
    final input = html.FileUploadInputElement()..accept = 'image/*';
    input.click();
    await input.onChange.first;
    final file = input.files?.isNotEmpty == true ? input.files!.first : null;
    if (file == null) return null;
    final reader = html.FileReader();
    reader.readAsArrayBuffer(file);
    await reader.onLoad.first;
    final result = reader.result;
    return result is ByteBuffer ? result.asUint8List() : null;
  }

  Future<void> _pickOriginal() async {
    final bytes = await _pickImageBytes();
    if (bytes != null && mounted) setState(() => _imageBytes = bytes);
  }

  Future<void> _pickLeverage() async {
    final selected = await showDialog<int>(
      context: context,
      builder: (dialogContext) {
        var current = _leverage.toDouble();
        return StatefulBuilder(
          builder: (context, setDialogState) {
            final currentInt = current.round();
            final color = _leverageColor(currentInt);
            return AlertDialog(
              backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0B0F11)),
              title: const Text('LEVERAGE', style: TextStyle(fontWeight: FontWeight.w900)),
              content: SizedBox(
                width: 350,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('${currentInt}x', style: TextStyle(color: color, fontSize: 22, fontWeight: FontWeight.w900)),
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: color,
                        thumbColor: color,
                        inactiveTrackColor: color.withValues(alpha: 0.18),
                        overlayColor: color.withValues(alpha: 0.12),
                        trackHeight: 4,
                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
                      ),
                      child: Slider(
                        min: 10,
                        max: 100,
                        divisions: 9,
                        value: current,
                        onChanged: (value) => setDialogState(() => current = (value.round() ~/ 10) * 10.0),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: List.generate(10, (index) {
                        final value = (index + 1) * 10;
                        final dotColor = _leverageColor(value);
                        final selectedDot = value == currentInt;
                        return Column(
                          children: [
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 160),
                              width: selectedDot ? 8 : 5,
                              height: selectedDot ? 8 : 5,
                              decoration: BoxDecoration(
                                color: dotColor,
                                shape: BoxShape.circle,
                                boxShadow: selectedDot ? [BoxShadow(color: dotColor.withValues(alpha: 0.55), blurRadius: 7)] : null,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text('${value}x', style: TextStyle(color: dotColor, fontSize: 8, fontWeight: FontWeight.w900)),
                          ],
                        );
                      }),
                    ),
                    const SizedBox(height: 12),
                    Text('10–30x GREEN   •   40–60x WARNING   •   70–100x RED', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textFaint, fontSize: 8, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')),
                FilledButton(
                  onPressed: () => Navigator.pop(dialogContext, currentInt),
                  style: FilledButton.styleFrom(backgroundColor: AppTheme.luxuryGold, foregroundColor: Colors.black),
                  child: const Text('SELECT', style: TextStyle(fontWeight: FontWeight.w900)),
                ),
              ],
            );
          },
        );
      },
    );
    if (selected != null && mounted) setState(() => _leverage = selected);
  }

  void _publish() {
    final asset = _assetController.text.trim().toUpperCase();
    if (asset.isEmpty ||
        _entryController.text.trim().isEmpty ||
        _tp1Controller.text.trim().isEmpty ||
        _tp2Controller.text.trim().isEmpty ||
        _tp3Controller.text.trim().isEmpty ||
        _stopController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Fill Asset, Entry, TP1, TP2, TP3 and Stoploss before publishing.')),
      );
      return;
    }
    Navigator.pop(
      context,
      _AlphaDenPost(
        text: '',
        imageBytes: _imageBytes,
        thumbnailBytes: null,
        bullish: _bullish,
        hashtags: const <String>[],
        coins: <String>[asset],
        signalAsset: asset,
        signalEntry: _entryController.text.trim(),
        signalLongDirection: _longDirection,
        signalLeverage: _leverage,
        signalTp1: _tp1Controller.text.trim(),
        signalTp2: _tp2Controller.text.trim(),
        signalTp3: _tp3Controller.text.trim(),
        signalStopLoss: _stopController.text.trim(),
      ),
    );
  }

  InputDecoration _fieldDecoration(String label) => InputDecoration(
    labelText: label,
    filled: true,
    fillColor: AppTheme.adaptiveSurface(Color(0xB5090D12)),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: AppTheme.borderFaint)),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide(color: AppTheme.luxuryGold.withValues(alpha: 0.65))),
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
  );

  @override
  Widget build(BuildContext context) {
    final directionColor = _longDirection ? AppTheme.neonGreen : const Color(0xFFE05252);
    final leverageColor = _leverageColor(_leverage);
    return Scaffold(
      appBar: AppBar(
        title: const Text('POST SIGNAL'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12, top: 8, bottom: 8),
            child: FilledButton(
              onPressed: _publish,
              style: FilledButton.styleFrom(backgroundColor: AppTheme.luxuryGold, foregroundColor: Colors.black),
              child: const Text('PUBLISH', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          const GalaxyBackground(animatePlanets: true, cinematicEntrance: false),
          SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _entry, curve: Curves.easeOut),
              child: SlideTransition(
                position: Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero).animate(CurvedAnimation(parent: _entry, curve: Curves.easeOutCubic)),
                child: Column(
                  children: [
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
                        children: [
                          Row(
                            children: [
                              Expanded(child: TextField(controller: _assetController, textCapitalization: TextCapitalization.characters, decoration: _fieldDecoration('ASSET'))),
                              Padding(padding: EdgeInsets.only(left: 8, right: 2), child: Text('/USDT', style: TextStyle(color: AppTheme.textSecondary, fontSize: 15, fontWeight: FontWeight.w900))),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Text('DIRECTION', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: 0.04), borderRadius: BorderRadius.circular(13), border: Border.all(color: directionColor.withValues(alpha: 0.35))),
                            child: Row(
                              children: [
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () => setState(() => _longDirection = true),
                                    child: AnimatedContainer(
                                      duration: const Duration(milliseconds: 220),
                                      padding: const EdgeInsets.symmetric(vertical: 11),
                                      decoration: BoxDecoration(color: _longDirection ? AppTheme.neonGreen.withValues(alpha: 0.18) : Colors.transparent, borderRadius: BorderRadius.circular(10)),
                                      child: Center(child: Text('LONG', style: TextStyle(color: AppTheme.neonGreen, fontWeight: FontWeight.w900))),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () => setState(() => _longDirection = false),
                                    child: AnimatedContainer(
                                      duration: const Duration(milliseconds: 220),
                                      padding: const EdgeInsets.symmetric(vertical: 11),
                                      decoration: BoxDecoration(color: !_longDirection ? const Color(0x22E05252) : Colors.transparent, borderRadius: BorderRadius.circular(10)),
                                      child: const Center(child: Text('SHORT', style: TextStyle(color: Color(0xFFE05252), fontWeight: FontWeight.w900))),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(controller: _entryController, decoration: _fieldDecoration('ENTRY')),
                          const SizedBox(height: 10),
                          GestureDetector(
                            onTap: _pickLeverage,
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                              decoration: BoxDecoration(color: leverageColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(11), border: Border.all(color: leverageColor.withValues(alpha: 0.55))),
                              child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.speed_rounded, color: leverageColor, size: 18), const SizedBox(width: 6), Text('LEVERAGE ${_leverage}x', style: TextStyle(color: leverageColor, fontSize: 10, fontWeight: FontWeight.w900))]),
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(controller: _tp1Controller, decoration: _fieldDecoration('TP1')),
                          const SizedBox(height: 10),
                          TextField(controller: _tp2Controller, decoration: _fieldDecoration('TP2')),
                          const SizedBox(height: 10),
                          TextField(controller: _tp3Controller, decoration: _fieldDecoration('TP3')),
                          const SizedBox(height: 10),
                          TextField(controller: _stopController, decoration: _fieldDecoration('STOPLOSS')),
                        ],
                      ),
                    ),
                    if (_imageBytes != null)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                        child: GestureDetector(
                          onTap: () => showDialog<void>(context: context, builder: (_) => Dialog(backgroundColor: Colors.black, insetPadding: const EdgeInsets.all(12), child: InteractiveViewer(child: Image.memory(_imageBytes!, fit: BoxFit.contain)))),
                          child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.memory(_imageBytes!, width: double.infinity, height: 92, fit: BoxFit.cover)),
                        ),
                      ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(12, 5, 12, 12),
                      child: Row(
                        children: [
                          IconButton(tooltip: 'Add chart or screenshot', onPressed: _pickOriginal, icon: const Icon(Icons.image_outlined, size: 26), color: AppTheme.textSecondary),
                          const SizedBox(width: 7),
                          GestureDetector(
                            onTap: _pickLeverage,
                            child: AnimatedContainer(duration: const Duration(milliseconds: 220), padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7), decoration: BoxDecoration(color: leverageColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10), border: Border.all(color: leverageColor.withValues(alpha: 0.5))), child: Text('LEVERAGE ${_leverage}x', style: TextStyle(color: leverageColor, fontSize: 9, fontWeight: FontWeight.w900))),
                          ),
                          const Spacer(),
                          Icon(Icons.remove_red_eye_outlined, color: AppTheme.textSoft, size: 22),
                          const SizedBox(width: 4),
                          Text('0', style: TextStyle(color: AppTheme.textSoft, fontWeight: FontWeight.w800)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _JellyPlusButton extends StatefulWidget {
  final String tooltip;
  final VoidCallback onPressed;
  final Color color;

  _JellyPlusButton({
    required this.tooltip,
    required this.onPressed,
    this.color = AppTheme.luxuryGold,
  });

  @override
  State<_JellyPlusButton> createState() => _JellyPlusButtonState();
}

class _JellyPlusButtonState extends State<_JellyPlusButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 420),
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _tap() async {
    await _controller.forward(from: 0);
    if (mounted) widget.onPressed();
  }

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: widget.tooltip,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          final jelly = TweenSequence<double>([
            TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.28).chain(CurveTween(curve: Curves.easeOut)), weight: 28),
            TweenSequenceItem(tween: Tween(begin: 1.28, end: 0.88).chain(CurveTween(curve: Curves.easeInOut)), weight: 30),
            TweenSequenceItem(tween: Tween(begin: 0.88, end: 1.08).chain(CurveTween(curve: Curves.elasticOut)), weight: 42),
          ]).evaluate(_controller);
          return Transform.scale(
            scale: jelly,
            child: IconButton(
              onPressed: _tap,
              tooltip: widget.tooltip,
              icon: Icon(Icons.add_circle_outline, color: widget.color, size: 27),
            ),
          );
        },
      ),
    );
  }
}

class _AlphaDenArticleComposerPage extends StatefulWidget {
  const _AlphaDenArticleComposerPage();
  @override State<_AlphaDenArticleComposerPage> createState() => _AlphaDenArticleComposerPageState();
}

class _AlphaDenArticleComposerPageState extends State<_AlphaDenArticleComposerPage> {
  final _title = TextEditingController();
  final _body = TextEditingController();
  final _hashtagController = TextEditingController();
  final _coinController = TextEditingController();
  final List<String> _hashtags = [];
  final List<String> _coins = [];
  Uint8List? _imageBytes;
  bool _bullish = true;

  @override void dispose() { _title.dispose(); _body.dispose(); _hashtagController.dispose(); _coinController.dispose(); super.dispose(); }

  Future<void> _pickImage() async {
    final bytes = await _pickImageBytes();
    if (!mounted) return;
    if (bytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please choose an image under 600 KB.')));
      return;
    }
    setState(() => _imageBytes = bytes);
  }

  void _addHashtag() {
    final raw = _hashtagController.text.trim().replaceAll('#', '');
    if (raw.isEmpty || _hashtags.contains(raw)) return;
    setState(() => _hashtags.add(raw)); _hashtagController.clear();
  }
  void _addCoin() {
    final raw = _coinController.text.trim().replaceAll('\$', '').toUpperCase();
    if (raw.isEmpty || _coins.contains(raw)) return;
    setState(() => _coins.add(raw)); _coinController.clear();
  }

  void _publish() {
    final title = _title.text.trim();
    final body = _body.text.trim();
    if (title.isEmpty || body.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add an article title and content before publishing.')));
      return;
    }
    Navigator.pop(context, _AlphaDenArticle(id: DateTime.now().microsecondsSinceEpoch.toString(), title: title, body: body, imageBytes: _imageBytes, hashtags: List<String>.from(_hashtags), coins: List<String>.from(_coins), bullish: _bullish));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF070B10)),
      appBar: AppBar(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)), surfaceTintColor: Colors.transparent, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios_new), onPressed: () => Navigator.pop(context)),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('ALPHA DEN EDITOR', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5, fontSize: 14)),
            Text('PREMIUM ARTICLE', style: TextStyle(color: AppTheme.textMuted, fontSize: 9, letterSpacing: 1.0)),
          ],
        ),
        actions: [Padding(padding: const EdgeInsets.only(right: 10), child: FilledButton(onPressed: _publish, child: const Text('PUBLISH')))],
      ),
      body: Stack(children: [
        const GalaxyBackground(animatePlanets: true, cinematicEntrance: true),
        SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppTheme.adaptiveSurface(Color(0xD00A1017)),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: const Color(0x554E9FC1)),
              boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 24, offset: Offset(0, 10))],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(Icons.article_outlined, color: Color(0xFF63C7FF), size: 18), SizedBox(width: 8), Text('LONG-FORM MARKET STORY', style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w900, letterSpacing: 1.0, fontSize: 10))]),
              const SizedBox(height: 10),
            TextField(controller: _title, maxLength: 90, decoration: const InputDecoration(labelText: 'ARTICLE TITLE', prefixIcon: Icon(Icons.title_rounded))),
            const SizedBox(height: 8),
            TextField(controller: _body, minLines: 12, maxLines: 20, maxLength: 8000, decoration: const InputDecoration(labelText: 'ARTICLE CONTENT', alignLabelWithHint: true, prefixIcon: Icon(Icons.notes_rounded))),
            if (_imageBytes != null) ...[const SizedBox(height: 12), ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(_imageBytes!, width: double.infinity, height: 190, fit: BoxFit.cover))],
            if (_hashtags.isNotEmpty || _coins.isNotEmpty) ...[const SizedBox(height: 12), Wrap(spacing: 6, runSpacing: 5, children: [for (final tag in _hashtags) InputChip(label: Text('#$tag'), onDeleted: () => setState(() => _hashtags.remove(tag))), for (final coin in _coins) InputChip(label: Text('\$$coin'), onDeleted: () => setState(() => _coins.remove(coin)))])],
          ])),
        ])),
      ]),
      bottomNavigationBar: SafeArea(child: Container(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF0B121A)), border: Border(top: BorderSide(color: AppTheme.fillFaint))), child: Row(children: [
        IconButton(tooltip: 'Add picture', onPressed: _pickImage, icon: Icon(_imageBytes == null ? Icons.image_outlined : Icons.image, color: AppTheme.textSecondary)),
        IconButton(tooltip: 'Add hashtag', onPressed: () async { _hashtagController.clear(); await showDialog<void>(context: context, builder: (c) => AlertDialog(title: const Text('ADD HASHTAG'), content: TextField(controller: _hashtagController, autofocus: true, decoration: const InputDecoration(hintText: '#marketview')), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('CANCEL')), FilledButton(onPressed: () { _addHashtag(); Navigator.pop(c); }, child: const Text('ADD'))])); }, icon: Icon(Icons.tag, color: AppTheme.textSecondary)),
        IconButton(tooltip: 'Add coin', onPressed: () async { _coinController.clear(); await showDialog<void>(context: context, builder: (c) => AlertDialog(title: const Text('ADD COIN'), content: TextField(controller: _coinController, autofocus: true, decoration: const InputDecoration(hintText: 'BTC / ETH / SOL')), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('CANCEL')), FilledButton(onPressed: () { _addCoin(); Navigator.pop(c); }, child: const Text('ADD'))])); }, icon: Icon(Icons.currency_bitcoin, color: AppTheme.textSecondary)),
        const Spacer(),
        SegmentedButton<bool>(segments: const [ButtonSegment<bool>(value: true, label: Text('BULL')), ButtonSegment<bool>(value: false, label: Text('BEAR'))], selected: {_bullish}, onSelectionChanged: (v) => setState(() => _bullish = v.first)),
      ]))),
    );
  }
}

class _JellyCreateChoice extends StatefulWidget {
  final IconData icon;
  final String title;
  final Color color;
  final VoidCallback onTap;

  const _JellyCreateChoice({required this.icon, required this.title, required this.color, required this.onTap});

  @override
  State<_JellyCreateChoice> createState() => _JellyCreateChoiceState();
}

class _JellyCreateChoiceState extends State<_JellyCreateChoice>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 620),
  )..forward();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final scale = Tween<double>(begin: 0.72, end: 1.0).animate(
          CurvedAnimation(parent: _controller, curve: Curves.elasticOut),
        ).value;
        return Transform.scale(
          scale: scale,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: widget.onTap,
              child: Container(
                width: 176,
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10),
                decoration: BoxDecoration(
                  color: AppTheme.adaptiveSurface(Color(0xE50A1017)),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: widget.color.withValues(alpha: 0.30)),
                  boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 14, offset: Offset(0, 6))],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(widget.icon, color: widget.color, size: 18),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        widget.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: widget.color,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(Icons.arrow_forward_ios_rounded, color: widget.color.withValues(alpha: 0.65), size: 11),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _AlphaDenPlusButton extends StatefulWidget {
  final VoidCallback onPressed;
  const _AlphaDenPlusButton({required this.onPressed});

  @override
  State<_AlphaDenPlusButton> createState() => _AlphaDenPlusButtonState();
}

class _AlphaDenPlusButtonState extends State<_AlphaDenPlusButton>
    with TickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
  )..repeat(reverse: true);
  late final AnimationController _pressController = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 420),
  );

  @override
  void dispose() {
    _controller.dispose();
    _pressController.dispose();
    super.dispose();
  }

  Future<void> _tap() async {
    await _pressController.forward(from: 0);
    if (mounted) widget.onPressed();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_controller, _pressController]),
      builder: (_, _) {
        final pulse = 0.97 + (_controller.value * 0.035);
        final jelly = TweenSequence<double>([
          TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.24).chain(CurveTween(curve: Curves.easeOut)), weight: 28),
          TweenSequenceItem(tween: Tween(begin: 1.24, end: 0.88).chain(CurveTween(curve: Curves.easeInOut)), weight: 30),
          TweenSequenceItem(tween: Tween(begin: 0.88, end: 1.0).chain(CurveTween(curve: Curves.elasticOut)), weight: 42),
        ]).evaluate(_pressController);
        return Transform.scale(
          scale: pulse * jelly,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: _tap,
              customBorder: const CircleBorder(),
              child: Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.luxuryGold.withValues(alpha: 0.68),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.luxuryGold.withValues(alpha: 0.32),
                      blurRadius: 24,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Icon(Icons.add, color: AppTheme.adaptiveSurface(Color(0xFF11151A)), size: 31),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _AlphaDenPostComposerPage extends StatefulWidget {
  const _AlphaDenPostComposerPage();

  @override
  State<_AlphaDenPostComposerPage> createState() => _AlphaDenPostComposerPageState();
}

class _AlphaDenPostComposerPageState extends State<_AlphaDenPostComposerPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _ideaController = TextEditingController();
  final TextEditingController _hashtagController = TextEditingController();
  final TextEditingController _coinController = TextEditingController();
  final List<String> _hashtags = [];
  final List<String> _coins = [];
  Uint8List? _imageBytes;
  Uint8List? _thumbnailBytes;
  bool _bullish = true;
  late final AnimationController _entryController = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 700),
  )..forward();

  @override
  void dispose() {
    _entryController.dispose();
    _ideaController.dispose();
    _hashtagController.dispose();
    _coinController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final bytes = await _pickImageBytes();
    if (!mounted) return;
    if (bytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please choose an image under 600 KB.')));
      return;
    }
    setState(() => _imageBytes = bytes);
  }

  void _addHashtag() {
    final raw = _hashtagController.text.trim().replaceAll('#', '');
    if (raw.isEmpty || _hashtags.contains(raw)) return;
    setState(() => _hashtags.add(raw));
    _hashtagController.clear();
  }

  void _addCoin() {
    final raw = _coinController.text.trim().replaceAll('\$', '').toUpperCase();
    if (raw.isEmpty || _coins.contains(raw)) return;
    setState(() => _coins.add(raw));
    _coinController.clear();
  }

  void _publish() {
    if (_ideaController.text.trim().isEmpty && _imageBytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Add an idea or an image before posting.')),
      );
      return;
    }
    Navigator.pop(
      context,
      _AlphaDenPost(
        text: _ideaController.text.trim(),
        imageBytes: _imageBytes,
        thumbnailBytes: _thumbnailBytes,
        bullish: _bullish,
        hashtags: List<String>.from(_hashtags),
        coins: List<String>.from(_coins),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      child: Scaffold(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF140A25)),
        appBar: AppBar(
          backgroundColor: AppTheme.adaptiveSurface(Color(0xFF140A25)),
          elevation: 0,
          surfaceTintColor: Colors.transparent,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('IDEA STUDIO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4, fontSize: 14)),
              Text('POST NEW IDEA', style: TextStyle(color: AppTheme.textMuted, fontSize: 9, letterSpacing: 1.0)),
            ],
          ),
          leading: IconButton(
            tooltip: 'Back',
            icon: const Icon(Icons.arrow_back_ios_new, size: 20),
            onPressed: () => Navigator.of(context).maybePop(),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 12, top: 9, bottom: 9),
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF3A3150),
                  foregroundColor: AppTheme.textPrimary,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                onPressed: _publish,
                child: const Text('POST', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      body: Stack(
        children: [
          const _PurpleGalaxyComposerBackground(),
          SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _entryController, curve: Curves.easeOut),
              child: SlideTransition(
                position: Tween<Offset>(begin: const Offset(0, 0.045), end: Offset.zero).animate(
                  CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
                ),
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: const Color(0xD91A102B),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0x775F3AA8)),
                        boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 24, offset: Offset(0, 10))],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [Icon(Icons.auto_awesome_rounded, color: AppTheme.luxuryGold, size: 17), SizedBox(width: 8), Text('MARKET THOUGHT', style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w900, letterSpacing: 1.0, fontSize: 10))]),
                          const SizedBox(height: 10),
                          TextField(
                        controller: _ideaController,
                        minLines: 7,
                        maxLines: 12,
                        maxLength: 1200,
                            decoration: InputDecoration(
                              hintText: 'Share your idea, setup, analysis or market view…',
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: AppTheme.textFaint),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text('Keep the thesis clear, actionable and easy to scan.', style: TextStyle(color: AppTheme.textFaint, fontSize: 10)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (_imageBytes != null) ...[
                      ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: Image.memory(_imageBytes!, width: double.infinity, height: 230, fit: BoxFit.cover),
                      ),
                      const SizedBox(height: 14),
                    ],
                    if (_hashtags.isNotEmpty || _coins.isNotEmpty) ...[
                      Wrap(
                        spacing: 7,
                        runSpacing: 7,
                        children: [
                          for (final tag in _hashtags) InputChip(label: Text('#$tag'), onDeleted: () => setState(() => _hashtags.remove(tag))),
                          for (final coin in _coins) InputChip(label: Text('\$$coin'), onDeleted: () => setState(() => _coins.remove(coin))),
                        ],
                      ),
                      const SizedBox(height: 14),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
        bottomNavigationBar: SafeArea(
          child: _ComposerBottomBar(
            bullish: _bullish,
            hasImage: _imageBytes != null,
            onImage: _pickImage,
            onBullishChanged: (value) => setState(() => _bullish = value),
            onHashtags: _showHashtagDialog,
            onCoins: _showCoinDialog,
          ),
        ),
      ),
    );
  }

  Future<void> _showHashtagDialog() async {
    _hashtagController.clear();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF1A102B)),
        title: const Text('ADD HASHTAG'),
        content: TextField(controller: _hashtagController, autofocus: true, onSubmitted: (_) { _addHashtag(); Navigator.pop(dialogContext); }, decoration: const InputDecoration(hintText: '#marketview')),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')), ElevatedButton(onPressed: () { _addHashtag(); Navigator.pop(dialogContext); }, child: const Text('ADD'))],
      ),
    );
  }

  Future<void> _showCoinDialog() async {
    _coinController.clear();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF1A102B)),
        title: const Text('ADD COIN TAG'),
        content: TextField(controller: _coinController, autofocus: true, onSubmitted: (_) { _addCoin(); Navigator.pop(dialogContext); }, decoration: const InputDecoration(hintText: 'BTC / ETH / SOL')),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')), ElevatedButton(onPressed: () { _addCoin(); Navigator.pop(dialogContext); }, child: const Text('ADD'))],
      ),
    );
  }
}

class _ComposerBottomBar extends StatelessWidget {
  final bool bullish;
  final bool hasImage;
  final VoidCallback onImage;
  final ValueChanged<bool> onBullishChanged;
  final VoidCallback onHashtags;
  final VoidCallback onCoins;

  const _ComposerBottomBar({
    required this.bullish,
    required this.hasImage,
    required this.onImage,
    required this.onBullishChanged,
    required this.onHashtags,
    required this.onCoins,
  });

  Widget _compactButton({
    required IconData icon,
    required VoidCallback onPressed,
    bool active = false,
    String? tooltip,
  }) {
    return SizedBox(
      width: 42,
      height: 38,
      child: IconButton(
        tooltip: tooltip,
        onPressed: onPressed,
        padding: EdgeInsets.zero,
        iconSize: 21,
        style: IconButton.styleFrom(
          backgroundColor: active ? const Color(0xFF25212D) : const Color(0xFF17131E),
          foregroundColor: active ? AppTheme.textPrimary : const Color(0xFFD2CDD9),
          side: const BorderSide(color: Color(0xFF312A3B)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        icon: Icon(icon),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
      decoration: const BoxDecoration(
        color: Color(0xFF0F0C15),
        border: Border(top: BorderSide(color: Color(0xFF2C2635))),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _compactButton(
                icon: hasImage ? Icons.image : Icons.image_outlined,
                onPressed: onImage,
                active: hasImage,
                tooltip: 'Add picture',
              ),
              const SizedBox(width: 7),
              Container(
                width: 92,
                height: 38,
                padding: const EdgeInsets.symmetric(horizontal: 5),
                decoration: BoxDecoration(
                  color: (bullish ? const Color(0xFF2E9D68) : const Color(0xFFC63D3D)).withValues(alpha: 0.10),
                  border: Border.all(
                    color: (bullish ? const Color(0xFF49C985) : const Color(0xFFE05252)).withValues(alpha: 0.42),
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Text(
                      bullish ? 'BULL' : 'BEAR',
                      style: TextStyle(
                        color: bullish ? const Color(0xFF49C985) : const Color(0xFFE05252),
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Expanded(
                      child: Switch(
                        value: bullish,
                        onChanged: onBullishChanged,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        activeThumbColor: const Color(0xFF49C985),
                        activeTrackColor: const Color(0x552E9D68),
                        inactiveThumbColor: const Color(0xFFE05252),
                        inactiveTrackColor: const Color(0x55C63D3D),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 7),
              _compactButton(
                icon: Icons.tag,
                onPressed: onHashtags,
                tooltip: 'Hashtags',
              ),
              const SizedBox(width: 7),
              _compactButton(
                icon: Icons.currency_bitcoin,
                onPressed: onCoins,
                tooltip: 'Coin tags',
              ),
            ],
          ),
          const Spacer(),
          const Padding(
            padding: EdgeInsets.only(right: 5),
            child: Icon(
              Icons.visibility_outlined,
              size: 22,
              color: Color(0xFFD2CDD9),
            ),
          ),
        ],
      ),
    );
  }
}

class _PurpleGalaxyComposerBackground extends StatefulWidget {
  const _PurpleGalaxyComposerBackground();
  @override
  State<_PurpleGalaxyComposerBackground> createState() => _PurpleGalaxyComposerBackgroundState();
}

class _PurpleGalaxyComposerBackgroundState extends State<_PurpleGalaxyComposerBackground> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(seconds: 7))..repeat();
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _controller,
    builder: (_, _) => Container(
      decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF12091F), Color(0xFF24104A), Color(0xFF0B0615)])),
      child: CustomPaint(painter: _ComposerStarsPainter(_controller.value), child: const SizedBox.expand()),
    ),
  );
}

class _ComposerStarsPainter extends CustomPainter {
  final double progress;
  _ComposerStarsPainter(this.progress);
  @override
  void paint(Canvas canvas, Size size) {
    final random = math.Random(77);
    final paint = Paint()..style = PaintingStyle.fill;
    for (int i = 0; i < 95; i++) {
      final x = random.nextDouble() * size.width;
      final baseY = random.nextDouble() * size.height;
      final y = (baseY + progress * 20 * ((i % 3) + 1)) % size.height;
      final twinkle = 0.35 + 0.65 * (0.5 + 0.5 * math.sin(progress * math.pi * 2 * ((i % 4) + 1) + i));
      paint.color = AppTheme.adaptiveWhite(alpha: twinkle * (i % 5 == 0 ? 0.9 : 0.45));
      canvas.drawCircle(Offset(x, y), i % 7 == 0 ? 1.5 : 0.8, paint);
    }
    final glow = Paint()..shader = RadialGradient(colors: [const Color(0x665F3AA8), const Color(0x00120A20)]).createShader(Rect.fromCircle(center: Offset(size.width * 0.62, size.height * 0.38), radius: size.width * 0.55));
    canvas.drawCircle(Offset(size.width * 0.62, size.height * 0.38), size.width * 0.55, glow);
  }
  @override
  bool shouldRepaint(covariant _ComposerStarsPainter oldDelegate) => oldDelegate.progress != progress;
}

String _alphaArticleFeedPostId(String sourceId) {
  final safeId = sourceId.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
  return 'article_$safeId';
}

class _AlphaDenArticle {
  final String id;
  final String title;
  final String body;
  final Uint8List? imageBytes;
  final List<String> hashtags;
  final List<String> coins;
  final bool bullish;
  int likes;
  int comments;
  int reposts;
  _AlphaDenArticle({required this.id, required this.title, required this.body, this.imageBytes, this.hashtags = const [], this.coins = const [], this.bullish = true, this.likes = 0, this.comments = 0, this.reposts = 0});
}

class _AlphaDenRepost {
  final String id;
  final String originalPostId;
  final String originalAuthorUid;
  final String sourceType;
  final String sourceId;
  final String text;
  final Uint8List? imageBytes;
  final bool bullish;
  final List<String> hashtags;
  final List<String> coins;
  final String? articleTitle;
  final String? articleBody;
  final String? signalAsset;
  final String? signalEntry;
  final bool? signalLongDirection;
  final int? signalLeverage;
  final String? signalTp1;
  final String? signalTp2;
  final String? signalTp3;
  final String? signalStopLoss;
  final bool tp1Hit, tp2Hit, tp3Hit, stopLossHit, breakEven, winTradeCounted;
  final String tp1Profit, tp2Profit, tp3Profit, stopLossProfit, breakEvenProfit;
  final Uint8List? winResultImageBytes;
  final int winTrades;
  final DateTime createdAt;

  const _AlphaDenRepost({this.id = '', required this.originalPostId, this.originalAuthorUid = '', this.sourceType = '', this.sourceId = '', required this.text, this.imageBytes, this.bullish = true, this.hashtags = const [], this.coins = const [], this.articleTitle, this.articleBody, this.signalAsset, this.signalEntry, this.signalLongDirection, this.signalLeverage, this.signalTp1, this.signalTp2, this.signalTp3, this.signalStopLoss, this.tp1Hit = false, this.tp2Hit = false, this.tp3Hit = false, this.stopLossHit = false, this.breakEven = false, this.winTradeCounted = false, this.tp1Profit = '', this.tp2Profit = '', this.tp3Profit = '', this.stopLossProfit = '', this.breakEvenProfit = '', this.winResultImageBytes, this.winTrades = 0, required this.createdAt});

  factory _AlphaDenRepost.fromMap(Map<String, dynamic> data) {
    Uint8List? bytes;
    final encoded = (data['imageBase64'] ?? '').toString();
    if (encoded.isNotEmpty) {
      try { bytes = base64Decode(encoded); } catch (_) {}
    }
    final ts = data['createdAt'];
    return _AlphaDenRepost(
      id: (data['id'] ?? '').toString(),
      originalPostId: (data['originalPostId'] ?? '').toString(),
      originalAuthorUid: (data['originalAuthorUid'] ?? '').toString(),
      sourceType: (data['sourceType'] ?? '').toString(),
      sourceId: (data['sourceId'] ?? '').toString(),
      text: (data['text'] ?? '').toString(),
      imageBytes: bytes,
      bullish: data['bullish'] != false,
      hashtags: List<String>.from((data['hashtags'] as List?) ?? const []),
      coins: List<String>.from((data['coins'] as List?) ?? const []),
      articleTitle: data['articleTitle']?.toString(),
      articleBody: data['articleBody']?.toString(),
      signalAsset: data['signalAsset']?.toString(),
      signalEntry: data['signalEntry']?.toString(),
      signalLongDirection: data['signalLongDirection'] is bool ? data['signalLongDirection'] as bool : null,
      signalLeverage: data['signalLeverage'] is num ? (data['signalLeverage'] as num).toInt() : null,
      signalTp1: data['signalTp1']?.toString(),
      signalTp2: data['signalTp2']?.toString(),
      signalTp3: data['signalTp3']?.toString(),
      signalStopLoss: data['signalStopLoss']?.toString(),
      tp1Hit: data['tp1Hit'] == true, tp2Hit: data['tp2Hit'] == true, tp3Hit: data['tp3Hit'] == true, stopLossHit: data['stopLossHit'] == true, breakEven: data['breakEven'] == true, winTradeCounted: data['winTradeCounted'] == true,
      tp1Profit: (data['tp1Profit'] ?? '').toString(), tp2Profit: (data['tp2Profit'] ?? '').toString(), tp3Profit: (data['tp3Profit'] ?? '').toString(), stopLossProfit: (data['stopLossProfit'] ?? '').toString(), breakEvenProfit: (data['breakEvenProfit'] ?? '').toString(), winResultImageBytes: (data['winResultImageBase64'] is String && (data['winResultImageBase64'] as String).isNotEmpty) ? _tryDecodeBase64(data['winResultImageBase64'] as String) : null, winTrades: (data['winTrades'] ?? 0) is num ? (data['winTrades'] as num).toInt() : 0,
      createdAt: ts is Timestamp ? ts.toDate() : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => <String, dynamic>{
    'originalAuthorUid': originalAuthorUid, 'sourceType': sourceType, 'sourceId': sourceId, 'text': text,
    'bullish': bullish, 'hashtags': hashtags, 'coins': coins, 'articleTitle': articleTitle, 'articleBody': articleBody,
    'signalAsset': signalAsset, 'signalEntry': signalEntry, 'signalLongDirection': signalLongDirection, 'signalLeverage': signalLeverage,
    'signalTp1': signalTp1, 'signalTp2': signalTp2, 'signalTp3': signalTp3, 'signalStopLoss': signalStopLoss,
    'tp1Hit': tp1Hit, 'tp2Hit': tp2Hit, 'tp3Hit': tp3Hit, 'stopLossHit': stopLossHit, 'breakEven': breakEven, 'winTradeCounted': winTradeCounted, 'tp1Profit': tp1Profit, 'tp2Profit': tp2Profit, 'tp3Profit': tp3Profit, 'stopLossProfit': stopLossProfit, 'breakEvenProfit': breakEvenProfit, if (winResultImageBytes != null) 'winResultImageBase64': base64Encode(winResultImageBytes!), 'winTrades': winTrades,
    if (imageBytes != null) 'imageBase64': base64Encode(imageBytes!),
  };
}

class _AlphaDenRepostsPage extends StatelessWidget {
  final List<_AlphaDenRepost> items;
  final ValueChanged<_AlphaDenRepost> onDelete;
  const _AlphaDenRepostsPage({required this.items, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const _AlphaDenEmptyState(icon: Icons.repeat_rounded, title: 'NO REPOSTS YET', subtitle: 'Reposted Ideas, Signals and Articles will collect here.');
    return ListView.separated(
      padding: const EdgeInsets.only(bottom: 24),
      itemCount: items.length,
      separatorBuilder: (_, _) => const SizedBox(height: 12),
      itemBuilder: (context, index) => _AlphaDenRepostCard(item: items[index], onDelete: () => onDelete(items[index])),
    );
  }
}

class _AlphaDenRepostCard extends StatefulWidget {
  final _AlphaDenRepost item;
  final VoidCallback onDelete;
  const _AlphaDenRepostCard({required this.item, required this.onDelete});
  @override State<_AlphaDenRepostCard> createState() => _AlphaDenRepostCardState();
}

class _AlphaDenRepostCardState extends State<_AlphaDenRepostCard> {
  bool liked = false;
  int repostCount = 0;
  bool loadingCount = true;

  @override
  void initState() { super.initState(); _loadCount(); }
  Future<void> _loadCount() async {
    try { repostCount = await AlphaDenService.repostCount(widget.item.originalPostId); }
    catch (_) {}
    if (mounted) setState(() => loadingCount = false);
  }
  Future<void> _openComments() async {
    final added = await _showFeedCommentsSheet(context, postId: widget.item.originalPostId, authorUid: widget.item.originalAuthorUid);
    if (added > 0 && mounted) setState(() {});
  }
  Future<void> _report() => _openContentReportSupportPage(context, postId: widget.item.originalPostId, authorUid: widget.item.originalAuthorUid);

  @override
  Widget build(BuildContext context) {
    final signal = widget.item.signalAsset != null;
    final article = widget.item.sourceType == 'article';
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: signal
          ? BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF303238)), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0x334E9FC1)))
          : _regularPostGlassDecoration(borderColor: const Color(0xFF4E9FC1), radius: 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(article ? Icons.article_outlined : signal ? Icons.candlestick_chart_outlined : Icons.repeat_rounded, color: AppTheme.luxuryGold, size: 17), const SizedBox(width: 7), Text(article ? 'REPOSTED ARTICLE' : signal ? 'REPOSTED SIGNAL' : 'REPOSTED IDEA', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .9)), const Spacer(), IconButton(visualDensity: VisualDensity.compact, onPressed: widget.onDelete, icon: Icon(Icons.delete_outline, color: AppTheme.textMuted, size: 18))]),
        const SizedBox(height: 8),
        if (article && (widget.item.articleTitle ?? '').isNotEmpty) Text(widget.item.articleTitle!, style: TextStyle(color: AppTheme.textPrimary, fontSize: 16, fontWeight: FontWeight.w900)),
        if (signal) ...[
          Row(children: [Expanded(child: Text('${widget.item.signalAsset} /USDT', style: TextStyle(color: AppTheme.textPrimary, fontSize: 18, fontWeight: FontWeight.w900))), _LiveCallBadge(text: widget.item.signalLongDirection == true ? 'LONG' : 'SHORT', color: widget.item.signalLongDirection == true ? AppTheme.neonGreen : const Color(0xFFE05252))]),
          const SizedBox(height: 8),
          _LiveCallValueRow(label: 'ENTRY', value: widget.item.signalEntry ?? ''),
          _LiveCallValueRow(label: 'LEVERAGE', value: '${widget.item.signalLeverage ?? 10}x'),
          _LiveCallValueRow(label: 'TP1', value: widget.item.signalTp1 ?? ''),
          _LiveCallValueRow(label: 'TP2', value: widget.item.signalTp2 ?? ''),
          _LiveCallValueRow(label: 'TP3', value: widget.item.signalTp3 ?? ''),
          _LiveCallValueRow(label: 'STOPLOSS', value: widget.item.signalStopLoss ?? '', warning: true),
        ] else Text(article ? (widget.item.articleBody ?? '') : widget.item.text, style: TextStyle(color: AppTheme.textSecondary, fontSize: 13, height: 1.45)),
        if (widget.item.winResultImageBytes != null && (widget.item.tp1Hit || widget.item.tp2Hit || widget.item.tp3Hit)) ...[
          const SizedBox(height: 8),
          GestureDetector(onTap: () => showDialog<void>(context: context, builder: (_) => Dialog(backgroundColor: Colors.black, insetPadding: const EdgeInsets.all(12), child: InteractiveViewer(child: Image.memory(widget.item.winResultImageBytes!, fit: BoxFit.contain)))), child: ClipRRect(borderRadius: BorderRadius.circular(9), child: Image.memory(widget.item.winResultImageBytes!, width: 105, height: 72, fit: BoxFit.cover))),
        ],
        if (widget.item.imageBytes != null) ...[const SizedBox(height: 10), ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(widget.item.imageBytes!, width: double.infinity, height: 190, fit: BoxFit.cover))],
        if (widget.item.hashtags.isNotEmpty || widget.item.coins.isNotEmpty) ...[const SizedBox(height: 8), Wrap(spacing: 6, children: [for (final tag in widget.item.hashtags) Text('#$tag', style: const TextStyle(color: Color(0xFFB28CFF), fontSize: 10)), for (final coin in widget.item.coins) Text('\$$coin', style: TextStyle(color: AppTheme.luxuryGold, fontSize: 10))])],
        const SizedBox(height: 8),
        Row(children: [IconButton(visualDensity: VisualDensity.compact, onPressed: () => setState(() => liked = !liked), icon: Icon(liked ? Icons.favorite : Icons.favorite_border, color: liked ? const Color(0xFFFF3B4D) : AppTheme.textSecondary, size: 19)), Text(liked ? 'Liked' : 'Like', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)), const SizedBox(width: 8), IconButton(visualDensity: VisualDensity.compact, onPressed: _openComments, icon: Icon(Icons.comment_outlined, color: AppTheme.textSecondary, size: 19)), Text('Comment', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)), const SizedBox(width: 8), Icon(Icons.repeat_rounded, color: AppTheme.luxuryGold, size: 17), const SizedBox(width: 3), Text(loadingCount ? '…' : '$repostCount', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)), const Spacer(), IconButton(visualDensity: VisualDensity.compact, onPressed: _report, icon: Icon(Icons.flag_outlined, color: AppTheme.textMuted, size: 18))]),
      ]),
    );
  }
}

class _AlphaDenSectionTabs extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  const _AlphaDenSectionTabs({required this.currentIndex, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final labels = ['IDEAS', 'SIGNALS', 'ARTICLES', 'REPOSTS'];
    final icons = [Icons.lightbulb_outline, Icons.candlestick_chart_outlined, Icons.article_outlined, Icons.repeat_rounded];
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xB80A1017)), borderRadius: BorderRadius.circular(18), border: Border.all(color: AppTheme.luxuryGold.withValues(alpha: 0.16))),
      child: Row(children: [for (int i = 0; i < 4; i++) Expanded(child: GestureDetector(
        onTap: () => onTap(i),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 260),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(color: currentIndex == i ? AppTheme.adaptiveWhite(alpha: 0.075) : Colors.transparent, borderRadius: BorderRadius.circular(13)),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icons[i], size: 16, color: currentIndex == i ? AppTheme.luxuryGold : AppTheme.textMuted), const SizedBox(width: 6), Text(labels[i], style: TextStyle(color: currentIndex == i ? AppTheme.textPrimary : AppTheme.textMuted, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.0))]),
        ),
      ))]),
    );
  }
}

class _AlphaDenIdeasPage extends StatelessWidget {
  final List<_AlphaDenPost> ideas;
  final Set<int> likedIdeas;
  final ValueChanged<int> onLike;
  final ValueChanged<int> onRepost;
  const _AlphaDenIdeasPage({required this.ideas, required this.likedIdeas, required this.onLike, required this.onRepost});
  @override
  Widget build(BuildContext context) {
    final items = <_AlphaDenPost>[];
    for (final post in ideas) { if (!post.isSignal) items.add(post); }
    if (items.isEmpty) return const _AlphaDenEmptyState(icon: Icons.lightbulb_outline, title: 'NO IDEAS YET', subtitle: 'Your published ideas will appear here.');
    return ListView.builder(physics: const BouncingScrollPhysics(), padding: const EdgeInsets.only(bottom: 20), itemCount: items.length, itemBuilder: (_, i) {
      final post = items[i];
      final originalIndex = ideas.indexOf(post);
      return _AlphaDenSinglePostCard(
        key: ValueKey<String>('alpha-idea-${post.id.isEmpty ? originalIndex : post.id}'),
        post: post,
        liked: likedIdeas.contains(originalIndex),
        onLike: () => onLike(originalIndex),
        onRepost: () => onRepost(originalIndex),
        onComment: () async { await _showFeedCommentsSheet(context, postId: post.id, authorUid: post.authorUid); },
        onOptions: () => (context.findAncestorStateOfType<_AlphaDenPageState>())?._showAlphaPostActions(post),
        label: 'IDEA',
        winTrades: (context.findAncestorStateOfType<_AlphaDenPageState>())?.winTrades ?? 0,
      );
    });
  }
}

class _AlphaDenSignalsPage extends StatelessWidget {
  final List<_AlphaDenPost> signals;
  final ValueChanged<int> onRepost;
  const _AlphaDenSignalsPage({required this.signals, required this.onRepost});
  @override
  Widget build(BuildContext context) {
    if (signals.isEmpty) return const _AlphaDenEmptyState(icon: Icons.candlestick_chart_outlined, title: 'NO SIGNALS YET', subtitle: 'Your published signals will appear here.');
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.only(bottom: 20),
      itemCount: signals.length,
      itemBuilder: (_, i) => _AlphaDenSinglePostCard(
        key: ValueKey<String>('alpha-signal-${signals[i].id.isEmpty ? i : signals[i].id}'),
        post: signals[i],
        liked: false,
        onLike: () {},
        onRepost: () => onRepost(i),
        onComment: () async { await _showFeedCommentsSheet(context, postId: signals[i].id, authorUid: signals[i].authorUid); },
        onOptions: () => (context.findAncestorStateOfType<_AlphaDenPageState>())?._showAlphaPostActions(signals[i]),
        label: 'SIGNAL',
        winTrades: (context.findAncestorStateOfType<_AlphaDenPageState>())?.winTrades ?? 0,
      ),
    );
  }
}

class _AlphaDenArticlesPage extends StatelessWidget {
  final List<_AlphaDenArticle> articles;
  final Set<String> likedArticles;
  final ValueChanged<String> onLike;
  final ValueChanged<String> onRepost;
  const _AlphaDenArticlesPage({required this.articles, required this.likedArticles, required this.onLike, required this.onRepost});

  void _openArticle(BuildContext context, _AlphaDenArticle article) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => _AlphaDenArticleReaderPage(article: article)));
  }

  @override
  Widget build(BuildContext context) {
    if (articles.isEmpty) return const _AlphaDenEmptyState(icon: Icons.article_outlined, title: 'NO ARTICLES YET', subtitle: 'Your published articles will appear here.');
    return ListView.builder(
      physics: const BouncingScrollPhysics(), padding: const EdgeInsets.only(bottom: 20), itemCount: articles.length,
      itemBuilder: (_, i) {
        final article = articles[i];
        final liked = likedArticles.contains(article.id);
        return Container(
          margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(15),
          decoration: _regularPostGlassDecoration(borderColor: const Color(0xFF4E9FC1), radius: 18),
          child: InkWell(
            borderRadius: BorderRadius.circular(14), onTap: () => _openArticle(context, article),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [const Icon(Icons.article_outlined, color: Color(0xFF63C7FF), size: 17), const SizedBox(width: 7), const Text('ARTICLE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.0)), const Spacer(), Text(article.bullish ? 'BULL' : 'BEAR', style: TextStyle(color: article.bullish ? AppTheme.neonGreen : const Color(0xFFE05252), fontSize: 9, fontWeight: FontWeight.w900)), const SizedBox(width: 6), IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 24, minHeight: 24), onPressed: () => _openContentReportSupportPage(context, postId: _alphaArticleFeedPostId(article.id), authorUid: _articleAuthorUid(article)), icon: Icon(Icons.flag_outlined, color: AppTheme.textMuted, size: 16)),
              IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 24, minHeight: 24), onPressed: () => (context.findAncestorStateOfType<_AlphaDenPageState>())?._showAlphaArticleActions(article), icon: Icon(Icons.more_horiz, color: AppTheme.textMuted, size: 17))]),
              const SizedBox(height: 10),
              Text(article.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              Text(article.body, maxLines: 7, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppTheme.textSecondary, height: 1.5, fontSize: 13)),
              if (article.imageBytes != null) ...[const SizedBox(height: 9), ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(article.imageBytes!, width: 92, height: 92, fit: BoxFit.cover))],
              if (article.hashtags.isNotEmpty || article.coins.isNotEmpty) ...[const SizedBox(height: 8), Wrap(spacing: 6, runSpacing: 4, children: [for (final tag in article.hashtags) Text('#$tag', style: TextStyle(color: AppTheme.textMuted, fontSize: 9, fontWeight: FontWeight.w600)), for (final coin in article.coins) Text('\$$coin', style: TextStyle(color: AppTheme.textMuted, fontSize: 9, fontWeight: FontWeight.w600))])],
              const SizedBox(height: 7),
              Row(children: [
                IconButton(visualDensity: const VisualDensity(horizontal: -3, vertical: -3), padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 28, minHeight: 28), onPressed: () => onLike(article.id), icon: Icon(liked ? Icons.favorite : Icons.favorite_border, size: 17, color: liked ? const Color(0xFFFF3B4D) : AppTheme.textSecondary)),
                Text('${article.likes}', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)),
                const SizedBox(width: 6),
                IconButton(visualDensity: const VisualDensity(horizontal: -3, vertical: -3), padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 28, minHeight: 28), onPressed: () => _openArticle(context, article), icon: Icon(Icons.comment_outlined, size: 17, color: AppTheme.textSecondary)),
                Text('${article.comments}', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)),
                const SizedBox(width: 6),
                IconButton(visualDensity: const VisualDensity(horizontal: -3, vertical: -3), padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 28, minHeight: 28), onPressed: () => onRepost(article.id), icon: Icon(Icons.repeat, size: 17, color: AppTheme.textSecondary)),
                Text('${article.reposts}', style: TextStyle(color: AppTheme.textSecondary, fontSize: 10)),
                const Spacer(),
                Icon(Icons.arrow_forward_ios_rounded, color: AppTheme.textVeryFaint, size: 12),
              ]),
              const SizedBox(height: 2),
              Text('Tap to read full article', style: TextStyle(color: AppTheme.textVeryFaint, fontSize: 9, fontWeight: FontWeight.w700)),
            ]),
          ),
        );
      },
    );
  }
}

class _AlphaDenArticleReaderPage extends StatefulWidget {
  final _AlphaDenArticle article;
  const _AlphaDenArticleReaderPage({required this.article});
  @override State<_AlphaDenArticleReaderPage> createState() => _AlphaDenArticleReaderPageState();
}

class _AlphaDenArticleReaderPageState extends State<_AlphaDenArticleReaderPage> {
  bool liked = false;
  @override
  Widget build(BuildContext context) {
    final article = widget.article;
    return Scaffold(
      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF070B10)),
      appBar: AppBar(title: const Text('ARTICLE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2))),
      body: ListView(padding: const EdgeInsets.fromLTRB(18, 12, 18, 28), children: [
        Text(article.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, height: 1.15)),
        const SizedBox(height: 8),
        Row(children: [Text(article.bullish ? 'BULLISH' : 'BEARISH', style: TextStyle(color: article.bullish ? AppTheme.neonGreen : const Color(0xFFE05252), fontSize: 10, fontWeight: FontWeight.w900)), const Spacer(), Text('ALPHA DEN', style: TextStyle(color: AppTheme.textFaint, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.0))]),
        if (article.imageBytes != null) ...[const SizedBox(height: 14), ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.memory(article.imageBytes!, width: double.infinity, height: 220, fit: BoxFit.cover))],
        const SizedBox(height: 16),
        Text(article.body, style: TextStyle(color: AppTheme.textPrimary, fontSize: 14, height: 1.65)),
        if (article.hashtags.isNotEmpty || article.coins.isNotEmpty) ...[const SizedBox(height: 14), Wrap(spacing: 7, runSpacing: 5, children: [for (final tag in article.hashtags) Text('#$tag', style: TextStyle(color: AppTheme.textMuted, fontSize: 10)), for (final coin in article.coins) Text('\$$coin', style: TextStyle(color: AppTheme.textMuted, fontSize: 10))])],
        const SizedBox(height: 12),
        Row(children: [IconButton(onPressed: () => setState(() { liked = !liked; article.likes += liked ? 1 : -1; }), icon: Icon(liked ? Icons.favorite : Icons.favorite_border, color: liked ? const Color(0xFFFF3B4D) : AppTheme.textSecondary)), Text('${article.likes}', style: TextStyle(color: AppTheme.textSecondary)), const SizedBox(width: 8), IconButton(onPressed: () async { final added = await _showFeedCommentsSheet(context, postId: _alphaArticleFeedPostId(article.id), authorUid: _articleAuthorUid(article)); if (added > 0 && mounted) setState(() => article.comments += added); }, icon: Icon(Icons.comment_outlined, color: AppTheme.textSecondary)), Text('${article.comments}', style: TextStyle(color: AppTheme.textSecondary)), const SizedBox(width: 8), IconButton(onPressed: () => setState(() => article.reposts += 1), icon: Icon(Icons.repeat, color: AppTheme.textSecondary)), Text('${article.reposts}', style: TextStyle(color: AppTheme.textSecondary)), const Spacer(), IconButton(onPressed: () => _openContentReportSupportPage(context, postId: _alphaArticleFeedPostId(article.id), authorUid: _articleAuthorUid(article)), icon: Icon(Icons.flag_outlined, color: AppTheme.textMuted))]),
      ]),
    );
  }
}


double _parseSignalPercent(String value) {
  final cleaned = value.replaceAll('%', '').replaceAll('+', '').trim();
  return double.tryParse(cleaned) ?? 0;
}

String _averageHitProfit({required bool tp1Hit, required bool tp2Hit, required bool tp3Hit, required String tp1Profit, required String tp2Profit, required String tp3Profit}) {
  final values = <double>[];
  if (tp1Hit) values.add(_parseSignalPercent(tp1Profit));
  if (tp2Hit) values.add(_parseSignalPercent(tp2Profit));
  if (tp3Hit) values.add(_parseSignalPercent(tp3Profit));
  if (values.isEmpty) return '';
  final avg = values.reduce((a, b) => a + b) / values.length;
  final rounded = avg.roundToDouble() == avg ? avg.toStringAsFixed(0) : avg.toStringAsFixed(1);
  return '+$rounded%';
}

Widget _signalTargetRow({required String label, required String value, bool warning = false, bool hit = false, String profit = ''}) => Padding(
  padding: const EdgeInsets.symmetric(vertical: 4),
  child: Row(children: [
    SizedBox(width: 76, child: Text(label, style: TextStyle(color: warning ? const Color(0xFFE05252) : AppTheme.textMuted, fontSize: 10, fontWeight: FontWeight.w900))),
    Expanded(child: Text(value, style: TextStyle(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w800))),
    if (hit) Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3), decoration: BoxDecoration(color: (warning ? const Color(0xFFE05252) : const Color(0xFF39E75F)).withValues(alpha: .14), borderRadius: BorderRadius.circular(6), border: Border.all(color: warning ? const Color(0xFFE05252) : const Color(0xFF39E75F))), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(warning ? Icons.close_rounded : Icons.check_rounded, size: 11, color: warning ? const Color(0xFFE05252) : const Color(0xFF39E75F)), const SizedBox(width: 3), Text(warning ? '$label HIT' : '$label HIT', style: TextStyle(color: warning ? const Color(0xFFE05252) : const Color(0xFF39E75F), fontSize: 8, fontWeight: FontWeight.w900))])),
    if (hit && profit.trim().isNotEmpty) ...[const SizedBox(width: 5), Text('${warning ? '-' : '+'}${profit.replaceFirst(RegExp(r'^[+-]'), '')}%', style: TextStyle(color: warning ? const Color(0xFFE05252) : const Color(0xFF39E75F), fontSize: 9, fontWeight: FontWeight.w900))],
  ]),
);

Widget _signalWinBadge({required bool tp1Hit, required bool tp2Hit, required bool tp3Hit, required String tp1Profit, required String tp2Profit, required String tp3Profit, required bool stopLossHit, required String stopLossProfit, required bool breakEven, required String breakEvenProfit}) {
  final avg = _averageHitProfit(tp1Hit: tp1Hit, tp2Hit: tp2Hit, tp3Hit: tp3Hit, tp1Profit: tp1Profit, tp2Profit: tp2Profit, tp3Profit: tp3Profit);
  final isWin = avg.isNotEmpty;
  final isLoss = !isWin && stopLossHit;
  final isBreakEven = !isWin && !isLoss && breakEven;
  if (!isWin && !isLoss && !isBreakEven) return const SizedBox.shrink();
  final label = isWin ? 'WIN' : isLoss ? 'LOSS' : 'BREAK EVEN';
  final value = isWin ? avg : isLoss ? '-${stopLossProfit.replaceFirst(RegExp(r'^[+-]'), '')}%' : '0%';
  final color = isWin ? const Color(0xFF39E75F) : const Color(0xFFE05252);
  return Container(width: isBreakEven ? 64 : 54, padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 4), decoration: BoxDecoration(color: color.withValues(alpha: .10), borderRadius: BorderRadius.circular(7), border: Border.all(color: color.withValues(alpha: .5))), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(label, style: TextStyle(color: color, fontSize: 5.5, fontWeight: FontWeight.w900, letterSpacing: .3)), const SizedBox(height: 1), Text(value, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w900))]));
}

class _AlphaDenSinglePostCard extends StatelessWidget {
  final _AlphaDenPost post;
  final bool liked;
  final VoidCallback onLike;
  final VoidCallback onRepost;
  final VoidCallback onComment;
  final VoidCallback onOptions;
  final String label;
  final int winTrades;
  const _AlphaDenSinglePostCard({super.key, required this.post, required this.winTrades, required this.liked, required this.onLike, required this.onRepost, required this.onComment, required this.onOptions, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF303238)), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0x334E9FC1))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(post.isSignal ? Icons.candlestick_chart_outlined : Icons.lightbulb_outline, color: post.isSignal ? AppTheme.neonGreen : AppTheme.luxuryGold, size: 16),
            const SizedBox(width: 7),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: .9)),
            const Spacer(),
            Text(post.bullish ? 'BULL' : 'BEAR', style: TextStyle(color: post.bullish ? AppTheme.neonGreen : const Color(0xFFE05252), fontSize: 10, fontWeight: FontWeight.w900)),
            const SizedBox(width: 5),
            _signalWinBadge(tp1Hit: post.tp1Hit, tp2Hit: post.tp2Hit, tp3Hit: post.tp3Hit, tp1Profit: post.tp1Profit, tp2Profit: post.tp2Profit, tp3Profit: post.tp3Profit, stopLossHit: post.stopLossHit, stopLossProfit: post.stopLossProfit, breakEven: post.breakEven, breakEvenProfit: post.breakEvenProfit),
            const SizedBox(width: 4),
            IconButton(
              tooltip: 'Post options',
              visualDensity: VisualDensity.compact,
              padding: EdgeInsets.zero,
              onPressed: onOptions,
              icon: Icon(Icons.more_vert_rounded, color: AppTheme.textSecondary, size: 20),
            ),
          ]),
          const SizedBox(height: 10),
          if (post.isSignal) ...[
            Text('${post.signalAsset ?? ''} /USDT', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text('ENTRY ${post.signalEntry ?? ''} • ${post.signalLongDirection == true ? 'LONG' : 'SHORT'} • ${post.signalLeverage ?? 10}x', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            _signalTargetRow(label: 'TP1', value: post.signalTp1 ?? '', hit: post.tp1Hit, profit: post.tp1Profit),
            _signalTargetRow(label: 'TP2', value: post.signalTp2 ?? '', hit: post.tp2Hit, profit: post.tp2Profit),
            _signalTargetRow(label: 'TP3', value: post.signalTp3 ?? '', hit: post.tp3Hit, profit: post.tp3Profit),
            _signalTargetRow(label: 'STOPLOSS', value: post.signalStopLoss ?? '', warning: true, hit: post.stopLossHit, profit: post.stopLossProfit),
            if (post.breakEven) _signalTargetRow(label: 'BREAK EVEN', value: '', warning: true, hit: true, profit: post.breakEvenProfit),
          if (post.winResultImageBytes != null && (post.tp1Hit || post.tp2Hit || post.tp3Hit)) ...[
            const SizedBox(height: 8),
            GestureDetector(onTap: () => showDialog<void>(context: context, builder: (_) => Dialog(backgroundColor: Colors.black, insetPadding: const EdgeInsets.all(12), child: InteractiveViewer(child: Image.memory(post.winResultImageBytes!, fit: BoxFit.contain)))), child: ClipRRect(borderRadius: BorderRadius.circular(9), child: Image.memory(post.winResultImageBytes!, width: 105, height: 72, fit: BoxFit.cover))),
          ],
          ] else ...[
            if (post.text.trim().split(RegExp(r'\s+')).length > 130) ...[
              Text(post.text, maxLines: 6, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppTheme.textPrimary, fontSize: 13, height: 1.45)),
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () {
                    showModalBottomSheet<void>(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: AppTheme.adaptiveSurface(Color(0xFF080D13)),
                      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
                      builder: (_) => SafeArea(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(post.text, style: TextStyle(color: AppTheme.textPrimary, fontSize: 14, height: 1.6)),
                                const SizedBox(height: 12),
                                Text(post.bullish ? 'BULLISH' : 'BEARISH', style: TextStyle(color: post.bullish ? AppTheme.neonGreen : const Color(0xFFE05252), fontSize: 10, fontWeight: FontWeight.w900)),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.open_in_new, size: 14),
                  label: const Text('READ FULL POST', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900)),
                ),
              ),
            ] else
              Text(post.text, style: TextStyle(color: AppTheme.textPrimary, fontSize: 13, height: 1.45)),
          ],
          if (post.imageBytes != null) ...[
            const SizedBox(height: 10),
            ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(post.imageBytes!, width: double.infinity, height: 210, fit: BoxFit.cover)),
          ],
          const SizedBox(height: 5),
          Row(children: [
            IconButton(padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 24, minHeight: 24), visualDensity: const VisualDensity(horizontal: -4, vertical: -4), onPressed: onLike, icon: Icon(liked ? Icons.favorite : Icons.favorite_border, size: 16, color: liked ? const Color(0xFFFF3B4D) : AppTheme.textSecondary)),
            const SizedBox(width: 3),
            Text(liked ? 'Liked' : 'Like', style: TextStyle(color: AppTheme.textSecondary, fontSize: 9.5)),
            const SizedBox(width: 10),
            IconButton(padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 24, minHeight: 24), visualDensity: const VisualDensity(horizontal: -4, vertical: -4), onPressed: onComment, icon: Icon(Icons.comment_outlined, size: 16, color: AppTheme.textSecondary)),
            const SizedBox(width: 3),
            Text('Comment', style: TextStyle(color: AppTheme.textSecondary, fontSize: 9.5)),
            const SizedBox(width: 10),
            Icon(Icons.auto_awesome, color: AppTheme.luxuryGold, size: 13),
            const SizedBox(width: 5),
            IconButton(padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 24, minHeight: 24), visualDensity: const VisualDensity(horizontal: -4, vertical: -4), onPressed: onRepost, icon: Icon(Icons.repeat, size: 16, color: AppTheme.textSecondary)),
            const SizedBox(width: 3),
            Text('Repost', style: TextStyle(color: AppTheme.textSecondary, fontSize: 9.5)),
          ]),
        ],
      ),
    );
  }
}

class _AlphaDenEmptyState extends StatelessWidget {
  final IconData icon; final String title; final String subtitle;
  const _AlphaDenEmptyState({required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 70, horizontal: 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: AppTheme.borderSoft, size: 34),
          const SizedBox(height: 12),
          Text(title, style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          const SizedBox(height: 6),
          Text(subtitle, textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textFaint, fontSize: 12)),
        ],
      ),
    ),
  );
}

Future<int> _showFeedCommentsSheet(BuildContext context, {required String postId, required String authorUid}) async {
  final currentUser = FirebaseAuth.instance.currentUser;
  if (currentUser == null || postId.trim().isEmpty) return 0;
  final controller = TextEditingController();
  final focusNode = FocusNode();
  final local = <_CommunityComment>[];
  var addedCount = 0;
  try {
    try {
      final rows = await FeedService.loadComments(postId);
      local.addAll(rows.map((data) => _CommunityComment(
        id: (data['id'] ?? '').toString(),
        authorUid: (data['authorUid'] ?? '').toString(),
        author: (data['author'] ?? 'User').toString(),
        text: (data['text'] ?? '').toString(),
        creatorReply: data['creatorReply'] == true,
        parentId: (data['parentId'] as String?)?.trim().isEmpty == true ? null : data['parentId']?.toString(),
        likes: (data['likes'] as num?)?.toInt() ?? 0,
      )));
    } catch (_) {}
    if (!context.mounted) return 0;
    if (!context.mounted) return 0;
    String? replyTo;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => StatefulBuilder(builder: (sheetContext, setModalState) {
        final inset = MediaQuery.of(sheetContext).viewInsets.bottom;
        final roots = local.where((c) => c.parentId == null).toList();
        List<_CommunityComment> replies(String id) => local.where((c) => c.parentId == id).toList();
        Future<void> submit() async {
          final text = controller.text.trim();
          if (text.isEmpty) return;
          try {
            final id = FeedService.newCommentId(postId);
            final author = currentUser.displayName?.trim().isNotEmpty == true ? currentUser.displayName!.trim() : 'You';
            final optimistic = _CommunityComment(id: id, authorUid: currentUser.uid, author: author, text: text, parentId: replyTo);
            local.add(optimistic);
            addedCount++;
            controller.clear();
            replyTo = null;
            setModalState(() {});
            try {
              await FeedService.addComment(
                postId: postId,
                authorUid: currentUser.uid,
                author: author,
                text: text,
                parentId: optimistic.parentId,
                creatorReply: currentUser.uid == authorUid && authorUid.isNotEmpty,
                commentId: id,
              );
            } catch (_) {
              local.removeWhere((c) => c.id == id);
              addedCount--;
              if (sheetContext.mounted) setModalState(() {});
              if (sheetContext.mounted) ScaffoldMessenger.of(sheetContext).showSnackBar(const SnackBar(content: Text('Comment could not be posted. Please check your connection and try again.')));
            }
          } catch (_) {
            if (sheetContext.mounted) ScaffoldMessenger.of(sheetContext).showSnackBar(const SnackBar(content: Text('Comment could not be posted. Please check your connection and try again.')));
          }
        }
        Widget tile(_CommunityComment c, {bool reply = false}) => Container(
          margin: EdgeInsets.only(left: reply ? 30 : 0, bottom: 8),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: .035), borderRadius: BorderRadius.circular(13), border: Border.all(color: AppTheme.fillFaint)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(c.author, style: TextStyle(color: AppTheme.textPrimary, fontSize: 10, fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text(c.text, style: TextStyle(color: AppTheme.textSecondary, fontSize: 12, height: 1.3)),
            const SizedBox(height: 5),
            Row(children: [InkWell(onTap: () async { final next = !c.likedByMe; c.likedByMe = next; c.likes = (c.likes + (next ? 1 : -1)).clamp(0, 1000000); setModalState(() {}); try { await FeedService.toggleCommentLike(postId: postId, commentId: c.id, uid: currentUser.uid, liked: next); } catch (_) {} }, child: Row(children: [Icon(c.likedByMe ? Icons.favorite : Icons.favorite_border, size: 13, color: c.likedByMe ? const Color(0xFFFF3B4D) : AppTheme.textFaint), const SizedBox(width: 3), Text('${c.likes}', style: TextStyle(color: AppTheme.textFaint, fontSize: 8))])), const SizedBox(width: 12), InkWell(onTap: () { replyTo = c.id; focusNode.requestFocus(); setModalState(() {}); }, child: const Text('REPLY', style: TextStyle(color: Color(0xFF59D7FF), fontSize: 8, fontWeight: FontWeight.w900))), const SizedBox(width: 12), InkWell(onTap: () { Navigator.pop(sheetContext); Future<void>.delayed(const Duration(milliseconds: 180), () { if (!sheetContext.mounted) return; _openContentReportSupportPage(sheetContext, postId: postId, commentId: c.id, authorUid: authorUid); }); }, child: Text('REPORT', style: TextStyle(color: AppTheme.textFaint, fontSize: 8, fontWeight: FontWeight.w900)))])
          ]),
        );
        return SafeArea(child: Padding(
          padding: EdgeInsets.only(bottom: inset),
          child: Container(
            height: MediaQuery.of(sheetContext).size.height * .68,
            decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF080D13)), borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
            child: Column(children: [
              Padding(padding: const EdgeInsets.fromLTRB(16, 10, 12, 8), child: Row(children: [Text('COMMENTS', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: AppTheme.textSecondary)), const Spacer(), IconButton(onPressed: () => Navigator.pop(sheetContext), icon: Icon(Icons.close, color: AppTheme.textMuted))])),
              Divider(height: 1, color: AppTheme.fillFaint),
              Expanded(child: local.isEmpty ? Center(child: Text('No comments yet. Start the conversation.', style: TextStyle(color: AppTheme.textFaint, fontSize: 12))) : ListView(padding: const EdgeInsets.all(14), children: [for (final c in roots) ...[tile(c), for (final r in replies(c.id)) tile(r, reply: true)]])),
              if (replyTo != null) Padding(padding: const EdgeInsets.fromLTRB(14, 0, 14, 4), child: Row(children: [Text('Replying', style: TextStyle(color: AppTheme.textFaint, fontSize: 9)), const Spacer(), TextButton(onPressed: () { replyTo = null; setModalState(() {}); }, child: const Text('CANCEL'))])),
              Padding(padding: const EdgeInsets.fromLTRB(12, 6, 12, 12), child: Row(children: [Expanded(child: TextField(controller: controller, focusNode: focusNode, minLines: 1, maxLines: 4, textInputAction: TextInputAction.newline, decoration: const InputDecoration(hintText: 'Write a comment...'))), const SizedBox(width: 7), IconButton(onPressed: submit, icon: Icon(Icons.send_rounded, color: AppTheme.luxuryGold))]))
            ]),
          ),
        ));
      }),
    );
  } finally {
    controller.dispose();
    focusNode.dispose();
  }
  return addedCount;
}

class _CommunityPostCard extends StatefulWidget {
  final _CommunityPost post;
  const _CommunityPostCard({required this.post});

  @override
  State<_CommunityPostCard> createState() => _CommunityPostCardState();
}

class _CommunityPostCardState extends State<_CommunityPostCard> {
  bool liked = false;
  bool following = false;
  bool reposted = false;
  bool _countedView = false;
  bool _isAdmin = false;

  @override
  void initState() {
    super.initState();
    if (!_countedView) {
      _countedView = true;
      widget.post.views += 1;
    }
    _loadAdminAccess();
  }

  Future<void> _loadAdminAccess() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final allowed = await _hasFirebaseAdminClaim(user);
      if (mounted && allowed != _isAdmin) setState(() => _isAdmin = allowed);
    } catch (_) {}
  }

  void _sortFeed() {
    final next = List<_CommunityPost>.from(_communityFeed.value);
    next.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    _communityFeed.value = next;
  }

  Future<void> _openComments() async {
    final controller = TextEditingController();
    final focusNode = FocusNode();
    final emojis = <String>['❤️', '🔥', '😂', '🚀', '👍', '😍'];
    final coins = <String>['BTC', 'ETH', 'SOL', 'XRP'];
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    try {
      final rows = await FeedService.loadComments(widget.post.id);
      // Merge the server snapshot into the existing in-memory list instead
      // of clearing it first. This prevents a temporarily stale read from
      // removing a comment that was just posted successfully.
      final mergedComments = <String, _CommunityComment>{
        for (final comment in widget.post.commentItems) comment.id: comment,
      };
      for (final data in rows) {
        final comment = _CommunityComment(
          id: (data['id'] ?? '').toString(),
          authorUid: (data['authorUid'] ?? '').toString(),
          author: (data['author'] ?? 'User').toString(),
          text: (data['text'] ?? '').toString(),
          creatorReply: data['creatorReply'] == true,
          parentId: (data['parentId'] as String?)?.trim().isEmpty == true ? null : data['parentId']?.toString(),
          likes: (data['likes'] as num?)?.toInt() ?? 0,
        );
        if (comment.id.isNotEmpty) mergedComments[comment.id] = comment;
      }
      widget.post.commentItems
        ..clear()
        ..addAll(mergedComments.values);
      if (mounted) setState(() {});
    } catch (_) {
      // Keep the local comments available if a legacy/missing comments collection is encountered.
    }

    String? replyTo;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.68),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (sheetContext, modalSetState) {
            final bottomInset = MediaQuery.of(sheetContext).viewInsets.bottom;
            final roots = widget.post.commentItems.where((c) => c.parentId == null).toList();
            List<_CommunityComment> repliesFor(String id) => widget.post.commentItems.where((c) => c.parentId == id).toList();

            Future<void> submit() async {
              final value = controller.text.trim();
              if (value.isEmpty) return;
              final parent = replyTo;
              try {
                final id = FeedService.newCommentId(widget.post.id);
                final author = currentUser.displayName?.trim().isNotEmpty == true ? currentUser.displayName!.trim() : 'You';
                final optimistic = _CommunityComment(
                  id: id,
                  authorUid: currentUser.uid,
                  author: author,
                  text: value,
                  parentId: parent,
                  creatorReply: currentUser.uid == widget.post.authorUid,
                );
                widget.post.commentItems.add(optimistic);
                widget.post.comments += 1;
                controller.clear();
                replyTo = null;
                _communityFeed.value = List<_CommunityPost>.from(_communityFeed.value);
                modalSetState(() {});
                try {
                  await FeedService.addComment(
                    postId: widget.post.id,
                    authorUid: currentUser.uid,
                    author: author,
                    text: value,
                    parentId: parent,
                    creatorReply: currentUser.uid == widget.post.authorUid,
                    commentId: id,
                  );
                } catch (_) {
                  widget.post.commentItems.removeWhere((c) => c.id == id);
                  widget.post.comments = (widget.post.comments - 1).clamp(0, 1000000).toInt();
                  _communityFeed.value = List<_CommunityPost>.from(_communityFeed.value);
                  if (sheetContext.mounted) modalSetState(() {});
                  if (sheetContext.mounted) ScaffoldMessenger.of(sheetContext).showSnackBar(const SnackBar(content: Text('Could not post this comment. Please try again.')));
                }
              } catch (_) {
                if (sheetContext.mounted) {
                  ScaffoldMessenger.of(sheetContext).showSnackBar(const SnackBar(content: Text('Could not post this comment. Please try again.')));
                }
              }
            }

            Future<void> reportComment(_CommunityComment item) async {
              final reason = await _showContentReportDialog(sheetContext, 'REPORT COMMENT');
              if (reason == null) return;
              try {
                await FeedService.reportComment(postId: widget.post.id, commentId: item.id, reporterUid: currentUser.uid, reason: reason);
                if (sheetContext.mounted) ScaffoldMessenger.of(sheetContext).showSnackBar(const SnackBar(content: Text('Comment reported.')));
              } catch (_) {
                if (sheetContext.mounted) ScaffoldMessenger.of(sheetContext).showSnackBar(const SnackBar(content: Text('Could not submit the report.')));
              }
            }

            Widget commentTile(_CommunityComment item, {bool reply = false}) {
              return Container(
                margin: EdgeInsets.only(left: reply ? 34 : 0, bottom: 8),
                padding: const EdgeInsets.fromLTRB(11, 9, 8, 9),
                decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: reply ? 0.025 : 0.035), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.fillFaint)),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  CircleAvatar(radius: reply ? 12 : 14, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF111A24)), child: Icon(Icons.person, size: reply ? 13 : 15, color: AppTheme.luxuryGold)),
                  const SizedBox(width: 9),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [Expanded(child: Text(item.author, style: TextStyle(color: item.creatorReply ? AppTheme.luxuryGold : AppTheme.textPrimary, fontWeight: FontWeight.w800, fontSize: 10))), if (item.creatorReply) const Text('CREATOR', style: TextStyle(color: Color(0xFF59D7FF), fontSize: 7, fontWeight: FontWeight.w900))]),
                    const SizedBox(height: 3),
                    Text(item.text, style: TextStyle(color: AppTheme.textSecondary, fontSize: 12, height: 1.3)),
                    const SizedBox(height: 5),
                    Row(children: [
                      InkWell(onTap: () async {
                        final next = !item.likedByMe;
                        modalSetState(() { item.likedByMe = next; item.likes = (item.likes + (next ? 1 : -1)).clamp(0, 1000000).toInt(); });
                        try { await FeedService.toggleCommentLike(postId: widget.post.id, commentId: item.id, uid: currentUser.uid, liked: next); } catch (_) {}
                      }, child: Row(children: [Icon(item.likedByMe ? Icons.favorite : Icons.favorite_border, size: 13, color: item.likedByMe ? const Color(0xFFFF3B4D) : AppTheme.textFaint), const SizedBox(width: 3), Text('${item.likes}', style: TextStyle(color: AppTheme.textFaint, fontSize: 9))])),
                      const SizedBox(width: 14),
                      InkWell(onTap: () { replyTo = item.id; focusNode.requestFocus(); modalSetState(() {}); }, child: const Text('REPLY', style: TextStyle(color: Color(0xFF59D7FF), fontSize: 8, fontWeight: FontWeight.w900))),
                      const SizedBox(width: 14),
                      InkWell(onTap: () => reportComment(item), child: Text('REPORT', style: TextStyle(color: AppTheme.textFaint, fontSize: 8, fontWeight: FontWeight.w900))),
                    ]),
                  ])),
                ]),
              );
            }

            return SafeArea(
              child: Padding(
                padding: EdgeInsets.only(bottom: bottomInset),
                child: Container(
                  height: MediaQuery.of(sheetContext).size.height * 0.68,
                  decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF080D13)), borderRadius: BorderRadius.vertical(top: Radius.circular(22)), border: Border(top: BorderSide(color: Color(0x334E9FC1)))),
                  child: Column(children: [
                    Padding(padding: const EdgeInsets.fromLTRB(16, 10, 12, 8), child: Row(children: [Container(width: 34, height: 4, decoration: BoxDecoration(color: AppTheme.borderSoft, borderRadius: BorderRadius.circular(3))), const Spacer(), Text('${widget.post.comments} COMMENTS', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.1, color: AppTheme.textSecondary)), const Spacer(), IconButton(iconSize: 18, padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 28, minHeight: 28), onPressed: () => Navigator.pop(sheetContext), icon: Icon(Icons.close, color: AppTheme.textMuted))])),
                    Divider(height: 1, color: AppTheme.fillFaint),
                    Expanded(child: roots.isEmpty
                      ? Center(child: Text('No comments yet. Start the conversation.', style: TextStyle(color: AppTheme.textFaint, fontSize: 12)))
                      : ListView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 10), children: [
                          for (final item in roots) ...[
                            commentTile(item),
                            for (final reply in repliesFor(item.id)) commentTile(reply, reply: true),
                          ],
                        ])),
                    Container(padding: const EdgeInsets.fromLTRB(12, 8, 12, 10), decoration: BoxDecoration(color: AppTheme.adaptiveSurface(Color(0xFF0B121A)), border: Border(top: BorderSide(color: AppTheme.fillFaint))), child: Column(children: [
                      if (replyTo != null) Align(alignment: Alignment.centerLeft, child: Padding(padding: const EdgeInsets.only(bottom: 5), child: Row(children: [const Icon(Icons.reply_rounded, size: 13, color: Color(0xFF59D7FF)), const SizedBox(width: 5), const Text('REPLYING TO COMMENT', style: TextStyle(color: Color(0xFF59D7FF), fontSize: 8, fontWeight: FontWeight.w900)), const Spacer(), InkWell(onTap: () => modalSetState(() => replyTo = null), child: Text('CANCEL', style: TextStyle(color: AppTheme.textFaint, fontSize: 8, fontWeight: FontWeight.w900)))]))),
                      SizedBox(height: 28, child: ListView(scrollDirection: Axis.horizontal, children: [for (final emoji in emojis) Padding(padding: const EdgeInsets.only(right: 6), child: InkWell(onTap: () { controller.text += emoji; controller.selection = TextSelection.fromPosition(TextPosition(offset: controller.text.length)); modalSetState(() {}); }, borderRadius: BorderRadius.circular(10), child: Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4), decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: 0.05), borderRadius: BorderRadius.circular(10)), child: Text(emoji, style: const TextStyle(fontSize: 14))))), for (final coin in coins) Padding(padding: const EdgeInsets.only(right: 6), child: InkWell(onTap: () { controller.text += '\$$coin '; controller.selection = TextSelection.fromPosition(TextPosition(offset: controller.text.length)); modalSetState(() {}); }, child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5), decoration: BoxDecoration(color: AppTheme.adaptiveWhite(alpha: 0.04), borderRadius: BorderRadius.circular(10)), child: Text('\$$coin', style: TextStyle(color: AppTheme.textMuted, fontSize: 9, fontWeight: FontWeight.w800)))))])),
                      const SizedBox(height: 7),
                      Row(children: [Expanded(child: TextField(controller: controller, focusNode: focusNode, minLines: 1, maxLines: 3, decoration: InputDecoration(hintText: replyTo == null ? 'Write a comment…' : 'Write a reply…', hintStyle: TextStyle(color: AppTheme.textVeryFaint, fontSize: 11), filled: true, fillColor: AppTheme.adaptiveWhite(alpha: 0.045), contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none), prefixIcon: Icon(Icons.emoji_emotions_outlined, size: 17, color: AppTheme.textFaint)))), const SizedBox(width: 7), InkWell(onTap: submit, borderRadius: BorderRadius.circular(16), child: Container(width: 42, height: 42, decoration: BoxDecoration(color: AppTheme.luxuryGold, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.send_rounded, size: 18, color: Colors.black)))]),
                    ])),
                  ]),
                ),
              ),
            );
          },
        );
      },
    );
    controller.dispose();
    focusNode.dispose();
  }

  Future<String?> _showContentReportDialog(BuildContext context, String title) async {
    final reasons = <String>['Abusive language', 'Explicit content', 'Misinformation', 'Misguiding', 'Fraud'];
    return showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0A1119)),
        title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final reason in reasons) ListTile(dense: true, leading: Icon(Icons.flag_outlined, size: 18, color: AppTheme.textMuted), title: Text(reason, style: const TextStyle(fontSize: 12)), onTap: () => Navigator.pop(dialogContext, reason)),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL'))],
      ),
    );
  }

  Future<void> _reportPost() async {
    if (!mounted) return;
    await _openContentReportSupportPage(context, postId: widget.post.id, authorUid: widget.post.authorUid);
  }

  void _like() {
    setState(() => liked = !liked);
    widget.post.likes += liked ? 1 : -1;
    if (widget.post.likes < 0) widget.post.likes = 0;
    _sortFeed();
  }

  void _follow() {
    setState(() => following = !following);
    widget.post.followers += following ? 1 : -1;
    if (widget.post.followers < 0) widget.post.followers = 0;
    _sortFeed();
  }

  Future<void> _sharePost() async {
    final post = widget.post;
    final author = post.nickname.trim().isNotEmpty ? post.nickname.trim() : post.username.trim();
    final content = post.text.trim();
    final tags = <String>[
      ...post.hashtags.map((tag) => '#${tag.trim()}').where((tag) => tag != '#'),
      ...post.coins.map((coin) => '\$${coin.trim()}').where((coin) => coin != '\$'),
    ];
    final baseUrl = Uri.base;
    final shareUrl = baseUrl.replace(
      queryParameters: <String, String>{
        ...baseUrl.queryParameters,
        'post': post.id,
      },
    ).toString();
    final textParts = <String>[
      if (content.isNotEmpty) content,
      if (tags.isNotEmpty) tags.join(' '),
      'Posted by ${author.isEmpty ? 'Crypto Doctors Hub' : author}',
      'Crypto Doctors Hub',
    ];
    final shareText = textParts.join('\n\n');
    final shareMessage = '$shareText\n\n$shareUrl';

    Future<void> openShareTarget(String name, Uri uri, {bool copyFirst = false}) async {
      if (copyFirst) {
        await Clipboard.setData(ClipboardData(text: shareMessage));
      }
      try {
        final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
        if (!launched && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not open $name.')));
        } else if (copyFirst && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Post content copied. Continue sharing in $name.')));
        }
      } catch (_) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not open $name.')));
      }
    }

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetContext) {
        final options = <Map<String, dynamic>>[
          {'name': 'WhatsApp', 'icon': Icons.chat_rounded, 'uri': Uri.parse('https://wa.me/?text=${Uri.encodeComponent(shareMessage)}')},
          {'name': 'Twitter / X', 'icon': Icons.alternate_email_rounded, 'uri': Uri.parse('https://twitter.com/intent/tweet?text=${Uri.encodeComponent(shareText)}&url=${Uri.encodeComponent(shareUrl)}')},
          {'name': 'Discord', 'icon': Icons.forum_rounded, 'uri': Uri.parse('https://discord.com/app'), 'copy': true},
          {'name': 'Instagram', 'icon': Icons.camera_alt_outlined, 'uri': Uri.parse('https://www.instagram.com/'), 'copy': true},
          {'name': 'Telegram', 'icon': Icons.send_rounded, 'uri': Uri.parse('https://t.me/share/url?url=${Uri.encodeComponent(shareUrl)}&text=${Uri.encodeComponent(shareText)}')},
          {'name': 'Reddit', 'icon': Icons.forum_outlined, 'uri': Uri.parse('https://www.reddit.com/submit?url=${Uri.encodeComponent(shareUrl)}&title=${Uri.encodeComponent('Crypto Doctors Hub post by $author')}')},
        ];
        return SafeArea(
          child: Container(
            margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
            decoration: BoxDecoration(
              color: AppTheme.adaptiveSurface(Color(0xFF0B121A)),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: const Color(0x334E9FC1)),
              boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 24, offset: Offset(0, 10))],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 38, height: 4, decoration: BoxDecoration(color: AppTheme.borderSoft, borderRadius: BorderRadius.circular(4))),
                const SizedBox(height: 12),
                const Text('SHARE POST', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
                const SizedBox(height: 5),
                Text('Share the actual CD Feed post and its content.', style: TextStyle(color: AppTheme.textMuted, fontSize: 9.5)),
                const SizedBox(height: 14),
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    for (final option in options)
                      InkWell(
                        onTap: () {
                          Navigator.pop(sheetContext);
                          openShareTarget(option['name'] as String, option['uri'] as Uri, copyFirst: option['copy'] == true);
                        },
                        borderRadius: BorderRadius.circular(15),
                        child: SizedBox(
                          width: 86,
                          child: Column(
                            children: [
                              Container(
                                width: 46,
                                height: 46,
                                decoration: BoxDecoration(
                                  color: AppTheme.adaptiveWhite(alpha: .055),
                                  borderRadius: BorderRadius.circular(15),
                                  border: Border.all(color: AppTheme.borderFaint),
                                ),
                                child: Icon(option['icon'] as IconData, color: AppTheme.textPrimary, size: 21),
                              ),
                              const SizedBox(height: 6),
                              Text(option['name'] as String, textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondary, fontSize: 8.5, fontWeight: FontWeight.w800)),
                            ],
                          ),
                        ),
                      ),
                    InkWell(
                      onTap: () async {
                        await Clipboard.setData(ClipboardData(text: shareMessage));
                        if (sheetContext.mounted) Navigator.pop(sheetContext);
                        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('CD Feed post content copied to clipboard.')));
                      },
                      borderRadius: BorderRadius.circular(15),
                      child: SizedBox(
                        width: 86,
                        child: Column(children: [
                          SizedBox(height: 0),
                          Icon(Icons.copy_rounded, color: AppTheme.textSecondary, size: 25),
                          SizedBox(height: 9),
                          Text('Copy Post', style: TextStyle(color: AppTheme.textSecondary, fontSize: 8.5, fontWeight: FontWeight.w800)),
                        ]),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _repost() async {
    if (reposted) return;
    setState(() => reposted = true);
    widget.post.reposts += 1;
    _sortFeed();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Post reposted.')));
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final profile = await AlphaDenService.loadProfile(user.uid);
      if (profile == null) return;
      final currentReposts = (profile['reposts'] as num?)?.toInt() ?? 0;
      await AlphaDenService.saveProfile(
        uid: user.uid,
        username: (profile['username'] ?? 'user').toString(),
        handle: (profile['handle'] ?? '').toString(),
        name: (profile['name'] ?? '').toString(),
        age: (profile['age'] ?? '').toString(),
        sex: (profile['sex'] ?? '').toString(),
        bio: (profile['bio'] ?? '').toString(),
        profilePicUrl: (profile['profilePicUrl'] ?? '').toString(),
        followers: (profile['followers'] as num?)?.toInt() ?? 0,
        posts: (profile['posts'] as num?)?.toInt() ?? 0,
        likes: (profile['likes'] as num?)?.toInt() ?? 0,
        views: (profile['views'] as num?)?.toInt() ?? 0,
        reposts: currentReposts + 1,
        referrals: (profile['referrals'] as num?)?.toInt() ?? 0,
        winTrades: (profile['winTrades'] as num?)?.toInt() ?? 0,
        verified: profile['verifiedCreatorApproved'] as bool? ?? false,
      );
    } catch (_) {}
  }

  Future<void> _editPost() async {
    await Future<void>.delayed(Duration.zero);
    if (!mounted) return;
    final controller = TextEditingController(text: widget.post.text);
    String? result;
    try {
      result = await showDialog<String>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0A1119)),
          title: const Text('EDIT POST'),
          content: TextField(
            controller: controller,
            autofocus: true,
            minLines: 3,
            maxLines: 7,
            decoration: const InputDecoration(hintText: 'Update your post…'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('CANCEL')),
            ElevatedButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim()), child: const Text('SAVE')),
          ],
        ),
      );
    } finally {
      controller.dispose();
    }
    if (result == null || result == widget.post.text || !mounted) return;
    await Future<void>.delayed(Duration.zero);
    if (!mounted) return;
    try {
      await FeedService.updatePost(widget.post.id, authorUid: widget.post.authorUid, text: result);
      if (!mounted) return;
      widget.post.text = result;
      _communityFeed.value = List<_CommunityPost>.from(_communityFeed.value);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Post updated.')));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not update this post.')));
    }
  }

  bool get _isAlphaDenPost => widget.post.sourceType == 'alpha_den' || widget.post.sourceType == 'alpha_den_signal';

  Future<void> _deletePost() async {
    await Future<void>.delayed(Duration.zero);
    if (!mounted) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppTheme.adaptiveSurface(Color(0xFF0A1119)),
        title: const Text('DELETE POST'),
        content: const Text('Delete this post permanently? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE05252), foregroundColor: AppTheme.textPrimary),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('DELETE'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await FeedService.deletePost(widget.post.id, authorUid: widget.post.authorUid, requesterUid: FirebaseAuth.instance.currentUser?.uid, adminDelete: _isAdmin && _isAlphaDenPost);
      _communityFeed.value = _communityFeed.value.where((p) => p.id != widget.post.id).toList();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Post deleted.')));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not delete this post.')));
    }
  }

  void _openImage() {
    final bytes = widget.post.imageBytes;
    if (bytes == null) return;
    Navigator.of(context).push(PageRouteBuilder(
      opaque: false,
      transitionDuration: const Duration(milliseconds: 420),
      pageBuilder: (_, animation, _) => FadeTransition(
        opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
        child: _FullPostImagePage(bytes: bytes),
      ),
    ));
  }

  void _openWinResultImage() {
    final bytes = widget.post.winResultImageBytes;
    if (bytes == null) return;
    Navigator.of(context).push(PageRouteBuilder(opaque: false, transitionDuration: const Duration(milliseconds: 350), pageBuilder: (_, animation, _) => FadeTransition(opacity: animation, child: _FullPostImagePage(bytes: bytes))));
  }

  @override
  Widget build(BuildContext context) {
    final post = widget.post;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: (post.signalAsset != null && post.signalAsset!.trim().isNotEmpty)
          ? BoxDecoration(
              color: AppTheme.adaptiveSurface(Color(0xFF303238)),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0x334E9FC1)),
            )
          : _regularPostGlassDecoration(borderColor: const Color(0xFF4E9FC1), radius: 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          InkWell(
            onTap: () => _openPublicAlphaDenProfile(context, post.authorUid),
            borderRadius: BorderRadius.circular(22),
            child: CircleAvatar(
            radius: 20,
            backgroundColor: AppTheme.adaptiveSurface(Color(0xFF111A24)),
            backgroundImage: post.profilePicBytes != null
                ? MemoryImage(post.profilePicBytes!)
                : (post.profilePicUrl.trim().isNotEmpty ? NetworkImage(post.profilePicUrl) : null),
            child: post.profilePicBytes == null && post.profilePicUrl.trim().isEmpty ? Icon(Icons.person, color: AppTheme.luxuryGold) : null,
          ),
          ),
          const SizedBox(width: 9),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: InkWell(onTap: () => _openPublicAlphaDenProfile(context, post.authorUid), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                LayoutBuilder(
                  builder: (context, constraints) {
                    final name = post.nickname.trim().isNotEmpty ? post.nickname : post.username;
                    final nameStyle = const TextStyle(fontWeight: FontWeight.w900, fontSize: 12);
                    final painter = TextPainter(
                      text: TextSpan(text: name, style: nameStyle),
                      textDirection: Directionality.of(context),
                      maxLines: 1,
                    )..layout();
                    final estimatedBadgeWidth = 14.0 +
                        (post.isPremium ? 20.0 : 0.0) +
                        (post.hasMentorship ? 20.0 : 0.0) +
                        34.0;
                    final available = constraints.maxWidth;
                    final needsExtraSpacing = painter.width + estimatedBadgeWidth > available * .62;
                    final badgeSpacing = needsExtraSpacing
                        ? (8.0 + ((painter.width / math.max(1.0, available)) * 8.0)).clamp(8.0, 14.0)
                        : 4.0;
                    final nameMaxWidth = needsExtraSpacing
                        ? available
                        : math.max(90.0, available - estimatedBadgeWidth - badgeSpacing);
                    final badges = <Widget>[
                      if (post.verified)
                        const Icon(Icons.verified, color: Color(0xFF4EA7FF), size: 14),
                      if (post.isPremium) _FeedPremiumBadge(badgeType: post.premiumBadgeType),
                      if (post.hasMentorship) _FeedStudentBadge(badgeType: post.mentorshipBadgeType),
                      _ReferralCrownBadge(referrals: post.referrals, flamingAura: post.winTrades >= 10),
                    ];
                    return Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: badgeSpacing,
                      runSpacing: 3,
                      children: [
                        ConstrainedBox(
                          constraints: BoxConstraints(maxWidth: nameMaxWidth),
                          child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: nameStyle),
                        ),
                        ...badges,
                      ],
                    );
                  },
                ),
                const SizedBox(height: 1),
                Text(post.username.startsWith('@') ? post.username : '@${post.username}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: AppTheme.textMuted, fontSize: 9, fontWeight: FontWeight.w700)),
              ]))),
            ]),
          ])),
          const SizedBox(width: 8),
          Transform.scale(
            scale: 0.86,
            alignment: Alignment.center,
            child: _signalWinBadge(tp1Hit: post.tp1Hit, tp2Hit: post.tp2Hit, tp3Hit: post.tp3Hit, tp1Profit: post.tp1Profit, tp2Profit: post.tp2Profit, tp3Profit: post.tp3Profit, stopLossHit: post.stopLossHit, stopLossProfit: post.stopLossProfit, breakEven: post.breakEven, breakEvenProfit: post.breakEvenProfit),
          ),
          const SizedBox(width: 7),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: (post.bullish ? const Color(0xFF45D483) : const Color(0xFFE05252)).withValues(alpha: .12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: (post.bullish ? const Color(0xFF45D483) : const Color(0xFFE05252)).withValues(alpha: .45)),
            ),
            child: Text(post.bullish ? 'BULLISH' : 'BEARISH', style: TextStyle(color: post.bullish ? const Color(0xFF45D483) : const Color(0xFFE05252), fontSize: 6.5, fontWeight: FontWeight.w900, letterSpacing: .35)),
          ),
          const SizedBox(width: 6),
          SizedBox(
            width: 58,
            height: 22,
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: _follow,
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppTheme.textMuted),
                  color: AppTheme.adaptiveWhite(alpha: .045),
                ),
                child: Text(following ? 'FOLLOWING' : 'FOLLOW', style: TextStyle(color: AppTheme.textPrimary, fontSize: 6.1, fontWeight: FontWeight.w900, letterSpacing: 0.2)),
              ),
            ),
          ),
        ]),
        const SizedBox(height: 8),
        if (post.text.trim().isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: _LongContentPreview(
              text: post.text,
              onShowMore: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _FullTextPostPage(title: 'CD FEED POST', author: post.nickname.trim().isNotEmpty ? post.nickname : post.username, text: post.text, imageBytes: post.imageBytes))),
            ),
          ),
        if (post.signalAsset != null && post.signalAsset!.trim().isNotEmpty) ...[
          Row(children: [
            Expanded(child: Text('${post.signalAsset} /USDT', style: TextStyle(color: AppTheme.textPrimary, fontSize: 18, fontWeight: FontWeight.w900))),
            _LiveCallBadge(text: post.signalLongDirection == true ? 'LONG' : 'SHORT', color: post.signalLongDirection == true ? AppTheme.neonGreen : const Color(0xFFE05252)),
          ]),
          const SizedBox(height: 8),
          _LiveCallValueRow(label: 'ENTRY', value: post.signalEntry ?? ''),
          Row(children: [SizedBox(width: 76, child: Text('LEVERAGE', style: TextStyle(color: AppTheme.textMuted, fontSize: 10, fontWeight: FontWeight.w900))), Text('${post.signalLeverage ?? 10}x', style: TextStyle(color: _leverageColor(post.signalLeverage ?? 10), fontSize: 13, fontWeight: FontWeight.w900))]),
          _signalTargetRow(label: 'TP1', value: post.signalTp1 ?? '', hit: post.tp1Hit, profit: post.tp1Profit),
          _signalTargetRow(label: 'TP2', value: post.signalTp2 ?? '', hit: post.tp2Hit, profit: post.tp2Profit),
          _signalTargetRow(label: 'TP3', value: post.signalTp3 ?? '', hit: post.tp3Hit, profit: post.tp3Profit),
          _signalTargetRow(label: 'STOPLOSS', value: post.signalStopLoss ?? '', warning: true, hit: post.stopLossHit, profit: post.stopLossProfit),
          if (post.breakEven) _signalTargetRow(label: 'BREAK EVEN', value: '', warning: true, hit: true, profit: post.breakEvenProfit),
          if (post.winResultImageBytes != null && (post.tp1Hit || post.tp2Hit || post.tp3Hit)) ...[
            const SizedBox(height: 8),
            GestureDetector(onTap: _openWinResultImage, child: ClipRRect(borderRadius: BorderRadius.circular(9), child: Image.memory(post.winResultImageBytes!, width: 105, height: 72, fit: BoxFit.cover))),
          ],
        ],
        if (post.signalAsset == null || post.signalAsset!.trim().isEmpty) if (post.text.isNotEmpty) ...[
          const SizedBox(height: 9),
          Text(post.text, style: TextStyle(color: AppTheme.textPrimary, fontSize: 13, height: 1.45)),
        ],
        if (post.imageBytes != null) ...[
          const SizedBox(height: 9),
          Align(
            alignment: Alignment.centerLeft,
            child: GestureDetector(
              onTap: _openImage,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Stack(children: [
                  Image.memory(post.imageBytes!, width: 92, height: 92, fit: BoxFit.cover),
                  Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black.withValues(alpha: 0.42)])))),
                  Positioned(right: 6, bottom: 5, child: Icon(Icons.open_in_full, size: 16, color: AppTheme.textPrimary)),
                ]),
              ),
            ),
          ),
        ],
        if (post.hashtags.isNotEmpty || post.coins.isNotEmpty) ...[
          const SizedBox(height: 9),
          Wrap(spacing: 6, runSpacing: 4, children: [
            for (final tag in post.hashtags) Text('#$tag', style: TextStyle(color: AppTheme.textMuted, fontWeight: FontWeight.w600, fontSize: 9)),
            for (final coin in post.coins) Text('\$$coin', style: TextStyle(color: AppTheme.textMuted, fontWeight: FontWeight.w600, fontSize: 9)),
          ]),
        ],
        const SizedBox(height: 8),
        Row(children: [
          IconButton(
            visualDensity: const VisualDensity(horizontal: -3, vertical: -3),
            padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 24, minHeight: 24), onPressed: _like,
            icon: Icon(liked ? Icons.favorite : Icons.favorite_border, size: 16, color: liked ? const Color(0xFFFF3B4D) : AppTheme.textSecondary),
          ),
          Text('${post.likes}', style: TextStyle(color: AppTheme.textSecondary, fontSize: 9.5)),
          const SizedBox(width: 14),
          IconButton(visualDensity: const VisualDensity(horizontal: -4, vertical: -4), padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 24, minHeight: 24), onPressed: _openComments, icon: Icon(Icons.comment_outlined, size: 16, color: AppTheme.textSecondary)),
          Text('${post.comments}', style: TextStyle(color: AppTheme.textSecondary, fontSize: 9.5)),
          const SizedBox(width: 14),
          IconButton(visualDensity: const VisualDensity(horizontal: -4, vertical: -4), padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 24, minHeight: 24), onPressed: _repost, icon: Icon(Icons.repeat, size: 16, color: AppTheme.textSecondary)),
          Text('${post.reposts}', style: TextStyle(color: AppTheme.textSecondary, fontSize: 9.5)),
          const Spacer(),
          IconButton(visualDensity: const VisualDensity(horizontal: -4, vertical: -4), padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 28, minHeight: 28), tooltip: 'Share post', onPressed: _sharePost, icon: Icon(Icons.share_outlined, size: 17, color: AppTheme.textSecondary)),
          const SizedBox(width: 3),
          Text('Share', style: TextStyle(color: AppTheme.textSecondary, fontSize: 9.5)),
        ]),
      ]),
    );
  }
}

class _FullPostImagePage extends StatelessWidget {
  final Uint8List bytes;
  const _FullPostImagePage({required this.bytes});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black.withValues(alpha: 0.96),
      appBar: AppBar(backgroundColor: Colors.transparent, title: const Text('POST IMAGE')),
      body: Center(child: InteractiveViewer(minScale: 0.8, maxScale: 4, child: Image.memory(bytes, fit: BoxFit.contain))),
    );
  }
}

class _FeedStudentBadge extends StatelessWidget {
  final String badgeType;
  const _FeedStudentBadge({this.badgeType = ''});

  @override
  Widget build(BuildContext context) {
    final graduated = badgeType == 'graduated_admin';
    final installment = badgeType.startsWith('mentorship_installment');
    return Padding(
      padding: const EdgeInsets.only(right: 2),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.school_rounded, color: graduated ? Colors.black : installment ? Colors.white : const Color(0xFF8DB0FF), size: 16),
      ]),
    );
  }
}

class _FeedPremiumBadge extends StatelessWidget {
  final String badgeType;
  const _FeedPremiumBadge({this.badgeType = ''});

  @override
  Widget build(BuildContext context) {
    final lifetime = badgeType == 'premium_lifetime';
    return Padding(
      padding: const EdgeInsets.only(right: 2),
      child: Icon(Icons.workspace_premium_rounded, color: lifetime ? const Color(0xFFB56CFF) : AppTheme.luxuryGold, size: 16),
    );
  }
}

// ============================================================
// REUSABLE WIDGETS / GALAXY COMPONENTS RESTORED FROM BASELINE
// ============================================================

// ============================================================
// REUSABLE WIDGETS
// ============================================================

class SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;

  const SectionHeader({
    super.key,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        bottom: 16,
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: AppTheme.neonGreen,
              fontSize: 25,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            subtitle,
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .55),
            ),
          ),
        ],
      ),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;

  const GlassCard({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final isLight = Theme.of(context).brightness == Brightness.light;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isLight ? Theme.of(context).colorScheme.surface : AppTheme.adaptiveSurface(Color(0xDD0A0E10)),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isLight ? const Color(0x338A6A18) : const Color(0x3059D7FF),
        ),
        boxShadow: [
          BoxShadow(
            color: isLight ? const Color(0x22000000) : const Color(0x44000000),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: DefaultTextStyle.merge(
        style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
        child: IconTheme.merge(
          data: IconThemeData(color: Theme.of(context).colorScheme.onSurface),
          child: child,
        ),
      ),
    );
  }
}

class PostCard extends StatelessWidget {
  final String username;
  final String text;
  final bool verified;

  const PostCard({
    super.key,
    required this.username,
    required this.text,
    this.verified = false,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: Color(0xFF14231A),
                child: Icon(
                  Icons.person,
                  color: AppTheme.neonGreen,
                ),
              ),

              const SizedBox(width: 10),

              Expanded(
                child: Text(
                  username,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              if (verified)
                Icon(
                  Icons.verified,
                  color: AppTheme.neonGreen,
                ),

              Icon(
                Icons.workspace_premium,
                color: AppTheme.luxuryGold,
              ),
            ],
          ),

          const SizedBox(height: 14),

          Text(text),

          const SizedBox(height: 12),

          Row(
            children: [
              IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.favorite_border,
                ),
              ),
              const Text('Like'),

              const SizedBox(width: 15),

              IconButton(
                onPressed: () {},
                icon: const Icon(
                  Icons.comment_outlined,
                ),
              ),
              const Text('Comment'),
            ],
          ),
        ],
      ),
    );
  }
}

class CallCard extends StatelessWidget {
  final String asset;
  final String title;
  final bool locked;

  const CallCard({
    super.key,
    required this.asset,
    required this.title,
    required this.locked,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Stack(
        children: [
          Opacity(
            opacity: locked ? 0.20 : 1,
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  asset,
                  style: TextStyle(
                    color: AppTheme.neonGreen,
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                  ),
                ),

                const SizedBox(height: 5),

                Text(title),

                const SizedBox(height: 16),

                Container(
                  height: 65,
                  decoration: BoxDecoration(
                    color: AppTheme.adaptiveSurface(Color(0xFF14191B)),
                    borderRadius:
                        BorderRadius.circular(12),
                  ),
                ),
              ],
            ),
          ),

          if (locked)
            Positioned.fill(
              child: InkWell(
                onTap: () {
                  showPremiumDialog(
                    context,
                    'PREMIUM CALL',
                  );
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xDD050607),
                    borderRadius:
                        BorderRadius.circular(20),
                  ),
                  child: Column(
                    mainAxisAlignment:
                        MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.lock,
                        color:
                            AppTheme.luxuryGold,
                        size: 36,
                      ),
                      SizedBox(height: 8),
                      Text(
                        'UPGRADE TO PREMIUM',
                        style: TextStyle(
                          color:
                              AppTheme.neonGreen,
                          fontWeight:
                              FontWeight.w900,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'to see more calls',
                        style: TextStyle(
                          color: AppTheme.textSoft,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class LockedLesson extends StatelessWidget {
  final String title;

  const LockedLesson({
    super.key,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: ListTile(
        leading: Icon(
          Icons.lock,
          color: AppTheme.luxuryGold,
        ),
        title: Text(title),
        subtitle: const Text(
          'Locked until mentorship access is verified.',
        ),
      ),
    );
  }
}

class _UserPayoutPaymentDetailsPage extends StatefulWidget {
  const _UserPayoutPaymentDetailsPage();

  @override
  State<_UserPayoutPaymentDetailsPage> createState() => _UserPayoutPaymentDetailsPageState();
}

class _UserPayoutPaymentDetailsPageState extends State<_UserPayoutPaymentDetailsPage> {
  static const _methods = <String>['BEP20', 'TRC20', 'ERC20', 'Easypaisa'];
  final _detailController = TextEditingController();
  String _method = 'BEP20';
  String _userName = '';
  String _uid = '';
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _detailController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final user = AuthService.currentUser;
    if (user == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    _uid = user.uid;
    try {
      final profile = await ProfileService.loadUserProfile(user.uid);
      _userName = (profile?['displayName'] ?? user.displayName ?? '').toString().trim();
      final data = await PayoutService.load(uid: user.uid);
      if (data != null) {
        final savedMethod = (data['paymentMethod'] ?? '').toString().trim();
        if (_methods.contains(savedMethod)) _method = savedMethod;
        _detailController.text = (data['paymentDetail'] ?? '').toString();
        if (_userName.isEmpty) _userName = (data['userName'] ?? '').toString().trim();
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  String get _detailLabel {
    switch (_method) {
      case 'BEP20':
        return 'USDT wallet address — BEP20';
      case 'TRC20':
        return 'USDT wallet address — TRC20';
      case 'ERC20':
        return 'USDT wallet address — ERC20';
      default:
        return 'Easypaisa mobile/account number';
    }
  }

  String get _detailHint {
    switch (_method) {
      case 'BEP20':
        return 'Enter the wallet address that should receive your USDT on BEP20.';
      case 'TRC20':
        return 'Enter the wallet address that should receive your USDT on TRC20.';
      case 'ERC20':
        return 'Enter the wallet address that should receive your USDT on ERC20.';
      default:
        return 'Enter the Easypaisa number/account detail that should receive your payout.';
    }
  }

  Future<void> _save() async {
    final user = AuthService.currentUser;
    if (user == null || _saving) return;
    final detail = _detailController.text.trim();
    if (detail.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Enter your $_detailLabel.')));
      return;
    }
    if (_userName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please set your name in Edit Profile before saving payout details.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await PayoutService.save(
        uid: user.uid,
        userName: _userName,
        paymentMethod: _method,
        paymentDetail: detail,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Your payout details were saved securely.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save your payout details. Please try again.')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  InputDecoration _decoration(String label, IconData icon) => InputDecoration(
        labelText: label,
        helperText: _detailHint,
        helperMaxLines: 3,
        prefixIcon: Icon(icon, size: 18, color: AppTheme.luxuryGold),
        filled: true,
        fillColor: Theme.of(context).brightness == Brightness.light ? const Color(0xFFFFFCF6) : AppTheme.adaptiveSurface(const Color(0xFF11161A)),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      );

  @override
  Widget build(BuildContext context) {
    final light = Theme.of(context).brightness == Brightness.light;
    if (_loading) {
      return Scaffold(appBar: AppBar(title: const Text('PAYMENT DETAILS')), body: const Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('PAYMENT DETAILS')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        children: [
          GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(Icons.account_balance_wallet_outlined, color: light ? const Color(0xFF6F5414) : AppTheme.luxuryGold),
                const SizedBox(width: 9),
                Expanded(child: Text('YOUR PAYOUT DETAILS', style: TextStyle(color: light ? const Color(0xFF6F5414) : AppTheme.luxuryGold, fontWeight: FontWeight.w900, letterSpacing: .8))),
              ]),
              const SizedBox(height: 7),
              Text(
                'This section stores your own payout destination so Crypto Doctors Hub can send eligible earnings to you. It is not the payment information used to receive Premium or Mentorship payments.',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .65), fontSize: 10, height: 1.45),
              ),
              const SizedBox(height: 14),
              Text('User name', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .55), fontSize: 10)),
              const SizedBox(height: 3),
              Text(_userName.isEmpty ? 'Name not set' : _userName, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
              const SizedBox(height: 9),
              Text('UID', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .55), fontSize: 10)),
              const SizedBox(height: 3),
              SelectableText(_uid, style: TextStyle(color: Theme.of(context).colorScheme.onSurface, fontSize: 11, fontWeight: FontWeight.w700)),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                initialValue: _method,
                decoration: InputDecoration(
                  labelText: 'Payout method',
                  prefixIcon: Icon(Icons.payments_outlined, color: AppTheme.luxuryGold, size: 18),
                  filled: true,
                  fillColor: light ? const Color(0xFFFFFCF6) : AppTheme.adaptiveSurface(const Color(0xFF11161A)),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
                items: _methods.map((m) => DropdownMenuItem(value: m, child: Text(m == 'Easypaisa' ? 'Easypaisa' : 'USDT — $m'))).toList(),
                onChanged: (value) {
                  if (value == null) return;
                  setState(() => _method = value);
                },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _detailController,
                keyboardType: _method == 'Easypaisa' ? TextInputType.phone : TextInputType.text,
                minLines: _method == 'Easypaisa' ? 1 : 2,
                maxLines: _method == 'Easypaisa' ? 1 : 3,
                decoration: _decoration(_detailLabel, _method == 'Easypaisa' ? Icons.phone_android_rounded : Icons.currency_exchange_rounded),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: light ? const Color(0xFFF2EBDD) : AppTheme.adaptiveWhite(alpha: .025),
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(color: light ? const Color(0x338A6A18) : AppTheme.fillFaint),
                ),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(Icons.security_rounded, color: light ? const Color(0xFF8A6A18) : AppTheme.luxuryGold, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: Text(
                    _method == 'Easypaisa'
                        ? 'Easypaisa is stored as your payout destination. Crypto payouts are always USDT only.'
                        : 'Crypto payouts are USDT only. Make sure the selected network matches the wallet address you provide.',
                    style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .60), fontSize: 9.5, height: 1.35),
                  )),
                ]),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: const Icon(Icons.save_outlined),
                  label: Text(_saving ? 'SAVING...' : 'SAVE PAYOUT DETAILS'),
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

class ReferralPaymentDetailsCard extends StatefulWidget {
  const ReferralPaymentDetailsCard({super.key});

  @override
  State<ReferralPaymentDetailsCard> createState() => _ReferralPaymentDetailsCardState();
}

class _ReferralPaymentDetailsCardState extends State<ReferralPaymentDetailsCard> {
  final _recipientController = TextEditingController();
  final _trc20Controller = TextEditingController();
  final _bep20Controller = TextEditingController();
  final _erc20Controller = TextEditingController();
  final _easypaisaController = TextEditingController();
  String _country = 'Pakistan';
  String _preferredMethod = 'USDT TRC-20';
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _recipientController.dispose();
    _trc20Controller.dispose();
    _bep20Controller.dispose();
    _erc20Controller.dispose();
    _easypaisaController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final user = AuthService.currentUser;
    if (user == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      final data = await ProfileService.loadReferralPaymentDetails(uid: user.uid);
      if (data != null) {
        _country = (data['country'] ?? 'Pakistan').toString();
        if (_country != 'Pakistan') _country = 'Other';
        _preferredMethod = (data['preferredMethod'] ?? 'USDT TRC-20').toString();
        if (!const ['USDT TRC-20', 'USDT BEP-20', 'USDT ERC-20', 'Easypaisa'].contains(_preferredMethod)) _preferredMethod = 'USDT TRC-20';
        _recipientController.text = (data['recipientName'] ?? '').toString();
        _trc20Controller.text = (data['usdtTrc20Address'] ?? '').toString();
        _bep20Controller.text = (data['usdtBep20Address'] ?? '').toString();
        _erc20Controller.text = (data['usdtErc20Address'] ?? '').toString();
        _easypaisaController.text = (data['easypaisaNumber'] ?? '').toString();
        if (_country != 'Pakistan' && _preferredMethod == 'Easypaisa') _preferredMethod = 'USDT TRC-20';
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    final user = AuthService.currentUser;
    if (user == null || _saving) return;
    final recipient = _recipientController.text.trim();
    final trc20 = _trc20Controller.text.trim();
    final bep20 = _bep20Controller.text.trim();
    final erc20 = _erc20Controller.text.trim();
    final easypaisa = _easypaisaController.text.trim();
    if (recipient.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter the recipient name for referral incentives.')));
      return;
    }
    if (trc20.isEmpty && bep20.isEmpty && erc20.isEmpty && (_country != 'Pakistan' || easypaisa.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add at least one USDT address or, for Pakistan, an Easypaisa number.')));
      return;
    }
    if (_preferredMethod == 'Easypaisa' && _country != 'Pakistan') {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Easypaisa is only available for direct PKR payments in Pakistan.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await ProfileService.saveReferralPaymentDetails(
        uid: user.uid,
        country: _country,
        preferredMethod: _preferredMethod,
        recipientName: recipient,
        usdtTrc20Address: trc20,
        usdtBep20Address: bep20,
        usdtErc20Address: erc20,
        easypaisaNumber: easypaisa,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Payment details saved securely.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save payment details. Please try again.')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  InputDecoration _decoration(String label, IconData icon) => InputDecoration(
    labelText: label,
    prefixIcon: Icon(icon, size: 18, color: AppTheme.luxuryGold),
    filled: true,
    fillColor: Theme.of(context).brightness == Brightness.light ? const Color(0xFFFFFCF6) : AppTheme.adaptiveSurface(Color(0xFF11161A)),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
  );

  @override
  Widget build(BuildContext context) {
    if (_loading) return const GlassCard(child: Padding(padding: EdgeInsets.all(18), child: Center(child: CircularProgressIndicator())));
    final cryptoMethods = const ['USDT TRC-20', 'USDT BEP-20', 'USDT ERC-20'];
    final methods = _country == 'Pakistan' ? [...cryptoMethods, 'Easypaisa'] : cryptoMethods;
    if (!methods.contains(_preferredMethod)) _preferredMethod = methods.first;
    final light = Theme.of(context).brightness == Brightness.light;
    final text = Theme.of(context).colorScheme.onSurface;
    return GlassCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('PAYMENT DETAILS', style: TextStyle(color: light ? const Color(0xFF6F5414) : AppTheme.luxuryGold, fontWeight: FontWeight.w900, letterSpacing: .8)),
        const SizedBox(height: 5),
        Text('Referral rewards are paid in USDT only. For Pakistan, direct PKR payments can be received through Easypaisa.', style: TextStyle(color: text.withValues(alpha: .60), fontSize: 10, height: 1.4)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          initialValue: _country,
          decoration: _decoration('Country', Icons.public_rounded),
          items: const [DropdownMenuItem(value: 'Pakistan', child: Text('Pakistan')), DropdownMenuItem(value: 'Other', child: Text('Other country'))],
          onChanged: (value) => setState(() {
            _country = value ?? 'Pakistan';
            if (_country != 'Pakistan' && _preferredMethod == 'Easypaisa') _preferredMethod = 'USDT TRC-20';
          }),
        ),
        const SizedBox(height: 10),
        TextField(controller: _recipientController, decoration: _decoration('Recipient / account name', Icons.person_outline_rounded)),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          initialValue: _preferredMethod,
          decoration: _decoration('Preferred payment method', Icons.account_balance_wallet_outlined),
          items: methods.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
          onChanged: (value) => setState(() => _preferredMethod = value ?? methods.first),
        ),
        const SizedBox(height: 10),
        TextField(controller: _trc20Controller, decoration: _decoration('USDT — TRC-20 address', Icons.currency_exchange_rounded)),
        const SizedBox(height: 10),
        TextField(controller: _bep20Controller, decoration: _decoration('USDT — BEP-20 address', Icons.currency_exchange_rounded)),
        const SizedBox(height: 10),
        TextField(controller: _erc20Controller, decoration: _decoration('USDT — ERC-20 address', Icons.currency_exchange_rounded)),
        if (_country == 'Pakistan') ...[
          const SizedBox(height: 12),
          TextField(controller: _easypaisaController, keyboardType: TextInputType.phone, decoration: _decoration('Easypaisa number (Pakistan only)', Icons.phone_android_rounded)),
          const SizedBox(height: 5),
          Text('Available for direct PKR payments.', style: TextStyle(color: light ? const Color(0xFF6A665D) : AppTheme.textMuted, fontSize: 9.5, fontWeight: FontWeight.w700)),
        ],
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: light ? const Color(0xFFF2EBDD) : AppTheme.adaptiveWhite(alpha: .025), borderRadius: BorderRadius.circular(11), border: Border.all(color: light ? const Color(0x338A6A18) : AppTheme.fillFaint)),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.security_rounded, color: light ? const Color(0xFF8A6A18) : AppTheme.luxuryGold, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(_country == 'Pakistan' ? 'Crypto referral rewards use USDT addresses only. Easypaisa is for direct PKR payments.' : 'Crypto referral rewards use USDT addresses only.', style: TextStyle(color: text.withValues(alpha: .58), fontSize: 9.5, height: 1.35))),
          ]),
        ),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.save_outlined), label: Text(_saving ? 'SAVING...' : 'SAVE PAYMENT DETAILS'))),
      ]),
    );
  }
}

class ReferralCard extends StatelessWidget {
  const ReferralCard({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const _ReferralCardBody(referrals: 0);
    return StreamBuilder<Map<String, dynamic>?>(
      stream: AlphaDenService.watchProfile(uid),
      builder: (context, snapshot) {
        final referrals = (snapshot.data?['referrals'] as num?)?.toInt() ?? 0;
        return _ReferralCardBody(referrals: referrals);
      },
    );
  }
}

class _ReferralCardBody extends StatelessWidget {
  final int referrals;
  const _ReferralCardBody({required this.referrals});

  @override
  Widget build(BuildContext context) {
    final tiers = <({int min, String label, String reward, String range, String colorName})>[
      (min: 0, label: 'BROWN CROWN', reward: '\$0', range: '0 referrals', colorName: 'BROWN'),
      (min: 1, label: 'BLUE CROWN', reward: '\$4 / \$8', range: '1–2 referrals', colorName: 'BLUE'),
      (min: 3, label: 'PURPLE CROWN', reward: '\$9 / \$12', range: '3–4 referrals', colorName: 'PURPLE'),
      (min: 5, label: 'GOLDEN CROWN', reward: '\$15 / \$18 / \$21', range: '5–7 referrals', colorName: 'GOLD'),
      (min: 8, label: 'GOLDEN CROWN', reward: 'Progress to 10+', range: '8–9 referrals', colorName: 'GOLD'),
      (min: 10, label: 'BLACK + GOLD CROWN', reward: '10+ referrals', range: 'FLAME AURA', colorName: 'BLACK + GOLD'),
    ];
    return GlassCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('REFERRAL REWARDS & CROWNS', style: TextStyle(color: AppTheme.luxuryGold, fontWeight: FontWeight.w900, letterSpacing: 0.7)),
        const SizedBox(height: 6),
        const SizedBox(height: 3),
        Text('Your crown updates live as your qualified referral count changes.', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .60), fontSize: 10, height: 1.35)),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .025), borderRadius: BorderRadius.circular(18), border: Border.all(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .10))),
          child: Row(children: [
            _ReferralCrownShowcase(referrals: referrals),
            const SizedBox(width: 13),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_crownTitleForReferrals(referrals), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(_crownRewardForReferrals(referrals), style: TextStyle(color: AppTheme.luxuryGold, fontSize: 10, fontWeight: FontWeight.w800)),
            ])),
          ]),
        ),
        const SizedBox(height: 12),
        for (final tier in tiers)
          _ReferralTierRow(
            referrals: referrals,
            min: tier.min,
            range: tier.range,
            label: tier.label,
            reward: tier.reward,
            colorName: tier.colorName,
          ),
      ]),
    );
  }
}

String _crownTitleForReferrals(int r) {
  if (r >= 10) return 'BLACK + GOLD CROWN';
  if (r >= 5) return 'GOLDEN CROWN';
  if (r >= 3) return 'PURPLE CROWN';
  if (r >= 1) return 'BLUE CROWN';
  return 'BROWN CROWN';
}

String _crownRewardForReferrals(int r) {
  if (r >= 10) return '10+ qualified referrals • flame aura';
  if (r >= 7) return '7 qualified referrals • \$21';
  if (r >= 6) return '6 qualified referrals • \$18';
  if (r >= 5) return '5 qualified referrals • \$15';
  if (r >= 4) return '4 qualified referrals • \$12';
  if (r >= 3) return '3 qualified referrals • \$9';
  if (r == 2) return '2 qualified referrals • \$8';
  if (r == 1) return '1 qualified referral • \$4';
  return 'Build your first qualified referral';
}

class _ReferralCrownShowcase extends StatelessWidget {
  final int referrals;
  const _ReferralCrownShowcase({required this.referrals});
  @override
  Widget build(BuildContext context) => SizedBox(width: 76, height: 58, child: Center(child: Transform.scale(scale: 1.75, child: _ReferralCrownBadge(referrals: referrals))));
}

class _ReferralTierRow extends StatelessWidget {
  final int referrals;
  final int min;
  final String range;
  final String label;
  final String reward;
  final String colorName;
  const _ReferralTierRow({required this.referrals, required this.min, required this.range, required this.label, required this.reward, required this.colorName});

  @override
  Widget build(BuildContext context) {
    final active = referrals >= min && (min == 10 || referrals < (min == 0 ? 1 : min == 1 ? 3 : min == 3 ? 5 : min == 5 ? 10 : 10));
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
      decoration: BoxDecoration(color: active ? Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.055) : Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.018), borderRadius: BorderRadius.circular(12), border: Border.all(color: active ? AppTheme.luxuryGold.withValues(alpha: 0.45) : Theme.of(context).colorScheme.onSurface.withValues(alpha: .10))),
      child: Row(children: [
        SizedBox(width: 38, child: Transform.scale(scale: 0.9, child: _ReferralCrownBadge(referrals: min >= 10 ? 10 : min))),
        const SizedBox(width: 7),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(range, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900)), Text(label, style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .54), fontSize: 8))])),
        Text(reward, style: TextStyle(color: active ? AppTheme.luxuryGold : Theme.of(context).colorScheme.onSurface.withValues(alpha: .54), fontSize: 8, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class _ReferralCrownBadge extends StatefulWidget {
  final int referrals;
  final bool flamingAura;
  const _ReferralCrownBadge({required this.referrals, this.flamingAura = false});
  @override
  State<_ReferralCrownBadge> createState() => _ReferralCrownBadgeState();
}

class _ReferralCrownBadgeState extends State<_ReferralCrownBadge>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2400),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.referrals;
    final flame = widget.flamingAura || r >= 10;
    final purple = r >= 3 && r <= 4;
    final enhancedGold = r >= 8 && r <= 9;
    final gold = r >= 5 && r <= 9;
    final crown = widget.flamingAura
        ? const Color(0xFFE7C76B)
        : r == 0
        ? const Color(0xFF9A6748)
        : r <= 2
            ? const Color(0xFF4FA8FF)
            : purple
                ? const Color(0xFFB86CFF)
                : flame
                    ? const Color(0xFFE7C76B)
                    : const Color(0xFFFFD34D);
    final dark = r == 0
        ? const Color(0xFF382116)
        : r <= 2
            ? const Color(0xFF0B294D)
            : purple
                ? const Color(0xFF32104F)
                : flame
                    ? const Color(0xFF07080A)
                    : const Color(0xFF714700);

    return AnimatedBuilder(
      animation: _controller,
      builder: (_, _) {
        final t = _controller.value * math.pi * 2;
        final pulse = .72 + .28 * ((math.sin(t) + 1) / 2);
        final glowColor = purple
            ? const Color(0xFFB86CFF)
            : gold
                ? const Color(0xFFFFD34D)
                : crown;
        final glowStrength = flame ? 1.25 : enhancedGold ? 1.12 : purple ? .95 : .62;
        return SizedBox(
          width: 27,
          height: flame ? 28 : 23,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              if (flame)
                Positioned.fill(
                  child: CustomPaint(
                    painter: _MiniCrownFlamePainter(progress: _controller.value),
                  ),
                ),
              Container(
                width: 24,
                height: 20,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(7),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: flame
                        ? [const Color(0xFF30343A), const Color(0xFF08090B), const Color(0xFF000000)]
                        : [dark, crown.withValues(alpha: .38), const Color(0xFF080A0C)],
                  ),
                  border: Border.all(
                    color: flame ? const Color(0xFFE7C76B) : crown.withValues(alpha: .82),
                    width: flame ? 1.0 : .75,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: glowColor.withValues(alpha: .17 + .20 * pulse * glowStrength),
                      blurRadius: flame ? 13 : enhancedGold ? 9 : purple ? 8 : 5,
                      spreadRadius: flame ? 1.4 : enhancedGold ? .8 : 0,
                    ),
                    if (flame)
                      BoxShadow(
                        color: const Color(0xFFFF5A2A).withValues(alpha: .20 + .12 * pulse),
                        blurRadius: 16,
                        spreadRadius: 2,
                      ),
                  ],
                ),
                child: CustomPaint(
                  painter: _ThreeDCrownPainter(
                    base: crown,
                    dark: dark,
                    progress: _controller.value,
                    blackGold: flame,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ThreeDCrownPainter extends CustomPainter {
  final Color base, dark;
  final double progress;
  final bool blackGold;
  const _ThreeDCrownPainter({
    required this.base,
    required this.dark,
    required this.progress,
    this.blackGold = false,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    final shadow = Path()
      ..moveTo(w * .08, h * .25)
      ..lineTo(w * .26, h * .43)
      ..lineTo(w * .50, h * .29)
      ..lineTo(w * .74, h * .43)
      ..lineTo(w * .92, h * .25)
      ..lineTo(w * .82, h * .83)
      ..quadraticBezierTo(w * .50, h * .96, w * .18, h * .83)
      ..close();
    canvas.drawPath(shadow, Paint()..color = Colors.black.withValues(alpha: .78));

    final front = Path()
      ..moveTo(w * .07, h * .20)
      ..lineTo(w * .25, h * .42)
      ..lineTo(w * .50, h * .27)
      ..lineTo(w * .75, h * .42)
      ..lineTo(w * .93, h * .20)
      ..lineTo(w * .82, h * .70)
      ..quadraticBezierTo(w * .50, h * .86, w * .18, h * .70)
      ..close();

    final shader = LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: blackGold
          ? [const Color(0xFFF5E3A0), const Color(0xFF8E7440), const Color(0xFF22252A), const Color(0xFF050608)]
          : [AppTheme.adaptiveWhite(alpha: .88), base, dark],
      stops: blackGold ? const [.0, .28, .62, 1] : null,
    ).createShader(Rect.fromLTWH(0, 0, w, h));
    canvas.drawPath(front, Paint()..shader = shader);

    final edge = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = blackGold ? .9 : .7
      ..color = (blackGold ? const Color(0xFFFFE7A0) : AppTheme.textPrimary).withValues(alpha: .38);
    canvas.drawPath(front, edge);

    final glintAlpha = .42 + .22 * ((math.sin(progress * math.pi * 2) + 1) / 2);
    final glint = Paint()
      ..color = AppTheme.adaptiveWhite(alpha: glintAlpha)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, .7);
    canvas.drawCircle(Offset(w * .25, h * .42), 1.0, glint);
    canvas.drawCircle(Offset(w * .50, h * .28), 1.15, glint);
    canvas.drawCircle(Offset(w * .75, h * .42), 1.0, glint);

    if (blackGold) {
      final inner = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .55
        ..color = const Color(0xFFFFD86A).withValues(alpha: .42);
      final innerPath = Path()
        ..moveTo(w * .17, h * .57)
        ..quadraticBezierTo(w * .50, h * .75, w * .83, h * .57);
      canvas.drawPath(innerPath, inner);
    }
  }

  @override
  bool shouldRepaint(covariant _ThreeDCrownPainter oldDelegate) =>
      oldDelegate.progress != progress ||
      oldDelegate.base != base ||
      oldDelegate.dark != dark ||
      oldDelegate.blackGold != blackGold;
}

class _MiniCrownFlamePainter extends CustomPainter {
  final double progress;
  const _MiniCrownFlamePainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final t = progress * math.pi * 2;

    void drawCornerFlame(Offset base, double scale, double phase, bool mirror) {
      final sway = math.sin(t * 1.15 + phase) * scale * .13;
      final outer = Path()
        ..moveTo(base.dx - scale * .34, base.dy)
        ..quadraticBezierTo(base.dx - scale * .12 + sway, base.dy - scale * .34, base.dx + sway, base.dy - scale)
        ..quadraticBezierTo(base.dx + scale * .18 + sway, base.dy - scale * .50, base.dx + scale * .38, base.dy)
        ..close();
      canvas.drawPath(
        outer,
        Paint()
          ..color = const Color(0xFFFF3B22).withValues(alpha: .56)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.8),
      );
      final mid = Path()
        ..moveTo(base.dx - scale * .23, base.dy)
        ..quadraticBezierTo(base.dx - scale * .06 + sway, base.dy - scale * .32, base.dx + sway, base.dy - scale * .78)
        ..quadraticBezierTo(base.dx + scale * .12 + sway, base.dy - scale * .39, base.dx + scale * .25, base.dy)
        ..close();
      canvas.drawPath(mid, Paint()..color = const Color(0xFFFF8A24).withValues(alpha: .82));
      final inner = Path()
        ..moveTo(base.dx - scale * .11, base.dy)
        ..quadraticBezierTo(base.dx + sway * .45, base.dy - scale * .28, base.dx + sway, base.dy - scale * .58)
        ..quadraticBezierTo(base.dx + scale * .07 + sway, base.dy - scale * .30, base.dx + scale * .13, base.dy)
        ..close();
      canvas.drawPath(inner, Paint()..color = const Color(0xFFFFE7A0).withValues(alpha: .94));
    }

    // Flames originate from the four corners and rise outward, rather than
    // looking like a flat row underneath the crown.
    drawCornerFlame(Offset(3, size.height - 2), 9, 0.4, true);
    drawCornerFlame(Offset(size.width - 3, size.height - 2), 9, 2.1, true);
    drawCornerFlame(Offset(4, size.height * .72), 6.5, 3.4, true);
    drawCornerFlame(Offset(size.width - 4, size.height * .72), 6.5, 4.8, true);
  }

  @override
  bool shouldRepaint(covariant _MiniCrownFlamePainter oldDelegate) => oldDelegate.progress != progress;
}

class ReferralRow extends StatelessWidget {
  final String text;

  const ReferralRow({
    super.key,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 5,
      ),
      child: Row(
        children: [
          Icon(
            Icons.workspace_premium,
            color: AppTheme.luxuryGold,
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(text),
          ),
        ],
      ),
    );
  }
}

class _MarketAsset {
  final String symbol;
  final String name;
  final double price;
  final double change24h;
  final String logoUrl;

  const _MarketAsset({
    required this.symbol,
    required this.name,
    required this.price,
    required this.change24h,
    required this.logoUrl,
  });

  factory _MarketAsset.fromJson(Map<String, dynamic> json) {
    return _MarketAsset(
      symbol: (json['symbol'] ?? '').toString().toUpperCase(),
      name: (json['name'] ?? '').toString(),
      price: (json['current_price'] as num?)?.toDouble() ?? 0,
      change24h: (json['price_change_percentage_24h'] as num?)?.toDouble() ?? 0,
      logoUrl: (json['image'] ?? '').toString(),
    );
  }
}

class _LiveMarketStore {
  static const _url = 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=24h';
  static const _binanceUrl = 'https://api.binance.com/api/v3/ticker/24hr';

  static Future<List<_MarketAsset>> fetchTop100() async {
    try {
      final response = await html.HttpRequest.request(_url, method: 'GET', requestHeaders: const {'accept': 'application/json'});
      if (response.status == 200) {
        final decoded = jsonDecode(response.responseText ?? '[]');
        if (decoded is List) {
          final assets = decoded.whereType<Map>()
              .map((item) => _MarketAsset.fromJson(Map<String, dynamic>.from(item)))
              .where((asset) => asset.price > 0).toList();
          if (assets.length >= 4) return assets;
        }
      }
    } catch (_) {}
    return _fetchFromBinance();
  }

  static String _logoUrlForSymbol(String symbol) {
    const coinGeckoIds = <String, String>{
      'BTC': 'bitcoin',
      'ETH': 'ethereum',
      'SOL': 'solana',
      'XRP': 'ripple',
      'DOGE': 'dogecoin',
      'BNB': 'binancecoin',
      'ADA': 'cardano',
      'AVAX': 'avalanche-2',
      'LINK': 'chainlink',
      'TRX': 'tron',
      'DOT': 'polkadot',
      'LTC': 'litecoin',
      'BCH': 'bitcoin-cash',
      'UNI': 'uniswap',
      'ATOM': 'cosmos',
      'ETC': 'ethereum-classic',
    };
    final id = coinGeckoIds[symbol.toUpperCase()];
    if (id != null) {
      return 'https://coin-images.coingecko.com/coins/images/'
          '${_coinGeckoImageId(id)}/large/$id.png';
    }
    // Binance fallback symbols do not include a CoinGecko coin id.
    // CoinCap provides a direct PNG logo path keyed by symbol.
    return 'https://assets.coincap.io/assets/icons/${symbol.toLowerCase()}@2x.png';
  }

  static int _coinGeckoImageId(String id) {
    const imageIds = <String, int>{
      'bitcoin': 1,
      'ethereum': 279,
      'solana': 4128,
      'ripple': 44,
      'dogecoin': 5,
      'binancecoin': 825,
      'cardano': 975,
      'avalanche-2': 12559,
      'chainlink': 877,
      'tron': 1094,
      'polkadot': 12171,
      'litecoin': 2,
      'bitcoin-cash': 780,
      'uniswap': 12504,
      'cosmos': 5894,
      'ethereum-classic': 1321,
    };
    return imageIds[id] ?? 0;
  }

  static Future<List<_MarketAsset>> _fetchFromBinance() async {
    final response = await html.HttpRequest.request(_binanceUrl, method: 'GET', requestHeaders: const {'accept': 'application/json'});
    if (response.status != 200) throw Exception('Live market services are temporarily unavailable.');
    final decoded = jsonDecode(response.responseText ?? '[]');
    if (decoded is! List) throw Exception('Invalid backup market response.');
    const preferred = <String>['BTC','ETH','SOL','XRP','DOGE','BNB','ADA','AVAX','LINK','TRX','DOT','LTC','BCH','UNI','ATOM','ETC'];
    final rows = decoded.whereType<Map>().map((raw) {
      final item = Map<String, dynamic>.from(raw);
      final symbol = (item['symbol'] ?? '').toString().toUpperCase();
      if (!symbol.endsWith('USDT')) return null;
      final base = symbol.substring(0, symbol.length - 4);
      if (base.isEmpty || base.contains('UP') || base.contains('DOWN') || base.contains('BULL') || base.contains('BEAR')) return null;
      final price = double.tryParse((item['lastPrice'] ?? '').toString()) ?? 0;
      final change = double.tryParse((item['priceChangePercent'] ?? '').toString()) ?? 0;
      final volume = double.tryParse((item['quoteVolume'] ?? '').toString()) ?? 0;
      if (price <= 0) return null;
      return <String, dynamic>{'symbol': base, 'price': price, 'change': change, 'volume': volume};
    }).whereType<Map<String, dynamic>>().toList();
    final bySymbol = <String, Map<String, dynamic>>{for (final row in rows) row['symbol'] as String: row};
    final selected = <Map<String, dynamic>>[];
    for (final symbol in preferred) { final row = bySymbol[symbol]; if (row != null) selected.add(row); }
    final remainder = rows.where((row) => !preferred.contains(row['symbol'])).toList()
      ..sort((a, b) => (b['volume'] as double).compareTo(a['volume'] as double));
    selected.addAll(remainder);
    return selected.take(100).map((row) => _MarketAsset(
      symbol: row['symbol'] as String,
      name: row['symbol'] as String,
      price: row['price'] as double,
      change24h: row['change'] as double,
      logoUrl: _logoUrlForSymbol(row['symbol'] as String),
    )).toList();
  }
}

class LiveMarketPreview extends StatefulWidget {
  const LiveMarketPreview({super.key});

  @override
  State<LiveMarketPreview> createState() => _LiveMarketPreviewState();
}

class _LiveMarketPreviewState extends State<LiveMarketPreview> {
  late Future<List<_MarketAsset>> _future;
  Timer? _marketTimer;

  @override
  void initState() {
    super.initState();
    _future = _LiveMarketStore.fetchTop100();
    _marketTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (!mounted) return;
      setState(() => _future = _LiveMarketStore.fetchTop100());
    });
  }

  @override
  void dispose() {
    _marketTimer?.cancel();
    super.dispose();
  }

  void _refresh() {
    setState(() => _future = _LiveMarketStore.fetchTop100());
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<_MarketAsset>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const SizedBox(
            height: 170,
            child: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Live market data could not be loaded right now.',
                style: TextStyle(color: AppTheme.textSoft, fontSize: 12),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: _refresh,
                icon: const Icon(Icons.refresh),
                label: const Text('RETRY'),
              ),
            ],
          );
        }

        final visible = snapshot.data!.take(4).toList();

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: _MarketPreviewTile(asset: visible[0])),
                const SizedBox(width: 10),
                if (visible.length > 1)
                  Expanded(child: _MarketPreviewTile(asset: visible[1]))
                else
                  const Expanded(child: SizedBox()),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (visible.length > 2)
                  Expanded(child: _MarketPreviewTile(asset: visible[2]))
                else
                  const Expanded(child: SizedBox()),
                const SizedBox(width: 10),
                if (visible.length > 3)
                  Expanded(child: _MarketPreviewTile(asset: visible[3]))
                else
                  const Expanded(child: SizedBox()),
              ],
            ),
            const SizedBox(height: 2),
            IconButton(
              tooltip: 'Open Top 100 market',
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => _Top100MarketPage(assets: snapshot.data!),
                  ),
                );
              },
              icon: Icon(Icons.keyboard_arrow_down_rounded, color: AppTheme.textSecondary, size: 24),
              visualDensity: VisualDensity.compact,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 30, minHeight: 30),
            ),
          ],
        );
      },
    );
  }
}

class _MarketPreviewTile extends StatelessWidget {
  final _MarketAsset asset;

  const _MarketPreviewTile({required this.asset});

  void _openChart(BuildContext context) {
    if (!_LiveCoinChartStore.supportedSymbols.contains(asset.symbol)) return;
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _LiveCoinChartPage(asset: asset),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final positive = asset.change24h >= 0;
    final chartEnabled = _LiveCoinChartStore.supportedSymbols.contains(asset.symbol);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: chartEnabled ? () => _openChart(context) : null,
        borderRadius: BorderRadius.circular(14),
        child: Ink(
          height: 82,
          padding: const EdgeInsets.fromLTRB(9, 8, 9, 7),
          decoration: BoxDecoration(
            color: AppTheme.adaptiveSurface(Color(0xFF303238)).withValues(alpha: 0.94),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppTheme.adaptiveWhite(alpha: 0.09)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.12),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 13,
                    backgroundColor: AppTheme.adaptiveSurface(Color(0xFF202228)).withValues(alpha: 0.86),
                    backgroundImage: asset.logoUrl.isNotEmpty
                        ? NetworkImage(asset.logoUrl)
                        : null,
                    child: asset.logoUrl.isEmpty
                        ? Icon(
                            Icons.currency_bitcoin,
                            size: 14,
                            color: AppTheme.textSecondary,
                          )
                        : null,
                  ),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      asset.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w800,
                        fontSize: 11,
                      ),
                    ),
                  ),
                  if (chartEnabled)
                    Icon(Icons.show_chart_rounded, size: 14, color: AppTheme.textFaint),
                ],
              ),
              const SizedBox(height: 7),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  '24h ${positive ? '+' : ''}${asset.change24h.toStringAsFixed(2)}%',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: positive
                        ? AppTheme.neonGreen
                        : const Color(0xFFE05252),
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LiveCoinChartStore {
  static const supportedSymbols = <String>{'BTC', 'ETH', 'SOL', 'XRP'};

  static Future<_CoinChartData> fetch(String symbol) async {
    if (!supportedSymbols.contains(symbol)) {
      throw Exception('Chart is not enabled for this market asset.');
    }
    final pair = '${symbol}USDT';
    final uri = Uri.parse(
      'https://api.binance.com/api/v3/klines?symbol=$pair&interval=1m&limit=60',
    );
    final response = await html.HttpRequest.request(
      uri.toString(),
      method: 'GET',
      requestHeaders: const {'accept': 'application/json'},
    );
    if (response.status != 200) {
      throw Exception('Live chart data is temporarily unavailable.');
    }
    final decoded = jsonDecode(response.responseText ?? '[]');
    if (decoded is! List || decoded.isEmpty) {
      throw Exception('No live chart data is available.');
    }
    final closes = <double>[];
    for (final row in decoded) {
      if (row is! List || row.length < 5) continue;
      final close = double.tryParse(row[4].toString());
      if (close != null && close > 0) closes.add(close);
    }
    if (closes.length < 2) throw Exception('No usable live chart data is available.');
    return _CoinChartData(symbol: symbol, prices: closes, currentPrice: closes.last);
  }
}

class _CoinChartData {
  final String symbol;
  final List<double> prices;
  final double currentPrice;
  const _CoinChartData({required this.symbol, required this.prices, required this.currentPrice});
}

class _LiveCoinChartPage extends StatefulWidget {
  final _MarketAsset asset;
  const _LiveCoinChartPage({super.key, required this.asset});

  @override
  State<_LiveCoinChartPage> createState() => _LiveCoinChartPageState();
}

class _LiveCoinChartPageState extends State<_LiveCoinChartPage> {
  late Future<_CoinChartData> _future;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) {
      if (mounted) _load();
    });
  }

  void _load() {
    setState(() {
      _future = _LiveCoinChartStore.fetch(widget.asset.symbol);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.asset.name} / USDT'),
      ),
      body: FutureBuilder<_CoinChartData>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || !snapshot.hasData) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Live chart data could not be loaded right now.', style: TextStyle(color: AppTheme.textSecondary)),
                  const SizedBox(height: 10),
                  TextButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: const Text('RETRY')),
                ],
              ),
            );
          }
          final data = snapshot.data!;
          final positive = data.prices.last >= data.prices.first;
          return Padding(
            padding: const EdgeInsets.fromLTRB(14, 16, 14, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GlassCard(
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(widget.asset.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                            const SizedBox(height: 3),
                            Text(widget.asset.symbol, style: TextStyle(color: AppTheme.textMuted, fontSize: 11, fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(_formatMarketPrice(data.currentPrice), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 3),
                          Text('LIVE • 1 MIN', style: TextStyle(color: positive ? AppTheme.neonGreen : const Color(0xFFE05252), fontSize: 10, fontWeight: FontWeight.w800)),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                Expanded(
                  child: GlassCard(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(8, 16, 8, 10),
                      child: _LiveCoinLineChart(prices: data.prices, positive: positive),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Center(child: Text('Live market data • refreshed while this chart is open', style: TextStyle(color: AppTheme.textFaint, fontSize: 10))),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _LiveCoinLineChart extends StatelessWidget {
  final List<double> prices;
  final bool positive;
  const _LiveCoinLineChart({required this.prices, required this.positive});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _LiveCoinChartPainter(prices: prices, positive: positive),
      child: const SizedBox.expand(),
    );
  }
}

class _LiveCoinChartPainter extends CustomPainter {
  final List<double> prices;
  final bool positive;
  _LiveCoinChartPainter({required this.prices, required this.positive});

  @override
  void paint(Canvas canvas, Size size) {
    if (prices.length < 2 || size.width <= 0 || size.height <= 0) return;
    final minPrice = prices.reduce(math.min);
    final maxPrice = prices.reduce(math.max);
    final range = math.max(maxPrice - minPrice, maxPrice * 0.000001);
    final chartRect = Rect.fromLTWH(10, 10, math.max(1, size.width - 20), math.max(1, size.height - 24));

    final grid = Paint()..color = AppTheme.adaptiveWhite(alpha: 0.06)..strokeWidth = 1;
    for (int i = 1; i < 5; i++) {
      final y = chartRect.top + chartRect.height * i / 5;
      canvas.drawLine(Offset(chartRect.left, y), Offset(chartRect.right, y), grid);
    }

    final path = Path();
    for (int i = 0; i < prices.length; i++) {
      final x = chartRect.left + chartRect.width * i / (prices.length - 1);
      final y = chartRect.bottom - ((prices[i] - minPrice) / range) * chartRect.height;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }

    final line = Paint()
      ..color = positive ? AppTheme.neonGreen : const Color(0xFFE05252)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(path, line);

    final fill = Path.from(path)
      ..lineTo(chartRect.right, chartRect.bottom)
      ..lineTo(chartRect.left, chartRect.bottom)
      ..close();
    final fillPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          (positive ? AppTheme.neonGreen : const Color(0xFFE05252)).withValues(alpha: 0.16),
          Colors.transparent,
        ],
      ).createShader(chartRect);
    canvas.drawPath(fill, fillPaint);

    final lastX = chartRect.right;
    final lastY = chartRect.bottom - ((prices.last - minPrice) / range) * chartRect.height;
    final dot = Paint()..color = positive ? AppTheme.neonGreen : const Color(0xFFE05252);
    canvas.drawCircle(Offset(lastX, lastY), 4, dot);
  }

  @override
  bool shouldRepaint(covariant _LiveCoinChartPainter oldDelegate) =>
      oldDelegate.prices != prices || oldDelegate.positive != positive;
}

String _formatMarketPrice(double price) {
  if (price >= 1000) return '\$${price.toStringAsFixed(2)}';
  if (price >= 1) return '\$${price.toStringAsFixed(2)}';
  if (price >= 0.01) return '\$${price.toStringAsFixed(4)}';
  return '\$${price.toStringAsFixed(8)}';
}

class _Top100MarketPage extends StatefulWidget {
  final List<_MarketAsset> assets;
  const _Top100MarketPage({super.key, required this.assets});

  @override
  State<_Top100MarketPage> createState() => _Top100MarketPageState();
}

class _Top100MarketPageState extends State<_Top100MarketPage> {
  late final ScrollController _controller;
  late List<_MarketAsset> _assets;
  Timer? _marketTimer;

  @override
  void initState() {
    super.initState();
    _controller = ScrollController();
    _assets = List<_MarketAsset>.from(widget.assets);
    _marketTimer = Timer.periodic(const Duration(seconds: 30), (_) async {
      try {
        final latest = await _LiveMarketStore.fetchTop100();
        if (!mounted) return;
        setState(() => _assets = latest);
      } catch (_) {}
    });
  }

  @override
  void dispose() {
    _marketTimer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('TOP 100 LIVE MARKET')),
      body: RefreshIndicator(
        onRefresh: () async {
          try {
            final latest = await _LiveMarketStore.fetchTop100();
            if (!mounted) return;
            setState(() => _assets = latest);
          } catch (_) {}
        },
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) {
            return ListView.builder(
              controller: _controller,
              physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
              itemCount: _assets.length,
              itemBuilder: (context, index) {
                final asset = _assets[index];
                final offset = _controller.hasClients ? _controller.offset : 0.0;
                final itemTop = index * 76.0;
                final distance = (itemTop - offset).abs();
                final factor = (1.0 - (distance / 420.0)).clamp(0.0, 1.0);
                return Transform.translate(
                  offset: Offset((1 - factor) * 12, 0),
                  child: Transform.scale(
                    scale: 0.97 + factor * 0.03,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _MarketTop100Card(rank: index + 1, asset: asset),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class _MarketTop100Card extends StatelessWidget {
  final int rank;
  final _MarketAsset asset;
  const _MarketTop100Card({required this.rank, required this.asset});

  @override
  Widget build(BuildContext context) {
    final positive = asset.change24h >= 0;
    return GlassCard(
      child: Row(
        children: [
          SizedBox(width: 30, child: Text('$rank', style: TextStyle(color: AppTheme.textFaint, fontWeight: FontWeight.w800))),
          CircleAvatar(radius: 20, backgroundImage: asset.logoUrl.isNotEmpty ? NetworkImage(asset.logoUrl) : null, backgroundColor: AppTheme.adaptiveSurface(Color(0xFF16231A)), child: asset.logoUrl.isEmpty ? Icon(Icons.currency_bitcoin, color: AppTheme.neonGreen) : null),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(asset.name, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 2), Text(asset.symbol, style: TextStyle(color: AppTheme.textMuted, fontSize: 11, fontWeight: FontWeight.w700))])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(_formatMarketPrice(asset.price), style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text('${positive ? '+' : ''}${asset.change24h.toStringAsFixed(2)}%', style: TextStyle(color: positive ? const Color(0xFF39E75F) : const Color(0xFFE05252), fontSize: 11, fontWeight: FontWeight.w800))]),
        ],
      ),
    );
  }
}

class _GalacticFeedHeading extends StatefulWidget {
  const _GalacticFeedHeading();
  @override
  State<_GalacticFeedHeading> createState() => _GalacticFeedHeadingState();
}

class _GalacticFeedHeadingState extends State<_GalacticFeedHeading> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) => SizedBox(
        height: 72,
        child: CustomPaint(
          painter: _GalacticFeedTextPainter(progress: _controller.value),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }
}

class _GalacticFeedTextPainter extends CustomPainter {
  final double progress;
  _GalacticFeedTextPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final style = TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.w900,
      letterSpacing: 1.3,
      color: AppTheme.textPrimary,
    );
    final tp = TextPainter(
      text: TextSpan(text: "CD's FEED", style: style),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: size.width);
    tp.paint(canvas, Offset.zero);

    // Stars are drawn into a layer and then masked by the exact glyph shapes,
    // so the moving particles stay inside every letter.
    canvas.saveLayer(Offset.zero & size, Paint());
    final starPaint = Paint();
    for (int i = 0; i < 42; i++) {
      final x = ((i * 47.0) % math.max(1.0, size.width)) +
          math.sin(progress * math.pi * 2 + i) * 7;
      final y = 8 + ((i * 23.0) % 42);
      final z = 0.35 +
          0.65 *
              (0.5 +
                  0.5 *
                      math.sin(progress * math.pi * 2 * (1 + i % 3) + i * 1.7));
      starPaint.color = AppTheme.adaptiveWhite(alpha: z);
      canvas.drawCircle(
        Offset(x, y),
        i % 6 == 0 ? 1.6 : 0.75,
        starPaint,
      );
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _GalacticFeedTextPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

class _Feed3DWorldIcon extends StatefulWidget {
  const _Feed3DWorldIcon();

  @override
  State<_Feed3DWorldIcon> createState() => _Feed3DWorldIconState();
}

class _Feed3DWorldIconState extends State<_Feed3DWorldIcon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 8),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, _) => CustomPaint(
        painter: _Feed3DWorldPainter(progress: _controller.value),
      ),
    );
  }
}

class _Feed3DWorldPainter extends CustomPainter {
  final double progress;
  _Feed3DWorldPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * 0.50, size.height * 0.50);
    final radius = math.min(size.width, size.height) * 0.39;

    // Original Web-3 globe: blue glass sphere, moving meridians, latitude lines,
    // a subtle atmosphere and a single slow orbital data ring.
    final shadow = Paint()
      ..color = Colors.black.withValues(alpha: 0.42)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(center.dx + 1.5, center.dy + radius * 0.86),
        width: radius * 1.45,
        height: radius * 0.28,
      ),
      shadow,
    );

    final sphereRect = Rect.fromCircle(center: center, radius: radius);
    final sphere = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.34, -0.38),
        radius: 1.10,
        colors: const [
          Color(0xFFF7FCFF),
          Color(0xFF67B5FF),
          Color(0xFF176BDB),
          Color(0xFF041F61),
        ],
        stops: const [0.0, 0.28, 0.66, 1.0],
      ).createShader(sphereRect);
    canvas.drawCircle(center, radius, sphere);

    canvas.save();
    canvas.clipPath(Path()..addOval(sphereRect));

    final rotation = progress * math.pi * 2;
    final grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.72
      ..color = const Color(0xFFBDE2FF).withValues(alpha: 0.34);

    // Latitude bands.
    for (int i = -2; i <= 2; i++) {
      final y = center.dy + i * radius * 0.27;
      final widthFactor = 1.0 - i.abs() * 0.08;
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(center.dx, y),
          width: radius * 1.84 * widthFactor,
          height: radius * (0.30 + i.abs() * 0.035),
        ),
        grid,
      );
    }

    // Curved meridians create the 3D rotation effect.
    for (int i = -2; i <= 2; i++) {
      final phase = rotation + i * math.pi / 5;
      final x = math.sin(phase) * radius * 0.68;
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(center.dx + x, center.dy),
          width: radius * (0.72 + 0.18 * math.cos(phase).abs()),
          height: radius * 1.86,
        ),
        grid,
      );
    }

    // Minimal abstract land shapes — intentionally original rather than copied
    // from the supplied reference image.
    final land = Paint()..color = const Color(0xFFE7F6FF).withValues(alpha: 0.82);
    final drift = math.sin(rotation) * radius * 0.10;
    final landPath = Path()
      ..moveTo(center.dx - radius * 0.56 + drift, center.dy - radius * 0.30)
      ..quadraticBezierTo(center.dx - radius * 0.34 + drift, center.dy - radius * 0.58, center.dx - radius * 0.10 + drift, center.dy - radius * 0.28)
      ..quadraticBezierTo(center.dx - radius * 0.22 + drift, center.dy - radius * 0.03, center.dx - radius * 0.46 + drift, center.dy + radius * 0.05)
      ..close();
    canvas.drawPath(landPath, land);

    final lowerLand = Path()
      ..moveTo(center.dx + radius * 0.02 + drift, center.dy + radius * 0.08)
      ..quadraticBezierTo(center.dx + radius * 0.35 + drift, center.dy - radius * 0.02, center.dx + radius * 0.31 + drift, center.dy + radius * 0.27)
      ..quadraticBezierTo(center.dx + radius * 0.17 + drift, center.dy + radius * 0.52, center.dx - radius * 0.02 + drift, center.dy + radius * 0.36)
      ..close();
    canvas.drawPath(lowerLand, land);

    canvas.restore();

    // Atmospheric rim.
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.35
      ..color = const Color(0xFF9ED7FF).withValues(alpha: 0.92);
    canvas.drawCircle(center, radius * 0.985, rim);

    // Slow orbiting Web-3 data ring.
    final ringAngle = rotation * 0.55;
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(ringAngle);
    final ringPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1
      ..color = const Color(0xFF63D7FF).withValues(alpha: 0.70);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset.zero,
        width: radius * 2.18,
        height: radius * 0.62,
      ),
      ringPaint,
    );
    canvas.drawCircle(
      Offset(radius * 1.02, 0),
      2.2,
      Paint()..color = const Color(0xFFB9F2FF),
    );
    canvas.restore();

    final highlightAngle = rotation * 0.8;
    final highlight = Offset(
      center.dx + math.cos(highlightAngle) * radius * 0.43,
      center.dy + math.sin(highlightAngle) * radius * 0.25,
    );
    canvas.drawCircle(
      highlight,
      radius * 0.12,
      Paint()
        ..shader = RadialGradient(
          colors: [
            AppTheme.adaptiveWhite(alpha: 0.80),
            AppTheme.adaptiveWhite(alpha: 0.0),
          ],
        ).createShader(
          Rect.fromCircle(center: highlight, radius: radius * 0.12),
        ),
    );
  }

  @override
  bool shouldRepaint(covariant _Feed3DWorldPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// ============================================================
// DIALOG
// ============================================================

void showPremiumDialog(
  BuildContext context,
  String title,
) {
  showDialog(
    context: context,
    builder: (_) {
      return AlertDialog(
        title: Text(title),
        content: const Text(
          'Premium access and payment verification will be connected to the secure backend later.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('CLOSE'),
          ),
        ],
      );
    },
  );
}

// ============================================================
// GALAXY BACKGROUND
// ============================================================

// ============================================================
// ANIMATED GALAXY BACKGROUND
// ============================================================

class GalaxyBackground extends StatefulWidget {
  final bool animatePlanets;
  final bool animateCryptoCoins;
  final bool cinematicEntrance;
  final Duration animationDuration;
  final bool pauseMotion;

  const GalaxyBackground({
    super.key,
    this.animatePlanets = false,
    this.animateCryptoCoins = false,
    this.cinematicEntrance = false,
    this.animationDuration = const Duration(seconds: 45),
    this.pauseMotion = false,
  });

  @override
  State<GalaxyBackground> createState() => _GalaxyBackgroundState();
}

class _GalaxyBackgroundState extends State<GalaxyBackground>
    with TickerProviderStateMixin {
  late final AnimationController motionController;
  late final AnimationController entranceController;

  @override
  void initState() {
    super.initState();
    motionController = AnimationController(vsync: this, duration: widget.animationDuration);
    if (!widget.pauseMotion) {
      motionController.repeat();
    }
    entranceController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400));
    if (widget.cinematicEntrance) {
      entranceController.forward();
    } else {
      entranceController.value = 1;
    }
  }

  @override
  void didUpdateWidget(covariant GalaxyBackground oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.pauseMotion != oldWidget.pauseMotion) {
      if (widget.pauseMotion) {
        motionController.stop(canceled: false);
      } else if (!motionController.isAnimating) {
        motionController.repeat();
      }
    }
  }

  @override
  void dispose() {
    motionController.dispose();
    entranceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (Theme.of(context).brightness == Brightness.light) {
      return Positioned.fill(
        child: Container(color: const Color(0xFFF4F0E8)),
      );
    }
    return Positioned.fill(
      child: AnimatedBuilder(
        animation: Listenable.merge([motionController, entranceController]),
        builder: (context, child) {
          // The galaxy is deliberately slow. Repainting it on every 60Hz frame
          // competes with scrolling and touch input. Quantizing the slow motion
          // to ~20 visual updates/sec keeps the background alive while leaving
          // the UI thread more headroom for gestures and lists.
          final sampledMotion = (motionController.value * 900).floor() / 900.0;
          return RepaintBoundary(
            child: CustomPaint(
              painter: StarPainter(
                sampledMotion,
                animatePlanets: widget.animatePlanets,
                animateCryptoCoins: widget.animateCryptoCoins,
                lightMode: Theme.of(context).brightness == Brightness.light,
                matteBlackMode: appThemePreference.value == 'dark',
                reveal: Curves.easeOutCubic.transform(entranceController.value),
              ),
            ),
          );
        },
      ),
    );
  }
}

class StarPainter extends CustomPainter {
  final double progress;
  final bool animatePlanets;
  final bool animateCryptoCoins;
  final bool lightMode;
  final bool matteBlackMode;
  final double reveal;

  StarPainter(
    this.progress, {
    this.animatePlanets = false,
    this.animateCryptoCoins = false,
    this.lightMode = false,
    this.matteBlackMode = false,
    this.reveal = 1.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // In the explicit Dark Theme, the background is a completely solid
    // matte black surface. No stars, shimmer, sweep, texture, or gradient
    // is painted behind the existing interface.
    if (matteBlackMode) {
      canvas.drawColor(Colors.black, BlendMode.srcOver);
      return;
    }

    final eased = Curves.easeInOutSine.transform(progress);
    final base = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: lightMode
            ? const [Color(0xFFF1EBDD), Color(0xFFF8F4EA), Color(0xFFEAE4D7)]
            : const [Color(0xFF000000), Color(0xFF030303), Color(0xFF000000)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, base);

    // Matte-black luxury texture with dense micro-speckles and a very slow,
    // continuous shimmer. No planets, crypto logos or coin marks.
    final width = size.width;
    final height = size.height;
    for (int i = 0; i < 360; i++) {
      final seed = i * 17.371;
      final bx = ((math.sin(seed * 1.731) + 1) * 0.5) * width;
      final by = ((math.cos(seed * 1.193) + 1) * 0.5) * height;
      final drift = progress * math.pi * 2 * (0.020 + (i % 7) * 0.0025);
      final x = (bx + math.sin(drift + seed) * width * 0.010) % width;
      final y = (by + math.cos(drift * 0.73 + seed) * height * 0.008) % height;
      final twinkle = 0.10 + 0.52 * ((math.sin(progress * math.pi * 2 * (0.18 + (i % 5) * 0.035) + seed) + 1) / 2);
      final radius = 0.35 + (i % 5) * 0.17;
      final speckleColor = lightMode ? const Color(0xFF7D7567) : AppTheme.textPrimary;
      final paint = Paint()..color = speckleColor.withValues(alpha: twinkle * (i % 9 == 0 ? 0.52 : 0.30));
      canvas.drawCircle(Offset(x, y), radius, paint);
      if (i % 17 == 0) {
        final glowColor = lightMode ? const Color(0xFF9A8C70) : AppTheme.textPrimary;
        final glow = Paint()..color = glowColor.withValues(alpha: twinkle * (lightMode ? 0.07 : 0.16))..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0);
        canvas.drawCircle(Offset(x, y), radius * 3.8, glow);
      }
    }

    final sweepX = width * (-0.35 + eased * 1.70);
    final sweep = Paint()
      ..shader = RadialGradient(
        center: Alignment((sweepX / width) * 2 - 1, 0.05),
        radius: 1.15,
        colors: const [Color(0x1FFFFFFF), Color(0x08FFFFFF), Color(0x00000000)],
        stops: const [0.0, 0.22, 1.0],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, sweep);

    for (int i = 0; i < 34; i++) {
      final seed = i * 29.17 + 4.0;
      final x0 = ((math.sin(seed) + 1) * 0.5) * width;
      final y0 = ((math.cos(seed * 0.71) + 1) * 0.5) * height;
      final phase = progress * math.pi * 2 * 0.055 + seed;
      final x = (x0 + math.sin(phase) * width * 0.022) % width;
      final y = (y0 + math.cos(phase * 0.81) * height * 0.018) % height;
      final alpha = 0.18 + 0.62 * ((math.sin(phase * 1.7) + 1) / 2);
      final p = Paint()..color = (lightMode ? const Color(0xFF756C5D) : AppTheme.textPrimary).withValues(alpha: alpha * (lightMode ? 0.42 : 1.0));
      canvas.drawCircle(Offset(x, y), 0.9 + (i % 3) * 0.35, p);
      if (i % 4 == 0) {
        final glow = Paint()..color = AppTheme.adaptiveWhite(alpha: alpha * 0.22)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
        canvas.drawCircle(Offset(x, y), 4.5, glow);
      }
    }
  }

  @override
  bool shouldRepaint(covariant StarPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.animatePlanets != animatePlanets ||
        oldDelegate.animateCryptoCoins != animateCryptoCoins ||
        oldDelegate.matteBlackMode != matteBlackMode ||
        oldDelegate.reveal != reveal;
  }
}

class AlphaDenOrb extends StatefulWidget {
  final IconData icon;
  final Color? color;
  final List<Shadow>? shadows;

  const AlphaDenOrb({
    super.key,
    required this.icon,
    this.color,
    this.shadows,
  });

  @override
  State<AlphaDenOrb> createState() => _AlphaDenOrbState();
}

class _AlphaDenOrbState extends State<AlphaDenOrb>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 7),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final iconColor = widget.color ?? AppTheme.luxuryGold;
        return SizedBox(
          width: 150,
          height: 118,
          child: Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              CustomPaint(
                size: const Size(150, 118),
                painter: _AlphaDenPortal3DOrbitPainter(
                  progress: _controller.value,
                  centerRadius: 22,
                  color: iconColor,
                ),
              ),
              Icon(
                widget.icon,
                size: 35,
                color: iconColor,
                shadows: widget.shadows ?? [
                  Shadow(
                    color: iconColor.withValues(alpha: 0.85),
                    blurRadius: 16,
                  ),
                ],
              ),
              Container(
                width: 7,
                height: 7,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppTheme.textPrimary,
                  boxShadow: [
                    BoxShadow(
                      color: iconColor,
                      blurRadius: 12,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _AlphaDenPortal3DOrbitPainter extends CustomPainter {
  final double progress;
  final double centerRadius;
  final Color color;

  const _AlphaDenPortal3DOrbitPainter({
    required this.progress,
    required this.centerRadius,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final t = progress * math.pi * 2;
    final green = AppTheme.neonGreen;

    final orbits = <_DashboardOrbit3D>[
      _DashboardOrbit3D(118, 30, -0.25, 0.62, color, 0.80, phase: 0.20),
      _DashboardOrbit3D(108, 40, 0.68, -0.54, green, 0.72, phase: 1.10),
      _DashboardOrbit3D(98, 50, -1.00, 0.46, color, 0.62, phase: 2.05),
      _DashboardOrbit3D(86, 60, 0.32, -0.38, green, 0.54, phase: 2.80),
      _DashboardOrbit3D(72, 70, 1.12, 0.30, color, 0.46, phase: 3.55),
    ];

    for (var i = 0; i < orbits.length; i++) {
      if (i.isOdd) continue;
      _drawOrbit(canvas, center, orbits[i], t, i, front: false);
    }

    final nucleusPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = AppTheme.adaptiveSurface(Color(0xFF080B0F));
    canvas.drawCircle(center, centerRadius, nucleusPaint);

    final nucleusBorder = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..color = color.withValues(alpha: 0.95);
    canvas.drawCircle(center, centerRadius, nucleusBorder);

    final glow = Paint()
      ..color = color.withValues(alpha: 0.16)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
    canvas.drawCircle(center, centerRadius - 2, glow);

    for (var i = 0; i < orbits.length; i++) {
      if (i.isEven) continue;
      _drawOrbit(canvas, center, orbits[i], t, i, front: true);
    }
  }

  void _drawOrbit(
    Canvas canvas,
    Offset center,
    _DashboardOrbit3D orbit,
    double t,
    int index, {
    required bool front,
  }) {
    final direction = index.isEven ? 1.0 : -1.0;
    final rotation = orbit.baseRotation + t * orbit.speed * direction;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(rotation);

    final rect = Rect.fromCenter(
      center: Offset.zero,
      width: orbit.width,
      height: orbit.height,
    );

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9
      ..isAntiAlias = true
      ..color = orbit.color.withValues(
        alpha: front ? orbit.alpha : orbit.alpha * 0.48,
      );
    canvas.drawOval(rect, paint);

    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.6
      ..isAntiAlias = true
      ..color = orbit.color.withValues(
        alpha: front ? orbit.alpha * 0.10 : orbit.alpha * 0.055,
      )
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.8);
    canvas.drawOval(rect, glow);

    final a = t * orbit.speed * direction + orbit.phase;
    final dot = Offset(
      math.cos(a) * orbit.width * 0.5,
      math.sin(a) * orbit.height * 0.5,
    );
    final dotPaint = Paint()
      ..color = orbit.color
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.0);
    canvas.drawCircle(dot, front ? 2.8 : 2.3, dotPaint);

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _AlphaDenPortal3DOrbitPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.centerRadius != centerRadius ||
        oldDelegate.color != color;
  }
}

class AlphaDenCore extends StatefulWidget {
  final double width;
  final double height;
  final BoxDecoration decoration;
  final Widget child;

  const AlphaDenCore({
    super.key,
    required this.width,
    required this.height,
    required this.decoration,
    required this.child,
  });

  @override
  State<AlphaDenCore> createState() => _AlphaDenCoreState();
}

class _AlphaDenCoreState extends State<AlphaDenCore> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) => Stack(
        alignment: Alignment.center,
        children: [
          AlphaDenOrb(icon: Icons.blur_circular, color: AppTheme.luxuryGold),
          Container(width: widget.width, height: widget.height, decoration: widget.decoration, child: widget.child),
        ],
      ),
    );
  }
}


class _MentorshipChatRoomPage extends StatefulWidget {
  final bool isAdmin;
  final bool isStudent;
  const _MentorshipChatRoomPage({required this.isAdmin, required this.isStudent});

  @override
  State<_MentorshipChatRoomPage> createState() => _MentorshipChatRoomPageState();
}

class _OptimisticChatMessage {
  final String id;
  final Map<String, dynamic> data;
  _OptimisticChatMessage(this.id, this.data);
}

class _MentorshipChatRoomPageState extends State<_MentorshipChatRoomPage> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _sending = false;
  int _cooldown = 0;
  Timer? _cooldownTimer;
  bool _showReactionsFor(String id) => _reactionMessageId == id;
  String? _reactionMessageId;
  final List<_OptimisticChatMessage> _optimisticMessages = <_OptimisticChatMessage>[];

  @override
  void dispose() {
    _cooldownTimer?.cancel();
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<String> _currentName() async {
    final uid = AuthService.currentUser?.uid;
    if (uid == null) return 'Mentorship Student';
    final data = await MentorshipService.loadMyMentorship(uid) ?? {};
    return (data['displayName'] ?? data['name'] ?? AuthService.currentUser?.displayName ?? 'Mentorship Student').toString();
  }

  void _startCooldown() {
    _cooldownTimer?.cancel();
    setState(() => _cooldown = 5);
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return timer.cancel();
      if (_cooldown <= 1) {
        timer.cancel();
        setState(() => _cooldown = 0);
      } else {
        setState(() => _cooldown--);
      }
    });
  }

  Future<void> _send({String? imageUrl}) async {
    if (_sending || _cooldown > 0) return;
    final uid = AuthService.currentUser?.uid;
    if (uid == null) return;
    final text = _controller.text.trim();
    if (text.isEmpty && (imageUrl == null || imageUrl.isEmpty)) return;

    final name = AuthService.currentUser?.displayName?.trim().isNotEmpty == true
        ? AuthService.currentUser!.displayName!.trim()
        : 'Mentorship Student';
    final messageId = MentorshipService.newChatMessageId();
    final optimistic = _OptimisticChatMessage(messageId, <String, dynamic>{
      'senderUid': uid,
      'senderName': name,
      'text': text,
      if (imageUrl != null && imageUrl.isNotEmpty) 'imageUrl': imageUrl,
      'reactions': <String, dynamic>{},
      'createdAt': Timestamp.fromDate(DateTime.now()),
    });

    // Render locally first. Firebase synchronization continues immediately in
    // the background, while server-side rules remain authoritative.
    setState(() {
      _sending = true;
      _optimisticMessages.insert(0, optimistic);
      _controller.clear();
      _reactionMessageId = null;
    });
    _startCooldown();

    try {
      await MentorshipService.sendChatMessage(
        uid: uid,
        name: name,
        text: text,
        imageUrl: imageUrl,
        messageId: messageId,
      );
      if (mounted) {
        setState(() => _optimisticMessages.removeWhere((m) => m.id == messageId));
      }
    } catch (e) {
      if (mounted) {
        setState(() => _optimisticMessages.removeWhere((m) => m.id == messageId));
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Bad state: ', ''))));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _pickScreenshot() async {
    if (_sending || _cooldown > 0) return;
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 82);
    if (picked == null) return;
    final mime = (picked.mimeType ?? '').toLowerCase();
    final name = picked.name.toLowerCase();
    final allowed = mime.startsWith('image/') || name.endsWith('.png') || name.endsWith('.jpg') || name.endsWith('.jpeg') || name.endsWith('.webp');
    if (!allowed || name.endsWith('.gif')) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Only screenshot/image files are allowed.')));
      return;
    }
    try {
      final bytes = await picked.readAsBytes();
      final ext = name.contains('.') ? name.split('.').last : 'jpg';
      final url = await MentorshipService.uploadChatScreenshot(uid: AuthService.currentUser!.uid, bytes: bytes, extension: ext);
      await _send(imageUrl: url);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not upload screenshot: $e')));
    }
  }

  Future<void> _react(String messageId, String reaction, Map<String, dynamic> reactions) async {
    final uid = AuthService.currentUser?.uid;
    if (uid == null) return;
    try {
      if (reactions[uid] == reaction) {
        await MentorshipService.removeChatReaction(messageId: messageId, uid: uid);
      } else {
        await MentorshipService.setChatReaction(messageId: messageId, uid: uid, reaction: reaction);
      }
      if (mounted) setState(() => _reactionMessageId = null);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not update reaction: $e')));
    }
  }

  void _showReactionPicker(String messageId, Map<String, dynamic> reactions) {
    setState(() => _reactionMessageId = _reactionMessageId == messageId ? null : messageId);
  }

  Future<void> _openModeration() async {
    if (!widget.isAdmin) return;
    final members = await MentorshipService.loadChatMembers();
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.adaptiveSurface(const Color(0xFF0B0B0B)),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
        child: SizedBox(height: MediaQuery.of(context).size.height * .62, child: Column(children: [
          Row(children: [Expanded(child: Text('CHAT MODERATION', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w900, fontSize: 16))), IconButton(onPressed: () => Navigator.pop(sheetContext), icon: Icon(Icons.close_rounded, color: AppTheme.textPrimary))]),
          const SizedBox(height: 8),
          Expanded(child: members.isEmpty ? Center(child: Text('No chat members yet.', style: TextStyle(color: AppTheme.textMuted))) : ListView.separated(
            itemCount: members.length,
            separatorBuilder: (_, __) => Divider(color: AppTheme.textPrimary.withOpacity(.08)),
            itemBuilder: (_, i) {
              final d = members[i].data();
              final uid = members[i].id;
              final active = d['active'] != false;
              final banned = d['banned'] == true;
              return ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text((d['name'] ?? uid).toString(), style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w700)),
                subtitle: Text(banned ? 'BANNED' : (active ? 'ACTIVE' : 'REMOVED'), style: TextStyle(color: banned ? Colors.redAccent : AppTheme.textMuted, fontSize: 10)),
                trailing: PopupMenuButton<String>(icon: Icon(Icons.more_vert, color: AppTheme.textPrimary), onSelected: (action) async {
                  try {
                    if (action == 'remove') await MentorshipService.adminSetChatMember(uid: uid, active: false, banned: false);
                    if (action == 'restore') await MentorshipService.adminSetChatMember(uid: uid, active: true, banned: false);
                    if (action == 'ban') await MentorshipService.adminSetChatMember(uid: uid, active: false, banned: true);
                    if (action == '30') await MentorshipService.adminSetChatMember(uid: uid, active: true, banned: false, restrictedUntil: DateTime.now().add(const Duration(minutes: 30)));
                    if (action == '5') await MentorshipService.adminSetChatMember(uid: uid, active: true, banned: false, restrictedUntil: DateTime.now().add(const Duration(minutes: 5)));
                    if (sheetContext.mounted) Navigator.pop(sheetContext);
                    if (mounted) _openModeration();
                  } catch (e) {
                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Moderation action failed: $e')));
                  }
                }, itemBuilder: (_) => [
                  if (!active || banned) const PopupMenuItem(value: 'restore', child: Text('Restore access')),
                  if (active && !banned) const PopupMenuItem(value: 'remove', child: Text('Remove from group')),
                  if (!banned) const PopupMenuItem(value: 'ban', child: Text('Ban messaging')),
                  const PopupMenuItem(value: '5', child: Text('Restrict for 5 minutes')),
                  const PopupMenuItem(value: '30', child: Text('Restrict for 30 minutes')),
                ]),
              );
            },
          )),
        ])),
      )),
    );
  }

  Widget _reactionBar(String messageId, Map<String, dynamic> reactions) {
    const choices = ['👍', '❤️', '😂', '😮', '😢', 'LIKE', 'DISLIKE'];
    return Container(
      margin: const EdgeInsets.only(top: 5),
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 4),
      decoration: BoxDecoration(color: AppTheme.adaptiveSurface(const Color(0xFF181818)), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.textPrimary.withOpacity(.10))),
      child: Wrap(spacing: 2, children: [for (final r in choices) InkWell(onTap: () => _react(messageId, r, reactions), borderRadius: BorderRadius.circular(12), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3), child: Text(r, style: TextStyle(color: AppTheme.textPrimary, fontSize: r.length > 2 ? 9 : 15, fontWeight: FontWeight.w700))))]),
    );
  }

  Widget _messageBubble(String messageId, Map<String, dynamic> d) {
    final uid = AuthService.currentUser?.uid ?? '';
    final mine = d['senderUid'] == uid;
    final reactions = Map<String, dynamic>.from((d['reactions'] as Map?) ?? {});
    final created = d['createdAt'];
    final time = created is Timestamp ? created.toDate().toLocal() : null;
    final imageUrl = (d['imageUrl'] ?? '').toString();
    final text = (d['text'] ?? '').toString();
    final grouped = <String, int>{};
    for (final r in reactions.values) grouped[r.toString()] = (grouped[r.toString()] ?? 0) + 1;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onTap: () => _showReactionPicker(messageId, reactions),
        child: Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
          margin: EdgeInsets.fromLTRB(mine ? 45 : 10, 4, mine ? 10 : 45, 4),
          padding: const EdgeInsets.fromLTRB(11, 8, 11, 7),
          decoration: BoxDecoration(
            color: mine ? const Color(0xFF075E54) : const Color(0xFF202C33),
            borderRadius: BorderRadius.only(topLeft: const Radius.circular(14), topRight: const Radius.circular(14), bottomLeft: Radius.circular(mine ? 14 : 4), bottomRight: Radius.circular(mine ? 4 : 14)),
            border: Border.all(color: AppTheme.textPrimary.withOpacity(.10)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (!mine) Padding(padding: const EdgeInsets.only(bottom: 3), child: Text((d['senderName'] ?? 'Mentorship Student').toString(), style: TextStyle(color: AppTheme.textPrimary, fontSize: 10.5, fontWeight: FontWeight.w800))),
            if (imageUrl.isNotEmpty) ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(imageUrl, width: 220, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Padding(padding: const EdgeInsets.all(12), child: Text('Screenshot unavailable', style: TextStyle(color: AppTheme.textMuted))))),
            if (text.isNotEmpty) Padding(padding: EdgeInsets.only(top: imageUrl.isNotEmpty ? 7 : 0), child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.25))),
            const SizedBox(height: 3),
            Row(mainAxisSize: MainAxisSize.min, children: [if (time != null) Text('${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}', style: TextStyle(color: Colors.white.withOpacity(.60), fontSize: 8.5)), if (grouped.isNotEmpty) ...[const SizedBox(width: 7), for (final e in grouped.entries) Padding(padding: const EdgeInsets.only(right: 3), child: Container(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1), decoration: BoxDecoration(color: Colors.black.withOpacity(.22), borderRadius: BorderRadius.circular(9)), child: Text('${e.key} ${e.value}', style: const TextStyle(color: Colors.white, fontSize: 8))))]]),
            if (_showReactionsFor(messageId)) _reactionBar(messageId, reactions),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final open = widget.isAdmin || widget.isStudent;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        titleSpacing: 0,
        title: Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppTheme.textPrimary.withValues(alpha: .18))), child: Icon(Icons.school_rounded, color: AppTheme.textPrimary, size: 18)), const SizedBox(width: 9), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [Text('Mentorship Students', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800)), Text('Chat Room • 24/7', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white54, fontSize: 9))]))]),
        actions: [if (widget.isAdmin) IconButton(tooltip: 'Moderation', onPressed: _openModeration, icon: const Icon(Icons.admin_panel_settings_rounded, color: Colors.white)), IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded, color: Colors.white))],
      ),
      body: !open ? Center(child: Container(margin: const EdgeInsets.all(24), padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: const Color(0xFF121212), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white10)), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.lock_outline_rounded, color: Colors.white, size: 34), const SizedBox(height: 12), const Text('MENTORSHIP CHAT LOCKED', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), const SizedBox(height: 7), const Text('This Chat Room is available only to Admins and active Mentorship students.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60, fontSize: 11))]))) : Column(children: [
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: MentorshipService.mentorshipChatStream(), builder: (context, snap) {
          if (snap.hasError) return Center(child: Text('Unable to load chat.', style: TextStyle(color: AppTheme.textMuted)));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          final serverIds = docs.map((d) => d.id).toSet();
          final pending = _optimisticMessages.where((m) => !serverIds.contains(m.id)).toList();
          if (docs.isEmpty && pending.isEmpty) return Center(child: Text('No messages yet. Start the conversation.', style: TextStyle(color: AppTheme.textMuted)));
          return ListView.builder(
            controller: _scrollController,
            reverse: true,
            padding: const EdgeInsets.fromLTRB(4, 12, 4, 12),
            itemCount: docs.length + pending.length,
            itemBuilder: (_, i) {
              if (i < pending.length) {
                final m = pending[i];
                return _messageBubble(m.id, m.data);
              }
              final d = docs[i - pending.length];
              return _messageBubble(d.id, d.data());
            },
          );
        })),
        SafeArea(top: false, child: Container(padding: const EdgeInsets.fromLTRB(8, 7, 8, 8), decoration: const BoxDecoration(color: Color(0xFF101010), border: Border(top: BorderSide(color: Colors.white12))), child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          IconButton(tooltip: 'Send screenshot', onPressed: (_sending || _cooldown > 0) ? null : _pickScreenshot, icon: const Icon(Icons.image_outlined, color: Colors.white)),
          Expanded(child: Container(decoration: BoxDecoration(color: const Color(0xFF202C33), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white12)), child: TextField(controller: _controller, minLines: 1, maxLines: 5, style: const TextStyle(color: Colors.white, fontSize: 14), textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(hintText: 'Message', hintStyle: TextStyle(color: Colors.white54), border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 15, vertical: 10))))),
          const SizedBox(width: 6),
          Container(width: 46, height: 46, decoration: BoxDecoration(shape: BoxShape.circle, color: _cooldown > 0 ? Colors.white10 : const Color(0xFF075E54)), child: IconButton(onPressed: (_sending || _cooldown > 0) ? null : () => _send(), icon: _cooldown > 0 ? Text('$_cooldown', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 11)) : const Icon(Icons.send_rounded, color: Colors.white, size: 20))),
        ]))),
      ]),
    );
  }
}
