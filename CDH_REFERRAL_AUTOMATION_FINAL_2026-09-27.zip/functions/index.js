const { onDocumentCreated, onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();

const TIERS = [
  { min: 10, type: 'referral_crown_black_gold', title: 'Black + Gold Crown', description: 'Black + Gold Crown • 10 qualified referrals.' },
  { min: 5, type: 'referral_crown_gold', title: 'Golden Crown', description: 'Golden Crown • 5 qualified referrals.' },
  { min: 3, type: 'referral_crown_purple', title: 'Purple Crown', description: 'Purple Crown • 3 qualified referrals.' },
  { min: 1, type: 'referral_crown_blue', title: 'Blue Crown', description: 'Blue Crown • 1 qualified referral.' },
];

function tierForCount(count) {
  return TIERS.find((tier) => count >= tier.min) || null;
}

function asNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function usernameFrom(data, fallback = 'User') {
  return String(data?.displayName || data?.username || data?.alphaDenProfile?.username || fallback).trim() || fallback;
}

/** Create the backend relationship record from the referral captured at sign-up. */
exports.syncReferralRelationship = onDocumentCreated('users/{uid}', async (event) => {
  const data = event.data?.data() || {};
  const uid = event.params.uid;
  const referrerUid = String(data.referredByUid || '').trim();
  const referralCode = String(data.referredByCode || '').trim().toUpperCase();
  if (!referrerUid || referrerUid === uid || !referralCode) return null;

  const referrerSnap = await db.collection('users').doc(referrerUid).get();
  if (!referrerSnap.exists) return null;
  const referrer = referrerSnap.data() || {};
  if (String(referrer.referralCode || '').toUpperCase() !== referralCode) return null;

  await db.collection('referralRelationships').doc(uid).set({
    referredUid: uid,
    referrerUid,
    referralCode,
    status: 'pending_qualification',
    referredUsername: usernameFrom(data),
    referrerUsername: usernameFrom(referrer),
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  }, { merge: true });
  return null;
});

/**
 * A payment becomes referral-qualified only after the Admin has approved it.
 * This function creates a permanent reward record, updates the referrer's
 * lifetime statistics, and creates an Admin notification. The client never
 * gets permission to manufacture these records.
 */
exports.processApprovedReferralPayment = onDocumentUpdated('paymentRequests/{requestId}', async (event) => {
  const before = event.data?.before?.data() || {};
  const after = event.data?.after?.data() || {};
  const requestId = event.params.requestId;
  if (String(before.status || '') === 'approved' || String(after.status || '') !== 'approved') return null;

  const referredUid = String(after.uid || '').trim();
  if (!referredUid) return null;

  const userSnap = await db.collection('users').doc(referredUid).get();
  if (!userSnap.exists) return null;
  const user = userSnap.data() || {};
  const referrerUid = String(user.referredByUid || '').trim();
  const referralCode = String(user.referredByCode || '').trim().toUpperCase();
  if (!referrerUid || referrerUid === referredUid) return null;

  const relationshipRef = db.collection('referralRelationships').doc(referredUid);
  const relationshipSnap = await relationshipRef.get();
  const relationship = relationshipSnap.exists ? (relationshipSnap.data() || {}) : {};
  if (relationship.referrerUid && String(relationship.referrerUid) !== referrerUid) return null;

  const referrerSnap = await db.collection('users').doc(referrerUid).get();
  if (!referrerSnap.exists) return null;
  const referrer = referrerSnap.data() || {};
  if (referralCode && String(referrer.referralCode || '').toUpperCase() !== referralCode) return null;

  const product = String(after.product || '').trim();
  const planId = String(after.planId || '').trim();
  const planName = String(after.planName || planId || product).trim();
  const installmentNumber = asNumber(after.installmentNumber, 0);

  let incentive = 0;
  let incentiveType = '';
  if (product === 'premium' && planId === 'premium_monthly') {
    incentive = 4;
    incentiveType = 'premium_monthly';
  } else if (product === 'premium' && planId === 'premium_one_time') {
    incentive = 12;
    incentiveType = 'premium_lifetime';
  } else if (product === 'mentorship' && planId === 'mentorship_one_time') {
    incentive = 20;
    incentiveType = 'mentorship_one_time';
  } else if (product === 'mentorship' && planId === 'mentorship_installment') {
    incentive = 5;
    incentiveType = `mentorship_installment_${installmentNumber || 1}`;
  } else {
    return null;
  }

  const rewardId = `${requestId}_${incentiveType}`.replace(/[^A-Za-z0-9_-]/g, '_');
  const rewardRef = db.collection('referralRewards').doc(rewardId);
  const statsRef = db.collection('referralStats').doc(referrerUid);
  const qualificationId = `${referrerUid}_${referredUid}`.replace(/[^A-Za-z0-9_-]/g, '_');
  const qualificationRef = db.collection('referralQualifications').doc(qualificationId);
  const notificationRef = db.collection('referralAdminNotifications').doc(rewardId);
  const mailRef = db.collection('users').doc(referrerUid).collection('mail').doc(`referral_${rewardId}`);

  await db.runTransaction(async (tx) => {
    const existingReward = await tx.get(rewardRef);
    if (existingReward.exists) return;

    const qualificationSnap = await tx.get(qualificationRef);
    const statsSnap = await tx.get(statsRef);
    const stats = statsSnap.exists ? (statsSnap.data() || {}) : {};
    const firstQualification = !qualificationSnap.exists;

    tx.set(rewardRef, {
      rewardId,
      requestId,
      referrerUid,
      referrerUsername: usernameFrom(referrer),
      referredUid,
      referredUsername: usernameFrom(user),
      product,
      planId,
      planName,
      paymentAmount: asNumber(after.amount),
      currency: String(after.currency || 'USD').toUpperCase(),
      paymentMethodName: String(after.paymentMethodName || ''),
      transactionReference: String(after.transactionReference || ''),
      installmentNumber,
      incentiveAmountUsd: incentive,
      incentiveType,
      qualificationStatus: 'qualified',
      status: 'earned',
      approvedAt: after.reviewedAt || FieldValue.serverTimestamp(),
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    }, { merge: true });

    if (firstQualification) {
      tx.create(qualificationRef, {
        referrerUid,
        referredUid,
        referredUsername: usernameFrom(user),
        firstQualifiedProduct: product,
        firstQualifiedPlanId: planId,
        firstQualifiedRequestId: requestId,
        qualifiedAt: FieldValue.serverTimestamp(),
        status: 'qualified',
      });
    }

    tx.set(statsRef, {
      referrerUid,
      referrerUsername: usernameFrom(referrer),
      totalReferrals: asNumber(stats.totalReferrals) + (firstQualification ? 1 : 0),
      qualifiedReferrals: asNumber(stats.qualifiedReferrals) + (firstQualification ? 1 : 0),
      premiumMonthlyEarningsUsd: asNumber(stats.premiumMonthlyEarningsUsd) + (incentiveType === 'premium_monthly' ? incentive : 0),
      premiumLifetimeEarningsUsd: asNumber(stats.premiumLifetimeEarningsUsd) + (incentiveType === 'premium_lifetime' ? incentive : 0),
      mentorshipEarningsUsd: asNumber(stats.mentorshipEarningsUsd) + (product === 'mentorship' ? incentive : 0),
      totalEarnedUsd: asNumber(stats.totalEarnedUsd) + incentive,
      totalPaidUsd: asNumber(stats.totalPaidUsd),
      outstandingUsd: asNumber(stats.outstandingUsd) + incentive,
      lastReferralUid: referredUid,
      lastReferralUsername: usernameFrom(user),
      lastReferralAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    }, { merge: true });

    tx.set(notificationRef, {
      type: 'referral_qualified_payment',
      rewardId,
      referrerUid,
      referrerUsername: usernameFrom(referrer),
      referredUid,
      referredUsername: usernameFrom(user),
      product,
      planId,
      planName,
      paymentAmount: asNumber(after.amount),
      incentiveAmountUsd: incentive,
      incentiveType,
      installmentNumber,
      status: 'unread',
      message: `${usernameFrom(user)} (${referredUid}) completed a confirmed ${planName} purchase under ${usernameFrom(referrer)} (${referrerUid}). Incentive earned: $${incentive.toFixed(2)} USD.`,
      createdAt: FieldValue.serverTimestamp(),
    }, { merge: true });

    tx.set(mailRef, {
      type: 'referral_reward',
      title: 'REFERRAL INCENTIVE EARNED',
      body: `${usernameFrom(user)} completed ${planName}. You earned $${incentive.toFixed(2)} USD from this qualified referral. Your dashboard now records this earning for payout processing.`,
      rewardId,
      referredUid,
      product,
      planId,
      incentiveAmountUsd: incentive,
      readAt: null,
      createdAt: FieldValue.serverTimestamp(),
    }, { merge: true });
  });

  return null;
});

/**
 * Existing Crown reward automation. It remains separate from product referral
 * incentives and only reacts to the qualified-referral counter.
 */
exports.issueReferralCrownReward = onDocumentUpdated('users/{uid}', async (event) => {
  const before = event.data?.before?.data() || {};
  const after = event.data?.after?.data() || {};
  const beforeProfile = before.alphaDenProfile || {};
  const afterProfile = after.alphaDenProfile || {};
  const beforeCount = Number(beforeProfile.referrals || 0);
  const afterCount = Number(afterProfile.referrals || 0);

  if (!Number.isFinite(afterCount) || afterCount <= beforeCount) return null;
  const tier = tierForCount(afterCount);
  if (!tier) return null;

  const userRef = db.collection('users').doc(event.params.uid);
  const entitlementRef = userRef.collection('badgeEntitlements').doc(tier.type);
  const mailRef = userRef.collection('mail').doc(`reward_${tier.type}`);

  await db.runTransaction(async (tx) => {
    const entitlementSnap = await tx.get(entitlementRef);
    if (!entitlementSnap.exists) {
      tx.create(entitlementRef, {
        badgeId: tier.type,
        badgeType: tier.type,
        eligible: true,
        status: 'available',
        referralCount: afterCount,
        title: tier.title,
        description: tier.description,
        source: 'referral_crown',
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      });
    }
    const mailSnap = await tx.get(mailRef);
    if (!mailSnap.exists) {
      tx.create(mailRef, {
        type: 'badge',
        title: `${tier.title} Reward Available`,
        body: `You reached ${tier.min} qualified referrals and earned your ${tier.title}. Open this reward to collect it.`,
        badgeIds: [tier.type],
        referralCount: afterCount,
        readAt: null,
        createdAt: FieldValue.serverTimestamp(),
      });
    }
  });
  return null;
});
