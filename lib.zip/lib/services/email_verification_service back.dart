import 'package:cloud_functions/cloud_functions.dart';

class EmailVerificationService {
  static FirebaseFunctions get _functions =>
      FirebaseFunctions.instanceFor(region: 'us-central1');

  static Future<String> startSignup({required String email}) async {
    final result = await _functions
        .httpsCallable('startSignupEmailCode')
        .call(<String, dynamic>{'email': email.trim().toLowerCase()});
    final data = Map<String, dynamic>.from(result.data as Map);
    final attemptId = (data['attemptId'] ?? '').toString();
    if (attemptId.isEmpty) {
      throw StateError('No verification attempt was returned.');
    }
    return attemptId;
  }

  static Future<bool> verifySignup({
    required String attemptId,
    required String email,
    required String code,
  }) async {
    final result = await _functions
        .httpsCallable('verifySignupEmailCode')
        .call(<String, dynamic>{
      'attemptId': attemptId,
      'email': email.trim().toLowerCase(),
      'code': code.trim(),
    });
    final data = Map<String, dynamic>.from(result.data as Map);
    return data['verified'] == true;
  }

  static Future<void> finalizeSignupVerification({
    required String attemptId,
  }) async {
    await _functions
        .httpsCallable('finalizeSignupEmailVerification')
        .call(<String, dynamic>{'attemptId': attemptId});
  }

  static Future<String> startLogin({required String email}) async {
    final result = await _functions
        .httpsCallable('startLoginEmailCode')
        .call(<String, dynamic>{'email': email.trim().toLowerCase()});
    final data = Map<String, dynamic>.from(result.data as Map);
    final attemptId = (data['attemptId'] ?? '').toString();
    if (attemptId.isEmpty) {
      throw StateError('No verification attempt was returned.');
    }
    return attemptId;
  }

  static Future<String> verifyLogin({
    required String attemptId,
    required String email,
    required String code,
  }) async {
    final result = await _functions
        .httpsCallable('verifyLoginEmailCode')
        .call(<String, dynamic>{
      'attemptId': attemptId,
      'email': email.trim().toLowerCase(),
      'code': code.trim(),
    });
    final data = Map<String, dynamic>.from(result.data as Map);
    final customToken = (data['customToken'] ?? '').toString();
    if (customToken.isEmpty) {
      throw StateError('No authentication token was returned.');
    }
    return customToken;
  }
}
